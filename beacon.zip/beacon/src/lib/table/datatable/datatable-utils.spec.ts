import { datatableUtils } from './datatable-utils';

type TestType = {
  dateOfBirth: string;
};

describe('Datatable Utils', () => {
  describe('dateStringSort', () => {
    const comparer = datatableUtils.getDateStringComparer<TestType>('dateOfBirth');
    it('is greater than 0 when first date is larger ', () => {
      expect(comparer({ dateOfBirth: '1/1/2020' }, { dateOfBirth: '12/1/2010' })).toBeGreaterThan(0);
    });
    it('is less than 0 when first date is smaller ', () => {
      expect(comparer({ dateOfBirth: '12/1/2010' }, { dateOfBirth: '1/1/2020' })).toBeLessThan(0);
    });

    it('is greater than 0 when second date is undefined ', () => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      expect(comparer({ dateOfBirth: '1/1/2020' }, {} as any)).toBeGreaterThan(0);
    });
    it('is less than 0 when first date is undefined', () => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      expect(comparer({} as any, { dateOfBirth: '1/1/2020' })).toBeLessThan(0);
    });
  });
});
