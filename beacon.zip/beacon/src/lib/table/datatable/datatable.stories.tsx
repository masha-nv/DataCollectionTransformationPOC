import { Meta, Story } from '@storybook/react';
import moment from 'moment';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Label } from '../../forms/label/label';
import { RadioOption } from '../../forms/radio/radio-option';
import { SearchBar } from '../../forms/search-bar/search-bar';
import { Select, SelectOption } from '../../forms/select/select';
import { ISelectOption, SelectSize } from '../../forms/select/select.types';
import { Icon, IconType, IconVariant } from '../../icon/icon';
import { Tooltip } from '../../modals/tooltip/tooltip';
import { StoryBadge } from '../../stories';
import { Documentation, dropdownFromHeadingStyles, dropdownFromHeadingTypes } from '../../stories/documentation';
import { a11yConfig } from '../../stories/story.config';
import { Datatable, DatatableOverflow, datatableUtils, IDatatableColumn } from './datatable';
import './datatable.stories.scss';
import { Button } from '../../button/button';

export default {
  component: Datatable,
  title: 'Core Components/Tables/Datatable',
  parameters: {
    a11y: a11yConfig,
    badges: [StoryBadge.READY],
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const whenToUse = (
  <div>
    <p>
      Datatables should be used where users will need to review large amounts of related information in different
      formats. This is accomplished through features like sorting and filtering. Examples of datatables in ELIS include
      the list of cases on the My Cases page and results from the Case Search.
    </p>
    <p>Generally, use this style if:</p>
    <ul>
      <li>Table rows are selectable or there is an action dropdown menu in the row</li>
      <li>You need to be able to sort columns</li>
      <li>You need to be able to perform bulk actions</li>
      <li>You need to be able to filter data</li>
    </ul>
  </div>
);

const argTypes = {
  headingType: {
    control: dropdownFromHeadingTypes(),
    defaultValue: 'h3',
  },
  headingStyle: {
    control: dropdownFromHeadingStyles(),
  },
};

interface ColorData {
  id: number;
  name: string;
  hex: string;
  updated: string | null;
  created: string;
  childRows?: ColorData[];
}
const colorData: ColorData[] = [
  { id: 1, name: 'plum', hex: '#323a44', updated: '2018-05-11T12:00:00.000Z', created: '11/01/2020' },
  { id: 2, name: 'green', hex: '#0F0', updated: '2018-05-11T12:00:00.000Z', created: '01/10/2021' },
  { id: 3, name: 'lemonchiffon', hex: '#FFFACD', updated: '2018-03-05T12:00:00.000Z', created: '11/25/2020' },
  { id: 4, name: 'yellow', hex: '#FF0', updated: '2018-03-05T12:00:00.000Z', created: '04/12/2005' },
  { id: 5, name: 'tomato', hex: '#FF6347', updated: '2018-03-01T12:00:00.000Z', created: '04/12/2016' },
  { id: 6, name: 'blue', hex: '#00F', updated: '2018-03-01T12:00:00.000Z', created: '10/12/2018' },
  { id: 7, name: 'red', hex: '#F00', updated: '2018-01-02T13:00:00.000Z', created: '05/12/2020' },
  { id: 8, name: 'aqua', hex: '#00FFFF', updated: '2018-01-02T13:00:00.000Z', created: '08/12/2010' },
  { id: 9, name: 'crimson', hex: '#DC143C', updated: '2018-01-01T12:00:00.000Z', created: '08/12/2010' },
  { id: 10, name: 'black', hex: '#000', updated: '2018-01-01T12:00:00.000Z', created: '08/12/2010' },
  { id: 11, name: 'white', hex: '#FFF', updated: null, created: '08/12/2010' },
  { id: 12, name: 'palevioletred', hex: '#DB7093', updated: null, created: '08/12/2010' },
];

const colorDataWithChildData: ColorData[] = [
  {
    id: 1,
    name: 'plum',
    hex: '#323a44',
    updated: '2018-05-11T12:00:00.000Z',
    created: '11/01/2020',
    childRows: [
      { id: 1, name: 'red', hex: '#F00', updated: '2018-01-02T13:00:00.000Z', created: '05/12/2020' },
      { id: 2, name: 'palevioletred', hex: '#DB7093', updated: '2018-03-05T12:00:00.000Z', created: '08/12/2010' },
    ],
  },
  {
    id: 2,
    name: 'green',
    hex: '#0F0',
    updated: '2018-05-11T12:00:00.000Z',
    created: '01/10/2021',
    childRows: [
      { id: 1, name: 'red', hex: '#F00', updated: '2018-01-02T13:00:00.000Z', created: '05/12/2020' },
      { id: 2, name: 'tomato', hex: '#FF6347', updated: '2018-03-01T12:00:00.000Z', created: '04/12/2016' },
    ],
  },
  {
    id: 3,
    name: 'lemonchiffon',
    hex: '#FFFACD',
    updated: '2018-03-05T12:00:00.000Z',
    created: '11/25/2020',
    childRows: [],
  },
  {
    id: 4,
    name: 'yellow',
    hex: '#FF0',
    updated: '2018-03-05T12:00:00.000Z',
    created: '04/12/2005',
    childRows: [{ id: 1, name: 'red', hex: '#F00', updated: '2018-01-02T13:00:00.000Z', created: '05/12/2020' }],
  },
  { id: 5, name: 'tomato', hex: '#FF6347', updated: '2018-03-01T12:00:00.000Z', created: '04/12/2016', childRows: [] },
];
const defaultColumns = [
  {
    name: 'Color Name',
    selector: 'name',
  },
  {
    name: 'HEX Value',
    selector: 'hex',
  },
  {
    name: 'Last Updated Date/Time',
    selector: 'updated',
  },
];
const cell = (row: ColorData) => (
  <div
    style={{
      backgroundColor: row.hex,
      width: '10px',
      height: '10px',
      border: '1px solid black',
    }}
  />
);
export const Example: Story = (props) => {
  const sampleData: ColorData[] = [
    { id: 1, name: 'plum', hex: '#323a44', updated: '2018-05-11T12:00:00.000Z', created: '08/12/2030' },
    { id: 2, name: 'green', hex: '#0F0', updated: '2018-05-11T12:00:00.000Z', created: '08/12/2030' },
    { id: 3, name: 'lemonchiffon', hex: '#FFFACD', updated: '2018-03-05T12:00:00.000Z', created: '08/12/2030' },
    { id: 4, name: 'yellow', hex: '#FF0', updated: '2018-03-05T12:00:00.000Z', created: '08/12/2030' },
    { id: 5, name: 'tomato', hex: '#FF6347', updated: '2018-03-01T12:00:00.000Z', created: '08/12/2030' },
    { id: 6, name: 'blue', hex: '#00F', updated: '2018-03-01T12:00:00.000Z', created: '08/12/2030' },
    { id: 7, name: 'red', hex: '#FF0', updated: '2018-01-02T13:00:00.000Z', created: '08/12/2030' },
    { id: 8, name: 'aqua', hex: '#00FFFF', updated: '2018-01-02T13:00:00.000Z', created: '08/12/2030' },
    { id: 9, name: 'crimson', hex: '#DC143C', updated: '2018-01-01T12:00:00.000Z', created: '08/12/2030' },
    { id: 10, name: 'black', hex: '#000', updated: '2018-01-01T12:00:00.000Z', created: '08/12/2030' },
    { id: 11, name: 'white', hex: '#FFF', updated: null, created: '08/12/2030' },
    { id: 12, name: 'palevioletred', hex: '#DB7093', updated: null, created: '08/12/2030' },
  ];
  const columns: IDatatableColumn<ColorData>[] = [
    {
      id: 'name-column',
      name: 'Color Name',
      selector: 'name',
    },
    {
      id: 'hex',
      name: 'HEX Value',
      selector: 'hex',
    },
    {
      id: 'updated',
      name: 'Last Updated',
      cell: (row: ColorData) => row.updated && moment(row.updated).format('MM/DD/YYYY'),
    },
    {
      id: 'updated-datetime',
      name: 'Last Updated Date/Time',
      selector: 'updated',
      cell: (row: ColorData) => row.updated && moment(row.updated).format('MM/DD/YYYY hh:mm A'),
    },
    {
      id: 'preview',
      name: 'Preview',
      cell: cell,
    },
  ];

  return (
    <Datatable
      id="colors-table"
      title="Colors"
      columns={columns}
      data={sampleData}
      pagination
      selectableRows
      defaultSelected={(row) => ['red', 'green', 'blue'].includes(row.name)}
      headingType={props.headingType}
      headingStyle={props.headingStyle}
      selectAll={props.selectAll}
    />
  );
};
Example.storyName = 'Datatable';
Example.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Datatable"
      description="These tables are used to view and compare large amounts of data and enable users to sort columns."
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
Example.argTypes = argTypes;

/****************************/
/* Conditional Row Variants */
/****************************/

const isGreenish = (colorName: string) => colorName === 'green';
const isBluish = (colorName: string) => ['blue', 'aqua'].some((bluishColor) => colorName === bluishColor);
const isYellowish = (colorName: string) =>
  ['yellow', 'lemonchiffon'].some((yellowishColor) => colorName === yellowishColor);
const isReddish = (colorName: string) =>
  ['red', 'crimson', 'palevioletred', 'tomato'].some((reddishColor) => colorName === reddishColor);

const greenishLabel = 'This is green, yay!';
const bluishLabel = 'Huh, this is blue. This is a long label.';
const yellowishLabel = 'Uh oh, yellow?';
const reddishLabel = 'Oh no, red!';

export const ConditionalRowVariants: Story = (props) => {
  const columns: IDatatableColumn<ColorData>[] = [
    {
      name: 'Color Name',
      cell: (row: ColorData) => {
        let variantIcon;
        if (isGreenish(row.name)) {
          variantIcon = (
            <Tooltip content={greenishLabel}>
              <Icon type={IconType.checkCircle} variant={IconVariant.success} />
            </Tooltip>
          );
        } else if (isBluish(row.name)) {
          variantIcon = (
            <Tooltip content={bluishLabel}>
              <Icon type={IconType.infoCircle} variant={IconVariant.info} />
            </Tooltip>
          );
        } else if (isYellowish(row.name)) {
          variantIcon = (
            <Tooltip content={yellowishLabel}>
              <Icon type={IconType.exclamationTriangle} variant={IconVariant.warning} />
            </Tooltip>
          );
        } else if (isReddish(row.name)) {
          variantIcon = (
            <Tooltip content={reddishLabel}>
              <Icon type={IconType.exclamationCircle} variant={IconVariant.danger} />
            </Tooltip>
          );
        } else {
          variantIcon = <div className="icon-spacer" />;
        }
        return (
          <>
            {variantIcon}
            <span className="after-icon-label">{row.name}</span>
          </>
        );
      },
    },
    {
      name: 'HEX Value',
      selector: 'hex',
      sortable: false,
    },
    {
      name: 'Last Updated Date/Time',
      selector: 'updated',
    },
    {
      name: 'Created Date',
      selector: 'created',
      sortFunction: datatableUtils.getDateStringComparer<ColorData>('created'),
    },
  ];
  const [activeColor, setActiveColor] = useState<ColorData | undefined>(undefined);
  return (
    <>
      <p>
        <b className="mr-2">Active color:</b>
        {activeColor && <code>{activeColor.name}</code>}
        {!activeColor && 'None'}
      </p>

      <Datatable
        id="colors-with-row-variants-table"
        title="Colors with Row Variants"
        columns={columns}
        data={colorData}
        rowVariantConditions={{
          active: (row) => row === activeColor,
          success: { label: greenishLabel, condition: (row) => isGreenish(row.name) },
          info: { label: bluishLabel, condition: (row) => isBluish(row.name) },
          warning: { label: yellowishLabel, condition: (row) => isYellowish(row.name) },
          danger: { label: reddishLabel, condition: (row) => isReddish(row.name) },
        }}
        onRowClicked={(row: ColorData) => {
          if (row === activeColor) {
            setActiveColor(undefined);
          } else {
            setActiveColor(row);
          }
        }}
        headingType={props.headingType}
        headingStyle={props.headingStyle}
        pagination={false}
        showLegend={props.showLegend}
      />
    </>
  );
};

const conditionalRowVariantsDescription = (
  <>
    <p>
      Datatables allow for conditions to be defined under which rows will be rendered as one of four standard variants;
      success, information, warning and danger. These conditions are defined by using the{' '}
      <code>rowVariantConditions</code> property, which accepts an object containing a <code>RowVariantCondition</code>{' '}
      for any of the four variants. Each <code>RowVariantCondition</code> must contain two fields:
    </p>
    <ul>
      <li>
        <code>label</code>: the label to be displayed for this variant
      </li>
      <li>
        <code>condition</code>: a function mapping a <code>row</code> value to a <code>boolean</code> representing
        whether the condition should apply to the given <code>row</code>
      </li>
    </ul>
    <p>
      Defining any of these variant conditions will add a legend popover to the Datatable's header with that variant's
      icon and label.
    </p>
    <p>
      When using these variants it is the responsibility of the developer to ensure that a value reflecting the state
      depicted by the variant is added as a column, and that the column includes an appropriately styled{' '}
      <code>Icon</code> to match the variant, with a <code>Tooltip</code> for the variant's label.
    </p>
  </>
);
ConditionalRowVariants.storyName = 'Conditional Datatable Row Variants';
ConditionalRowVariants.decorators = [
  (ConditionalRowVariantsStory: Story) => (
    <Documentation
      name="Conditional row variants"
      whenToUse={whenToUse}
      description={conditionalRowVariantsDescription}
    >
      <ConditionalRowVariantsStory />
    </Documentation>
  ),
];
ConditionalRowVariants.argTypes = argTypes;

/***************************/
/* Conditional Row Styling */
/***************************/
interface INotification {
  task: string;
  receiptNumber: string;
  isRead: boolean;
}
export const ConditionalRowStyling: Story = (props) => {
  const columns: IDatatableColumn<INotification>[] = [
    {
      name: 'Task Name',
      selector: 'task',
    },
    {
      name: 'Receipt Number',
      selector: 'receiptNumber',
    },
    {
      name: 'Read',
      selector: 'isRead',
      cell: (row) => (row.isRead ? 'Yes' : 'No'),
    },
  ];

  const notificationData: INotification[] = [
    { task: 'Manual Name Harvesting', receiptNumber: 'IOE0123456789', isRead: false },
    { task: 'Verify A-Number', receiptNumber: 'IOE0534283433', isRead: false },
    { task: 'Conduct Interview', receiptNumber: 'IOE7452343355', isRead: false },
    { task: 'Resolve Address Flags', receiptNumber: 'IOE8856310065', isRead: true },
    { task: 'Initiate FBI Namecheck', receiptNumber: 'IOE1222112356', isRead: true },
  ];

  return (
    <>
      <p>
        Default Example: Unread notifications have a blue left border and white background. Read notifiations have a
        gray background.'.
      </p>
      <Datatable
        id="notifications-table"
        title="Notifications"
        columns={columns}
        data={notificationData}
        headingType={props.headingType}
        headingStyle={props.headingStyle}
        defaultSortField={props.defaultSortField}
        defaultSortAsc={props.defaultSortAsc}
        conditionalRowStyles={props.conditionalRowStyles}
        zebraStriping={false}
      />
    </>
  );
};
ConditionalRowStyling.storyName = 'Conditional Row Styling';
ConditionalRowStyling.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Conditional Row Styling"
      description={
        <>
          <p>
            Datatables can be provided with an array of condition-style pairs through the{' '}
            <code>conditionalRowStyles</code> prop which applies the <code>style</code> to a <code>row</code> when
            provided conditions are met for the aforementioned <code>row</code>.
          </p>
          <p>Each condition-style pair object consists of the following:</p>
          <ul>
            <li>
              <code>when</code>: a function mapping a <code>row</code> value to a <code>boolean</code> representing
              whether the condition should apply to the given <code>row</code>
            </li>
            <li>
              <code>style</code>:an object containg css key-value pairs to apply to the <code>row</code>
            </li>
          </ul>
          <p>
            Note that this prop is applied after <em>rowVariantConditions</em> and will override any conflicting styles
            applied by <code>rowVariantConditions</code> in the case that a row has overlapping conditions.
          </p>
        </>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];

ConditionalRowStyling.argTypes = {
  ...argTypes,
  conditionalRowStyles: {
    control: {
      type: 'select',
      labels: {
        first: 'Active: blue left border, inactive: gray',
      },
    },
    options: ['first'],
    mapping: {
      first: [
        { when: (row: INotification) => !row.isRead, style: { background: 'white', borderLeft: '5px solid #0071BB' } },
        { when: (row: INotification) => row.isRead, style: { background: 'rgba(250,250,250,1)', paddingLeft: '5px' } },
      ],
    },
    defaultValue: [
      { when: (row: INotification) => !row.isRead, style: { background: 'white', borderLeft: '5px solid #0071BB' } },
      { when: (row: INotification) => row.isRead, style: { background: 'rgba(250,250,250,1)', paddingLeft: '5px' } },
    ],
  },
};

/******************/
/* Zebra Striping */
/******************/

export const ZebraStripingAndHoverableRows: Story = (props) => {
  const columns: IDatatableColumn<ColorData>[] = [
    {
      name: 'Color Name',
      selector: 'name',
    },
    {
      name: 'HEX Value',
      selector: 'hex',
      sortable: false,
    },
    {
      name: 'Last Updated Date/Time',
      selector: 'updated',
    },
    {
      name: 'Created Date',
      selector: 'created',
      sortFunction: datatableUtils.getDateStringComparer<ColorData>('created'),
    },
  ];
  const [activeColor, setActiveColor] = useState<ColorData | undefined>(undefined);
  return (
    <Datatable
      id="zebra-striped-colors-table"
      title="Zebra Striping and Hoverable Rows"
      zebraStriping
      hoverableRows
      columns={columns}
      data={colorData}
      rowVariantConditions={{
        active: (row) => row === activeColor,
      }}
      onRowClicked={(row: ColorData) => setActiveColor(row === activeColor ? undefined : row)}
      headingType={props.headingType}
      headingStyle={props.headingStyle}
    />
  );
};

const zebraStripingDescription = (
  <p>
    Complex datatables (i.e. with many rows or columns) may be easier to read when enabling zebra striping (alternating
    row background colors) by using the <code>zebraStriping</code> parameter or hoverable rows using the{' '}
    <code>hoverableRows</code> parameter. <code>zebraStriping</code> and <code>hoverableRows</code> are enabled by
    default.
  </p>
);
ZebraStripingAndHoverableRows.storyName = 'Zebra Striping and Hoverable Rows';
ZebraStripingAndHoverableRows.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Zebra Striping and Hoverable Rows"
      whenToUse={whenToUse}
      description={zebraStripingDescription}
    >
      <ComponentStory />
    </Documentation>
  ),
];
ConditionalRowVariants.argTypes = argTypes;

/******************/
/*   Scrollable   */
/******************/

export const Scrollable: Story = (props) => {
  const columns: IDatatableColumn<ColorData>[] = [
    {
      name: 'Color Name',
      selector: 'name',
    },
    {
      name: 'HEX Value',
      selector: 'hex',
      sortable: false,
    },
    {
      name: 'Last Updated Date/Time',
      selector: 'updated',
    },
    {
      name: 'Created Date',
      selector: 'created',
      sortFunction: datatableUtils.getDateStringComparer<ColorData>('created'),
    },
  ];
  const [activeColor, setActiveColor] = useState<ColorData | undefined>(undefined);
  return (
    <div style={{ height: '100%' }}>
      <Datatable
        id="scrollable-colors-table"
        title="Scrollable"
        zebraStriping
        hoverableRows
        scrollable={'200px'}
        columns={columns}
        data={colorData}
        rowVariantConditions={{
          active: (row) => row === activeColor,
        }}
        onRowClicked={(row: ColorData) => setActiveColor(row === activeColor ? undefined : row)}
        headingType={props.headingType}
        headingStyle={props.headingStyle}
        pagination={false}
      />
    </div>
  );
};

const scrollableDescription = (
  <p>
    Enables a sticky header with a scrollable table underneath. Use the `scrollable` prop to set the max height of the
    table body.
  </p>
);
Scrollable.storyName = 'Scrollable';
Scrollable.decorators = [
  (ComponentStory: Story) => (
    <Documentation name="Scrollable" whenToUse={whenToUse} description={scrollableDescription}>
      <ComponentStory />
    </Documentation>
  ),
];

export const CellOverflow: Story = (props) => {
  const data = [
    {
      id: 13,
      data: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Cursus in hac habitasse platea dictumst quisque sagittis purus sit. Cursus turpis massa tincidunt dui ut ornare lectus sit.',
    },
  ];
  const columns: IDatatableColumn<typeof data[number]>[] = [
    {
      name: 'Default',
      selector: 'data',
    },
    {
      name: 'Overflow wrap',
      selector: 'data',
      overflow: DatatableOverflow.wrap,
    },
    {
      name: 'Overflow hide',
      selector: 'data',
      overflow: DatatableOverflow.hide,
      maxWidth: '250px',
    },
    {
      name: 'Overflow ellipsis',
      selector: 'data',
      overflow: DatatableOverflow.ellipsis,
      maxWidth: '250px',
    },
    {
      name: 'Custom',
      selector: 'data',
      cell: (row) => `${row.data.slice(0, 150)}...`,
    },
  ];

  return (
    <Datatable
      id="overflow-table"
      title="Data"
      columns={columns}
      data={data}
      pagination
      headingType={props.headingType}
      headingStyle={props.headingStyle}
    />
  );
};
CellOverflow.storyName = 'Datatables with Cell Overflow';
CellOverflow.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Cell Overflow"
      whenToUse={whenToUse}
      description={
        <div>
          <p>
            By default, cells in the datatable with wrap when they overflow. However, this can be controlled with the{' '}
            <code>column.overflow</code> property.
          </p>
          <p>
            If the hide option (<code>DatatableOverflow.hide</code>) is used, the cells in that column will hide or not
            display overflowed text. If the ellipsis option (<code>DatatableOverflow.ellipsis</code>) is used, then
            cells in the column will replace overflowed text with an ellipsis (...).
          </p>
          <p>
            If either of those options are used, then developers <strong>must</strong> specify a{' '}
            <code>column.width</code> or <code>column.maxWidth</code> so that cells have a breakpoint for whenever they
            should overflow.
          </p>
          <p>
            Columns can also be configured to format their content themselves with the <code>column.cell</code>{' '}
            property.
          </p>
        </div>
      }
    >
      <ComponentStory />
    </Documentation>
  ),
];
CellOverflow.argTypes = argTypes;

export const CustomCellContent: Story = (props) => {
  const columns: IDatatableColumn<ColorData>[] = [
    {
      name: 'Color Name',
      selector: 'name',
    },
    {
      name: 'HEX Value',
      selector: 'hex',
    },
    {
      name: 'Last Updated',
      cell: (row: ColorData) => row.updated && moment(row.updated).format('MM/DD/YYYY'),
    },
    {
      name: 'Last Updated Date/Time',
      selector: 'updated',
      cell: (row: ColorData) => row.updated && moment(row.updated).format('MM/DD/YYYY hh:mm A'),
    },
    {
      name: 'Preview',
      cell: cell,
    },
  ];
  return (
    <Datatable
      id="colors-table"
      title="Colors"
      columns={columns}
      data={colorData}
      pagination
      headingType={props.headingType}
      headingStyle={props.headingStyle}
    />
  );
};
CustomCellContent.storyName = 'Datatables with Custom Cell Content';
CustomCellContent.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Custom Cell Content"
      description={
        <p>
          Datatables can render custom content for cells using the <code>cell</code> property.
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
CustomCellContent.argTypes = argTypes;

const ExpandableRowsComponent = (props: { data?: unknown }) => (
  <div>
    <pre>{JSON.stringify(props.data, null, 2)}</pre>
  </div>
);
export const ExpandableRows: Story = (props) => {
  return (
    <Datatable
      id="colors-table"
      title="Colors"
      columns={defaultColumns}
      data={colorData}
      pagination
      expandableRows
      expandableRowsComponent={<ExpandableRowsComponent />}
      headingType={props.headingType}
      headingStyle={props.headingStyle}
    />
  );
};
ExpandableRows.storyName = 'Datatables with Expandable Rows';
const whenToUseExpandable = (
  <>
    {whenToUse}
    <p>
      <strong>Expandable rows </strong>are useful when there is a lot of information in table rows, but it would also be
      helpful for users to be able to scan the headings before deciding where to drill down into the accordions for more
      information.
    </p>
  </>
);

ExpandableRows.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Expandable Rows"
      description={
        <p>
          Rows in the datatable become expandable when the <code>expandableRows</code> property is enabled. When
          enabled, clicking the expand/collapse button will expand or collapse a row (i.e. like an accordion). The{' '}
          <code>expandableRowsComponent</code> property is used to customize the the contents of the expanded secton.
        </p>
      }
      whenToUse={whenToUseExpandable}
    >
      <ComponentStory />
    </Documentation>
  ),
];
ExpandableRows.argTypes = argTypes;

/**
 * Expandable rows with child row data
 */
export const ExpandableRowsWithChildData: Story = (props) => {
  return (
    <Datatable
      id="colors-table"
      title="Colors"
      columns={defaultColumns}
      data={colorDataWithChildData}
      pagination
      headingType={props.headingType}
      headingStyle={props.headingStyle}
      showChildRowData
      childRowDataField="childRows"
    />
  );
};
ExpandableRowsWithChildData.storyName = 'Datatables with Expandable Rows and Child Data';
const whenToUseExpandableRowsWithChildData = (
  <>
    {whenToUse}
    <p>
      <strong>Expandable rows with child data </strong>are useful for displaying additional information (e.g. history),
      as a child row(s) for each parent row.
    </p>
  </>
);

ExpandableRowsWithChildData.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Expandable Rows With Child Data"
      description={
        <p>
          Child rows become enabled for the datatable when the <code>showChildRowData</code> property is enabled. The
          value of <code>childRowDataField</code>, which pertains to the child data for each element in data[], is used
          to display the child data in the expanded rows.
          <br></br>
          <code>Caution:</code> You cannot enable <code>expandableRows</code> with <code>showChildRowData</code>. This
          will cause an exception.
        </p>
      }
      whenToUse={whenToUseExpandableRowsWithChildData}
    >
      <ComponentStory />
    </Documentation>
  ),
];
ExpandableRowsWithChildData.argTypes = argTypes;

/**
 * Multi-Row selection
 */
export const MultiRowSelection: Story = (props) => {
  const columns: IDatatableColumn<ColorData>[] = [
    {
      name: 'Color Name',
      selector: 'name',
    },
    {
      name: 'HEX Value',
      selector: 'hex',
    },
    {
      name: 'Last Updated Date/Time',
      selector: 'updated',
    },
  ];

  const [selectedRows, setSelectedRows] = useState([]);

  const selectableRowDisabled = (row: ColorData) => row.name === 'red';

  const onSelectedRowsChangeCallback = useCallback(({ selectedRowValues }) => {
    setSelectedRows(selectedRowValues);
  }, []);

  return (
    <>
      <Datatable
        id="colors-table"
        title="Colors"
        columns={columns}
        data={colorData}
        pagination
        selectableRows
        selectableTitleField="name"
        selectableRowDisabled={selectableRowDisabled}
        onSelectedRowsChange={onSelectedRowsChangeCallback}
        headingType={props.headingType}
        headingStyle={props.headingStyle}
      />
      <span>
        <strong>Selected Rows: </strong>
        {`${JSON.stringify(selectedRows)}`}
      </span>
    </>
  );
};

const multiRowDescription = (
  <p>
    Rows can made selectable with the <code>selectableRows</code> property. When enabled, checking the checkbox in the
    first column will select the corresponding row(s). Events for changes in selection can be listened to with the{' '}
    <code>onSelectedRowsChange</code> callback.
  </p>
);
MultiRowSelection.storyName = 'Datatables with Multiple Row Selection';
MultiRowSelection.decorators = [
  (ComponentStory: Story) => (
    <Documentation name="Multiple Row Selections" whenToUse={whenToUse} description={multiRowDescription}>
      <ComponentStory />
    </Documentation>
  ),
];
MultiRowSelection.argTypes = argTypes;

const fetchData = async (page: number, itemsPerPage: number) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(colorData.slice((page - 1) * itemsPerPage, page * itemsPerPage));
    }, 1500);
  }) as Promise<ColorData[]>;
};

const fetchDataLength = () => colorData.length;
export const ServerSidePagination: Story = (props) => {
  const columns: IDatatableColumn<ColorData>[] = [
    {
      name: 'Color Name',
      selector: 'name',
    },
    {
      name: 'HEX Value',
      selector: 'hex',
    },
    {
      name: 'Last Updated',
      selector: 'updated',
      cell: (row: ColorData) => row.updated && moment(row.updated).format('MM/DD/YYYY'),
    },
  ];

  const [fetchedData, setFetchedData] = useState<ColorData[]>([]);
  const [totalRows, setTotalRows] = useState(0);
  const [perPage, setPerPage] = useState(10);
  const [loading, setLoading] = useState(false);

  const handlePageChange = async (page: number) => {
    setLoading(true);
    const newData = await fetchData(page, perPage);
    setFetchedData(newData);
    setLoading(false);
  };

  const handlePerRowsChange = async (newPerPage: number, page: number) => {
    setLoading(true);

    const newData = await fetchData(page, newPerPage);
    setFetchedData(newData);
    setPerPage(newPerPage);
    setLoading(false);
  };

  useEffect(() => {
    const fetchInitialData = async () => {
      setLoading(true);
      const newData = await fetchData(1, 10);
      const dataLength = fetchDataLength();
      setFetchedData(newData);
      setTotalRows(dataLength);
      setLoading(false);
    };
    fetchInitialData();
  }, []);

  return (
    <Datatable
      id="colors-table"
      title="Colors"
      columns={columns}
      data={fetchedData}
      pagination
      paginationServer
      progressPending={loading}
      paginationPerPage={perPage}
      paginationTotalRows={totalRows}
      selectableRows
      onChangeRowsPerPage={handlePerRowsChange}
      onChangePage={handlePageChange}
      headingType={props.headingType}
      headingStyle={props.headingStyle}
      selectAll={props.selectAll}
    />
  );
};
ServerSidePagination.storyName = 'Datatables with Server Side Pagination';
ServerSidePagination.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Server Side Pagination"
      description="The datatable can also be customized to provide server-side pagination. This feature changes all UI data
      processing to rely on server-side processing. The basic idea behind this feature is that it allows the datatable
      to ask the server for 1 specfic page at a time."
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
ServerSidePagination.argTypes = argTypes;

/***********/
/* Sorting */
/***********/
export const SingleRowSelection: Story = (props) => {
  const [selectedRow, setSelectedRow] = useState<ColorData>();

  const RadioButton = ({ row }: { row: ColorData }) => {
    const onChangeCallback = useCallback(() => setSelectedRow(row), [row]);
    return (
      <RadioOption id={`select-row-${row.name}`} name="test" onChange={onChangeCallback} hiddenLabel>
        {`Select ${row.name}`}
      </RadioOption>
    );
  };

  const columns: IDatatableColumn<ColorData>[] = useMemo(
    () => [
      {
        id: 'row-selection',
        name: <div className="sr-only">Row Selection</div>,
        cell: (row) => <RadioButton row={row}></RadioButton>,
        width: '50px',
      },
      {
        name: 'Color Name',
        selector: 'name',
      },
      {
        name: 'HEX Value',
        selector: 'hex',
      },
      {
        name: 'Last Updated Date/Time',
        selector: 'updated',
      },
    ],
    []
  );

  return (
    <>
      <Datatable
        id="colors-table"
        title="Colors"
        columns={columns}
        data={colorData}
        pagination
        headingType={props.headingType}
        headingStyle={props.headingStyle}
      />
      <span>
        <strong>Selected Row: </strong>
        {JSON.stringify(selectedRow)}
      </span>
    </>
  );
};
SingleRowSelection.storyName = 'Datatables with Single Row Selection';
SingleRowSelection.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Single Row Selections"
      whenToUse={whenToUse}
      description="Single row selections can be accomplished by adding a column that uses a radio button as the custom content."
      accessibilityConsiderations={
        <div>
          <p>
            Each of the custom radio buttons should that an accessible friendly title or label associated to it, even if
            not displayed (e.g. <code>title</code> attribute) .
          </p>

          <p>
            The <code>name</code> for the selection column should include <code>.sr-only</code> text so that
            screenreaders know what the column is for. Likewise, the selection column should have an <code>id</code> so
            that the the column heading, which will use the id in these scenarios, is a meaningful string instead of the
            default, autogenerated hash.
          </p>
        </div>
      }
    >
      <ComponentStory />
    </Documentation>
  ),
];
SingleRowSelection.argTypes = argTypes;

export const Sorting: Story = (props) => {
  const columns: IDatatableColumn<ColorData>[] = [
    {
      name: 'Color Name',
      selector: 'name',
    },
    {
      name: 'HEX Value',
      selector: 'hex',
      sortable: false,
    },
    {
      name: 'Last Updated Date/Time',
      selector: 'updated',
    },
    {
      name: 'Created Date',
      selector: 'created',
      sortFunction: datatableUtils.getDateStringComparer<ColorData>('created'),
    },
  ];
  return (
    <Datatable
      id="colors-table"
      title="Colors"
      columns={columns}
      data={colorData}
      pagination
      headingType={props.headingType}
      headingStyle={props.headingStyle}
    />
  );
};

const sortingDescription = (
  <p>
    Columns with the <code>selector</code> property are, by default, sortable. When sortable, clicking the header cell
    will sort the rows by the ascending or descending order of the selected data. Columns can be made not sortable by
    setting the <code>sortable</code> property as false.
  </p>
);
Sorting.storyName = 'Datatables with Sorting and Ordering';
Sorting.decorators = [
  (ComponentStory: Story) => (
    <Documentation name="Sorting/Ordering columns" whenToUse={whenToUse} description={sortingDescription}>
      <ComponentStory />
    </Documentation>
  ),
];
Sorting.argTypes = argTypes;

export const FilteringAtHeader: Story = (props) => {
  const [filterText, setFilterText] = React.useState('');
  const filteredData = colorData.filter((item) => item.name.includes(filterText));
  const onChangeCallback = (selection: ISelectOption) => setFilterText(selection.value as string);

  const actions = [
    <>
      <Label htmlFor="select-filter" className="no-margin-label">
        Color Name:
      </Label>
      <Select
        id="select-filter"
        name="select-filter"
        size={SelectSize.small}
        onChange={(_, selection) => onChangeCallback(selection)}
      >
        {colorData.map((entry) => {
          return <SelectOption value={entry.name}>{entry.name}</SelectOption>;
        })}
      </Select>
    </>,
  ];

  return (
    <Datatable
      id="colors-table"
      title="Colors"
      columns={defaultColumns}
      data={filteredData}
      pagination
      expandableRows
      expandableRowsComponent={<ExpandableRowsComponent />}
      actions={actions}
      headingType={props.headingType}
      headingStyle={props.headingStyle}
    />
  );
};
FilteringAtHeader.storyName = 'Filtering Datatables at Header';
const filteringAtHeaderDescription = (
  <p>
    Filtering data can be achieved by manually modifying or filtering the <code>data</code> that is supplied to the
    datatable as a prop. Custom controls for manipulating the data can be defined in the header of the datatable via the{' '}
    <code>actions</code> properties.
  </p>
);

FilteringAtHeader.decorators = [
  (ComponentStory: Story) => (
    <Documentation name="Filtering input" whenToUse={whenToUse} description={filteringAtHeaderDescription}>
      <ComponentStory />
    </Documentation>
  ),
];
FilteringAtHeader.argTypes = argTypes;

export const FilteringAtSubheader: Story = (props) => {
  const [filterText, setFilterText] = React.useState('');
  const filteredData = colorData.filter((item) => item.name.includes(filterText));

  const subHeaderComponent = (
    <div className="d-flex justify-content-end">
      <div className="form-inline">
        <Label htmlFor="search-filter" className="mr-2">
          Search by Color:
        </Label>
        <SearchBar id="search-filter" onChange={(_, query) => setFilterText(query)} hideResults allowEmpty />
      </div>
    </div>
  );

  return (
    <Datatable
      id="colors-table"
      title="Colors"
      columns={defaultColumns}
      data={filteredData}
      pagination
      subHeader
      subHeaderComponent={subHeaderComponent}
      headingType={props.headingType}
      headingStyle={props.headingStyle}
    />
  );
};
FilteringAtSubheader.storyName = 'Filtering Datatables at Subheader';
const filteringDescription = (
  <p>
    Filtering data can be achieved by manually modifying or filtering the <code>data</code> that is supplied to the
    datatable as a prop. Custom controls for manipulating the data can be defined in the subheader of the datatable via
    the <code>subHeader</code> and <code>subHeaderComponent</code> properties.
  </p>
);

FilteringAtSubheader.decorators = [
  (ComponentStory: Story) => (
    <Documentation name="Filtering input" whenToUse={whenToUse} description={filteringDescription}>
      <ComponentStory />
    </Documentation>
  ),
];
FilteringAtSubheader.argTypes = argTypes;

export const CustomRowsPerPageOptions: Story = (props) => {
  const { paginationRowsPerPageOptions: rowsPerPageOptsProp } = props;
  const defaultRowsPerPageOptions = [10, 15, 20, 25, 30];
  const columns: IDatatableColumn<ColorData>[] = [
    {
      name: 'Color Name',
      selector: 'name',
    },
    {
      name: 'HEX Value',
      selector: 'hex',
    },
    {
      name: 'Last Updated Date/Time',
      selector: 'updated',
    },
  ];
  const rowsPerPageOptions =
    Array.isArray(rowsPerPageOptsProp) && rowsPerPageOptsProp.length > 0
      ? props.paginationRowsPerPageOptions
      : defaultRowsPerPageOptions;
  return (
    <Datatable
      id="colors-table"
      title="Colors"
      columns={columns}
      data={colorData}
      pagination
      paginationRowsPerPageOptions={rowsPerPageOptions}
      headingType={props.headingType}
      headingStyle={props.headingStyle}
    />
  );
};
CustomRowsPerPageOptions.storyName = 'Datatables with Custom Rows Per Page Options';
CustomRowsPerPageOptions.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Custom Rows per Page Options"
      description={
        <p>
          Paginated datatables come with default rows per page options of [10,15,20,25,30]. The options can be replaced
          using the <code>paginationRowsPerPageOptions</code> prop.
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
CustomRowsPerPageOptions.argTypes = {
  ...argTypes,
  paginationRowsPerPageOptions: {
    control: 'object',
    defaultValue: [],
  },
};

export const DefaultSorting: Story = (props) => {
  const columns: IDatatableColumn<ColorData>[] = [
    {
      name: 'Color Name',
      selector: 'name',
    },
    {
      name: 'HEX Value',
      selector: 'hex',
    },
    {
      name: 'Last Updated Date/Time',
      selector: 'updated',
    },
  ];
  return (
    <Datatable
      id="colors-table"
      title="Colors"
      columns={columns}
      data={colorData}
      headingType={props.headingType}
      headingStyle={props.headingStyle}
      defaultSortField={props.defaultSortField}
      defaultSortAsc={props.defaultSortAsc}
      onSort={props.onSort}
    />
  );
};
DefaultSorting.storyName = 'Default sorting and onSort callback';
DefaultSorting.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Default sorting and onSort callback"
      description={
        <p>
          Datatables can be provided with a default sort column and sort order on initial render. The{' '}
          <code>onSort</code> prop can be provided as a callback that is executed whenever sorting occurs.
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
DefaultSorting.argTypes = {
  ...argTypes,
  defaultSortField: { control: 'text', defaultValue: 'name' },
  defaultSortAsc: { control: 'boolean', defaultValue: true },
  onSort: {
    control: 'object',
    defaultValue: (column: IDatatableColumn<ColorData>, sortDirection: string) => {
      alert(`Sorting ${column.name} in ${sortDirection} order.`);
    },
  },
};

export const OnRowClickedCallback: Story = (props) => {
  const columns: IDatatableColumn<ColorData>[] = [
    {
      name: 'Color Name',
      selector: 'name',
    },
    {
      name: 'HEX Value',
      selector: 'hex',
    },
    {
      name: 'Last Updated Date/Time',
      selector: 'updated',
    },
  ];
  const [lastClicked, setLastClicked] = useState<string | undefined>(undefined);
  return (
    <>
      <p>
        <b>Last row clicked:</b> {lastClicked ?? 'N/A'}
      </p>
      <Datatable
        id="colors-table"
        title="Colors"
        columns={columns}
        data={colorData}
        headingType={props.headingType}
        headingStyle={props.headingStyle}
        defaultSortField={props.defaultSortField}
        defaultSortAsc={props.defaultSortAsc}
        onRowClicked={(row: ColorData) => setLastClicked(row.name)}
      />
    </>
  );
};
OnRowClickedCallback.storyName = 'Row Clicked Callback';
OnRowClickedCallback.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Row Clicked Callback"
      description={
        <>
          <p>
            Datatables can be provided with a callback via the <code>onRowClicked</code> prop which is executed when a
            row is clicked on.
          </p>
          <p>
            Note that this should not be used in place of <em>selected</em> rows, i.e. rows that have checkboxes (to
            support selection of multiple rows) or radio buttons (to support selection of single rows).
          </p>
        </>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
OnRowClickedCallback.argTypes = {
  ...argTypes,
  defaultSortField: { control: 'text', defaultValue: 'name' },
  defaultSortAsc: { control: 'boolean', defaultValue: true },
  onSort: {
    control: 'object',
    defaultValue: (column: IDatatableColumn<ColorData>, sortDirection: string) => {
      alert(`Sorting ${column.name} in ${sortDirection} order.`);
    },
  },
};

export const Compact: Story = (props) => {
  return (
    <Datatable
      id="colors-table"
      title="Colors"
      columns={defaultColumns}
      data={colorData}
      pagination
      selectableRows
      headingType={props.headingType}
      headingStyle={props.headingStyle}
      compact
    />
  );
};
Compact.storyName = 'Compact Table';
Compact.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Compact Datatable"
      description={
        <p>
          This verson uses styles for a more compact datatable by using the <code>compact</code> parameter.
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
Compact.argTypes = argTypes;

export const OmittingRow: Story = (props) => {
  const [hideColumn, setHideColumn] = useState<boolean>(true);
  return (
    <div>
      <Button
        id="show-omitted-btn"
        onClick={() => {
          setHideColumn((columnState) => !columnState);
        }}
      >
        {hideColumn ? 'Show' : 'Hide'} Times
      </Button>
      <Datatable
        id="colors-table"
        title="Colors"
        columns={[
          {
            name: 'Color Name',
            selector: 'name',
          },
          {
            name: 'HEX Value',
            selector: 'hex',
          },
          {
            name: 'Last Updated Date/Time',
            selector: 'updated',
            omit: hideColumn,
          },
        ]}
        headingType={props.headingType}
        headingStyle={props.headingStyle}
        data={colorData}
      />
    </div>
  );
};
OmittingRow.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Datatable with hideable row"
      description={
        <p>
          This verson uses the <code>omit</code> keyword in columns to hide a column.
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
OmittingRow.argTypes = argTypes;

export const SelectAll: Story = (props) => {
  const [selectAll, setSelectAllState] = useState<boolean>(false);
  const [clearSelectedRows, setClearSelectedRows] = useState<boolean>(false);

  const sampleData: ColorData[] = [
    { id: 1, name: 'plum', hex: '#323a44', updated: '2018-05-11T12:00:00.000Z', created: '08/12/2030' },
    { id: 2, name: 'green', hex: '#0F0', updated: '2018-05-11T12:00:00.000Z', created: '08/12/2030' },
    { id: 3, name: 'lemonchiffon', hex: '#FFFACD', updated: '2018-03-05T12:00:00.000Z', created: '08/12/2030' },
    { id: 4, name: 'yellow', hex: '#FF0', updated: '2018-03-05T12:00:00.000Z', created: '08/12/2030' },
    { id: 5, name: 'tomato', hex: '#FF6347', updated: '2018-03-01T12:00:00.000Z', created: '08/12/2030' },
    { id: 6, name: 'blue', hex: '#00F', updated: '2018-03-01T12:00:00.000Z', created: '08/12/2030' },
    { id: 7, name: 'red', hex: '#FF0', updated: '2018-01-02T13:00:00.000Z', created: '08/12/2030' },
    { id: 8, name: 'aqua', hex: '#00FFFF', updated: '2018-01-02T13:00:00.000Z', created: '08/12/2030' },
    { id: 9, name: 'crimson', hex: '#DC143C', updated: '2018-01-01T12:00:00.000Z', created: '08/12/2030' },
    { id: 10, name: 'black', hex: '#000', updated: '2018-01-01T12:00:00.000Z', created: '08/12/2030' },
    { id: 11, name: 'white', hex: '#FFF', updated: null, created: '08/12/2030' },
    { id: 12, name: 'palevioletred', hex: '#DB7093', updated: null, created: '08/12/2030' },
  ];
  const columns: IDatatableColumn<ColorData>[] = [
    {
      id: 'name-column',
      name: 'Color Name',
      selector: 'name',
    },
    {
      id: 'hex',
      name: 'HEX Value',
      selector: 'hex',
    },
    {
      id: 'updated',
      name: 'Last Updated',
      cell: (row: ColorData) => row.updated && moment(row.updated).format('MM/DD/YYYY'),
    },
    {
      id: 'updated-datetime',
      name: 'Last Updated Date/Time',
      selector: 'updated',
      cell: (row: ColorData) => row.updated && moment(row.updated).format('MM/DD/YYYY hh:mm A'),
    },
    {
      id: 'preview',
      name: 'Preview',
      cell: cell,
    },
  ];

  return (
    <div>
      <section style={{ paddingTop: 5 }}>
        <h2>Example with useState</h2>
        <div style={{ display: 'flex', gap: 4 }}>
          <Button
            id="show-select-all-btn"
            onClick={() => {
              setSelectAllState(true);
              setClearSelectedRows(false);
            }}
          >
            Select All
          </Button>
          <Button
            id="show-select-all-btn"
            onClick={() => {
              setSelectAllState(false);
              setClearSelectedRows(true);
            }}
          >
            Deselect All
          </Button>
        </div>
      </section>
      <Datatable
        id="colors-table"
        title="Colors"
        columns={columns}
        data={sampleData}
        selectableRowDisabled={(row: ColorData) => row.id === 1}
        pagination
        selectableRows
        headingType={props.headingType}
        headingStyle={props.headingStyle}
        selectAll={selectAll}
        clearSelectedRows={clearSelectedRows}
      />
      <Datatable
        id="colors-table"
        title="colors"
        columns={columns}
        data={sampleData}
        pagination
        selectableRows
        headingType={props.headingType}
        headingStyle={props.headingStyle}
        selectAll={selectAll}
      />
    </div>
  );
};
SelectAll.storyName = 'Select All';
SelectAll.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Select All"
      description={
        <p>
          This automatically selects all entries by using the <code>selectAll</code> parameter.
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
SelectAll.argTypes = argTypes;
