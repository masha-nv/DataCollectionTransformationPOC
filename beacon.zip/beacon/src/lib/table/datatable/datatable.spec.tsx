import React from 'react';
import { fireEvent, screen, render } from '@testing-library/react';
import { Datatable } from './datatable';
import { act } from 'react-dom/test-utils';
import userEvent from '@testing-library/user-event';

describe('Datatable', () => {
  const basicColumns = [
    {
      id: 'name',
      name: 'Color Name',
      selector: 'name',
      sortable: true,
    },
    {
      id: 'hex',
      name: 'HEX Value',
      selector: 'hex',
      sortable: true,
    },
  ];
  const basicData = [
    { id: 1, name: 'plum', hex: '#323a44' },
    { id: 2, name: 'green', hex: '#0F0' },
    { id: 3, name: 'lemonchiffon', hex: '#FFFACD' },
  ];

  test('wraps the uscis-react-datatable', () => {
    const { baseElement, container } = render(
      <Datatable
        id="colors-table"
        title="Colors"
        columns={basicColumns}
        data={basicData}
        zebraStriping={false}
        hoverableRows={false}
      />
    );

    expect(baseElement).toMatchSnapshot();
    expect(container.getElementsByClassName('beacon-datatable-zebra-striped').length).toEqual(0);
    expect(container.getElementsByClassName('beacon-datatable-hover').length).toEqual(0);
  });

  test('applies zebra striping', () => {
    const { baseElement, container } = render(
      <Datatable id="colors-table" title="Colors" columns={basicColumns} data={basicData} hoverableRows={false} />
    );

    expect(baseElement).toMatchSnapshot();
    expect(container.getElementsByClassName('beacon-datatable-zebra-striped').length).toEqual(1);
    expect(container.getElementsByClassName('beacon-datatable-hover').length).toEqual(0);
  });

  test('applies row hover styling', () => {
    const { baseElement, container } = render(
      <Datatable id="colors-table" title="Colors" columns={basicColumns} data={basicData} zebraStriping={false} />
    );

    expect(baseElement).toMatchSnapshot();
    expect(container.getElementsByClassName('beacon-datatable-zebra-striped').length).toEqual(0);
    expect(container.getElementsByClassName('beacon-datatable-hover').length).toEqual(1);
  });

  test('applies compact styling', () => {
    const { baseElement } = render(
      <Datatable id="colors-table" title="Colors" columns={basicColumns} data={basicData} compact />
    );
    expect(baseElement).toMatchSnapshot();
  });

  test('applies scrollable prop', () => {
    const { baseElement, container } = render(
      <Datatable
        id="colors-table"
        title="Colors"
        columns={basicColumns}
        data={basicData}
        hoverableRows={false}
        scrollable="200px"
      />
    );

    expect(baseElement).toMatchSnapshot();
    expect(container.getElementsByClassName('beacon-datatable-scrollable').length).toEqual(1);
    expect(container.getElementsByClassName('beacon-datatable-hover').length).toEqual(0);
  });

  test('display empty table when no data given', () => {
    const { baseElement, queryByText } = render(
      <Datatable id="empty-table" title="Empty" columns={basicColumns} data={[]} hoverableRows={false} />
    );

    expect(baseElement).toMatchSnapshot();
    expect(queryByText(basicColumns[0].name)).toBeFalsy();
  });

  test('display empty table with headers and pagination when no data given and showTableWhenEmpty is true', () => {
    const { baseElement, queryByText } = render(
      <Datatable
        id="empty-table"
        title="Empty"
        columns={basicColumns}
        data={[]}
        hoverableRows={false}
        showTableWhenEmpty
      />
    );

    expect(baseElement).toMatchSnapshot();
    expect(queryByText(basicColumns[0].name)).toBeTruthy();
  });

  test('with conditional row variants', () => {
    const data = [
      { id: 1, name: 'plum', hex: '#323a44' },
      { id: 2, name: 'green', hex: '#0F0' },
      { id: 3, name: 'lemonchiffon', hex: '#FFFACD' },
      { id: 4, name: 'chartreuse', hex: '#DFFF00' },
      { id: 5, name: 'periwinkle', hex: '#CCCCFF' },
    ];

    const { baseElement, getByText } = render(
      <Datatable
        id="colors-with-row-variants-table"
        title="Colors with Row Variants"
        columns={basicColumns}
        data={data}
        rowVariantConditions={{
          active: (row) => row.name === 'periwinkle',
          success: { label: 'yay!', condition: (row) => row.name === 'plum' },
          info: { label: 'huh!', condition: (row) => row.name === 'green' },
          warning: { label: 'hmm!', condition: (row) => row.name === 'lemonchiffon' },
          danger: { label: 'boo!', condition: (row) => row.name === 'chartreuse' },
        }}
      />
    );

    expect(baseElement).toMatchSnapshot();
    expect(getByText('Legend')).toBeDefined();
  });

  test('hides legend button with conditional row variants', () => {
    const data = [
      { id: 1, name: 'name1', hex: '#323a44' },
      { id: 2, name: 'name2', hex: '#0F0' },
      { id: 3, name: 'lemonchiffon', hex: '#FFFACD' },
      { id: 4, name: 'chartreuse', hex: '#DFFF00' },
      { id: 5, name: 'periwinkle', hex: '#CCCCFF' },
    ];

    const { baseElement } = render(
      <Datatable
        id="colors-with-row-variants-table"
        title="Colors with Row Variants"
        columns={basicColumns}
        data={data}
        rowVariantConditions={{
          active: (row) => row.name === 'periwinkle',
          success: { label: 'yay!', condition: (row) => row.name === 'name1' },
          info: { label: 'huh!', condition: (row) => row.name === 'name2' },
        }}
        showLegend={false}
      />
    );

    expect(baseElement).toMatchSnapshot();
    expect(baseElement.querySelector('colors-with-row-variants-table-legend')).toBeNull();
  });

  test('conditional row variants else cases', () => {
    const data = [
      { id: 1, name: 'plum', hex: '#323a44' },
      { id: 2, name: 'green', hex: '#0F0' },
      { id: 3, name: 'lemonchiffon', hex: '#FFFACD' },
      { id: 4, name: 'chartreuse', hex: '#DFFF00' },
      { id: 5, name: 'periwinkle', hex: '#CCCCFF' },
    ];

    const { baseElement } = render(
      <Datatable
        id="colors-with-row-variants-table"
        title="Colors with Row Variants"
        columns={basicColumns}
        data={data}
        rowVariantConditions={{}}
      />
    );

    expect(baseElement).toMatchSnapshot();
  });

  test('with expand all button', () => {
    const { baseElement } = render(
      <Datatable
        id="colors-table"
        title="Colors"
        columns={basicColumns}
        data={basicData}
        expandableRows
        expandableRowsComponent={<pre>{JSON.stringify(basicData, null, 2)}</pre>}
      />
    );

    expect(baseElement).toMatchSnapshot();
  });

  test('with collapse all button', () => {
    const { baseElement, container } = render(
      <Datatable
        id="colors-table"
        title="Colors"
        columns={basicColumns}
        data={basicData}
        expandableRows
        expandableRowsComponent={<pre>{JSON.stringify(basicData, null, 2)}</pre>}
      />
    );

    const button = container.querySelector(`#btn-expand-collapse-all-colors-table`);
    fireEvent.click(button);

    expect(baseElement).toMatchSnapshot();
  });

  test('changes expand button to collapse when all rows are expanded', () => {
    const { baseElement, container, getByText } = render(
      <Datatable
        id="colors-table"
        title="Colors"
        columns={basicColumns}
        data={basicData}
        expandableRows
        expandableRowsComponent={<pre>{JSON.stringify(basicData, null, 2)}</pre>}
      />
    );

    const buttons = container.querySelectorAll("button[id^='colors-table-expander-button']");

    buttons.forEach((button) =>
      act(() => {
        fireEvent.click(button);
      })
    );
    expect(getByText('Collapse All Rows')).toBeDefined();
  });

  test('expand all resets on page change', async () => {
    const { getByText } = render(
      <Datatable
        id="colors-table"
        title="Colors"
        columns={basicColumns}
        paginationPerPage={2}
        data={basicData}
        pagination
        expandableRows
        expandableRowsComponent={<pre>{JSON.stringify(basicData, null, 2)}</pre>}
      />
    );

    const expandAllButton = await screen.findByRole('button', { name: /Expand All Rows/i });
    const nextPage = screen.getAllByRole('button', { name: /Next Page/i })[0];

    act(() => {
      fireEvent.click(expandAllButton);
    });

    expect(getByText('Collapse All Rows')).toBeDefined();

    act(() => {
      fireEvent.click(nextPage);
    });

    expect(getByText('Expand All Rows')).toBeDefined();
  });

  test('changes expand button to collapse when all rows are expanded after a page size change in the middle', () => {
    const data = [
      { id: 1, name: 'plum', hex: '#323a44' },
      { id: 2, name: 'green', hex: '#0F0' },
      { id: 3, name: 'lemonchiffon', hex: '#FFFACD' },
      { id: 4, name: 'yellow', hex: '#FF0' },
    ];

    const { baseElement, container, getByText, rerender } = render(
      <Datatable
        id="colors-table"
        title="Colors"
        columns={basicColumns}
        paginationPerPage={2}
        data={data}
        pagination
        paginationRowsPerPageOptions={[5, 10, 15]}
        expandableRows
        expandableRowsComponent={<pre>{JSON.stringify(data, null, 2)}</pre>}
      />
    );

    let buttons = container.querySelectorAll("button[id^='colors-table-expander-button']");

    // expand one row
    act(() => {
      fireEvent.click(buttons[0]);
    });

    fireEvent.change(container.querySelector('select'), { target: { value: 15 } });

    buttons = container.querySelectorAll("button[id^='colors-table-expander-button']");
    // expand rest of the rows
    act(() => {
      fireEvent.click(buttons[1]);
    });
    act(() => {
      fireEvent.click(buttons[2]);
    });
    act(() => {
      fireEvent.click(buttons[3]);
    });

    expect(getByText('Collapse All Rows')).toBeDefined();
  });

  test('renders with customized heading', () => {
    const { baseElement } = render(
      <Datatable
        id="colors-table"
        title="Colors"
        columns={basicColumns}
        data={basicData}
        headingType="h1"
        headingStyle="m"
      />
    );

    expect(baseElement).toMatchSnapshot();
  });

  test('renders with no customized heading with empty title', () => {
    const { baseElement } = render(
      <Datatable id="colors-table" title="" columns={basicColumns} data={basicData} headingType="h1" headingStyle="m" />
    );

    expect(baseElement).toMatchSnapshot();
  });

  test('renders with aria-label', () => {
    const { baseElement } = render(
      <Datatable id="colors-table" title="" columns={basicColumns} data={basicData} ariaLabel="label" />
    );

    expect(baseElement).toMatchSnapshot();
  });

  test('table is initially sorted by Color in ascending order', () => {
    const { baseElement } = render(
      <Datatable
        id="colors-table"
        title="Colors"
        columns={basicColumns}
        defaultSortField={'name'}
        defaultSortAsc={true}
        data={basicData}
      />
    );
    expect(baseElement).toMatchSnapshot();

    const firstTableRow = baseElement.getElementsByClassName('rdt_TableRow')[0];
    const firstRowFirstCell = baseElement.getElementsByClassName('rdt_TableCell')[0];
    const thirdTableRow = baseElement.getElementsByClassName('rdt_TableRow')[2];
    const thirdRowFirstCell = baseElement.getElementsByClassName('rdt_TableCell')[4];
    expect(firstRowFirstCell.closest('.rdt_TableRow')).toBe(firstTableRow);
    expect(firstRowFirstCell.children[0].innerHTML).toBe('green');
    expect(thirdRowFirstCell.closest('.rdt_TableRow')).toBe(thirdTableRow);
    expect(thirdRowFirstCell.children[0].innerHTML).toBe('plum');
  });

  test('table is initially sorted by Color in descending order', () => {
    const { baseElement } = render(
      <Datatable
        id="colors-table"
        title="Colors"
        columns={basicColumns}
        defaultSortField={'name'}
        defaultSortAsc={false}
        data={basicData}
      />
    );
    expect(baseElement).toMatchSnapshot();

    const firstTableRow = baseElement.getElementsByClassName('rdt_TableRow')[0];
    const firstRowFirstCell = baseElement.getElementsByClassName('rdt_TableCell')[0];
    const thirdTableRow = baseElement.getElementsByClassName('rdt_TableRow')[2];
    const thirdRowFirstCell = baseElement.getElementsByClassName('rdt_TableCell')[4];
    expect(firstRowFirstCell.closest('.rdt_TableRow')).toBe(firstTableRow);
    expect(firstRowFirstCell.children[0].innerHTML).toBe('plum');
    expect(thirdRowFirstCell.closest('.rdt_TableRow')).toBe(thirdTableRow);
    expect(thirdRowFirstCell.children[0].innerHTML).toBe('green');
  });

  test('table uses provided rows per page props', () => {
    const rowsPerPageOptions = [5, 10, 25, 100];
    const { baseElement } = render(
      <Datatable
        id="colors-table"
        title="Colors"
        columns={basicColumns}
        pagination={true}
        paginationRowsPerPageOptions={rowsPerPageOptions}
        data={basicData}
      />
    );
    expect(baseElement).toMatchSnapshot();

    const rowsPerPageSelect = baseElement.querySelector('[aria-label="Rows per page:"]');
    const options = rowsPerPageSelect.children;
    for (let i = 0; i < options.length; i++) {
      expect(Number(options[i].innerHTML)).toEqual(rowsPerPageOptions[i]);
    }
  });

  test('when provided with an onSort prop, the table calls it on sort', async () => {
    let sortingBy = '';
    const { baseElement } = render(
      <Datatable
        id="colors-table"
        title="Colors"
        columns={basicColumns}
        onSort={(column, direction) => {
          sortingBy = `${column.name},${direction}`;
        }}
        data={basicData}
      />
    );
    expect(baseElement).toMatchSnapshot();

    const nameColumnHeader = baseElement.querySelector('[id^=colors-table-column]');
    userEvent.click(nameColumnHeader);
    expect(sortingBy).toEqual('Color Name,asc');
    userEvent.click(nameColumnHeader);
    expect(sortingBy).toEqual('Color Name,desc');
  });

  test('when provided with an onRowClicked prop, the table calls it when a row is clicked on', () => {
    const mockCallback = jest.fn();
    const { baseElement } = render(
      <Datatable id="colors-table" title="Colors" columns={basicColumns} onRowClicked={mockCallback} data={basicData} />
    );
    expect(baseElement).toMatchSnapshot();

    const nameColumnHeader = baseElement.querySelector('.rdt_TableCell');
    userEvent.click(nameColumnHeader);
    expect(mockCallback).toHaveBeenCalled();
  });

  test('table renders with conditionally styled rows if provided with the conditionalRowStyles prop', () => {
    const { baseElement } = render(
      <Datatable
        id="colors-table"
        title="Colors"
        columns={basicColumns}
        data={basicData}
        conditionalRowStyles={[{ when: (row) => row.name > 'i', style: { background: 'pink' } }]}
      />
    );

    const firstTableRow = baseElement.getElementsByClassName('rdt_TableRow')[0] as HTMLElement;
    const secondTableRow = baseElement.getElementsByClassName('rdt_TableRow')[1] as HTMLElement;
    const firstTableStyle = window.getComputedStyle(firstTableRow);
    const secondTableStyle = window.getComputedStyle(secondTableRow);

    expect(firstTableRow.innerHTML.includes('plum')).toBeTruthy();
    expect(firstTableStyle.background).toBe('pink');
    expect(secondTableRow.innerHTML.includes('green')).toBeTruthy();
    expect(secondTableStyle.background).not.toBe('pink');
  });

  test('Datatable with child rows', () => {
    const dataWithChildRows = [
      { id: 1, name: 'plum', hex: '#323a44', childRows: [{ id: 1, name: 'red', hex: '#F00' }] },
      { id: 2, name: 'green', hex: '#0F0', childRows: [{ id: 1, name: 'lemonchiffon', hex: '#FFFACD' }] },
      { id: 3, name: 'lemonchiffon', hex: '#FFFACD', childRows: [] },
      { id: 4, name: 'chartreuse', hex: '#DFFF00', childRows: [{ id: 1, name: 'periwinkle', hex: '#CCCCFF' }] },
      { id: 5, name: 'periwinkle', hex: '#CCCCFF', childRows: [] },
    ];

    const { baseElement } = render(
      <Datatable
        id="colors-table"
        title="Colors"
        columns={basicColumns}
        data={dataWithChildRows}
        pagination
        showChildRowData
        childRowDataField="childRows"
      />
    );

    const firstTableRow = baseElement.getElementsByClassName('rdt_TableRow')[0] as HTMLElement;
    const secondTableRow = baseElement.getElementsByClassName('rdt_TableRow')[1] as HTMLElement;
    const firstTableStyle = window.getComputedStyle(firstTableRow);
    const secondTableStyle = window.getComputedStyle(secondTableRow);
    expect(firstTableRow.innerHTML.includes('plum')).toBeTruthy();
    expect(firstTableStyle.background).toBe('rgb(255, 255, 255)');
    expect(secondTableRow.innerHTML.includes('green')).toBeTruthy();
    expect(secondTableStyle.background).not.toBe('pink');
  });
  test('With omitted column', () => {
    render(
      <Datatable
        id="omitted-row-table"
        title="omitted"
        columns={[
          {
            id: 'name',
            name: 'Color Name',
            selector: 'name',
            sortable: true,
            omit: true,
          },
          {
            id: 'hex',
            name: 'HEX Value',
            selector: 'hex',
            sortable: true,
          },
        ]}
        data={basicData}
      />
    );
    expect(screen.queryByText('plum')).not.toBeTruthy();
  });

  describe('With selectable rows', () => {
    test('With no rows selected by default', () => {
      // Given...
      // When...
      const { baseElement } = render(
        <Datatable
          id="colors-table"
          title="Colors"
          columns={basicColumns}
          data={basicData}
          zebraStriping={false}
          hoverableRows={false}
          selectableRows
        />
      );
      // Then...
      expect(screen.getAllByText(/select row [0-9]/i).length).toEqual(3);
      expect(baseElement.textContent).not.toContain('item selected');
      expect(baseElement.textContent).not.toContain('items selected');
    });

    test('With one row selected by default', () => {
      // Given...
      // When...
      const { baseElement } = render(
        <Datatable
          id="colors-table"
          title="Colors"
          columns={basicColumns}
          data={basicData}
          zebraStriping={false}
          hoverableRows={false}
          selectableRows
          defaultSelected={(row) => row.name === 'green'}
        />
      );
      // Then...
      expect(baseElement.textContent).toContain('1 item selected');
    });

    test('With disabled rows and select all selected by default', () => {
      // Given...
      // When...
      const { baseElement } = render(
        <Datatable
          id="colors-table"
          title="Colors"
          columns={basicColumns}
          data={basicData}
          zebraStriping={false}
          hoverableRows={false}
          selectableRows
          selectAll={true}
          selectableRowDisabled={(row) => row.id === 1}
        />
      );
      // Then...
      expect(baseElement.textContent).toContain('2 items selected');
    });

    test('With all rows selected by default', () => {
      // Given...
      // When...
      const { baseElement } = render(
        <Datatable
          id="colors-table"
          title="Colors"
          columns={basicColumns}
          data={basicData}
          zebraStriping={false}
          hoverableRows={false}
          selectableRows
          selectAll={true}
        />
      );
      // Then...
      expect(baseElement.textContent).toContain('3 items selected');
    });
  });
});
