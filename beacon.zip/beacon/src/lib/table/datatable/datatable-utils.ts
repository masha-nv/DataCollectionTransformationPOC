import { dateUtils } from '../../utils/date-utils';

/**
 * Creates a comparer for the property `propertyName` of type Type
 * Given two object, the comparer returns:
 * 1. Greater than 0 if rowA > rowB
 * 2. Less than 0 if rowA < rowB
 * 3. returns 0 if rowA = rowB
 * `propertyName` must be a string with valid date format
 */
export const getDateStringComparer = <Type>(propertyName: Extract<keyof Type, string>) => {
  return (rowA: Type, rowB: Type) => {
    return dateUtils.compareDateString(
      rowA[propertyName] as unknown as string,
      rowB[propertyName] as unknown as string
    );
  };
};

export const datatableUtils = {
  getDateStringComparer,
};
