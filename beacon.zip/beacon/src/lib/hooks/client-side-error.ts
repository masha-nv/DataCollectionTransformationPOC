/**
 * These represent errors that occurred from a client-side perspective, things like
 * a validation that failed, an action that is not allowed to be performed yet, etc.
 * This is not meant to handle a scenario where the backend returns an error response.
 */
export class ClientSideError extends Error {}
