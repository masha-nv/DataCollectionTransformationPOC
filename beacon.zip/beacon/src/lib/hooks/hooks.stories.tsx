import React, { useEffect } from 'react';
import { Meta, Story } from '@storybook/react';
import { noPayloadRestCall, payloadRestCall, RestCallHook, ParamRestCallHook, ServiceInvocation } from './hooks';
import { componentLogger } from '../logging/log';
import { Button } from '../button/button';
import { Alert, AlertVariant } from '../notifications/alert/alert';
import { Documentation } from '../stories';

const log = componentLogger('HookLessons');

export default {
  title: 'Lessons/Hooks',
} as Meta;

interface IHookDebugProps {
  isInvoked: boolean;
  isLoading: boolean;
  data: unknown;
  error: unknown;
  showDescription?: boolean;
}

const useFakeHelloWorldHook: RestCallHook<string> = () => {
  return noPayloadRestCall<string>(() => {
    return new Promise<string>((resolve) => {
      setTimeout(() => resolve('Hello world'), 3000);
    });
  })();
};

const useFakeHelloToMeWithTime: ParamRestCallHook<Date, string> = () => {
  return payloadRestCall<Date, string>((payload) => {
    return new Promise<string>((resolve) => {
      setTimeout(() => resolve('Hello world ' + payload.toLocaleTimeString()), 1000);
    });
  })();
};

function toString(value: boolean) {
  return value ? 'true' : 'false';
}

const HookDebug = ({ isInvoked, isLoading, data, error, showDescription = false }: IHookDebugProps) => {
  return (
    <table className="table w-50">
      <thead>
        <tr>
          <th scope="col">Hook Field</th>
          <th scope="col">Value</th>
          {showDescription && <th scope="col">Description</th>}
        </tr>
      </thead>
      <tbody>
        <tr>
          <th scope="row">execute</th>
          <td>
            <em>Not applicable</em>
          </td>
          {showDescription && (
            <td>
              The function by which to trigger the execution of the hook, it can be aliased like{' '}
              <code>{`{execute: callMyHook}`}</code> and then executed via <code>callMyHook()</code>.
            </td>
          )}
        </tr>
        <tr>
          <th scope="row">isInvoked</th>
          <td>
            <code>{toString(isInvoked)}</code>
          </td>
          {showDescription && (
            <td>
              Shows whether the hook has been invoked at least once, once the <code>execute</code> trigger of the hook
              is invoked, this becomes <code>true</code> and remains that way.
            </td>
          )}
        </tr>
        <tr>
          <th scope="row">isLoading</th>
          <td>
            <code>{toString(isLoading)}</code>
          </td>
          {showDescription && (
            <td>
              This will be true while the <code>Promise</code> that the hook triggers remains unresolved, useful if the
              developer needs to add a "loading" indicator or disabling multiple submissions.
            </td>
          )}
        </tr>
        <tr>
          <th scope="row">error</th>
          <td>
            <code>{error ? JSON.stringify(error) : 'null'}</code>
          </td>
          {showDescription && (
            <td>
              An error object that will be populated if the service's <code>Promise</code> rejects.
            </td>
          )}
        </tr>
        <tr>
          <th scope="row">data</th>
          <td>
            <code>{data ? JSON.stringify(data) : 'null'}</code>
          </td>
          {showDescription && (
            <td>
              The resolved data of the <code>Promise</code> will be stored here.
            </td>
          )}
        </tr>
      </tbody>
    </table>
  );
};

export const Hooks: Story = () => {
  const { isInvoked, isLoading, error, data, execute } = useFakeHelloWorldHook();

  const {
    isInvoked: isInvokedParam,
    isLoading: isLoadingParam,
    error: errorParam,
    data: dataParam,
    execute: executeParam,
  } = useFakeHelloToMeWithTime();

  return (
    <>
      <p className="mb-4">
        The following will trigger a hook that returns "Hello World" as its data, click the button to see it happen (the
        hook will take <strong>3 seconds</strong> to mimic a slow call). When the hook response is loading, notice the
        button becomes <code>disabled</code> and is re-enabled once the hook is finished loading.
      </p>
      <Button id="load-hook" onClick={() => execute()} disabled={isInvoked && isLoading}>
        Say hello to me!
      </Button>
      <HookDebug isInvoked={isInvoked} isLoading={isLoading} data={data} error={error} showDescription />

      <Button id="load-hook" onClick={() => executeParam(new Date())} disabled={isInvokedParam && isLoadingParam}>
        Say hello to me (with the time)!
      </Button>
      <HookDebug
        isInvoked={isInvokedParam}
        isLoading={isLoadingParam}
        data={dataParam}
        error={errorParam}
        showDescription
      />
    </>
  );
};
Hooks.storyName = 'Using Hooks';
Hooks.decorators = [
  (ComponentStory: Story) => {
    return (
      <Documentation name="hooks">
        <h2>Using Hooks</h2>

        <p>
          Hooks are the recommended way to access REST or asynchronous resources, they will replace the concept of
          AngularJS/Angular services. The framework that is in place allows you to do the following:
        </p>
        <ol>
          <li>Determine if the hook has been invoked at least once </li>
          <li>Have a loading indicator </li>
          <li>Execute the hook at any point in time you desire </li>
          <li>Get access to the data without having to deal with promises </li>
          <li>Access request errors for HTTP 4xx requests in a consistent manner </li>
        </ol>
        <ComponentStory />
      </Documentation>
    );
  },
];

export const WritingHooks: Story = () => {
  const myAsyncNoParamsService: ServiceInvocation<string> = () => {
    return new Promise<string>((resolve) => {
      setTimeout(() => resolve('i am done'), 1000);
    });
  };

  const useMyAsyncNoParamsHook: RestCallHook<string> = () => {
    // you execute the function because you're returning the actual hook, not a reference to the function
    return noPayloadRestCall(myAsyncNoParamsService)();
  };

  interface MyNote {
    note: string;
    category: string;
  }
  interface MyParams {
    caseId: number;
    noteToAdd: MyNote;
  }

  return (
    <div>
      See the samples by clicking on <strong>Show code</strong>
    </div>
  );
};

WritingHooks.decorators = [
  (ComponentStory: Story) => {
    return (
      <Documentation name="Writing Hooks">
        <h2>Writing Hooks</h2>
        <p>
          This sample shows the way in which you create a REST call hook. Rest call hooks is the standard for our
          project in React since they provide all the features shown in the other examples including ways to handle
          loading states and errors and removing the need for you, the developer, to deal with promises directly from
          your component code.
        </p>
        <p>
          Each exposed hook will be designed to access a single resource which means there will be a lot of hooks in
          ELIS. This is ok as they will ensure that we handle REST calls in a consistent manner throughout (and not just
          the happy paths as has been common).
        </p>
        <p>There are two types of hooks available, one for parameterless execution and one for payload executions.</p>
        <h3>Parameter-less executions</h3>
        <p>
          Parameterless executions mean that you invoke an endpoint or the asynchronous functionality, there are no
          parameters necessary to be passed in to the function. However, these functions must{' '}
          <strong>
            <em>always</em>
          </strong>{' '}
          return some sort of result. Parameterless functions should be typed with{' '}
          <code>ServiceInvocation&lt;T&gt;</code> where <code>T</code> is the type of the response coming back from this
          function. In the examples provided in the code snippet, the response type is <code>string</code>.
        </p>
        <p>Some examples of parameterless executions include things like:</p>
        <ol>
          <li>
            Calling a <code>GET, DELETE, PUT, POST</code> endpoint that doesn't accept any variable parameters or has a
            request body
          </li>
          <li>
            Firing an asynchronous action like a timeout that doesn't depend on a developer provided timeout value
          </li>
        </ol>
        <h3>Executions with parameters</h3>
        <p>
          Many times, asynchronous code will need parameters to perform their necessary function. In those instances the
          promise producing function must be of type <code>ParamServiceInvocation&lt;P,T&gt;</code> where <code>P</code>{' '}
          is the type of the payload the <em>function</em> accepts and <code>T</code> is the result type. The{' '}
          <code>P</code> represents what you're passing in to your hook, not what the end REST point is expecting. They
          may or may not be identical! Check the code sample for how those get used.
        </p>
        <Alert variant={AlertVariant.warning}>
          It's important you remember that the <code>P</code> type does not necessarily mean the payload to the REST
          endpoint
        </Alert>
        <ComponentStory />
      </Documentation>
    );
  },
];

const useSampleHook: RestCallHook<ISampleHookResult> = () => {
  return noPayloadRestCall<ISampleHookResult>(() => {
    return Promise.resolve({
      message: 'Hello world',
    });
  })();
};
interface ISampleHookResult {
  message: string;
}

export const InvokingHooksAtLoadTime: Story = () => {
  log.debug('Rendering');

  // get a handle of our hook and alias the execute method
  const { isInvoked, isLoading, execute: triggerHook, error, data } = useSampleHook();

  // this needs the "execute" alias as part of the dependency list or be ready for
  // an infinite loop
  useEffect(() => {
    log.debug('Triggering hook');
    triggerHook();
  }, [triggerHook]);

  return (
    <Documentation name="Invoking Hooks At LoadTime">
      <h2>Invoking hooks at load time</h2>
      <p>
        This shows an example of a hook that is invoked when the component loads. Notice on the code sample how the hook
        is invoked with a <code>useEffect()</code> wrapper with a <code>dependencyList</code> of the trigger function
        reference. This <code>dependencyList</code> is <strong>absolutely essential</strong> since it will prevent the
        <code>useEffect()</code> function from being invoked on every re-render, since the triggering of the hook itself
        will cause a re-render, we don't want to create an <strong>infinite loop!</strong>
      </p>
      <HookDebug isInvoked={isInvoked} isLoading={isLoading} data={data} error={error} />
    </Documentation>
  );
};

const useSampleErrorHook: RestCallHook<ISampleHookResult> = () => {
  return noPayloadRestCall<ISampleHookResult>(() => {
    return Promise.reject({
      message: 'Failed to do a thing',
      correlationId: 'error123',
    });
  })();
};

export const HandlingErrorStates: Story = () => {
  const { isInvoked, isLoading, execute: triggerHook, error, data } = useSampleErrorHook();

  useEffect(() => {
    triggerHook();
  }, [triggerHook]);

  useEffect(() => {
    new Promise((resolve) => {
      throw new Error('hello jank');
    });
  });

  return (
    <Documentation name="Handling Error States with Hooks">
      <h2>Handling errors</h2>
      <p>
        The hooks will populate the <code>error</code> object with the error returned by the hook. You can use this for
        all your error handling needs to provide a meaningful message to your user. There are two main ways to signal
        errors inside hooks, either by returning a <code>Promise.reject({})</code> or via{' '}
        <code>throw new ClientSideError('message')</code> from an <code>async</code> function.
      </p>
      <p>
        The advantates of returning a rejected promise is that you can include a custom object inside the{' '}
        <code>reject()</code> body, whereas on a<code>throw new ClientSideError()</code> you're limited to a simple
        string.
      </p>
      {error && (
        <Alert variant={AlertVariant.warning}>
          Oh no! We couldn't retrieve your data right now, use the following code for a developer{' '}
          <code>{error.message}</code>
        </Alert>
      )}
      <HookDebug isInvoked={isInvoked} isLoading={isLoading} data={data} error={error} />
    </Documentation>
  );
};
