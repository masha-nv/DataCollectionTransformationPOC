import { useState, useCallback } from 'react';
import { RestHookResponse } from './rest-hook-response';

export declare type ServiceInvocation<T> = () => Promise<T>;
export declare type RestCallHook<T> = () => RestHookResponse<HookExecution, T>;
export declare type RestCallHookCreator<T> = () => RestCallHook<T>;
export declare type HookExecution = () => void;

export declare type ParamServiceInvocation<P, T> = (payload: P) => Promise<T>;
export declare type ParamRestCallHook<P, T> = () => RestHookResponse<ParamHookExecution<P>, T>;
export declare type ParamRestCallHookCreator<P, T> = () => ParamRestCallHook<P, T>;
export declare type ParamHookExecution<P> = (payload: P) => void;

export function noPayloadRestCall<T>(generatorOfPromise: ServiceInvocation<T>): RestCallHook<T> {
  return function () {
    const [isInvoked, setIsInvoked] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);
    const [data, setData] = useState<T | null>(null);
    const execute = () => {
      setIsInvoked(true);
      setIsLoading(true);
      setError(null);
      generatorOfPromise()
        .then((resultData) => {
          setData(resultData);
          setIsLoading(false);
        })
        .catch((error) => {
          setError(error);
          setIsLoading(false);
        });
    };

    return {
      isInvoked,
      isLoading,
      error,
      data,
      execute: useCallback(execute, []),
    } as RestHookResponse<HookExecution, T>;
  };
}

export function payloadRestCall<P, T>(generatorOfPromise: ParamServiceInvocation<P, T>): ParamRestCallHook<P, T> {
  return function () {
    const [isInvoked, setIsInvoked] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);
    const [data, setData] = useState<T | null>(null);
    const execute = (payload: P) => {
      setIsInvoked(true);
      setIsLoading(true);
      setData(null);
      setError(null);
      generatorOfPromise(payload)
        .then((result) => {
          setData(result);
          setIsLoading(false);
        })
        .catch((error) => {
          setError(error);
          setIsLoading(false);
        });
    };

    return {
      isInvoked,
      isLoading,
      error,
      data,
      execute: useCallback(execute, []),
    } as RestHookResponse<ParamHookExecution<P>, T>;
  };
}
