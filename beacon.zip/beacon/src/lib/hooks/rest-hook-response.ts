import { ClientSideError } from './client-side-error';

export interface RestError {
  statusCode: number;
  message?: string;
  correlationId?: string;
  body?: unknown;
}
export interface RestHookResponse<ExecuteFunctionType, Datatype> {
  isInvoked: boolean;
  isLoading: boolean;
  error: ClientSideError | null;
  data: Datatype | null;
  execute: ExecuteFunctionType;
}
