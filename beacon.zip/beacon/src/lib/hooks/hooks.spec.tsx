import React from 'react';
import { fireEvent, render, RenderResult, waitFor } from '@testing-library/react';
import { HookTester, PayloadHookTester } from '../test-utils/hook-tester';
import {
  HookExecution,
  noPayloadRestCall,
  ParamHookExecution,
  ParamRestCallHook,
  payloadRestCall,
  RestCallHook,
} from './hooks';
import { RestHookResponse } from './rest-hook-response';
import { act } from 'react-dom/test-utils';
import { ClientSideError } from './client-side-error';

describe('Hooks service', () => {
  const useFakeService: RestCallHook<string> = () => {
    return noPayloadRestCall(() => Promise.resolve('hello world'))();
  };

  const useFakeServiceWithReject: RestCallHook<string> = () => {
    return noPayloadRestCall(async () => {
      throw new Error('error out');
    })();
  };

  const useFakeServiceWithIndeterminate: RestCallHook<string> = () => {
    return noPayloadRestCall(() => {
      return new Promise<string>(() => {
        console.log('I do nothing');
      });
    })();
  };

  interface ResponseWithPayload {
    payload: unknown;
    message: string;
  }
  const useFakeServiceWithPayload: ParamRestCallHook<string, ResponseWithPayload> = () => {
    return payloadRestCall((payload) =>
      Promise.resolve({
        payload,
        message: 'hello world',
      })
    )();
  };

  const useFakeServiceWithPayloadWithReject: ParamRestCallHook<string, ResponseWithPayload> = () => {
    return payloadRestCall(async (payload) => {
      throw new ClientSideError('rejected payload client side');
    })();
  };

  const useFakeServiceWithPayloadWithIndeterminate: ParamRestCallHook<string, ResponseWithPayload> = () => {
    return payloadRestCall(
      (payload) =>
        new Promise<ResponseWithPayload>(() => {
          console.log('indeterminate promise');
        })
    )();
  };

  describe('no payload hooks', () => {
    it('sets up initial state', () => {
      render(
        <HookTester
          id="basic-state-test"
          useHookFunction={useFakeService}
          callbackFunction={(hook) => {
            expect(hook.isInvoked).toBeFalsy();
            expect(hook.isLoading).toBeFalsy();
            expect(hook.error).toBeNull();
            expect(hook.data).toBeNull();
            expect(hook.execute).not.toBeNull();
          }}
        />
      );
    });

    it('contains the correct state on successful execute', async () => {
      let hookResponse: RestHookResponse<HookExecution, string>;
      const { getByTestId } = render(
        <HookTester
          id="no-payload-test"
          useHookFunction={useFakeService}
          callbackFunction={(hook) => {
            hookResponse = hook;
          }}
        />
      );
      act(() => {
        fireEvent.click(getByTestId('no-payload-test-execute'));
      });
      await waitFor(() => {
        getByTestId('no-payload-test-isLoading');
      });
      expect(hookResponse.isInvoked).toBeTruthy();
      expect(hookResponse.isLoading).toBeFalsy();
      expect(hookResponse.error).toBeNull();
      expect(hookResponse.data).toEqual('hello world');
    });

    it('contains the correct state on reject response', async () => {
      let hookResponse: RestHookResponse<HookExecution, string>;
      const { getByTestId } = render(
        <HookTester
          id="no-payload-test"
          useHookFunction={useFakeServiceWithReject}
          callbackFunction={(hook) => {
            hookResponse = hook;
          }}
        />
      );
      act(() => {
        fireEvent.click(getByTestId('no-payload-test-execute'));
      });
      await waitFor(() => {
        getByTestId('no-payload-test-isLoading');
      });
      expect(hookResponse.isInvoked).toBeTruthy();
      expect(hookResponse.isLoading).toBeFalsy();
      expect(hookResponse.error.message).toEqual('error out');
      expect(hookResponse.data).toBeNull();
    });

    it('contains the correct state on waiting for response', async () => {
      let hookResponse: RestHookResponse<HookExecution, string>;
      const { getByTestId } = render(
        <HookTester
          id="no-payload-test"
          useHookFunction={useFakeServiceWithIndeterminate}
          callbackFunction={(hook) => {
            hookResponse = hook;
          }}
        />
      );
      act(() => {
        fireEvent.click(getByTestId('no-payload-test-execute'));
      });
      await waitFor(() => {
        getByTestId('no-payload-test-isLoading');
      });
      expect(hookResponse.isInvoked).toBeTruthy();
      expect(hookResponse.isLoading).toBeTruthy();
      expect(hookResponse.error).toBeNull();
      expect(hookResponse.data).toBeNull();
    });
  });

  describe('hooks with payloads', () => {
    it('sets up initial state', () => {
      render(
        <PayloadHookTester
          id="basic-state-test"
          payload="payload-test"
          useHookFunction={useFakeServiceWithPayload}
          callbackFunction={(hook) => {
            expect(hook.isInvoked).toBeFalsy();
            expect(hook.isLoading).toBeFalsy();
            expect(hook.error).toBeNull();
            expect(hook.data).toBeNull();
            expect(hook.execute).not.toBeNull();
          }}
        />
      );
    });

    it('contains the correct state on successful execute', async () => {
      let hookResponse: RestHookResponse<ParamHookExecution<string>, ResponseWithPayload>;
      const { getByTestId } = render(
        <PayloadHookTester
          id="payload-test"
          payload="payload-test"
          useHookFunction={useFakeServiceWithPayload}
          callbackFunction={(hook) => {
            hookResponse = hook;
          }}
        />
      );
      act(() => {
        fireEvent.click(getByTestId('payload-test-execute'));
      });
      await waitFor(() => {
        getByTestId('payload-test-isLoading');
      });
      expect(hookResponse.isInvoked).toBeTruthy();
      expect(hookResponse.isLoading).toBeFalsy();
      expect(hookResponse.error).toBeNull();
      expect(hookResponse.data).toEqual({
        payload: 'payload-test',
        message: 'hello world',
      });
    });

    describe('error execute', () => {
      let hookResponse: RestHookResponse<ParamHookExecution<string>, ResponseWithPayload>;
      let renderResult: RenderResult;
      beforeEach(async () => {
        renderResult = render(
          <PayloadHookTester
            id="payload-test"
            payload="payload-test"
            useHookFunction={useFakeServiceWithPayloadWithReject}
            callbackFunction={(hook) => {
              hookResponse = hook;
            }}
          />
        );

        await act(async () => {
          fireEvent.click(renderResult.getByTestId('payload-test-execute'));
          await waitFor(() => {
            expect(renderResult.container.innerHTML).toContain('rejected payload client side');
          });
        });
      });

      it('contains the correct state', async () => {
        expect(hookResponse.isInvoked).toBeTruthy();
        expect(hookResponse.isLoading).toBeFalsy();
        expect(hookResponse.error.message).toEqual('rejected payload client side');
        expect(hookResponse.data).toBeNull();
      });

      it('contains the correct state before next execute', async () => {
        act(() => {
          fireEvent.click(renderResult.getByTestId('payload-test-execute'));
        });
        expect(hookResponse.isInvoked).toBeTruthy();
        expect(hookResponse.isLoading).toBeTruthy();
        expect(hookResponse.error).toBeNull();
        expect(hookResponse.data).toBeNull();

        await waitFor(() => {
          expect(renderResult.container.innerHTML).toContain('rejected payload client side');
        });
      });
    });

    it('contains the correct state on waiting for response', async () => {
      let hookResponse: RestHookResponse<ParamHookExecution<string>, ResponseWithPayload>;
      const { getByTestId } = render(
        <PayloadHookTester
          id="payload-test"
          payload="hello-world"
          useHookFunction={useFakeServiceWithPayloadWithIndeterminate}
          callbackFunction={(hook) => {
            hookResponse = hook;
          }}
        />
      );
      act(() => {
        fireEvent.click(getByTestId('payload-test-execute'));
      });
      await waitFor(() => {
        getByTestId('payload-test-isLoading');
      });
      expect(hookResponse.isInvoked).toBeTruthy();
      expect(hookResponse.isLoading).toBeTruthy();
      expect(hookResponse.error).toBeNull();
      expect(hookResponse.data).toBeNull();
    });
  });
});
