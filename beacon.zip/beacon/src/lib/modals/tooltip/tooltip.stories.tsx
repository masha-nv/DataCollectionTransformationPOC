import React from 'react';
import { Tooltip } from './tooltip';
import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../../stories';
import { Badge, BadgeVariant } from '../../notifications/badge/badge';
import { Button } from '../../button/button';
import { Direction, Theme } from '../modal-types';
import { a11yConfig } from '../../stories/story.config';
import { ButtonGroup, ButtonGroupDirection } from '../../button/button-group';
import './storybook-tooltip.scss';

export default {
  component: Tooltip,
  title: 'Core Components/Modal, Popover, and Tooltip/Tooltip',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
  },
} as Meta;

const whenToUse = (
  <>
    <p>Tooltips should be used to supply additonal information about some element on the page.</p>
    <ul>
      <li>
        <strong className="beacon-icon-success">Do </strong> use to indicate the meaning behind an icon
      </li>
      <li>
        <strong className="beacon-icon-success">Do </strong> use to provide a description of something without
        disrupting users’ workflow
      </li>
    </ul>
  </>
);

const accessibilityConsiderations = (
  <p>
    <strong>Tooltips are not labels</strong>. Tooltips should contain <em>descriptions</em> or{' '}
    <em>additional content</em> and should reinforce and support pre-existing labels.
  </p>
);

/**
 * Tooltip
 */
export const BasicExample: Story = () => {
  return (
    <Tooltip id="tooltip-default" content="Basic Tooltip has a dark theme and top direction with max width of 200px">
      <Button id="basic-beacon-button" onClick={() => null}>
        Basic Button Example
      </Button>
    </Tooltip>
  );
};
BasicExample.storyName = 'Tooltip';
BasicExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Tooltip"
      description={
        <>
          Tooltips appear on hover, are purely informational, and include text or HTML.
          <br />
          <strong>Note:</strong> Tooltips cannot be used on plain text. Wrap your plain text in a span
        </>
      }
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const TooltipDirection: Story = () => {
  return (
    <ButtonGroup direction={ButtonGroupDirection.LEFT}>
      <Tooltip id="tooltip-top" direction={Direction.top} content="This is a TOP tooltip!">
        <Button id="basic-beacon-button-top" onClick={() => null}>
          TOP
        </Button>
      </Tooltip>
      <Tooltip id="tooltip-right" direction={Direction.right} content="This is a RIGHT tooltip!">
        <Button id="basic-beacon-button-right" onClick={() => null}>
          RIGHT
        </Button>
      </Tooltip>
      <Tooltip id="tooltip-bottom" direction={Direction.bottom} content="This is a BOTTOM tooltip!">
        <Button id="basic-beacon-button-bottom" onClick={() => null}>
          BOTTOM
        </Button>
      </Tooltip>
      <Tooltip id="tooltip-left" direction={Direction.left} content="This is a LEFT tooltip!">
        <Button id="basic-beacon-button-left" onClick={() => null}>
          LEFT
        </Button>
      </Tooltip>
    </ButtonGroup>
  );
};

TooltipDirection.storyName = ' Tooltip Displaying in Different Directions';

TooltipDirection.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Tooltip"
      description="Tooltips with user-specified direction"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const TooltipTheme: Story = () => {
  return (
    <div>
      <span className="mr-3">
        <Tooltip id="tooltip-dark" content="This is a DARK tooltip!">
          <Button id="basic-beacon-button-dark" onClick={() => null}>
            Dark
          </Button>
        </Tooltip>
      </span>
      <Tooltip id="tooltip-light" content="This is a LIGHT tooltip!" theme={Theme.light}>
        <Button id="basic-beacon-button-light" onClick={() => null}>
          Light
        </Button>
      </Tooltip>
    </div>
  );
};

TooltipTheme.storyName = 'Tooltip Light and Dark Themes';

TooltipTheme.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Tooltip"
      description="Tooltips with user-specified theme"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const TooltipContent: Story = () => {
  return (
    <ButtonGroup direction={ButtonGroupDirection.LEFT}>
      <Tooltip
        id="tooltip-html-badge"
        content={
          <div>
            Using custom HTML with a badge.
            <br />
            <Badge id="tooltip-badge" variant={BadgeVariant.default}>
              Default
            </Badge>
          </div>
        }
      >
        <Button id="basic-beacon-button-html-badge" onClick={() => null}>
          HTML with Badge
        </Button>
      </Tooltip>
      <Tooltip
        id="tooltip-html-list"
        content={
          <div>
            Custom HTML List
            <ul id="tooltip-custom-list">
              <li>
                <span id="tooltip-custom-list-element-0">You can</span>
              </li>
              <li>
                <span id="tooltip-custom-list-element-1">Use custom</span>
              </li>
              <li>
                <span id="tooltip-custom-list-element-2">HTML in</span>
              </li>
              <li>
                <span id="tooltip-custom-list-element-3">Your Tooltips!</span>
              </li>
            </ul>
          </div>
        }
      >
        <Button id="basic-beacon-button-html-list" onClick={() => null}>
          HTML with List
        </Button>
      </Tooltip>
    </ButtonGroup>
  );
};

TooltipContent.storyName = 'Tooltip with HTML content';

TooltipContent.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Tooltip"
      description="Tooltips with user-specified HTML content"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const TooltipText: Story = () => {
  return (
    <p className={'my-2'}>
      Basic example of adding a{' '}
      <Tooltip id="tooltip-default-text" content="Tooltips can be added to anything">
        <span tabIndex={0}>
          <b>tooltip</b>
        </span>
      </Tooltip>{' '}
      to a body of text.
    </p>
  );
};

TooltipText.storyName = 'Tooltip Using Different Triggers';

TooltipText.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Tooltip"
      description={
        <>
          Tooltips with text as the trigger
          <br />
          <strong>Note:</strong> Tooltips cannot be used on plain text. Wrap your plain text in a span (with tabIndex as
          0 for keyboard accessibility).
        </>
      }
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];

/**
 * Tooltip
 */
export const TooltipPortal: Story = () => {
  return (
    <Tooltip id="tooltip-default" content="Tooltip is rendered in a portal" portalContainer={document.body}>
      <Button id="basic-beacon-button" onClick={() => null}>
        Portal Example
      </Button>
    </Tooltip>
  );
};
TooltipPortal.storyName = 'Tooltip in Portal';
TooltipPortal.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Tooltip"
      description={<>Tooltips rendered in a portal are useful when dealing with z-index or overflow hidden issues</>}
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
