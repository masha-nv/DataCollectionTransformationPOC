import React from 'react';
import { render, screen } from '@testing-library/react';
import { fireEvent, waitFor } from '@testing-library/dom';
import { Tooltip } from './tooltip';
import { Direction, Theme } from '../modal-types';
import { enumKeys } from '../../stories';

describe('Tooltip', () => {
  it('default', () => {
    const { baseElement } = render(
      <Tooltip id="tooltip-default" content="Display Tooltip">
        <div>Child Text</div>
      </Tooltip>
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('light', () => {
    const { baseElement } = render(
      <Tooltip id="tooltip-light" content="Display Tooltip" theme={Theme.light}>
        <div>Child Text</div>
      </Tooltip>
    );
    expect(baseElement).toMatchSnapshot();
  });

  enumKeys(Direction).forEach((direction) => {
    it(`${direction} direction`, async () => {
      const document = Direction.bottom;
      const { baseElement } = render(
        <Tooltip id={`tooltip-${direction}`} content="Display Tooltip" direction={Direction[direction]}>
          <div id="childText">Child Text</div>
        </Tooltip>
      );
      const childElement = screen.getByText('Child Text');
      fireEvent.mouseOver(childElement);
      await waitForTooltipToAppear();

      expect(baseElement).toMatchSnapshot();
    });
  });

  it('displays when user enters/hovers reference element', async () => {
    const { baseElement } = render(
      <Tooltip id="tooltip-default" content="Display Tooltip">
        <div id="childText">Child Text</div>
      </Tooltip>
    );
    const childElement = screen.getByText('Child Text');
    fireEvent.mouseOver(childElement);
    await waitForTooltipToAppear();

    expect(baseElement).toMatchSnapshot();
  });

  it('hides when user exists/unhovers reference element', async () => {
    const { baseElement } = render(
      <Tooltip id="tooltip-default" content="Display Tooltip">
        <div id="childText">Child Text</div>
      </Tooltip>
    );
    const childElement = screen.getByText('Child Text');
    fireEvent.mouseOver(childElement);
    await waitForTooltipToAppear();
    fireEvent.mouseOut(childElement);
    expect(baseElement).toMatchSnapshot();
  });

  it('displays when user focuses reference element', async () => {
    const { baseElement } = render(
      <Tooltip id="tooltip-default" content="Display Tooltip">
        <div id="childText">Child Text</div>
      </Tooltip>
    );
    const childElement = screen.getByText('Child Text');
    fireEvent.focus(childElement);
    await waitForTooltipToAppear();
    expect(baseElement).toMatchSnapshot();
  });

  it('hides when reference element loses focus', async () => {
    const { baseElement } = render(
      <Tooltip id="tooltip-default" content="Display Tooltip">
        <div id="childText">Child Text</div>
      </Tooltip>
    );
    const childElement = screen.getByText('Child Text');
    fireEvent.focus(childElement);
    await waitForTooltipToAppear();
    fireEvent.blur(childElement);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders around container element (span or div) of text', () => {
    const { baseElement } = render(
      <Tooltip id="tooltip-default" content="Display Tooltip">
        <span>Child Text</span>
      </Tooltip>
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('fails to renders around plain text child ', () => {
    const consoleSpy = jest.spyOn(console, 'warn').mockImplementation();
    render(
      <Tooltip id="tooltip-default" content="Display Tooltip">
        Child Text
      </Tooltip>
    );
    expect(consoleSpy).toBeCalled();
  });

  it('displays in portal when user enters/hovers reference element', async () => {
    const { container } = render(
      <Tooltip id="tooltip-default" content="Display Tooltip" portalContainer={document.body}>
        <div id="childText">Child Text</div>
      </Tooltip>
    );
    const childElement = screen.getByText('Child Text');
    fireEvent.mouseOver(childElement);
    await waitForTooltipToAppear();

    // Check that the tooltip is rendered in the document body (i.e. in a portal)
    const tooltip = document.body.querySelector('#tooltip-default');
    expect(tooltip).not.toBeNull();
    expect(tooltip.textContent).toContain('Display Tooltip');

    // Make sure it is not within the original rendered container
    const tooltipInOriginalContainer = container.querySelector('#tooltip-default');
    expect(tooltipInOriginalContainer).toBeNull();
  });

  it('does not display in portal when user enters/hovers reference element', async () => {
    const { container } = render(
      <Tooltip id="tooltip-default" content="Display Tooltip">
        <div id="childText">Child Text</div>
      </Tooltip>
    );
    const childElement = screen.getByText('Child Text');
    fireEvent.mouseOver(childElement);
    await waitForTooltipToAppear();

    // Check that the tooltip is rendered in the document body (i.e. in a portal)
    const tooltip = document.body.querySelector('#tooltip-default');
    expect(tooltip).not.toBeNull();
    expect(tooltip.textContent).toContain('Display Tooltip');

    // Checks that it is within the original rendered container as well
    const tooltipInOriginalContainer = container.querySelector('#tooltip-default');
    expect(tooltipInOriginalContainer).not.toBeNull();
  });
});

const waitForTooltipToAppear = async () => {
  await waitFor(() => {
    expect(document.querySelector('[data-popper-reference-hidden="false"]')).toBeDefined();
  });
};
