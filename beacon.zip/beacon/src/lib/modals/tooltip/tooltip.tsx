import React, {
  CSSProperties,
  forwardRef,
  ReactElement,
  RefAttributes,
  RefCallback,
  SetStateAction,
  useRef,
  useState,
} from 'react';
import { usePopper } from 'react-popper';
import { mergeRefs } from 'use-callback-ref';
import { ReactRef } from 'use-callback-ref/dist/es5/types';
import { Direction, ITooltipProps, Theme, TooltipContentProps } from '../modal-types';
import './../modal.scss';
import ReactDOM from 'react-dom';

interface ITooltipNodeProps extends ITooltipProps {
  /**
   * The boolean to show the tooltip
   */
  isActive: boolean;
}

const setElementHandlers = (
  element: HTMLElement,
  childElement: ReactElement,
  onTriggerFunction: () => void,
  onTriggerOffFunction: () => void
) => {
  element.onmouseover = (event) => {
    childElement.props.onMouseOver?.(event);
    onTriggerFunction();
  };
  element.onmouseout = (event) => {
    childElement.props.onMouseOut?.(event);
    onTriggerOffFunction();
  };
  element.onfocus = (event) => {
    childElement.props.onFocus?.(event);
    onTriggerFunction();
  };
  element.onblur = (event) => {
    childElement.props.onBlur?.(event);
    onTriggerOffFunction();
  };
};

const TooltipNode = forwardRef<HTMLDivElement, ITooltipNodeProps>(
  ({ id, isActive, direction, content, theme, maxWidth }, ref) => {
    const activeClass = isActive ? '' : 'd-none';
    const themeClass = theme === Theme.light ? 'beacon-tooltip-light' : '';
    return (
      <div
        id={id}
        ref={ref}
        style={{ maxWidth: maxWidth }}
        className={`beacon-tooltip ${activeClass} beacon-tooltip-${direction} ${themeClass}`}
      >
        {content}
      </div>
    );
  }
);

TooltipNode.displayName = 'TooltipNode';

const TooltipContent = (props: TooltipContentProps) => {
  const {
    children,
    popperElement,
    popperStyles,
    popperAttributes,
    setArrowElement,
    arrowStyles,
    state,
    direction,
    arrowThemeClass,
    isTooltipActive,
    portalContainer,
  } = props;

  const tooltipContentStyles = {
    ref: popperElement,
    style: popperStyles,
    ...popperAttributes,
    ...(portalContainer && { className: 'beacon' }),
  };

  return (
    <div {...tooltipContentStyles}>
      <div
        ref={setArrowElement as RefCallback<HTMLElement>}
        style={arrowStyles}
        className={`beacon-popper-arrow beacon-popper-arrow-${state ? state.placement : direction} ${arrowThemeClass} ${
          isTooltipActive ? '' : 'd-none'
        }`}
      />
      {children}
    </div>
  );
};

const getTooltipTargetElementRefCallback = (
  element: HTMLElement,
  children: ReactElement,
  onTriggerTooltip: () => void,
  onTriggerOffTooltip: () => void,
  isTooltipActive: boolean,
  setReferenceElement: (value: SetStateAction<HTMLElement | null>) => void,
  id?: string | null
) => {
  if (element != null) {
    setElementHandlers(element, children, onTriggerTooltip, onTriggerOffTooltip);
    // if we don't have an ID, there's no way to link back to ourselves
    if (id != null) {
      element.setAttribute('aria-describedby', id);
    }
  }

  if (isTooltipActive) {
    setReferenceElement(element);
  }
};

export const Tooltip = ({
  id,
  direction = Direction.top,
  children,
  content,
  theme = Theme.dark,
  maxWidth = '200px',
  portalContainer,
  zIndex = 20,
}: ITooltipProps) => {
  const [referenceElement, setReferenceElement] = useState<HTMLElement | null>(null);
  const popperElement = useRef<HTMLDivElement>(null);

  let tooltipElement: HTMLElement | null = null;
  const [isTooltipActive, setIsTooltipActive] = useState(false);

  const [arrowElement, setArrowElement] = useState<HTMLElement | null>(null);

  const arrowThemeClass = theme === Theme.light ? 'beacon-popper-arrow-light' : '';

  const { styles, attributes, state, update } = usePopper(referenceElement, popperElement.current, {
    placement: direction,
    modifiers: [
      { name: 'offset', options: { offset: [0, 10] } },
      { name: 'arrow', options: { element: arrowElement } },
      { name: 'preventOverflow', options: { padding: 10 } },
    ],
  });

  const popperStyles: CSSProperties = {
    ...styles.popper,
    zIndex: zIndex,
  };

  const onTriggerTooltip = (): void => {
    setIsTooltipActive(true);
  };

  const onTriggerOffTooltip = (): void => {
    setIsTooltipActive(false);
  };

  const tooltipRefCallback = (element: HTMLElement) => {
    if (element != null) {
      tooltipElement = element;
    }
  };

  const tooltipNode = (
    <TooltipNode
      id={id}
      children={children}
      isActive={isTooltipActive}
      ref={tooltipRefCallback as RefCallback<HTMLElement>}
      direction={direction}
      content={content}
      theme={theme}
      maxWidth={maxWidth}
    />
  );

  const getTooltipContent = () => {
    return (
      <TooltipContent
        popperElement={popperElement}
        popperStyles={popperStyles}
        popperAttributes={attributes.popper}
        setArrowElement={setArrowElement}
        arrowStyles={styles.arrow}
        state={state}
        direction={direction}
        arrowThemeClass={arrowThemeClass}
        isTooltipActive={isTooltipActive}
        portalContainer={portalContainer}
      >
        {tooltipNode}
      </TooltipContent>
    );
  };

  if (React.isValidElement(children)) {
    const tooltipTargetElementRefCallback = (element: HTMLElement) => {
      getTooltipTargetElementRefCallback(
        element,
        children,
        onTriggerTooltip,
        onTriggerOffTooltip,
        isTooltipActive,
        setReferenceElement,
        id
      );
    };

    return (
      <>
        {React.cloneElement(children, {
          ref: mergeRefs([
            (children as RefAttributes<HTMLElement>).ref as ReactRef<HTMLElement>,
            tooltipTargetElementRefCallback as RefCallback<HTMLElement>,
          ]),
        })}
        {portalContainer ? ReactDOM.createPortal(getTooltipContent(), portalContainer) : getTooltipContent()}
      </>
    );
  } else {
    console.warn('Do not use tooltips on plain text, wrap your content in a span');
    return null;
  }
};
