import { State } from '@popperjs/core';
import { CSSProperties, Dispatch, ReactNode, RefObject, SetStateAction } from 'react';

export enum Direction {
  left = 'left',
  right = 'right',
  top = 'top',
  bottom = 'bottom',
  bottomEnd = 'bottom-end',
  bottomStart = 'bottom-start',
}

export enum Theme {
  light = 'light',
  dark = 'dark',
}

export interface ITooltipProps {
  /**
   * The ID of the element, for tooltips, this is optional
   */
  id?: string;
  /**
   * The orientation of the tooltip: left, right, top, bottom
   */
  direction?: Direction;
  /**
   * The text to be displayed on the tooltip
   */
  content: ReactNode;
  /**
   * The element the tooltip is describing
   */
  children: ReactNode;
  /**
   * The color scheme of the tooltip background
   */
  theme?: Theme;
  /**
   * The max-width css value of the tooltip ex: '200px' or '10em'
   */
  maxWidth?: string;
  /**
   * The DOM element to render the tooltip in a portal
   */
  portalContainer?: Element;
  /**
   * z-index of the tooltip popover
   */
  zIndex?: number;
}

export type TooltipContentProps = {
  children: ReactNode;
  popperElement: RefObject<HTMLDivElement>;
  popperStyles: CSSProperties;
  popperAttributes?: {
    [key: string]: string;
  };
  setArrowElement: Dispatch<SetStateAction<HTMLElement | null>>;
  arrowStyles: CSSProperties;
  state: State | null;
  direction: Direction;
  arrowThemeClass: string;
  isTooltipActive: boolean;
  portalContainer?: Element;
};
