import { Direction } from './modal-types';

export const calculateElementOffset = (element: HTMLElement) => {
  const rect = element.getBoundingClientRect();
  const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;
  const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
  return { top: rect.top + scrollTop, left: rect.left + scrollLeft };
};

export const positionTooltipAroundChild = (
  childElement: HTMLElement,
  renderElement: HTMLElement,
  direction: Direction
) => {
  const adjustedPosition = calculateElementOffset(childElement);
  switch (direction) {
    case Direction.top:
      renderElement.style.top = adjustedPosition.top - renderElement.offsetHeight + 'px';
      renderElement.style.left =
        adjustedPosition.left + childElement.offsetWidth / 2 - renderElement.offsetWidth / 2 + 'px';
      break;
    case Direction.right:
      renderElement.style.top =
        adjustedPosition.top + childElement.offsetHeight / 2 - renderElement.offsetHeight / 2 + 'px';
      renderElement.style.left = adjustedPosition.left + childElement.offsetWidth + 'px';
      break;
    case Direction.bottom:
      renderElement.style.top = adjustedPosition.top + childElement.offsetHeight + 'px';
      renderElement.style.left =
        adjustedPosition.left + childElement.offsetWidth / 2 - renderElement.offsetWidth / 2 + 'px';
      break;
    case Direction.left:
      renderElement.style.top =
        adjustedPosition.top + childElement.offsetHeight / 2 - renderElement.offsetHeight / 2 + 'px';
      renderElement.style.left = adjustedPosition.left - renderElement.offsetWidth + 'px';
      break;
  }
};
