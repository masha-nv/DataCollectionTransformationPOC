import React, { useState } from 'react';
import { fireEvent, render } from '@testing-library/react';
import { DepthSize, Modal, ModalSize } from './modal';
import { noop } from '../../utils';
import { ModalWithDifferentParent } from './modal.stories';

const ModalWithParentNode = () => {
  const [isOpen, setIsOpen] = useState(false);
  const toggleModal = () => {
    setIsOpen(!isOpen);
  };
  return (
    <div id="approot">
      <button onClick={toggleModal}>Open</button>
      {isOpen && (
        <Modal
          id="modal-id"
          title="Modal Title goes here"
          footer={<>Footer Content</>}
          onRequestClose={noop}
          appElementSelector="#approot"
        >
          <div>Modal Body</div>
        </Modal>
      )}
    </div>
  );
};

describe('Modal', () => {
  it('renders correctly with default props', () => {
    const { baseElement } = render(
      <Modal
        id="modal-id"
        title="Modal Title goes here"
        footer={<>Footer Content</>}
        onRequestClose={noop}
        appElementSelector="body"
      >
        <div>Modal Body</div>
      </Modal>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders small modal correctly', () => {
    const { baseElement } = render(
      <Modal
        id="modal-id"
        size={ModalSize.small}
        title="Modal Title goes here"
        footer={<>Footer Content</>}
        onRequestClose={noop}
        appElementSelector="body"
      >
        <div>Modal Body</div>
      </Modal>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders medium modal correctly', () => {
    const { baseElement } = render(
      <Modal
        id="modal-id"
        size={ModalSize.medium}
        title="Modal Title goes here"
        footer={<>Footer Content</>}
        onRequestClose={noop}
        appElementSelector="body"
      >
        <div>Modal Body</div>
      </Modal>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders large modal correctly', () => {
    const { baseElement } = render(
      <Modal
        id="modal-id"
        size={ModalSize.large}
        title="Modal Title goes here"
        footer={<>Footer Content</>}
        onRequestClose={noop}
        appElementSelector="body"
      >
        <div>Modal Body</div>
      </Modal>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders xl modal correctly', () => {
    const { baseElement } = render(
      <Modal
        id="modal-id"
        size={ModalSize.xl}
        title="Modal Title goes here"
        footer={<>Footer Content</>}
        onRequestClose={noop}
        appElementSelector="body"
      >
        <div>Modal Body</div>
      </Modal>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders low depth modal correctly', () => {
    const { baseElement } = render(
      <Modal
        id="modal-id"
        depth={DepthSize.low}
        title="Modal Title goes here"
        footer={<>Footer Content</>}
        onRequestClose={noop}
        appElementSelector="body"
      >
        <div>Modal Body</div>
      </Modal>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders normal depth modal correctly', () => {
    const { baseElement } = render(
      <Modal
        id="modal-id"
        depth={DepthSize.normal}
        title="Modal Title goes here"
        footer={<>Footer Content</>}
        onRequestClose={noop}
        appElementSelector="body"
      >
        <div>Modal Body</div>
      </Modal>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders high depth modal correctly', () => {
    const { baseElement } = render(
      <Modal
        id="modal-id"
        depth={DepthSize.high}
        title="Modal Title goes here"
        footer={<>Footer Content</>}
        onRequestClose={noop}
        appElementSelector="body"
      >
        <div>Modal Body</div>
      </Modal>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('raised onAfterOpen when the modal is opened', () => {
    const handler = jest.fn();
    render(
      <Modal
        id="modal-id"
        size={ModalSize.xl}
        title="Modal Title goes here"
        footer={<>Footer Content</>}
        onRequestClose={noop}
        onShow={handler}
        appElementSelector="body"
      >
        <div>Modal Body</div>
      </Modal>
    );

    expect(handler).toHaveBeenCalled();
  });

  it('raises onRequestClose when the close button is pressed', () => {
    const handler = jest.fn();
    const { baseElement } = render(
      <Modal
        id="modal-id"
        size={ModalSize.xl}
        title="Modal Title goes here"
        footer={<>Footer Content</>}
        onRequestClose={handler}
        appElementSelector="body"
      >
        <div>Modal Body</div>
      </Modal>
    );

    const btn = baseElement.querySelector('.modal-header button');

    fireEvent.click(btn);

    expect(handler).toHaveBeenCalled();
  });

  it('applies and removes aria labels to root elements correctly', () => {
    const { container } = render(<ModalWithParentNode />);

    const btn = container.querySelector('button');
    const rootDiv = container.querySelector('#approot');

    fireEvent.click(btn);

    expect(rootDiv.getAttribute('aria-hidden')).toEqual('true');
    fireEvent.click(btn);
    expect(rootDiv.getAttribute('aria-hidden')).not.toEqual('true');
  });

  it('attaches the modal to a different parent selector', () => {
    const onClose = jest.fn();
    const { container } = render(
      <ModalWithDifferentParent
        id="app-modal-id"
        title="Modal Title goes here"
        footer="This is the modal footer"
        onRequestClose={onClose}
      >
        This is a modal
      </ModalWithDifferentParent>
    );

    const btn = container.querySelector('button');
    const parentDiv = container.querySelector('#myCustomContainer');

    fireEvent.click(btn);

    expect(parentDiv).toMatchSnapshot();
  });
  it('raises onRequestClose when the escape key is clicked', () => {
    const handler = jest.fn();
    const { baseElement } = render(
      <Modal
        id="modal-id"
        size={ModalSize.xl}
        title="Modal Title goes here"
        footer={<>Footer Content</>}
        onRequestClose={handler}
        appElementSelector="body"
      >
        <div id="modalDiv">Modal Body</div>
      </Modal>
    );

    const modalContent = baseElement.querySelector('#modalDiv');

    fireEvent.keyDown(modalContent, {
      key: 'Escape',
      code: 'Escape',
      keyCode: 27,
      charCode: 27,
    });

    expect(handler).toHaveBeenCalled();
  });

  it('does not raise onRequestClose when the escape key is clicked when ESC key is disabled', () => {
    const handler = jest.fn();
    const { baseElement } = render(
      <Modal
        id="modal-id"
        size={ModalSize.xl}
        title="Modal Title goes here"
        footer={<>Footer Content</>}
        onRequestClose={handler}
        shouldCloseOnEsc={false}
        appElementSelector="body"
      >
        <div id="modalDiv">Modal Body</div>
      </Modal>
    );

    const modalContent = baseElement.querySelector('#modalDiv');

    fireEvent.keyDown(modalContent, {
      key: 'Escape',
      code: 'Escape',
      keyCode: 27,
      charCode: 27,
    });

    expect(handler).not.toHaveBeenCalled();
  });

  it('renders with customized heading', () => {
    const { baseElement } = render(
      <Modal
        id="modal-id"
        title="Modal Title goes here"
        footer={<>Footer Content</>}
        onRequestClose={noop}
        appElementSelector="body"
        headingType="h1"
      >
        <div>Modal Body</div>
      </Modal>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders correctly with enableVerticalScrolling', () => {
    const { baseElement } = render(
      <Modal
        id="modal-id"
        title="Modal Title goes here"
        footer={<>Footer Content</>}
        onRequestClose={noop}
        appElementSelector="body"
        enableVerticalScrolling
      >
        <div>Modal Body</div>
      </Modal>
    );

    expect(baseElement).toMatchSnapshot();
  });
});
