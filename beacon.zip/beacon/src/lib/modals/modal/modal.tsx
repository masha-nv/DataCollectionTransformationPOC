import React, { ReactNode, useState } from 'react';
import ReactModal from 'react-modal';
import { WithId } from '../../with-id';
import classNames from 'classnames';

import './modal.scss';
import { Heading, HeadingType } from '../../heading/heading';

export interface IModalProps extends WithId {
  /**
   * Modal Title
   */
  title: string;
  /**
   * Size of the Modal
   */
  size?: ModalSize;
  /**
   * Depth of the Modal
   */
  depth?: DepthSize;
  /**
   * Modal contents
   */
  children: ReactNode;
  /**
   * Modal Footer contents (for action items like buttons)
   */
  footer: ReactNode;
  /**
   * Close Modal on mouse clicks outside its area
   */
  shouldCloseOnOutsideClick?: boolean;
  /**
   * Close Modal on ESC key press
   */
  shouldCloseOnEsc?: boolean;
  /**
   * App root element querySelector to set aria-hidden="true" to when the modal is open to set invisible to screen reader
   */
  appElementSelector?: string;
  /**
   * Modal Opened Event handler
   */
  onShow?: () => void;
  /**
   * Request Close Event handler
   */
  onRequestClose: () => void;

  /* Function that will be called to get the parent element that the modal will be attached to. */
  parentSelector?(): HTMLElement;
  /**
   * The type of heading used for the title.
   */
  headingType?: HeadingType;

  /**
   * Enables Vertical scrolling for long content that extends beyond the screen. Can have negative
   * interactions with dropdowns and tooltips.
   */
  enableVerticalScrolling?: boolean;
}

export enum ModalSize {
  small = 'small',
  medium = 'medium',
  large = 'large',
  xl = 'xl',
}

export enum DepthSize {
  low = 'low',
  normal = 'normal',
  high = 'high',
}

export const Modal = ({
  id,
  title: modalTitle,
  size = ModalSize.medium,
  depth = DepthSize.normal,
  children,
  footer: footerContent,
  shouldCloseOnOutsideClick = false,
  shouldCloseOnEsc = true,
  appElementSelector,
  onShow: onAfterOpen,
  onRequestClose,
  parentSelector,
  headingType,
  enableVerticalScrolling = false,
}: IModalProps) => {
  const [appElementDOM, setAppElementDOM] = useState(
    appElementSelector ? document.querySelector<HTMLElement>(appElementSelector) : document.body
  );

  const rootClasses = classNames({
    'modal-root-sm': size === ModalSize.small,
    'modal-root-md': size === ModalSize.medium,
    'modal-root-lg': size === ModalSize.large,
    'modal-root-xl': size === ModalSize.xl,
  });

  const overlayClasses = classNames({
    'modal-overlay': true,
    'modal-depth-low': depth === DepthSize.low,
    'modal-depth-normal': depth === DepthSize.normal,
    'modal-depth-high': depth === DepthSize.high,
  });

  const labelElemendId = `${id}-modal-header`;

  return (
    <ReactModal
      id={id}
      isOpen={true}
      shouldCloseOnOverlayClick={shouldCloseOnOutsideClick}
      shouldCloseOnEsc={shouldCloseOnEsc}
      className={rootClasses}
      overlayClassName={overlayClasses}
      onAfterOpen={onAfterOpen}
      onRequestClose={onRequestClose}
      contentLabel={modalTitle}
      appElement={appElementDOM as HTMLElement}
      parentSelector={parentSelector}
    >
      <section className="beacon react-beacon">
        <header className="modal-header" id={labelElemendId}>
          <Heading headingType={headingType ? headingType : 'h2'} headingStyle="m">
            {modalTitle}
          </Heading>
          <button id={`${id}-close`} type="button" className="close" aria-label="Close" onClick={onRequestClose}>
            <span aria-hidden="true">&times;</span>
          </button>
        </header>
        <div className={enableVerticalScrolling ? 'modal-body vertical-scroll' : 'modal-body'}>{children}</div>
        <footer className="modal-footer">{footerContent}</footer>
      </section>
    </ReactModal>
  );
};
