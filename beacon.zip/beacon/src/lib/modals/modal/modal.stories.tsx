import { Story } from '@storybook/react';
import React, { ChangeEvent, useEffect, useState } from 'react';
import { Button, ButtonType } from '../../button/button';
import { Checkbox } from '../../forms/checkboxes/checkbox';
import { DatePicker } from '../../forms/date-picker/date-picker';
import { FormGroup } from '../../forms/form-group/form-group';
import { Label } from '../../forms/label/label';
import { RequiredFieldLegend } from '../../forms/required-field-legend/required-field-legend';
import { TextInput, TextInputType } from '../../forms/text-input/text-input';
import { hookFormUtils } from '../../forms/utils/hookform-utils';
import { Documentation, dropdownFromHeadingTypes, StoryBadge } from '../../stories';
import { Modal, ModalSize, DepthSize, IModalProps } from './modal';
import { FieldValues, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { action } from '@storybook/addon-actions';
import { Alert, AlertVariant } from '../../notifications/alert/alert';
import { Form } from '../../forms/form/form';
import '../../utilities.scss';
import { Select, SelectOption } from '../../forms/select/select';
import { TextArea } from '../../forms/text-area/text-area';
import { SelectSize } from '../../forms/select/select.types';
export default {
  component: Modal,
  title: 'Core Components/Modal, Popover, and Tooltip/Modal',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: {
      element: '.beacon', // popup is added against the body so a11yConfig doesnt capture Modal
    },
    docs: {
      source: { type: 'code' },
    },
  },
};

const whenToUse = (
  <p>
    Use modals when the sole attention of users is required. Users must interact with the modal window before they can
    return to the parent application.
  </p>
);
const accessibilityConsiderations = <p>Focus must remain on the modal boxes until it is closed.</p>;
const description =
  'Modals are window-like elements that overlay the main window, disabling the main window but keeping it visible.';

const condition = (ref: HTMLDivElement | null, setHidden: (arg0: boolean) => void) => {
  if (ref) {
    setHidden(ref.hasAttribute('aria-hidden'));
  }
};

const argTypes = {
  headingType: {
    control: dropdownFromHeadingTypes(),
    defaultValue: 'h2',
  },
};

export const BasicModal: Story<IModalProps> = ({ headingType }: IModalProps) => {
  const [open, setOpen] = useState(false);
  const [ref, setRef] = useState<HTMLDivElement | null>(null);
  const [hidden, setHidden] = useState(false);

  useEffect(() => condition(ref, setHidden), [open, ref]);
  return (
    <>
      <div id="app-root" ref={setRef}>
        <Button id="btn-xl" type={ButtonType.primary} onClick={() => setOpen(true)}>
          Open Modal
        </Button>
        <p>
          <strong>aria-hidden</strong>
          {`: ${hidden}`}
        </p>
      </div>
      {open && (
        <Modal
          id="app-modal-id"
          title="Modal Title goes here"
          footer="This is the modal footer"
          onRequestClose={() => setOpen(false)}
          appElementSelector="#app-root"
          headingType={headingType}
        >
          This is a modal
        </Modal>
      )}
    </>
  );
};
BasicModal.storyName = 'Modal';
BasicModal.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Basic Modal"
      description={description}
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
BasicModal.argTypes = argTypes;

export const ModalsAndTheAppElement: Story<IModalProps> = ({ headingType }: IModalProps) => {
  const [open, setOpen] = useState(false);
  const [ref, setRef] = useState<HTMLDivElement | null>(null);
  const [hidden, setHidden] = useState(false);

  useEffect(() => condition(ref, setHidden), [open, ref]);

  return (
    <>
      <div id="app-root" ref={setRef} className="border border-secondary p-2">
        <p>This is the app element</p>
        <p>
          <strong>aria-hidden</strong>
          {`: ${hidden}`}
        </p>
        <Button id="btn-xl" type={ButtonType.primary} onClick={() => setOpen(true)}>
          Open Modal
        </Button>
      </div>

      {open && (
        <Modal
          id="app-modal-id"
          title="Modal Title goes here"
          footer="This is the modal footer"
          onRequestClose={() => setOpen(false)}
          appElementSelector="#app-root"
          headingType={headingType}
        >
          This is a modal
        </Modal>
      )}
    </>
  );
};
ModalsAndTheAppElement.storyName = 'Hiding Page Content when Modal is Open';
ModalsAndTheAppElement.decorators = [
  (ComponentStory: Story) => (
    <article className="beacon">
      <h2>Modals and Page Content</h2>
      <p>
        It is important for screenreaders that the page content be hidden (via the <code>aria-hidden</code> attribute)
        when the modal is open. To accomplish this, react-beacon modals will be appended to the <code>body</code>{' '}
        element when they are made visible. They will be placed alongside the page content.{' '}
        <strong>
          Developers, however, need to specify the page content via the <code>appElementSelector</code> property.
        </strong>{' '}
        When specified, modals that become visible will update the app element to specify that it is being hidden by the
        modal and vice versa when the modal disappears.
      </p>
      <p>
        For example, the following sample app element (<code>#app-root</code>) will update when the corresponding modal
        is opened and closed.
      </p>
      <ComponentStory />
    </article>
  ),
];
ModalsAndTheAppElement.argTypes = argTypes;

export const ModalWithDifferentParent: Story<IModalProps> = ({ headingType }: IModalProps) => {
  const [open, setOpen] = useState(false);

  return (
    <>
      <div>
        <Button id="btn-xl" type={ButtonType.primary} onClick={() => setOpen(true)}>
          Open Modal
        </Button>
      </div>

      {open && (
        <Modal
          id="app-modal-id"
          title="Modal Title goes here"
          footer="This is the modal footer"
          onRequestClose={() => setOpen(false)}
          parentSelector={() => document.querySelector('#myCustomContainer') as HTMLElement}
          headingType={headingType}
        >
          This is a modal
        </Modal>
      )}
      <div id="myCustomContainer">This is the parent of the modal now</div>
    </>
  );
};
ModalWithDifferentParent.storyName = 'Modal with Different Parent Element';
ModalWithDifferentParent.decorators = [
  (ComponentStory: Story) => (
    <article className="beacon">
      <h2>Modals with Different Parent elements</h2>
      <p>
        Sometimes it's required to set a different parent container for the modal, this example shows how to do that.
      </p>
      <ComponentStory />
    </article>
  ),
];
ModalWithDifferentParent.argTypes = argTypes;

type StoryFormData = {
  firstName: string;
  lastName: string;
  email: string;
};

// eslint-disable-next-line no-template-curly-in-string
const requiredMessage = '${path} is required';

declare type ReferralForm = {
  referCaseTo: string;
  referralReason: string;
  detailedReferralReason: string;
};
export const ModalWithForm: Story<IModalProps> = ({ headingType }: IModalProps) => {
  const [isOpen, setIsOpen] = useState(false);

  // eslint-disable-next-line no-template-curly-in-string
  const requiredMessage = '${path} is required';
  /**
   * Object schema for the form
   */
  const schema = yup.object().shape({
    firstName: yup.string().required(requiredMessage).label('First Name'),
    lastName: yup.string().required(requiredMessage).label('Last Name'),
    email: yup.string().required(requiredMessage).email().label('Email'),
  });

  const openModal = () => {
    reset();
    setIsOpen(true);
  };
  const closeModal = () => {
    setIsOpen(false);
  };

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(schema) /* A valid yup schema*/,
  });
  const onSubmit = (data: StoryFormData) => {
    action('submit-action')(data);
    closeModal();
  };
  const onError = (data: FieldValues) => action('error-action')(data);

  const footerContent = (
    <>
      <Button id="cancel" type={ButtonType.secondary} onClick={closeModal}>
        Cancel
      </Button>
      <Button id="confirm" type={ButtonType.primary} onClick={handleSubmit(onSubmit, onError)}>
        Confirm Changes
      </Button>
    </>
  );
  return (
    <>
      <Button id="btn-open" type={ButtonType.primary} onClick={() => openModal()}>
        Update Profile
      </Button>{' '}
      {isOpen && (
        <Modal
          id="modal-id"
          size={ModalSize.medium}
          title="User Profile"
          footer={footerContent}
          onRequestClose={closeModal}
          appElementSelector="#root"
          headingType={headingType}
        >
          {errors && Object.keys(errors).length > 0 && (
            <Alert variant={AlertVariant.error}>Cannot save while there are validation errors</Alert>
          )}
          <Form onSubmit={handleSubmit(onSubmit, onError)}>
            <RequiredFieldLegend />
            <FormGroup id="fg-firstName" errorMessages={hookFormUtils.getErrorMessages(errors, 'firstName')}>
              <Label htmlFor="firstName" required>
                First Name
              </Label>
              <TextInput id="firstName" {...register('firstName')} required />
            </FormGroup>
            <FormGroup id="fg-lastName" errorMessages={hookFormUtils.getErrorMessages(errors, 'lastName')}>
              <Label htmlFor="lastName" required>
                Last Name
              </Label>
              <TextInput id="lastName" {...register('lastName')} required />
            </FormGroup>
            <FormGroup id="fg-email" errorMessages={hookFormUtils.getErrorMessages(errors, 'email')}>
              <Label htmlFor="email" required>
                Email
              </Label>
              <TextInput type={TextInputType.email} id="email" {...register('email')} required />
            </FormGroup>
          </Form>
        </Modal>
      )}
    </>
  );
};
ModalWithForm.storyName = 'Modal with Form Fields';
ModalWithForm.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Modal with Form"
      description={description}
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
ModalWithForm.argTypes = argTypes;

export const ModalWithFormLayout: Story<IModalProps> = ({ headingType }: IModalProps) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const openModal = () => {
    setIsModalOpen(true);
  };
  const closeModal = () => {
    setIsModalOpen(false);
  };

  const schema = yup.object().shape({
    referCaseTo: yup.string().required(requiredMessage).label('Refer Case To'),
    referralReason: yup.string().required(requiredMessage).label('Referral Reason'),
    detailedReferralReason: yup.string().required(requiredMessage).email().label('Detailed Reason for Referral'),
  });

  const {
    register,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema) /* A valid yup schema*/,
    defaultValues: {} as ReferralForm,
  });

  return (
    <div className="beacon">
      <div>
        <Button id="btn-xl" type={ButtonType.primary} onClick={() => openModal()}>
          Open Form Modal
        </Button>
      </div>
      {isModalOpen && (
        <Modal
          id="modal-depth-high-id"
          size={ModalSize.large}
          title="Modal with Form Layout"
          footer="Modal Footer"
          onRequestClose={() => closeModal()}
          appElementSelector="#root"
          headingType={headingType}
        >
          <form>
            <RequiredFieldLegend />
            <div className="d-flex">
              <div className="w-50 pr-4">
                <FormGroup id="fg-referCaseTo" errorMessages={hookFormUtils.getErrorMessages(errors, 'referCaseTo')}>
                  <Label htmlFor="referCaseTo" required>
                    Refer Case To
                  </Label>
                  <Select id="referCaseTo" required {...register('referCaseTo')} size={SelectSize.fill}>
                    <SelectOption value="001">Option 1</SelectOption>
                    <SelectOption value="002">Option 2</SelectOption>
                  </Select>
                </FormGroup>
              </div>
              <div className="w-50">
                <FormGroup
                  id="fg-referralReason"
                  errorMessages={hookFormUtils.getErrorMessages(errors, 'referralReason')}
                >
                  <Label htmlFor="referralReason" required>
                    Referral Reason
                  </Label>
                  <Select id="referralReason" required {...register('referCaseTo')} size={SelectSize.fill}>
                    <SelectOption value="101">Option 1</SelectOption>
                    <SelectOption value="102">Option 2</SelectOption>
                  </Select>
                </FormGroup>
              </div>
            </div>

            <FormGroup
              id="fg-detailedReferralReason"
              errorMessages={hookFormUtils.getErrorMessages(errors, 'detailedReferralReason')}
            >
              <Label htmlFor="detailedReferralReason" required>
                Detailed Referral Reason
              </Label>
              <TextArea id="detailedReferralReason" {...register('detailedReferralReason')} required />
            </FormGroup>
          </form>
        </Modal>
      )}
    </div>
  );
};
ModalWithFormLayout.storyName = 'Modal with Form Layout';
ModalWithFormLayout.argTypes = argTypes;

export const ModalSizes: Story<IModalProps> = ({ headingType }: IModalProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [size, setSize] = useState(ModalSize.medium);
  const [allowModalClose, setAllowModalClose] = useState(true);

  const openModal = (modalSize: ModalSize) => {
    setSize(modalSize);
    setIsOpen(true);
  };
  const closeModal = () => {
    if (!allowModalClose) {
      alert('Closing the Modal is not allowed');
      return;
    }
    setIsOpen(false);
  };
  const onCheckboxChange = (event: ChangeEvent<HTMLInputElement>) => {
    const target = event.target;
    const value = target.checked;

    setAllowModalClose(value);
  };

  const onModalShow = () => action('on-modal-open')();
  const footerContent = (
    <>
      <Button id="cancel" type={ButtonType.secondary} onClick={closeModal}>
        Cancel
      </Button>
      <Button id="confirm" type={ButtonType.primary} onClick={closeModal}>
        Confirm Changes
      </Button>
    </>
  );
  return (
    <>
      <Button id="btn-sm" type={ButtonType.primary} onClick={() => openModal(ModalSize.small)}>
        Open Small
      </Button>{' '}
      <Button id="btn-md" type={ButtonType.primary} onClick={() => openModal(ModalSize.medium)}>
        Open Medium
      </Button>{' '}
      <Button id="btn-lg" type={ButtonType.primary} onClick={() => openModal(ModalSize.large)}>
        Open Large
      </Button>{' '}
      <Button id="btn-xl" type={ButtonType.primary} onClick={() => openModal(ModalSize.xl)}>
        Open XL
      </Button>
      {isOpen && (
        <Modal
          id="modal-id"
          size={size}
          title="Modal Title goes here"
          footer={footerContent}
          onShow={onModalShow}
          onRequestClose={closeModal}
          appElementSelector="#root"
          headingType={headingType}
        >
          <div>Modal body goes here.</div>
          <div className="pb-12">
            <Checkbox
              id="chk-allow"
              onChange={onCheckboxChange}
              checked={allowModalClose}
              label={' Allow closing the modal?'}
            />
          </div>
          <div>
            <Label htmlFor="date-picker-id">Date:</Label>
            <DatePicker id="date-picker-id" name="date-picker-name" />
          </div>
        </Modal>
      )}
    </>
  );
};
ModalSizes.storyName = 'Modal Sizes';
ModalSizes.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Modal Sizes"
      description={description}
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
ModalSizes.argTypes = argTypes;

export const ModalWithDifferentDepths: Story<IModalProps> = ({ headingType }: IModalProps) => {
  const [isModalOpen, setIsModalOpen] = useState([false, false, false]);

  const closeModal = (index: number) => {
    const newArr = [...isModalOpen];
    newArr[index] = false;
    setIsModalOpen(newArr);
  };

  const openModals = () => {
    setIsModalOpen([true, true, true]);
  };

  return (
    <>
      <div>
        <Button id="btn-xl" type={ButtonType.primary} onClick={() => openModals()}>
          Open Modals
        </Button>
      </div>
      {isModalOpen[0] && (
        <Modal
          id="modal-depth-high-id"
          size={ModalSize.small}
          depth={DepthSize.high}
          title="Modal with High Depth"
          footer="This is the modal footer"
          onRequestClose={() => closeModal(0)}
          appElementSelector="#root"
          headingType={headingType}
        >
          Modal with high depth
        </Modal>
      )}
      {isModalOpen[1] && (
        <Modal
          id="modal-depth-norml-id"
          size={ModalSize.medium}
          title="Modal with Normal Depth"
          footer="This is the modal footer"
          onRequestClose={() => closeModal(1)}
          appElementSelector="#root"
          headingType={headingType}
        >
          Modal with normal depth
        </Modal>
      )}
      {isModalOpen[2] && (
        <Modal
          id="modal-depth-low-id"
          size={ModalSize.large}
          depth={DepthSize.low}
          title="Modal with Low Depth"
          footer="This is the modal footer"
          onRequestClose={() => closeModal(2)}
          appElementSelector="#root"
          headingType={headingType}
        >
          Modal with low depth
        </Modal>
      )}
    </>
  );
};
ModalWithDifferentDepths.storyName = 'Stacking Modals';
ModalWithDifferentDepths.decorators = [
  (ComponentStory: Story) => (
    <article className="beacon">
      <h2>Modals with different depths</h2>
      <p>Sometimes when there are multiple modals it's required to open one on top.</p>
      <ComponentStory />
    </article>
  ),
];
ModalWithDifferentDepths.argTypes = argTypes;

export const VerticalScrolling: Story<IModalProps> = ({ headingType }: IModalProps) => {
  const [open, setOpen] = useState(false);

  return (
    <>
      <div>
        <Button id="btn-xl" type={ButtonType.primary} onClick={() => setOpen(true)}>
          Open Modal
        </Button>
      </div>
      {open && (
        <Modal
          id="app-modal-id"
          title="Vertical Scrolling"
          footer="This is the modal footer"
          onRequestClose={() => setOpen(false)}
          appElementSelector="#root"
          headingType={headingType}
          enableVerticalScrolling={true}
        >
          {[...Array(50)].map((x, i) => {
            return <div>{i}</div>;
          })}
        </Modal>
      )}
    </>
  );
};
VerticalScrolling.storyName = 'Vertical Scrolling';
VerticalScrolling.decorators = [
  (ComponentStory: Story) => (
    <article className="beacon">
      <h2>Vertical Scrolling</h2>
      <p>
        When the content of a modal is too long to fit in the modal, the enableVerticalScrolling property can be enabled
        to add a vertical scrollbar. This option can have negative interactions with dropdowns and tooltips that
        normally want to extend beyond the container.
      </p>
      <ComponentStory />
    </article>
  ),
];
VerticalScrolling.argTypes = argTypes;
