import { yupResolver } from '@hookform/resolvers/yup';
import { Meta, Story } from '@storybook/react';
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import * as yup from 'yup';
import { Button, ButtonType } from '../../button/button';
import { ButtonGroup, ButtonGroupDirection } from '../../button/button-group';
import { SubmitButton } from '../../button/submit-button';
import { FormGroup } from '../../forms/form-group/form-group';
import { Form } from '../../forms/form/form';
import { Label } from '../../forms/label/label';
import { TextArea } from '../../forms/text-area/text-area';
import { Documentation, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { noop } from '../../utils';
import { Direction, Theme } from '../modal-types';
import { Modal } from '../modal/modal';
import { Popover } from './popover';

export default {
  component: Popover,
  title: 'Core Components/Modal, Popover, and Tooltip/Popover',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
  },
} as Meta;

const whenToUse = (
  <>
    <p>Popovers should be used to supply additonal information about some element on the page.</p>
    <ul>
      <li>
        <strong className="beacon-icon-success">Do </strong>use when you want to include information such as forms and
        links without disrupting users’ workflow
      </li>
    </ul>
    <p>
      <b>Note:</b> Popovers cannot be used on plain text. Wrap your plain text in a span
    </p>
  </>
);

/**
 * Popover
 */
export const BasicExample: Story = () => {
  const content = (
    <Button id="another-button" onClick={noop}>
      {' '}
      Another Button
    </Button>
  );
  return (
    <div>
      <Popover id="popup-default" content="Basic Popup has a dark theme and top direction with max width of 200px">
        <Button id="basic-beacon-button" onClick={noop}>
          Basic Button Example
        </Button>
      </Popover>
    </div>
  );
};
BasicExample.storyName = 'Popover';
BasicExample.decorators = [
  (Story: Story) => (
    <Documentation
      name="Popover"
      description="Popovers are similar to tooltips, except popovers appear when users click on an element. Popovers can also contain
      more content than a tooltip, including forms, links, etc."
      whenToUse={whenToUse}
    >
      <Story />
    </Documentation>
  ),
];
export const ClickingOutside: Story = () => {
  const [modalOpen, setModalOpen] = useState(false);

  return (
    <div>
      <Popover
        id="popover-click-outside"
        content={
          <>
            <p>This popover will close when clicking outside of it.</p>
            <Button id="btn" onClick={() => setModalOpen(true)}>
              Open Modal
            </Button>
            {modalOpen && (
              <Modal
                id="modal"
                title="Modal Title"
                appElementSelector="body"
                onRequestClose={() => setModalOpen(false)}
                footer="nothing here"
              >
                <p>Interacting with this nested modal will not close the popover.</p>
              </Modal>
            )}
          </>
        }
        shouldCloseOnOutsideClick
      >
        <Button id="open-popover-btn" onClick={noop} type={ButtonType.primary}>
          Open Popover
        </Button>
      </Popover>
    </div>
  );
};
ClickingOutside.storyName = 'Popover Closed by Clicking Outside';
ClickingOutside.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Clicking Outside"
      description={
        <p>
          By default, popovers do <strong>not</strong> close when clicking outside of them and the reference element.
          However, they can be made to do so with the <code>shouldCloseOnOutsideClick</code> property.
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const PopoverDirection: Story = () => {
  return (
    <ButtonGroup direction={ButtonGroupDirection.LEFT}>
      <Popover id="popover-top" direction={Direction.top} content="This is a TOP popover!">
        <Button id="basic-beacon-button-top" onClick={noop}>
          TOP
        </Button>
      </Popover>
      <Popover id="popover-right" direction={Direction.right} content="This is a RIGHT popover!">
        <Button id="basic-beacon-button-right" onClick={noop}>
          RIGHT
        </Button>
      </Popover>
      <Popover id="popover-bottom" direction={Direction.bottom} content="This is a BOTTOM popover!">
        <Button id="basic-beacon-button-bottom" onClick={noop}>
          BOTTOM
        </Button>
      </Popover>
      <Popover id="popover-left" direction={Direction.left} content="This is a LEFT popover!">
        <Button id="basic-beacon-button-left" onClick={noop}>
          LEFT
        </Button>
      </Popover>
    </ButtonGroup>
  );
};

PopoverDirection.storyName = 'Popover Displaying in Different Directions';

PopoverDirection.decorators = [
  (Story: Story) => (
    <Documentation name="Popover" description="Popovers with user-specified direction" whenToUse={whenToUse}>
      <Story />
    </Documentation>
  ),
];

export const PopoverTheme: Story = () => {
  return (
    <ButtonGroup direction={ButtonGroupDirection.LEFT}>
      <Popover id="popover-dark" content="This is a DARK popover!">
        <Button id="basic-beacon-button-dark" onClick={noop}>
          Dark
        </Button>
      </Popover>
      <Popover id="popover-light" content="This is a LIGHT popover!" theme={Theme.light}>
        <Button id="basic-beacon-button-light" onClick={noop}>
          Light
        </Button>
      </Popover>
    </ButtonGroup>
  );
};

PopoverTheme.storyName = 'Popover Light and Dark Themes';

PopoverTheme.decorators = [
  (Story: Story) => (
    <Documentation name="Popover" description="with user-specified theme" whenToUse={whenToUse}>
      <Story />
    </Documentation>
  ),
];

export const PopoverContent: Story = () => {
  const schema = yup.object().shape({
    text: yup.string().required(),
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    // mode: 'onTouched' ,
    resolver: yupResolver(schema) /* A valid yup schema*/,
  });

  const onSubmit = (data: { test: string }) =>
    alert(`This form has been with submitted with data ${JSON.stringify(data)}`);

  return (
    <ButtonGroup direction={ButtonGroupDirection.LEFT}>
      <Popover
        id="popover-html-badge"
        content={
          <div>
            <a href="#/modals">Learn More</a> <i className="fas fa-external-link-alt beacon-icon-small"></i> about this
            new feature in ELIS
          </div>
        }
      >
        <Button id="basic-beacon-button-html-badge" onClick={noop}>
          Popover with HTML
        </Button>
      </Popover>
      <Popover
        id="popover-html-list"
        title="Popover Form"
        theme={Theme.light}
        content={
          <Form onSubmit={handleSubmit(onSubmit)} className="pl-2">
            <FormGroup id="form-group-text">
              <Label htmlFor="textarea">Enter text:</Label>
              <TextArea id="textarea" placeholder="Your text here" {...register('text')} />
            </FormGroup>
            <ButtonGroup>
              <Button id="clear-btn" type={ButtonType.secondary} onClick={() => reset()}>
                Clear
              </Button>
              <SubmitButton id="save-btn">Submit</SubmitButton>
            </ButtonGroup>{' '}
          </Form>
        }
      >
        <Button id="basic-beacon-button-html-list" onClick={noop}>
          Open Popover with Interactive Content
        </Button>
      </Popover>
    </ButtonGroup>
  );
};

PopoverContent.storyName = 'Popover with HTML content';

PopoverContent.decorators = [
  (Story: Story) => (
    <Documentation
      name="Popovers with custom HTML content"
      description={
        <>
          Popovers also support custom HTML content, including formatted text or forms. However, if the text content
          (including labels and buttons) is complicated and/or does not properly describe the entire popover, then
          developers should use the <code>title</code> property to add an appropriate title.
        </>
      }
      whenToUse={whenToUse}
    >
      <Story />
    </Documentation>
  ),
];
