import React, {
  CSSProperties,
  forwardRef,
  ReactElement,
  RefAttributes,
  RefCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import { mergeRefs } from 'use-callback-ref';
import { usePopper } from 'react-popper';
import { Direction, ITooltipProps, Theme } from '../modal-types';
import './../modal.scss';
import useOnClickOutside from 'use-onclickoutside';
import { ReactRef } from 'use-callback-ref/dist/es5/types';

const resolveThemeArrowClassName = (theme: string) => {
  return theme === Theme.light ? 'beacon-popper-arrow-light' : '';
};

const isClickedOutsidePopover = (shouldCloseOnOutsideClick: boolean, referenceElement: HTMLElement | null, e: Event) =>
  shouldCloseOnOutsideClick &&
  !referenceElement?.contains(e.target as Node) &&
  (e.target as HTMLElement).closest('.modal-overlay') === null;

// Tab back to target element if shift-tabbed. prevents the default behavior of going to the bottom of doc
const handleKeyboardInputs =
  (referenceElement: HTMLElement | null, setIsPopoverActive: React.Dispatch<React.SetStateAction<boolean>>) =>
  (event: React.KeyboardEvent) => {
    if (event.shiftKey && event.key === 'Tab') {
      event.preventDefault();
      referenceElement?.focus();
    }

    if (event.key === 'Escape') {
      referenceElement?.focus();
      setIsPopoverActive(false);
    }
  };

const setElementHandlers = (
  element: HTMLElement,
  childElement: ReactElement,
  onTriggerFunction: () => void,
  onBlur: () => void,
  isPopoverActive: boolean,
  popoverElement: HTMLDivElement | null
) => {
  element.onclick = (event) => {
    childElement.props.onClick?.(event);
    onTriggerFunction();
  };

  element.onblur = (event) => {
    childElement.props.onBlur?.(event);
    onBlur();
  };

  // Focus on popover content if tabbed from target element while popover is open
  element.onkeydown = (event) => {
    if (!event.shiftKey && event.key === 'Tab' && isPopoverActive) {
      event.preventDefault();
      popoverElement?.focus();
    }
  };
};

interface IPopoverNodeProps extends ITooltipProps {
  /**
   * The boolean to show the popover
   */
  isActive: boolean;
  handleKeyboardInputs: (e: React.KeyboardEvent) => void;
  title?: string;
}

export interface IPopoverProps extends ITooltipProps {
  /**
   * Close Modal on mouse clicks outside its area
   */
  shouldCloseOnOutsideClick?: boolean;
  /**
   * Title of the popover
   */
  title?: string;
}

const PopoverNode = forwardRef(
  (
    { id, content, title, theme, maxWidth, handleKeyboardInputs }: IPopoverNodeProps,
    ref: React.ForwardedRef<HTMLDivElement>
  ) => {
    const themeClass = theme === Theme.light ? 'beacon-tooltip-light' : '';
    const elementRef = useRef<HTMLDivElement>(null);

    useImperativeHandle(ref, () => elementRef.current as HTMLDivElement);

    useEffect(() => {
      elementRef.current?.focus();
    }, []);

    // Do not allow shift Tab to go back to element if tabbed inside of popover container
    const stopShiftTabProp = (keyEvent: React.KeyboardEvent) => {
      if (keyEvent.shiftKey && keyEvent.key === 'Tab') {
        keyEvent.stopPropagation();
      }
    };

    return (
      <div
        aria-label={title}
        onKeyDown={handleKeyboardInputs}
        tabIndex={0}
        data-testid={`${id}-test`}
        id={id}
        ref={elementRef}
        style={{ maxWidth }}
        className={`beacon-popover ${themeClass}`}
      >
        <div onKeyDown={stopShiftTabProp}>{content}</div>
      </div>
    );
  }
);

export const Popover = ({
  id,
  direction = Direction.top,
  children,
  content,
  theme = Theme.dark,
  maxWidth = '200px',
  shouldCloseOnOutsideClick = false,
  title,
}: IPopoverProps) => {
  const [referenceElement, setReferenceElement] = useState<HTMLElement | null>(null);
  const [arrowElement, setArrowElement] = useState<HTMLDivElement | null>(null);
  const [popoverElement, setPopoverElement] = useState<HTMLDivElement | null>(null);
  const [isPopoverActive, setIsPopoverActive] = useState(false);
  const popperElement = useRef<HTMLDivElement>(null);

  useOnClickOutside(popperElement, (e) => {
    if (isClickedOutsidePopover(shouldCloseOnOutsideClick, referenceElement, e)) {
      setIsPopoverActive(false);
    }
  });

  const onBlur = () => {
    /**
     * setTimeout used here because in some scenarios,
     * the document is activeElement until React creates the
     * popover elements.
     */
    setTimeout(() => {
      if (
        shouldCloseOnOutsideClick &&
        !popperElement.current?.contains(document.activeElement) &&
        !referenceElement?.contains(document.activeElement as Node) &&
        (document.activeElement as HTMLElement).closest('.modal-overlay') === null
      ) {
        setIsPopoverActive(false);
      }
    });
  };

  const { styles, attributes, state } = usePopper(referenceElement, popperElement.current, {
    placement: direction,
    modifiers: [
      { name: 'offset', options: { offset: [0, 10] } },
      { name: 'arrow', options: { element: arrowElement } },
      { name: 'preventOverflow', options: { padding: 20 } },
    ],
  });

  const popperStyles: CSSProperties = {
    ...styles.popper,
    zIndex: 1,
  };

  const onTriggerPopover = (): void => {
    setIsPopoverActive((prev) => !prev);
  };

  const arrowThemeClass = resolveThemeArrowClassName(theme);

  const popoverNode = (
    <div ref={popperElement} style={popperStyles} {...attributes.popper} onBlur={onBlur}>
      <div
        ref={setArrowElement as RefCallback<HTMLDivElement>}
        style={styles.arrow}
        className={`beacon-popper-arrow beacon-popper-arrow-${state ? state.placement : direction} ${arrowThemeClass}`}
      ></div>
      <PopoverNode
        id={id}
        ref={setPopoverElement as RefCallback<HTMLDivElement>}
        children={children}
        isActive={isPopoverActive}
        title={title}
        content={content}
        theme={theme}
        maxWidth={maxWidth}
        handleKeyboardInputs={handleKeyboardInputs(referenceElement, setIsPopoverActive)}
      />
    </div>
  );

  if (React.isValidElement(children)) {
    const popoverTargetElementRefCallback = (element: HTMLElement) => {
      if (element != null) {
        setElementHandlers(element, children, onTriggerPopover, onBlur, isPopoverActive, popoverElement);
        setReferenceElement(element);
      }
    };

    const refArray: ReactRef<HTMLElement>[] = [popoverTargetElementRefCallback as RefCallback<HTMLElement>];
    const childRef = (children as RefAttributes<HTMLElement>).ref;
    if (childRef) {
      refArray.push(childRef);
    }

    return (
      <>
        {React.cloneElement(children, {
          ref: mergeRefs(refArray),
        })}
        {isPopoverActive && popoverNode}
      </>
    );
  } else {
    console.warn('Do not use Popover on plain text, wrap your content in a span');
    return null;
  }
};
