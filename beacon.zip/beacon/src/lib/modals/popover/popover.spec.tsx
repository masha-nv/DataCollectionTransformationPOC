import { fireEvent } from '@testing-library/dom';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import React, { createRef } from 'react';
import { Button } from '../../button/button';
import { noop } from '../../utils';
import { Direction, Theme } from '../modal-types';
import { Popover } from './popover';
import { ClickingOutside } from './popover.stories';

describe('Popover Component', () => {
  it('renders default popover', async () => {
    const { baseElement } = render(getDefaultPopoverWithThemeDirection());
    const childElement = screen.getByText('Child Text');
    fireEvent.click(childElement);
    await screen.findByText('Display Popover');
    expect(baseElement).toMatchSnapshot();
  });

  it('renders light popover', async () => {
    const { baseElement } = render(getDefaultPopoverWithThemeDirection(Theme.light));
    const childElement = screen.getByText('Child Text');
    fireEvent.click(childElement);
    await screen.findByText('Display Popover');
    expect(baseElement).toMatchSnapshot();
  });

  it('closes default popover with click event', () => {
    const { baseElement } = render(getDefaultPopoverWithThemeDirection());

    const childElement = screen.getByText('Child Text');
    fireEvent.click(childElement);
    fireEvent.click(childElement);
    expect(baseElement).toMatchSnapshot();
  });
  it('keeps popover open when another element is focused and clicked', async () => {
    const { baseElement } = render(
      <div>
        <Popover id="popover-default" content="Display Popover">
          <Button id="popover-button" onClick={noop}>
            Popover Button
          </Button>
        </Popover>
        <Button
          id="outside-button"
          onClick={() => {
            return;
          }}
        >
          Outside Button
        </Button>
      </div>
    );

    const popOverButtonElement = screen.getByText('Popover Button');
    const outsideButtonElement = screen.getByText('Outside Button');

    fireEvent.click(popOverButtonElement);
    await screen.findByText('Display Popover');
    fireEvent.click(outsideButtonElement);
    expect(baseElement).toMatchSnapshot();
  });

  it('switches focus to popover container when target element is clicked', async () => {
    const { baseElement } = render(getPopoverWithButtonTargetElemet());

    const popOverTargetElement = screen.getByText('Popover Button');
    fireEvent.click(popOverTargetElement);
    const popoverContainerElement = await screen.findByTestId('popover-default-test');
    expect(document.activeElement).toEqual(popoverContainerElement);
    expect(baseElement).toMatchSnapshot();
  });

  it('returns focus back to popover target after shift tab is pressed from popover container', async () => {
    const id = 'popover-default';
    render(getPopoverWithButtonTargetElemet());

    const popOverTargetElement = screen.getByText('Popover Button');
    fireEvent.click(popOverTargetElement);
    await screen.findByTestId('popover-default-test');
    userEvent.tab({ shift: true });
    expect(document.activeElement).toEqual(popOverTargetElement);
  });

  it('closes popover and returns focus to popover target if escape key is pressed inside of popover', () => {
    const { baseElement } = render(getPopoverWithButtonTargetElemet());

    const popOverTargetElement = screen.getByText('Popover Button');
    fireEvent.click(popOverTargetElement);
    const popoverContainerElement = screen.getByTestId('popover-default-test');
    fireEvent.keyDown(popoverContainerElement, {
      key: 'Escape',
    });
    expect(document.activeElement).toEqual(popOverTargetElement);
    expect(baseElement).toMatchSnapshot();
  });

  it('Does not return focus to target element if shift tabbed inside of the popover container', async () => {
    render(getPopoverWithButtonTargetElemet());

    const popOverTargetElement = screen.getByText('Popover Button');
    fireEvent.click(popOverTargetElement);
    const popupContainerInnerElement = screen.getByTestId('popup-inner-content');
    const popoverContainerElement = await screen.findByTestId('popover-default-test');
    popupContainerInnerElement.focus();
    userEvent.tab({ shift: true });
    expect(document.activeElement).toEqual(popoverContainerElement);
  });

  it('moves focus to popout container if tab is pressed from target element', async () => {
    render(getPopoverWithButtonTargetElemet());

    const popOverTargetElement = screen.getByText('Popover Button');
    fireEvent.click(popOverTargetElement);
    const popoverContainerElement = await screen.findByTestId('popover-default-test');
    popOverTargetElement.focus();
    userEvent.tab();
    expect(document.activeElement).toEqual(popoverContainerElement);
  });

  it('Does not focus on Popover container if shift tabbed from target element', async () => {
    render(getPopoverWithButtonTargetElemet());

    const popOverTargetElement = screen.getByText('Popover Button');
    fireEvent.click(popOverTargetElement);
    const popoverContainerElement = await screen.findByTestId('popover-default-test');
    popOverTargetElement.focus();
    userEvent.tab({ shift: true });
    expect(document.activeElement).not.toEqual(popoverContainerElement);
  });

  it('attempts to render popover on a plain text element and throws warning', () => {
    const consoleSpy = jest.spyOn(console, 'warn').mockImplementation();
    render(
      <Popover id="popover-default" content="Display Popover">
        Child Text
      </Popover>
    );
    expect(consoleSpy).toBeCalled();
  });

  it('does not remove child refs', () => {
    const ref = createRef<HTMLButtonElement>();

    render(
      <Popover id="popover-default" content="Display Popover">
        <button ref={ref}>CLICK</button>
      </Popover>
    );
    expect(ref.current).not.toBe(null);
  });

  describe('configured to close when clicking outside', () => {
    it('closes', async () => {
      const { baseElement, getByText, findByText } = render(<Outside />);

      fireEvent.click(getByText('Open Popover'));
      await findByText('Display Popover');
      fireEvent.mouseDown(getByText('Not in Popover'));

      expect(baseElement).toMatchSnapshot();
    });

    it('closes on popover blur', async () => {
      const { queryByText, findByText } = render(<Outside />);

      fireEvent.click(queryByText('Open Popover'));
      await findByText('Display Popover');
      queryByText('Not in Popover').focus();

      await waitFor(() => expect(queryByText('Display Popover')).toBeNull());
    });

    it('closes on reference element blur', async () => {
      const { findByText, queryByText } = render(<Outside />);

      const referenceElement = queryByText('Open Popover');
      fireEvent.click(referenceElement);
      await findByText('Display Popover');
      referenceElement.focus();
      queryByText('Not in Popover').focus();

      await waitFor(() => expect(queryByText('Display Popover')).toBeNull());
    });

    it('closes on reference element click when open', async () => {
      const { findByText, queryByText } = render(<Outside />);

      const referenceElement = queryByText('Open Popover');
      fireEvent.click(referenceElement);
      await findByText('Display Popover');
      fireEvent.click(referenceElement);

      await waitFor(() => expect(queryByText('Display Popover')).toBeNull());
    });

    it('does not close when nested modal is open', async () => {
      const { baseElement } = render(<ClickingOutside />);

      fireEvent.click(baseElement.querySelector('#open-popover-btn'));
      const openModalButton = await screen.findByText('Open Modal');
      fireEvent.click(openModalButton);
      fireEvent.mouseDown(screen.getByText('Modal Title'));

      expect(baseElement).toMatchSnapshot();
    });
  });
});

const getDefaultPopoverWithThemeDirection = (theme?: Theme, direction?: Direction) => {
  return (
    <Popover id="popover-default" content="Display Popover" theme={theme} direction={direction}>
      <div>Child Text</div>
    </Popover>
  );
};

const getPopoverWithButtonTargetElemet = () => {
  return (
    <Popover id="popover-default" content={<button data-testid="popup-inner-content">Popup container content</button>}>
      <Button
        id="popover-button"
        onClick={() => {
          return;
        }}
      >
        Popover Button
      </Button>
    </Popover>
  );
};

const Outside = () => {
  return (
    <div>
      <Popover id="popover-default" content="Display Popover" shouldCloseOnOutsideClick>
        <Button id="popover-button" onClick={noop}>
          Open Popover
        </Button>
      </Popover>
      <button>Not in Popover</button>
    </div>
  );
};
