import React from 'react';
import { render } from '@testing-library/react';
import { Card, CardVariant } from './card';

describe('Card component', () => {
  it('renders default card', () => {
    const { baseElement } = render(<Card id="card-default">Default card</Card>);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders card with title', () => {
    const { baseElement } = render(
      <Card id="card-title" title="Title for Card">
        Card with Title
      </Card>
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('renders card with footer', () => {
    const { baseElement } = render(
      <Card id="card-footer" footer="Footer for Card">
        Card with Footer
      </Card>
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('renders card without padding', () => {
    const { baseElement } = render(
      <Card id="card-theme" noPadding>
        Card with Gray Theme
      </Card>
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('renders card with gray variant', () => {
    const { baseElement } = render(
      <Card id="card-theme" variant={CardVariant.gray}>
        Card with Gray Theme
      </Card>
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('renders card with suggestion variant', () => {
    const { baseElement } = render(
      <Card id="card-theme" variant={CardVariant.suggestion}>
        Card with Suggestion Variant
      </Card>
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('renders card with title and customized heading', () => {
    const { baseElement } = render(
      <Card id="card-title" title="Title for Card" headingType="h1" headingStyle="m">
        Card with Title
      </Card>
    );
    expect(baseElement).toMatchSnapshot();
  });
});
