import { forwardRef, ReactNode } from 'react';
import { WithId } from '../with-id';
import innerText from 'react-innertext';
import './card.scss';
import { Heading, HeadingType, HeadingStyle } from '../heading/heading';
import classNames from 'classnames';

export interface ICardProps extends WithId {
  /**
   * The content displayed on top of the card in a header tag.
   */
  title?: ReactNode;
  /**
   * The content displayed as the body of the card.
   */
  children: ReactNode;
  /**
   * The content displayed at the bottom of the card.
   */
  footer?: ReactNode;
  /**
   * The color scheme of the card background.
   */
  variant?: CardVariant;
  /**
   * The type of heading used for the title.
   */
  headingType?: HeadingType;
  /**
   * The heading style used for the title.
   */
  headingStyle?: HeadingStyle;

  /**
   * Remove padding around the card body. Defaults to false.
   */
  noPadding?: boolean;
}

export enum CardVariant {
  light = 'light',
  gray = 'gray',
  suggestion = 'suggestion',
}

export const Card = forwardRef<HTMLDivElement, ICardProps>(({ variant = CardVariant.light, ...props }, ref) => {
  const sectionTitle = props.title ? innerText(props.title) : `Section ${props.id}`;
  const cardClasses = classNames('card', {
    'card-gray': variant === CardVariant.gray,
    suggestion: variant === CardVariant.suggestion,
  });
  return (
    // this lint rule is disabled because ANDI sucks at knowing the implicit roles
    // see https://www.ssa.gov/accessibility/andi/help/modules.html for what ANDI knows about and
    // https://www.w3.org/TR/wai-aria-practices/examples/landmarks/HTML5.html for what it SHOULD know about
    // eslint-disable-next-line jsx-a11y/no-redundant-roles
    <section aria-label={sectionTitle} role="region" id={props.id} ref={ref} className={cardClasses}>
      <div className={props.noPadding ? '' : 'card-body'}>
        {props.title && (
          <Heading
            headingType={props.headingType ? props.headingType : 'h2'}
            headingStyle={props.headingStyle ? props.headingStyle : undefined}
          >
            {props.title}
          </Heading>
        )}
        {props.children}
      </div>
      {props.footer && <div className="card-footer">{props.footer}</div>}
    </section>
  );
});

Card.displayName = 'Card';
