import React from 'react';
import { Meta, Story } from '@storybook/react';
import { Documentation, dropdownFromHeadingTypes, dropdownFromHeadingStyles, StoryBadge } from '../stories';
import { a11yConfig } from '../stories/story.config';
import { Card, CardVariant, ICardProps } from './card';
import { Button, ButtonType } from '../button/button';
import { noop } from '../utils';
import { ButtonGroup } from '../button/button-group';

export default {
  component: Card,
  title: 'Core Components/Cards',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const whenToUse = (
  <>
    <p>Cards are surfaces that display content and actions on a single topic.</p>
    <p>
      They should be easy to scan for relevant and actionable information. Elements, like text, should be placed on them
      in a way that clearly indicates hierarchy.
    </p>
  </>
);

/**
 * Card
 */
export const BasicExample: Story = ({ ...args }) => {
  return (
    <Card id="card-default" {...args}>
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis consectetur justo a lorem pharetra ultricies. Fusce
      porta erat dolor, et placerat tortor placerat sed. Cras mollis risus eu velit aliquet, ultrices porttitor nibh
      feugiat. Nam feugiat elit ligula, id vulputate tellus faucibus posuere. Nulla convallis leo felis, eu pharetra
      felis porttitor vitae. Vestibulum et eros condimentum, varius enim sit amet, consequat turpis. Proin posuere elit
      eget turpis dapibus porttitor.
    </Card>
  );
};

BasicExample.storyName = 'White Card';

BasicExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="White Card"
      description="Cards contain content and actions about a single subject."
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const VariantExample: Story = () => {
  return (
    <Card id="card-variant-example" variant={CardVariant.gray}>
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis consectetur justo a lorem pharetra ultricies. Fusce
      porta erat dolor, et placerat tortor placerat sed. Cras mollis risus eu velit aliquet, ultrices porttitor nibh
      feugiat. Nam feugiat elit ligula, id vulputate tellus faucibus posuere. Nulla convallis leo felis, eu pharetra
      felis porttitor vitae. Vestibulum et eros condimentum, varius enim sit amet, consequat turpis. Proin posuere elit
      eget turpis dapibus porttitor.
    </Card>
  );
};

VariantExample.storyName = 'Gray Card';

VariantExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation name="Gray Card" description="Cards with user-specified variant" whenToUse={whenToUse}>
      <ComponentStory />
    </Documentation>
  ),
];
export const VariantAndFooterExample: Story = () => {
  return (
    <Card
      id="card-variant-footer-html"
      variant={CardVariant.gray}
      footer={
        <ButtonGroup>
          <Button id="variant-footer-button" onClick={noop}>
            Footer Button
          </Button>
          <Button id="variant-footer-button-2" onClick={noop} type={ButtonType.primary}>
            Using HTML
          </Button>
        </ButtonGroup>
      }
    >
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis consectetur justo a lorem pharetra ultricies. Fusce
      porta erat dolor, et placerat tortor placerat sed. Cras mollis risus eu velit aliquet, ultrices porttitor nibh
      feugiat. Nam feugiat elit ligula, id vulputate tellus faucibus posuere. Nulla convallis leo felis, eu pharetra
      felis porttitor vitae. Vestibulum et eros condimentum, varius enim sit amet, consequat turpis. Proin posuere elit
      eget turpis dapibus porttitor.
    </Card>
  );
};

VariantAndFooterExample.storyName = 'Gray Card with Footer';

VariantAndFooterExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Grey Card with Footer"
      description="Cards with variant and custom user-specified footer"
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const GrayCardwithTitle: Story<ICardProps> = ({ headingType, headingStyle }: ICardProps) => {
  return (
    <>
      <Card
        id="card-title"
        title="Gray Card with Title"
        variant={CardVariant.gray}
        headingType={headingType}
        headingStyle={headingStyle}
      >
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis consectetur justo a lorem pharetra ultricies.
        Fusce porta erat dolor, et placerat tortor placerat sed. Cras mollis risus eu velit aliquet, ultrices porttitor
        nibh feugiat. Nam feugiat elit ligula, id vulputate tellus faucibus posuere. Nulla convallis leo felis, eu
        pharetra felis porttitor vitae. Vestibulum et eros condimentum, varius enim sit amet, consequat turpis. Proin
        posuere elit eget turpis dapibus porttitor.
      </Card>
      <br />
      <Card
        id="card-title-html"
        variant={CardVariant.gray}
        title={
          <span className="text-danger">
            Card Title Using <em>HTML</em>
          </span>
        }
        headingType={headingType}
        headingStyle={headingStyle}
      >
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis consectetur justo a lorem pharetra ultricies.
        Fusce porta erat dolor, et placerat tortor placerat sed. Cras mollis risus eu velit aliquet, ultrices porttitor
        nibh feugiat. Nam feugiat elit ligula, id vulputate tellus faucibus posuere. Nulla convallis leo felis, eu
        pharetra felis porttitor vitae. Vestibulum et eros condimentum, varius enim sit amet, consequat turpis. Proin
        posuere elit eget turpis dapibus porttitor.
      </Card>
    </>
  );
};

GrayCardwithTitle.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Gray Card with Title"
      description="Cards with custom user-specified title"
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
GrayCardwithTitle.storyName = 'Gray Card with Title';
GrayCardwithTitle.argTypes = {
  headingType: {
    control: dropdownFromHeadingTypes(),
    defaultValue: 'h2',
  },
  headingStyle: {
    control: dropdownFromHeadingStyles(),
    defaultValue: null,
  },
};

export const FooterExample: Story = () => {
  return (
    <Card
      id="card-footer-html"
      footer={
        <ButtonGroup>
          <Button id="footer-button" onClick={noop}>
            Footer Button
          </Button>
          <Button id="footer-button-2" onClick={noop} type={ButtonType.primary}>
            Using HTML
          </Button>
        </ButtonGroup>
      }
    >
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis consectetur justo a lorem pharetra ultricies. Fusce
      porta erat dolor, et placerat tortor placerat sed. Cras mollis risus eu velit aliquet, ultrices porttitor nibh
      feugiat. Nam feugiat elit ligula, id vulputate tellus faucibus posuere. Nulla convallis leo felis, eu pharetra
      felis porttitor vitae. Vestibulum et eros condimentum, varius enim sit amet, consequat turpis. Proin posuere elit
      eget turpis dapibus porttitor.
    </Card>
  );
};

FooterExample.storyName = 'White Card with Footer';

FooterExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="White Card with Footer"
      description="Cards with custom user-specified footer"
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const WhiteCardWithTitle: Story<ICardProps> = ({ headingType, headingStyle }: ICardProps) => {
  return (
    <>
      <Card id="card-title" title="Card Title" headingType={headingType} headingStyle={headingStyle}>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis consectetur justo a lorem pharetra ultricies.
        Fusce porta erat dolor, et placerat tortor placerat sed. Cras mollis risus eu velit aliquet, ultrices porttitor
        nibh feugiat. Nam feugiat elit ligula, id vulputate tellus faucibus posuere. Nulla convallis leo felis, eu
        pharetra felis porttitor vitae. Vestibulum et eros condimentum, varius enim sit amet, consequat turpis. Proin
        posuere elit eget turpis dapibus porttitor.
      </Card>
      <br />
      <Card
        id="card-title-html"
        title={
          <span className="text-danger">
            Card Title Using <em>HTML</em>
          </span>
        }
        headingType={headingType}
        headingStyle={headingStyle}
      >
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis consectetur justo a lorem pharetra ultricies.
        Fusce porta erat dolor, et placerat tortor placerat sed. Cras mollis risus eu velit aliquet, ultrices porttitor
        nibh feugiat. Nam feugiat elit ligula, id vulputate tellus faucibus posuere. Nulla convallis leo felis, eu
        pharetra felis porttitor vitae. Vestibulum et eros condimentum, varius enim sit amet, consequat turpis. Proin
        posuere elit eget turpis dapibus porttitor.
      </Card>
    </>
  );
};

WhiteCardWithTitle.storyName = 'White Card with Title';

WhiteCardWithTitle.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="White Card with Title"
      description="Cards with custom user-specified title"
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];

WhiteCardWithTitle.argTypes = {
  headingType: {
    control: dropdownFromHeadingTypes(),
    defaultValue: 'h2',
  },
  headingStyle: {
    control: dropdownFromHeadingStyles(),
    defaultValue: null,
  },
};
