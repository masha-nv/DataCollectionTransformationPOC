import React from 'react';
import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../stories';
import { a11yConfig } from '../stories/story.config';
import { Card, CardVariant } from './card';
export default {
  component: Card,
  title: 'Core Components/AI Suggestions',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const whenToUse = (
  <>
    The AI Suggestion Card should be used anytime ELIS is using AI or machine learning to make suggestions to users. The
    card serves as a container for AI/ML suggested content.
  </>
);

const languageGuidelines = (
  <>
    <p>Same as the Beacon gray card, with the following exceptions:</p>
    <ul>
      <li>The AI Suggestion Card should only be used as a container for AI/ML suggested content.</li>
      <li>An AI Suggestion Badge should always be included somewhere within the AI Suggestion Card.</li>
      <li>
        AI Suggestion components should always be used instead of standard components within the AI Suggestion Card.
        This includes buttons, checkboxes, radio buttons, etc.
      </li>
    </ul>
  </>
);

export const AISuggestionCard: Story = () => {
  return (
    <Card id="card-default" variant={CardVariant.suggestion}>
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis consectetur justo a lorem pharetra ultricies. Fusce
      porta erat dolor, et placerat tortor placerat sed. Cras mollis risus eu velit aliquet, ultrices porttitor nibh
      feugiat. Nam feugiat elit ligula, id vulputate tellus faucibus posuere. Nulla convallis leo felis, eu pharetra
      felis porttitor vitae. Vestibulum et eros condimentum, varius enim sit amet, consequat turpis. Proin posuere elit
      eget turpis dapibus porttitor.
    </Card>
  );
};

AISuggestionCard.storyName = 'AI Suggestion Card';

AISuggestionCard.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="AI Suggestion Card"
      description="Cards contain content and actions about a single subject."
      whenToUse={whenToUse}
      languageGuidelines={languageGuidelines}
    >
      <ComponentStory />
    </Documentation>
  ),
];
