import React from 'react';
import { render } from '@testing-library/react';
import { containsFocusableChildById, focusOnFirstFocusableChildById, getPropertyValueFromPath } from './utils';

describe('Utils', () => {
  describe('getPropertyValueFromPath', () => {
    const data = {
      topLevel: 'top',
      secondLevel: {
        second: 'second',
        thirdLevel: {
          third: 'third',
        },
        array: [
          'zero',
          {
            arrayObj: 'ArrayObject',
          },
          'two',
        ],
      },
    };
    it('should return top level property', () => {
      expect(getPropertyValueFromPath(data, 'topLevel')).toEqual(data.topLevel);
    });
    it('should return third level property', () => {
      expect(getPropertyValueFromPath(data, 'secondLevel.thirdLevel.third')).toEqual(data.secondLevel.thirdLevel.third);
    });
    it('should return null', () => {
      expect(getPropertyValueFromPath(data, 'secondLevel.fourthLevel.fifth')).toEqual(null);
    });
    it('should return array index 0', () => {
      expect(getPropertyValueFromPath(data, 'secondLevel.array[0]')).toEqual(data.secondLevel.array[0]);
    });
    it('should return array index 1 object', () => {
      expect(getPropertyValueFromPath(data, 'secondLevel.array[1].arrayObj')).toEqual(
        (data.secondLevel.array[1] as Record<string, unknown>)['arrayObj']
      );
    });
  });

  describe('focusOnFirstFocusableChild', () => {
    it('should focus on first focusable child', () => {
      render(
        <>
          <div>
            <input type="text" id="three" />
          </div>
          <div id="test-div">
            <input type="text" id="first" />
            <input type="text" id="second" />
          </div>
        </>
      );

      focusOnFirstFocusableChildById('test-div');
      expect(document.activeElement).toBe(document.getElementById('first'));
    });

    it('should not change focus if no focusable child found', () => {
      render(
        <>
          <div>
            <input type="text" id="three" />
          </div>
          <div id="test-div">
            <span>Hello world</span>
          </div>
        </>
      );

      focusOnFirstFocusableChildById('test-div');

      expect(document.activeElement).toBe(document.getElementsByTagName('body')[0]);
    });

    it('should not change focus if element by that id does not exist', () => {
      render(
        <div>
          <input type="text" id="three" />
        </div>
      );

      focusOnFirstFocusableChildById('test-div');

      expect(document.activeElement).toBe(document.getElementsByTagName('body')[0]);
    });
  });

  describe('containsFocusableChildById', () => {
    it('should return true since contains focusable child', () => {
      render(
        <>
          <div>
            <input type="text" id="three" />
          </div>
          <div id="test-div">
            <input type="text" id="first" />
            <input type="text" id="second" />
          </div>
        </>
      );

      const actual = containsFocusableChildById('test-div');
      expect(actual).toBeTruthy();
    });

    it('should return false since does not contain focusable child', () => {
      render(
        <>
          <div>
            <input type="text" id="three" />
          </div>
          <div id="test-div">
            <span>Hello world</span>
          </div>
        </>
      );

      const actual = containsFocusableChildById('test-div');

      expect(actual).toBeFalsy();
    });

    it('should return false element does not exist', () => {
      render(
        <>
          <div>
            <input type="text" id="three" />
          </div>
          <div id="test-div">
            <span>Hello world</span>
          </div>
        </>
      );

      const actual = containsFocusableChildById('doestnotexist');

      expect(actual).toBeFalsy();
    });
  });
});
