import classNames from 'classnames';
import { forwardRef, ReactNode } from 'react';
import './heading.scss';

export type HeadingType = 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6';

export type HeadingStyle = 'xxl' | 'xl' | 'l' | 'm' | 's' | 'xs';

export interface IHeadingProps {
  /**
   * The type of HTML heading to use.
   */
  headingType: HeadingType;
  /**
   * A heading style to override the default heading style.
   */
  headingStyle?: HeadingStyle;
  /**
   * The content displayed as the body of the heading.
   */
  children: ReactNode;
}

export const Heading = forwardRef<HTMLHeadingElement, IHeadingProps>(({ ...props }, ref) => {
  const Tag: keyof JSX.IntrinsicElements = props.headingType;

  const typeClasses = classNames({
    'heading-xs': props.headingType === 'h6',
    'heading-s': props.headingType === 'h5',
    'heading-m': props.headingType === 'h4',
    'heading-l': props.headingType === 'h3',
    'heading-xl': props.headingType === 'h2',
    'heading-xxl': props.headingType === 'h1',
  });

  const styleClasses = classNames({
    'heading-xs': props.headingStyle === 'xs',
    'heading-s': props.headingStyle === 's',
    'heading-m': props.headingStyle === 'm',
    'heading-l': props.headingStyle === 'l',
    'heading-xl': props.headingStyle === 'xl',
    'heading-xxl': props.headingStyle === 'xxl',
  });

  return <Tag className={styleClasses ? styleClasses : typeClasses}>{props.children}</Tag>;
});

Heading.displayName = 'Heading';
