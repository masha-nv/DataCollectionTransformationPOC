import React from 'react';
import { render } from '@testing-library/react';
import { Heading } from './heading';

describe('Heading component', () => {
  it('renders default headings', () => {
    const { baseElement } = render(
      <>
        <Heading headingType="h1">H1</Heading>
        <Heading headingType="h2">H2</Heading>
        <Heading headingType="h3">H3</Heading>
        <Heading headingType="h4">H4</Heading>
        <Heading headingType="h5">H5</Heading>
        <Heading headingType="h6">H6</Heading>
      </>
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('renders headings with style', () => {
    const { baseElement } = render(
      <>
        <Heading headingType="h1" headingStyle="xxl">
          H1 as XXL
        </Heading>
        <Heading headingType="h1" headingStyle="xl">
          H1 as XL
        </Heading>
        <Heading headingType="h1" headingStyle="l">
          H1 as L
        </Heading>
        <Heading headingType="h1" headingStyle="m">
          H1 as M
        </Heading>
        <Heading headingType="h1" headingStyle="s">
          H1 as S
        </Heading>
        <Heading headingType="h1" headingStyle="xs">
          H1 as XL
        </Heading>
      </>
    );
    expect(baseElement).toMatchSnapshot();
  });
});
