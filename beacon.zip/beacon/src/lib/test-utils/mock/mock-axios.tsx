import { ReactElement, useEffect } from 'react';
import MockAdapter from 'axios-mock-adapter';
import axios from 'axios';

interface IMockAxiosProps {
  children: ReactElement;
  mock: (adapter: MockAdapter) => void;
}
const apiMock = new MockAdapter(axios);

export function MockAxios({ children, mock }: IMockAxiosProps): ReactElement {
  useEffect(() => {
    mock(apiMock);
    return () => {
      apiMock.reset();
    };
  });
  return children;
}
