import React, { ReactElement } from 'react';
import { HookExecution, ParamHookExecution, ParamRestCallHook, RestCallHook, RestHookResponse } from '../hooks';

export function HookTester<T>({
  id,
  useHookFunction,
  callbackFunction,
}: {
  id: string;
  useHookFunction: RestCallHook<T>;
  callbackFunction: (values: RestHookResponse<HookExecution, T>) => void;
}): ReactElement {
  const hookResponse = useHookFunction();
  callbackFunction(hookResponse);
  return (
    <div data-testid={id}>
      <span data-testid={`${id}-isLoading`}>{hookResponse.isLoading}</span>
      <span data-testid={`${id}-error`}>{JSON.stringify(hookResponse.error)}</span>
      <span data-testid={`${id}-data`}>{JSON.stringify(hookResponse.data)}</span>
      <button
        data-testid={`${id}-execute`}
        onClick={() => {
          hookResponse.execute();
        }}
      >
        Execute
      </button>
    </div>
  );
}

export function PayloadHookTester<P, T>({
  id,
  payload,
  useHookFunction,
  callbackFunction,
}: {
  id: string;
  payload: P;
  useHookFunction: ParamRestCallHook<P, T>;
  callbackFunction: (values: RestHookResponse<ParamHookExecution<P>, T>) => void;
}): ReactElement {
  const hookResponse = useHookFunction();
  callbackFunction(hookResponse);
  return (
    <div data-testid={id}>
      <span data-testid={`${id}-isLoading`}>{hookResponse.isLoading}</span>
      <span data-testid={`${id}-error`}>{hookResponse.error?.message}</span>
      <span data-testid={`${id}-data`}>{JSON.stringify(hookResponse.data)}</span>
      <button
        data-testid={`${id}-execute`}
        onClick={() => {
          hookResponse.execute(payload);
        }}
      >
        Execute
      </button>
    </div>
  );
}
