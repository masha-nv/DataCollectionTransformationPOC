export const emptyFunction: () => void = () => {
  // eslint-disable-next-line @typescript-eslint/no-empty-function
  return () => {};
};
