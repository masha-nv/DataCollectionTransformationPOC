import React, { ReactNode } from 'react';
import { track } from '../analytics';
import { Alert, AlertVariant } from '../notifications/alert/alert';

type ErrorBoundaryProps = {
  contextualId?: string;
  children: ReactNode;
};

type ErrorPayload = {
  host: string;
  path: string;
  error: Error;
  contextualId?: string;
};

type ErrorBoundaryState = {
  hasError: boolean;
};

export class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  myRef: React.RefObject<HTMLDivElement>;

  constructor(properties: ErrorBoundaryProps) {
    super(properties);
    this.state = { hasError: false };
    this.myRef = React.createRef();
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo): void {
    const errorPayload: ErrorPayload = {
      contextualId: this.props.contextualId,
      error: error,
      host: window.location.host,
      path: `${window.location.pathname}${window.location.hash ?? ''}`,
    };
    const nearestIdedParent = this.myRef.current?.closest('[id]');
    if (nearestIdedParent) {
      errorPayload.contextualId = nearestIdedParent.id;
    }
    track({
      grouping: 'React Render Errors',
      trackingKey: errorPayload.path,
      action: `${errorPayload.contextualId ?? 'No ID found'} - ${error.message} - ${new Date().toISOString()} - ${
        error.stack
      }`,
    });
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true };
  }

  render(): React.ReactNode {
    return (
      <div ref={this.myRef}>
        {this.state.hasError && (
          <Alert variant={AlertVariant.warning}>
            <strong>An unexpected error was encountered</strong>
            <p>
              We apologize, there was a programming error rendering this section. The error has been reported to our
              error logs.
            </p>
          </Alert>
        )}
        {!this.state.hasError && this.props.children}
      </div>
    );
  }
}
