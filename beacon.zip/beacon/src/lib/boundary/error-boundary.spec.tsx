import { render, screen } from '@testing-library/react';
import { ReactNode } from 'react';
import { track, TrackableEvent } from '../analytics';
import { ErrorBoundary } from './error-boundary';
jest.mock('../analytics/matomo');

const mockTrack = track as jest.MockedFunction<typeof track>;

describe('Error Boundary', () => {
  const originalConsoleError = console.error;

  const BoundaryContainer: React.FC<{ children: ReactNode }> = ({ children }) => (
    <div id="parent-of-boundary">
      <ErrorBoundary>{children}</ErrorBoundary>
    </div>
  );
  const ProblematicChild: React.FC = () => {
    const message: unknown = undefined;
    return <div>Hello {(message as string).length}</div>;
  };

  afterEach(() => {
    console.error = originalConsoleError;
    jest.clearAllMocks();
  });

  it('renders children', () => {
    render(<BoundaryContainer>hello world</BoundaryContainer>);

    expect(screen.getByText('hello world')).toBeTruthy();
  });

  it('renders an error when children contain an error', () => {
    console.error = jest.fn();
    render(
      <BoundaryContainer>
        <ProblematicChild />
      </BoundaryContainer>
    );

    expect(screen.getByText('An unexpected error was encountered')).toBeTruthy();
    expect(console.error).toHaveBeenCalled();
    expect(mockTrack).toHaveBeenCalled();

    const trackedEvent: TrackableEvent = mockTrack.mock.calls[0][0];
    expect(trackedEvent.action).toContain('parent-of-boundary');
  });

  it('renders an error when ancesters do not have an ID', () => {
    console.error = jest.fn();
    render(
      <ErrorBoundary>
        <ProblematicChild />
      </ErrorBoundary>
    );

    expect(screen.getByText('An unexpected error was encountered')).toBeTruthy();

    const trackedEvent: TrackableEvent = mockTrack.mock.calls[0][0];
    expect(trackedEvent.action).toContain('No ID found');
  });
});
