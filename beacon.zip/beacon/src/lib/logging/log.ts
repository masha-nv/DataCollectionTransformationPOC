const createLogger = (type: string, component: string) => {
  const color = type === 'Component' ? 'cyan' : 'lightgreen';
  return {
    log: (message: string, ...params: unknown[]) => {
      console.log(
        `%c[${type}-${component}]%c ${message}`,
        `background: #444; color: ${color}`,
        'background: auto; color: auto',
        params.length > 0 ? params : ''
      );
    },
    warn: (message: string, ...params: unknown[]) => {
      console.warn(
        `%c[${type}-${component}]%c ${message}`,
        `background: #444; color: ${color}`,
        'background: auto; color: auto',
        params.length > 0 ? params : ''
      );
    },
    error: (message: string, ...params: unknown[]) => {
      console.error(
        `%c[${type}-${component}]%c ${message}`,
        `background: #444; color: ${color}`,
        'background: auto; color: auto',
        params.length > 0 ? params : ''
      );
    },
    debug: (message: string, ...params: unknown[]) => {
      console.debug(
        `%c[${type}-${component}]%c ${message}`,
        `background: #444; color: ${color}`,
        'background: auto; color: auto',
        params.length > 0 ? params : ''
      );
    },
  };
};
export const componentLogger = (component: string) => {
  return createLogger('Component', component);
};
export const hookLogger = (hook: string) => {
  return createLogger('Hook', hook);
};
