import { ChangeEvent, FocusEvent } from 'react';

export type ChangeEventHandler<T = HTMLInputElement, U = string> = (event: ChangeEvent<T>, value: U) => void;

export interface WithInput<
  T extends HTMLTextAreaElement | HTMLInputElement | HTMLSelectElement = HTMLInputElement,
  U = string
> {
  /**
   * Indicates if input is required by form
   */
  required?: boolean;
  /**
   * Name of field when using input inside of form
   */
  name?: string;
  /**
   * Disables input from being used
   */
  disabled?: boolean;
  /**
   * Accessibility label if an input cannot have a label tag associated with it
   */
  'aria-label'?: string;
  /**
   * The event handler for when the input is changed
   */
  onChange?: ChangeEventHandler<T, U>;
  /**
   * The event handler on Blur event
   */
  onBlur?: (event: FocusEvent<T>) => void;
}
