import { SyntheticEvent } from 'react';
import { track } from './matomo';
import { TrackableEvent } from './trackable';

export declare type TrackableEventHandler<T> = (event: T) => void;

/**
 * Wrap an event with tracking information
 */
export const trackableEvent = <T extends SyntheticEvent = SyntheticEvent>(
  trackableEvent: TrackableEvent,
  handler: TrackableEventHandler<T>
): TrackableEventHandler<T> => {
  return (event) => {
    track(trackableEvent);
    handler(event);
  };
};

/**
 * Combine custom and default tracking configuration
 */
export const defaultTracking = (
  userProvided: TrackableEvent | null | undefined,
  defaults: TrackableEvent
): TrackableEvent => {
  const result: TrackableEvent = Object.assign({}, defaults);
  return Object.assign(result, userProvided);
};

/**
 * Wrap an event with tracking information
 */
export const getTrackableClickHandler = <T extends SyntheticEvent = SyntheticEvent>(
  tracking: TrackableEvent | undefined,
  defaults: TrackableEvent,
  onClick: TrackableEventHandler<T>
): TrackableEventHandler<T> => {
  const trackingInfo = defaultTracking(tracking, defaults);
  return trackableEvent(trackingInfo, onClick);
};
