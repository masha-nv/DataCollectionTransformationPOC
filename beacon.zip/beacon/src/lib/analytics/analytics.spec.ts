import { SyntheticEvent } from 'react';
import { defaultTracking, track, trackableEvent } from '.';
import { TrackableEvent } from './trackable';

describe('Analytics service', () => {
  const MOCK_TRACKABLE_EVENT = {
    grouping: 'fake group',
    action: 'fake action',
    trackingKey: 'custom element',
    value: 'some value',
  } as TrackableEvent;
  const EXPECTED_TRACKABLE_EVENT_RESULT = ['trackEvent', 'fake group', 'fake action', 'custom element', 'some value'];
  describe('with matomo disabled', () => {
    it('does not log to the console', () => {
      jest.spyOn(console, 'log');

      track(MOCK_TRACKABLE_EVENT);

      expect(console.log).not.toHaveBeenCalledWith(
        expect.stringContaining('fake group-fake action'),
        'color: yellow',
        'color: auto',
        'color: lightgreen',
        'color: auto',
        'color: lightblue',
        'color: auto',
        'color: red',
        'color: lightgreen'
      );
    });

    it('can create default TrackingEvent objects with proper overrides', () => {
      expect(defaultTracking(null, MOCK_TRACKABLE_EVENT)).toEqual(MOCK_TRACKABLE_EVENT);
      expect(
        defaultTracking(
          {
            grouping: 'New group',
          },
          MOCK_TRACKABLE_EVENT
        )
      ).toEqual({
        grouping: 'New group',
        action: MOCK_TRACKABLE_EVENT.action,
        trackingKey: MOCK_TRACKABLE_EVENT.trackingKey,
        value: MOCK_TRACKABLE_EVENT.value,
      });
    });
  });
  describe('with matomo enabled', () => {
    let mockMatomo = null;

    beforeEach(() => {
      mockMatomo = {
        push: jest.fn(),
      };
      // Matomo's object has no typing info 😑
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (window as any)._paq = mockMatomo;
    });

    afterEach(() => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (window as any)._paq = null;
    });

    it('will track to matomo when matomo is defined', () => {
      track(MOCK_TRACKABLE_EVENT);

      expect(mockMatomo.push).toHaveBeenCalledWith(EXPECTED_TRACKABLE_EVENT_RESULT);
    });

    it('can create a trackable event', () => {
      const fakeEventHandler = jest.fn();
      const fakeEvent = {} as SyntheticEvent;

      trackableEvent(MOCK_TRACKABLE_EVENT, fakeEventHandler)(fakeEvent);

      expect(mockMatomo.push).toHaveBeenCalledWith(EXPECTED_TRACKABLE_EVENT_RESULT);
      expect(fakeEventHandler).toHaveBeenCalledWith(fakeEvent);
    });

    it('can create a trackable event', () => {
      const fakeEventHandler = jest.fn();
      const fakeEvent = {} as SyntheticEvent;
      const MOCK_TRACKABLE_EVENT_UNDEFINED_VALUE = {
        grouping: 'fake group',
        action: 'fake action',
        trackingKey: 'custom element',
      } as TrackableEvent;
      const EXPECTED_TRACKABLE_EVENT_RESULT_UNDEFINED_VALUE = [
        'trackEvent',
        'fake group',
        'fake action',
        'custom element',
      ];
      trackableEvent(MOCK_TRACKABLE_EVENT_UNDEFINED_VALUE, fakeEventHandler)(fakeEvent);
      expect(mockMatomo.push).toHaveBeenCalledWith(EXPECTED_TRACKABLE_EVENT_RESULT_UNDEFINED_VALUE);
      expect(fakeEventHandler).toHaveBeenCalledWith(fakeEvent);
    });

    it('can create trackable event with custom event', () => {
      const event: TrackableEvent = {
        trackingEvent: 'event',
        trackingKey: 'key',
        grouping: 'group',
        action: 'action',
        value: 'value',
      };
      track(event);
      track({ trackingEvent: event.trackingEvent, value: event.value });
      expect(mockMatomo.push).toHaveBeenCalledWith([
        event.trackingEvent,
        event.grouping,
        event.action,
        event.trackingKey,
        event.value,
      ]);
      expect(mockMatomo.push).toHaveBeenCalledWith([event.trackingEvent, event.value]);
    });
  });
});
