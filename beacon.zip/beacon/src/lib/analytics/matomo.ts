import { TrackableEvent } from './trackable';

export const track = (event: TrackableEvent): void => {
  // this is required here, matomo defines a global variable _paq which is what actually gets binded to
  // the event tracking, unfortunately it has to be an "any" object.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const matomoTracker = (window as any)._paq;
  if (matomoTracker != null) {
    if (event.trackingEvent) {
      const trackingArray = [event.trackingEvent];
      event.grouping && trackingArray.push(event.grouping);
      event.action && trackingArray.push(event.action);
      event.trackingKey && trackingArray.push(event.trackingKey);
      event.value && trackingArray.push(event.value);
      matomoTracker.push(trackingArray);
    } else if (event.value === undefined) {
      matomoTracker.push(['trackEvent', event.grouping, event.action, event.trackingKey]);
    } else {
      matomoTracker.push(['trackEvent', event.grouping, event.action, event.trackingKey, event.value]);
    }
  } else if (
    matomoTracker === null &&
    (process.env.JEST_WORKER_ID === undefined || Number(process.env.JEST_WORKED_ID) === 1)
  ) {
    if (event.value === undefined) {
      console.log(
        `%cTRACKING LOCAL%c event: %c[${event.grouping}-${event.action}%c on %c${event.trackingKey}]`,
        'color: yellow',
        'color: auto',
        'color: lightgreen',
        'color: auto',
        'color: lightblue'
      );
    } else {
      console.log(
        `%cTRACKING LOCAL%c event: %c[${event.grouping}-${event.action}%c on %c${event.trackingKey}%c with value %c${event.value}%c]`,
        'color: yellow',
        'color: auto',
        'color: lightgreen',
        'color: auto',
        'color: lightblue',
        'color: auto',
        'color: red',
        'color: lightgreen'
      );
    }
  }
};
