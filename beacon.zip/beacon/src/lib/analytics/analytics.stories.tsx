import React from 'react';
import { Button, ButtonType } from '../button/button';
import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../stories';
import { TrackableEvent } from './trackable';
import { HorizontalTable } from '../horizontal-table/horizontal-table';
import { IHorizontalTableField } from '../horizontal-table/horizontal-table-types';

const data: TrackableEvent[] = [
  {
    grouping: 'grouping',
    action: 'action',
    trackingKey: 'trackingKey',
    value: 'value',
  },
  {
    grouping: 'Event Category',
    action: 'Event Action',
    trackingKey: 'Event Name',
    value: 'Event Value',
  },
];

const fields: IHorizontalTableField<TrackableEvent>[] = [
  {
    label: 'Event Category',
    field: 'grouping',
    showEdit: false,
  },
  {
    label: 'Event Action',
    field: 'action',
    showEdit: false,
  },
  {
    label: 'Event Name',
    field: 'trackingKey',
    showEdit: false,
  },
  {
    label: 'Event Value',
    field: 'value',
    showEdit: false,
  },
];

const btnInnerText = 'Play';
const defaultTrackingKey = `Button-${btnInnerText}`;

const getColumnLabel = (index: number) => (index === 0 ? 'Application Reference' : 'Matomo Reference');

export default {
  title: 'Matomo Analytics',
  component: Button,
  parameters: {
    badges: [StoryBadge.READY],
    controls: { include: ['tracking'] },
  },
  argTypes: {
    tracking: {
      control: {
        type: 'object',
      },
    },
  },
  args: {
    tracking: {
      grouping: 'Ungrouped',
      action: 'Clicked',
      trackingKey: defaultTrackingKey,
      value: undefined,
    },
  },
} as Meta;

export const Tracking: Story = (args) => {
  const trackingDefaults: TrackableEvent = {
    grouping: 'Ungrouped',
    action: 'Clicked',
    trackingKey: defaultTrackingKey,
  };

  const trackableClickHandler = (customTracking: TrackableEvent) => {
    const event = `Tracked Event: ${JSON.stringify(customTracking || trackingDefaults, null, 2)}`;
    alert(event);
    console.log(event);
  };

  return (
    <div className="d-flex align-items-stretch">
      <Button
        id="btn-play-video-defult-tracking"
        type={ButtonType.primary}
        title={`Tracking: ${JSON.stringify(args.tracking, null, 2)}`}
        onClick={() => trackableClickHandler(args.tracking)}
      >
        {btnInnerText}
      </Button>
    </div>
  );
};

Tracking.storyName = 'Event Tracking';
Tracking.decorators = [
  (Story: Story) => (
    <Documentation
      name="Event Tracking"
      description={
        <>
          <p>
            Each of these components makes use of the <code>tracking</code> attribute to allow for{' '}
            <a href="https://matomo.org/" rel="noreferrer" target="_blank">
              Matomo
            </a>{' '}
            events to be published. The three examples show different levels of customization including the default
            out-of-the-box tracking metadata included.
          </p>
          <p>
            To see the tracking events as they'll be published to Matomo, you may click the button for default tracking
            or use the control panel below to provide custom tracking.
          </p>
          <HorizontalTable
            id={''}
            title=""
            data={data}
            fields={fields}
            columnLabel={(record: TrackableEvent, columnIndex: number) => getColumnLabel(columnIndex)}
          />
        </>
      }
      whenToUse={
        <p>
          Use the <code>tracking</code> attribute when customizing the Matomo events you want published for your
          interactive components.
        </p>
      }
    >
      <Story />
    </Documentation>
  ),
];
