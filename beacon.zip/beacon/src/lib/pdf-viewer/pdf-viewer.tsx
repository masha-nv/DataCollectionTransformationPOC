import { WithId } from '../with-id';

export interface IPDFViewer extends WithId {
  /**
   * The url location where the pdf is fetched from.
   */
  url: string;
  /**
   * The string for title of the displaying element.
   */
  title?: string;
  /**
   * The size for width of the displaying element.
   */
  width?: string;
  /**
   * The size for height of the displaying element.
   */
  height?: string;
}

export const PDFViewer: React.FC<IPDFViewer> = ({ height = '800px', width = '100%', ...props }: IPDFViewer) => {
  return <iframe id={props.id} src={props.url} title={props.title} height={height} width={width} />;
};
