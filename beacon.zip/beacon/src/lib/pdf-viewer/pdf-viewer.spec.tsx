import { render } from '@testing-library/react';
import { PDFViewer } from './pdf-viewer';

describe('PDFViewer component', () => {
  it('renders successfully', () => {
    const { baseElement } = render(<PDFViewer id="pdf-viewer-test" url="testSource" height={'400px'} />);
    expect(baseElement).toMatchSnapshot();
  });
});
