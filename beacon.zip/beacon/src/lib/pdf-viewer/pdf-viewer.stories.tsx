import { Meta, Story } from '@storybook/react';
import { PDFViewer } from './pdf-viewer';
import { Documentation, StoryBadge } from '../stories';
import { a11yConfig } from '../stories/story.config';

export default {
  component: PDFViewer,
  title: 'Core Components/PDF Viewer',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const whenToUse = (
  <>
    <p>Use when trying to view a PDF embeded into a page</p>
    <p>
      If the PDF does not need to be embeded into the page, then open the pdf in a new window without the PDFViewer or
      change to a download.
    </p>
  </>
);

export const BasicExample: Story = ({ height }) => {
  const pdfBlob = new Blob([TEST_PDF], { type: 'application/pdf' });
  const url = window.URL.createObjectURL(pdfBlob);
  return <PDFViewer id="pdf-viewer-story" url={url} height={height} title="storybook-pdf" />;
};

BasicExample.storyName = 'PDF Viewer';

BasicExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="PDF Viewer"
      whenToUse={whenToUse}
      description="PDF Viewer is used to display PDF's embeded into a page"
    >
      <ComponentStory />
    </Documentation>
  ),
];

BasicExample.argTypes = {
  height: { defaultValue: '400px' },
  pdfUrl: {
    control: false,
  },
  title: {
    control: false,
  },
  width: {
    control: false,
  },
  id: {
    control: false,
  },
};

const TEST_PDF = `%PDF-1.4
  1 0 obj <</Type /Catalog /Pages 2 0 R>>
  endobj
  2 0 obj <</Type /Pages /Kids [3 0 R] /Count 1>>
  endobj
  3 0 obj<</Type /Page /Parent 2 0 R /Resources 4 0 R /MediaBox [0 0 500 800] /Contents 6 0 R>>
  endobj
  4 0 obj<</Font <</F1 5 0 R>>>>
  endobj
  5 0 obj<</Type /Font /Subtype /Type1 /BaseFont /Helvetica>>
  endobj
  6 0 obj
  <</Length 44>>
  stream
  BT /F1 24 Tf 175 720 Td (Test PDF)Tj ET
  endstream
  endobj
  xref
  0 7
  0000000000 65535 f
  0000000009 00000 n
  0000000056 00000 n
  0000000111 00000 n
  0000000212 00000 n
  0000000250 00000 n
  0000000317 00000 n
  trailer <</Size 7/Root 1 0 R>>
  startxref
  406
  %%EOF`;
