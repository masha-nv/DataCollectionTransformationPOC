import classNames from 'classnames';
import React, { Children, useRef, ReactNode } from 'react';
import { Heading, HeadingType } from '../../heading/heading';
import { WithId } from '../../with-id';
import { ISideNavigationItemProps, SideNavigationItem } from './side-navigation-item';
import './side-navigation.scss';
export interface ISideNavigationProps extends WithId {
  /**
   * Header that will be displayed above the Navigation Component
   */
  title?: string | ReactNode;
  /**
   * Set to true to show anchor lines on the left of the child Side Navigation Items
   */
  showAnchors?: boolean;
  /**
   * If true, a button will be added to the top of the SideNavigationItem list that will allow the user
   * to immediately move focus to the bottom of the list. The button will not be displayed unless it is tabbed to
   */
  skipToEnd?: boolean;
  /**
   * Must be one or more SideNavigationItem or SideNavigation components
   */
  children: React.ReactElement<ISideNavigationItemProps>[] | React.ReactElement<ISideNavigationItemProps>;
  /**
   * The type of heading used for the title.
   */
  headingType?: HeadingType;
}
export const SideNavigation = ({ showAnchors = false, skipToEnd = false, ...props }: ISideNavigationProps) => {
  const skipToEndElementRef = useRef<HTMLDivElement>(null);

  const skipNav = () => {
    skipToEndElementRef.current?.focus();
  };

  const wrapperClasses = classNames('navigation-wrapper', {
    'nav-anchors': showAnchors,
  });

  return (
    <div className={wrapperClasses} id={`${props.id}-container`}>
      {typeof props.title === 'string' ? (
        <Heading headingType={props.headingType ?? 'h2'} headingStyle="m">
          {props.title}
        </Heading>
      ) : (
        props.title
      )}
      <ul className="nav flex-column" id={props.id}>
        {skipToEnd && (
          <button
            type="button"
            id={`${props.id}-skip-to-end-button`}
            className="sr-only show-on-focus"
            onClick={skipNav}
          >
            Skip Side Menu
          </button>
        )}
        {Children.map(props.children, (child) => {
          if (child.type !== SideNavigationItem && child.type !== SideNavigation) {
            console.warn(
              `${SideNavigation.name} component only allows children of types ${SideNavigationItem.name} or ${SideNavigation.name}`
            );
            return;
          }

          return child;
        })}
      </ul>
      {skipToEnd && (
        <div tabIndex={-1} className="sr-only show-on-focus" ref={skipToEndElementRef} id={`${props.id}-menu-end`} />
      )}
    </div>
  );
};
