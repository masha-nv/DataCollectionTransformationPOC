import React, { Children, ReactNode, SyntheticEvent, useEffect, useState } from 'react';
import { defaultTracking, Trackable, trackableEvent } from '../../analytics';
import { noop } from '../../utils';
import { WithId } from '../../with-id';
import { ISideNavigationProps, SideNavigation } from './side-navigation';
import classNames from 'classnames';
import { Icon, IconType } from '../../icon/icon';

export interface ISideNavigationItemProps extends WithId, Trackable {
  /**
   * Label will be displayed as the navigation item text
   */
  label: ReactNode;
  /**
   * Text attribute that will be read on hover or on focus. If the label is a simple text,
   * the title will automatically be set to the label, unless the title is explicitely declared.
   */
  title?: string;
  /**
   * The aria-label of the button element for accessibilty.
   */
  ariaLabel?: string;
  /**
   * Set to true to show formatting that indicates that the section on the screen corresponds to this item
   */
  inView?: boolean;
  /**
   * Set to true to show that this navigation idem is the current active item
   */
  active?: boolean;
  /**
   * Set to true to show a checkmark, indicating that the ttask in this section is completed
   */
  completed?: boolean;
  /**
   * Set to true to show a highlighted item with a dashed background indicating item is being dragged on
   */
  draggedOn?: boolean;
  /**
   * This canbe used to control the collapsed state of the item. By default,
   * the item is collapsed - meaning that the subsections are hidden.
   */
  collapse?: boolean;
  /**
   * Set this to false to prevent a item from being collapsible. By default, a item is collapsible if
   * the item has subsections
   */
  collapsible?: boolean;
  /**
   * URL that will be navigated to upon clicking the navigation item
   */
  href?: string;
  /**
   * Callback function that will be executed upon clicking on the item
   */
  onClick?: (event: SyntheticEvent) => void;
  /**
   * Must be a SideNavigation component. Declare children to show subsections in an item
   */
  children?: React.ReactElement<ISideNavigationProps>;
  /**
   * Callback function that will be executed once when a component is dragged on an item
   */
  onDragEnter?: (event: React.DragEvent<HTMLDivElement>, ...args: unknown[]) => void;
  /**
   * Callback function that will be executed once when a component is dragged away from an item
   */
  onDragLeave?: (event: React.DragEvent<HTMLDivElement>, ...args: unknown[]) => void;
  /**
   * Callback function that will be executed once when a component is dragged and dropped on an item
   */
  onDrop?: (event: React.DragEvent<HTMLDivElement>, ...args: unknown[]) => void;
  /**
   * Callback function that will be executed everytime a component is dragged over an item
   */
  onDragOver?: (event: React.DragEvent<HTMLDivElement>, ...args: unknown[]) => void;
}

export const SideNavigationItem = ({
  onClick = noop,
  onDragEnter = noop,
  onDragLeave = noop,
  onDrop = noop,
  onDragOver = noop,
  title = undefined,
  ariaLabel= undefined,
  collapse = true,
  active = false,
  completed = false,
  collapsible = true,
  inView = false,
  ...props
}: ISideNavigationItemProps) => {
  const trackingInfo = defaultTracking(props.tracking, {
    grouping: 'Ungrouped',
    action: 'Link Item Clicked',
    trackingKey: `SideNavigation-${props.id}`,
  });

  const [collapsed, setCollapsed] = useState(false);
  const [isCollapsible, setIsCollapsible] = useState(false);

  // Update if children are added or removed. Set collapsible dynamically, or override with
  // props.collapsible if provided
  useEffect(() => {
    setIsCollapsible(Children.count(props.children) > 0 && !!collapsible);
  }, [props.children, collapsible]);

  // Allow user to control the collapse state
  useEffect(() => {
    setCollapsed(!!collapse);
  }, [collapse]);

  const navLinkClasses = classNames('nav-link', {
    active: active,
    completed: completed,
    inview: inView,
    draggedOn: props.draggedOn,
  });

  return (
    <li className="nav-item">
      <div
        className="nav-link-wrapper"
        onDragEnter={onDragEnter}
        onDragLeave={onDragLeave}
        onDragOver={onDragOver}
        onDrop={onDrop}
      >
        {isCollapsible && (
          <button
            type="button"
            id={`${props.id}-collapse-button`}
            className="expansion-arrow"
            onClick={(e) => setCollapsed((prev) => !prev)}
            title={`${collapsed ? 'Show Details' : 'Hide Details'}`}
          >
            {collapsed && <Icon description="Navigation Item Collapsed" type={IconType.chevronDown} />}
            {!collapsed && <Icon description="Navigation Item Expanded" type={IconType.chevronUp} />}
          </button>
        )}

        {props.href && (
          <a
            id={props.id}
            title={title}
            onClick={trackableEvent(trackingInfo, onClick)}
            className={navLinkClasses}
            href={props.href}
            tabIndex={0}
          >
            <span>{props.label}</span>
            {completed && <i title="Completed" className="completed-icon fas fa-check" />}
          </a>
        )}

        {!props.href && (
          <button
            title={title}
            aria-label={ariaLabel}
            type="button"
            onClick={trackableEvent(trackingInfo, onClick)}
            className={navLinkClasses}
            tabIndex={0}
            id={props.id}
          >
            {' '}
            <span>{props.label}</span>
            {completed && <i title="Completed" className="completed-icon fas fa-check" />}
          </button>
        )}
      </div>
      {!collapsed &&
        props.children &&
        Children.count(props.children) > 0 &&
        Children.map(props.children, (child) => {
          const sideNavigationProps = child.props;
          return <SideNavigation {...sideNavigationProps} skipToEnd={false}></SideNavigation>;
        })}
    </li>
  );
};
