import classNames from 'classnames';
import { forwardRef } from 'react';
import { defaultTracking, trackableEvent } from '../../analytics';
import { noop } from '../../utils';
import './pill-navigation.scss';
import { IPillNavigationItemProps, PillNavigationItemType } from './pill-navigation.type';

export const PillNavigationItem = forwardRef<HTMLButtonElement & HTMLAnchorElement, IPillNavigationItemProps>(
  ({ type = PillNavigationItemType.basic, selected = false, disabled = false, onClick = noop, ...props }, ref) => {
    const trackingInfo = defaultTracking(props.tracking, {
      grouping: 'Ungrouped',
      action: 'Pill Navigation Item Clicked',
      trackingKey: `PillNavigationItem-${props.id}`,
    });

    const navItemClasses = classNames({
      'beacon-pill-basic': type === PillNavigationItemType.basic || type === PillNavigationItemType.dropdown,
      'beacon-pill-external': type === PillNavigationItemType.external,
      'beacon-pill-dropdown-left-content': type === PillNavigationItemType.dropdown,
      current: selected,
      disabled: disabled,
    });

    const externalIconClasses = classNames('ml-1', 'fas', 'fa-external-link-alt', 'pill-icon-circle', {
      current: selected,
    });

    return (
      // Render a button when disabled instead of an a link, which cannot be disabled
      <>
        {(!props.href || disabled) && (
          <button
            type="button"
            disabled={disabled}
            onClick={trackableEvent(trackingInfo, onClick)}
            tabIndex={0}
            id={props.id}
            className={navItemClasses}
            ref={ref}
          >
            {type === PillNavigationItemType.basic && <span className="spanPillPadding">{props.children}</span>}
          </button>
        )}
        {props.href && !disabled && (
          <a
            onClick={trackableEvent(trackingInfo, onClick)}
            id={props.id}
            href={props.href}
            target={type === PillNavigationItemType.external && !selected ? '_blank' : undefined}
            className={navItemClasses}
            ref={ref}
            rel="noreferrer"
          >
            {type === PillNavigationItemType.basic && <span className="spanPillPadding">{props.children}</span>}
            {type === PillNavigationItemType.external && (
              <span className="beacon-pill-external-content">
                <span className="spanPillExternalPadding">{props.children}</span>
                <i className={externalIconClasses} />
              </span>
            )}
            {type === PillNavigationItemType.dropdown && (
              <span className="spanPillPaddingDropDown">{props.children}</span>
            )}
          </a>
        )}
        {props.href && !disabled && type === PillNavigationItemType.dropdown && props.dropDownComponent}
      </>
    );
  }
);

PillNavigationItem.displayName = 'PillNavigationItem';
