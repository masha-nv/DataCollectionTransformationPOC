import { render } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Icon, IconType } from '../../icon/icon';
import { Badge } from '../../notifications/badge/badge';
import { PillNavigationDropdown } from './pill-navigation-dropdown';
import { PillNavigationItem } from './pill-navigation-item';
import { PillNavigationItemType } from './pill-navigation.type';
import { PillNavigationDropdownItem } from './pill-navigation-dropdown-item';

describe('PillNavigationItem Component', () => {
  it('renders basic Item', () => {
    const { baseElement } = render(basicPillNavigationItem);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders basic Item with selected', () => {
    const { baseElement } = render(basicPillNavigationItem);
    expect(baseElement).toMatchSnapshot();
  });
  it('renders disabled links', () => {
    const { baseElement } = render(withDisabled);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders external links', () => {
    const { baseElement } = render(withExternal);
    expect(baseElement).toMatchSnapshot();
  });
  it('renders dropdown links', () => {
    const { baseElement } = render(withDropDown);
    const item1 = baseElement.querySelector('#pillDropDown-item-1');
    const item2 = baseElement.querySelector('#pillDropDown-item-2');
    userEvent.hover(item1, 1);
    userEvent.hover(item2, 1);
    let item3 = baseElement.querySelector('#pillDropDownMenupillDropDown-item-1');
    let item4 = baseElement.querySelector('#pillDropDownMenupillDropDown-item-2');
    expect(item3).toBeDefined();
    expect(item4).toBeDefined();
    userEvent.hover(item3, 1);
    userEvent.unhover(item3, 1);
    userEvent.unhover(item1, 1);
    userEvent.hover(item4, 1);
    userEvent.unhover(item4, 1);
    userEvent.unhover(item2, 1);
    item3 = baseElement.querySelector('#pillDropDownMenupillDropDown-item-1');
    item4 = baseElement.querySelector('#pillDropDownMenupillDropDown-item-2');
    expect(item3).toBeNull();
    expect(item4).toBeNull();
    expect(baseElement).toMatchSnapshot();
  });

  it('calls onClick function', () => {
    const fakeOnClick = jest.fn();
    const { baseElement } = render(withOnClickFunction(fakeOnClick));
    const item1 = baseElement.querySelector('#item-1');
    userEvent.click(item1);

    expect(fakeOnClick).toHaveBeenCalled();
  });
});

const dropDownData = {
  formType: 'I-130',
  applicantName: 'Tom',
  links: [
    { formType: 'I-485', href: '#' },
    { formType: 'I-130', href: '#' },
    { formType: 'I-764', href: '#' },
    { formType: 'I-131', href: '#' },
  ],
};

const basicPillNavigationItem = (
  <>
    <PillNavigationItem id="item-1" href="#">
      Item 1
    </PillNavigationItem>
    <PillNavigationItem id="item-2">
      Item 2 with <Badge id="basic-badge-1">Badge</Badge>
    </PillNavigationItem>
  </>
);

const withSelected = (
  <>
    <PillNavigationItem id="item-1" href="#" selected>
      Item 1
    </PillNavigationItem>
    <PillNavigationItem id="item-2" selected>
      Item 2 with <Badge id="selected-badge-1">Badge</Badge>
    </PillNavigationItem>
  </>
);
const withDisabled = (
  <>
    <PillNavigationItem id="item-1" href="#" disabled>
      Item 1
    </PillNavigationItem>
    <PillNavigationItem id="item-2" disabled>
      Item 2
    </PillNavigationItem>
  </>
);
const withExternal = (
  <>
    <PillNavigationItem id="item-1" href="#" type={PillNavigationItemType.external}>
      Item 1
    </PillNavigationItem>
    <PillNavigationItem id="item-2" type={PillNavigationItemType.external}>
      Item 2
    </PillNavigationItem>
  </>
);

const withDropDown = (
  <>
    <PillNavigationItem
      href="#"
      id="dropdown-item-1"
      type={PillNavigationItemType.dropdown}
      dropDownComponent={
        <PillNavigationDropdown
          id="pillDropDown-item-1"
          title="Navigate through Tom's forms"
          selected
          dropDownComponentItems={
            <>
              <PillNavigationDropdownItem id="pillDropDownItem-item-1" href="#">
                <Icon type={IconType.folder} />
                <strong>I-485</strong>
              </PillNavigationDropdownItem>
              <PillNavigationDropdownItem id="pillDropDownItem-item-2" href="#" selected>
                <Icon type={IconType.folder} />
                <strong>I-130</strong>
              </PillNavigationDropdownItem>
              <PillNavigationDropdownItem id="pillDropDownItem-item-3" href="#">
                <Icon type={IconType.folder} />
                <strong>I-764</strong>
              </PillNavigationDropdownItem>
              <PillNavigationDropdownItem id="pillDropDownItem-item-4" href="#">
                <Icon type={IconType.folder} />
                <strong>I-131</strong>
              </PillNavigationDropdownItem>
            </>
          }
        >
          <strong>I-130</strong>
        </PillNavigationDropdown>
      }
    >
      <span>Hello</span>
    </PillNavigationItem>
    <PillNavigationItem
      href="#"
      id="dropdown-item-2"
      type={PillNavigationItemType.dropdown}
      dropDownComponent={
        <PillNavigationDropdown
          id="pillDropDown-item-2"
          title="Navigate through Tim's forms"
          dropDownComponentItems={
            <>
              <PillNavigationDropdownItem id="pillDropDownItem-item-5" href="#" selected>
                <Icon type={IconType.folder} />
                <strong>I-485</strong>
              </PillNavigationDropdownItem>
              <PillNavigationDropdownItem id="pillDropDownItem-item-6" href="#">
                <Icon type={IconType.folder} />
                <strong>I-130</strong>
              </PillNavigationDropdownItem>
              <PillNavigationDropdownItem id="pillDropDownItem-item-7" href="#">
                <Icon type={IconType.folder} />
                <strong>I-764</strong>
              </PillNavigationDropdownItem>
              <PillNavigationDropdownItem id="pillDropDownItem-item-8" href="#">
                <Icon type={IconType.folder} />
                <strong>I-131</strong>
              </PillNavigationDropdownItem>
            </>
          }
        >
          <strong>I-485</strong>
        </PillNavigationDropdown>
      }
    >
      <span>Hello</span>
    </PillNavigationItem>
  </>
);

const withDropDownComponent = <PillNavigationDropdown id="item-1">Item</PillNavigationDropdown>;

const withOnClickFunction = (onClickFn: () => void) => (
  <PillNavigationItem id="item-1" onClick={onClickFn}>
    Item 1
  </PillNavigationItem>
);
