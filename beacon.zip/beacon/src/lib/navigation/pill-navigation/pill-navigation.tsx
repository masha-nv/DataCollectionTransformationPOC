import React, { Children, ForwardedRef, forwardRef, SyntheticEvent, useState } from 'react';
import { Trackable } from '../../analytics';
import { WithId } from '../../with-id';
import { PillNavigationItem } from './pill-navigation-item';
import { IPillNavigationItemProps } from './pill-navigation.type';

export interface IPillNavigationProps extends WithId, Trackable {
  /**
   * Id of the PillNavigationItem that should be styled as selected by default
   */
  defaultSelected?: string;
  /**
   * Must be of type PillNavigationItem
   */
  children: React.ReactElement<IPillNavigationItemProps>[] | React.ReactElement<IPillNavigationItemProps>;
}

export const PillNavigation = forwardRef((props: IPillNavigationProps, ref: ForwardedRef<HTMLDivElement>) => {
  const [selected, setSelected] = useState(props.defaultSelected ? props.defaultSelected : null);

  return (
    <div className="beacon-tab-container" id={props.id} ref={ref}>
      <ul className="nav nav-pills" role="listbox" aria-label="nav">
        {Children.map(props.children, (child) => {
          if (child.type !== PillNavigationItem) {
            console.warn(`${PillNavigation.name} component only allows children of types ${PillNavigationItem.name}`);
            return;
          }

          if (child.props.selected != null) {
            console.warn(`When using PillNavigation, "selected" will be controlled by the parent PillNavigation.`);
          }

          const itemProps = child.props;

          const handleOnClick = (event: SyntheticEvent) => {
            if (itemProps.onClick) {
              itemProps.onClick(event);
            }
            setSelected(itemProps.id);
          };

          return (
            <li className="nav-item" role="option" aria-selected={itemProps.id === selected}>
              <PillNavigationItem
                {...itemProps}
                selected={itemProps.id === selected}
                onClick={handleOnClick}
              ></PillNavigationItem>
            </li>
          );
        })}
      </ul>
    </div>
  );
});

PillNavigation.displayName = 'PillNavigation';
