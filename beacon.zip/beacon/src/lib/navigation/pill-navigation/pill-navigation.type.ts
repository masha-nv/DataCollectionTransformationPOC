import { ReactNode, SyntheticEvent } from 'react';
import { Trackable } from '../../analytics';
import { WithId } from '../../with-id';

export enum PillNavigationItemType {
  basic = 'basic',
  external = 'external',
  dropdown = 'dropdown',
}

export interface IPillNavigationItemProps extends WithId, Trackable {
  /**
   * The type of button to render, retrieve them from `PillNavigationItemType`
   */
  type?: PillNavigationItemType;
  /**
   * Url to a page that should be opened when PillNavigationItem is clicked upon
   */
  href?: string;
  /**
   * Setting this to true will disable this PillNavigationItem from being selected
   */
  disabled?: boolean;
  /**
   * Callback function executed when PillNavigationItem is clicked upon
   * This is controlled by the parent PillNavigation component if it is within a group.
   */
  onClick?: (event: SyntheticEvent) => void;
  /**
   * Determines if the PillNavigationItem is in a "selected" state.
   * This is controlled by the parent PillNavigation component if it is within a group.
   */
  selected?: boolean;
  children: ReactNode;
  title?: string;
  dropDownComponent?: ReactNode;
}

export interface IPillNavigationDropDownProps extends IPillNavigationItemProps {
  dropDownComponentItems?: ReactNode;
}
