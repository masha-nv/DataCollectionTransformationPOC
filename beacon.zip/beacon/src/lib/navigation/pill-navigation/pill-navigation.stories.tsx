import { useState } from 'react';
import { Meta, Story } from '@storybook/react';
import { Documentation, dropdownFromEnum, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { PillNavigationItem } from './pill-navigation-item';
import { Badge, BadgeVariant } from '../../notifications/badge/badge';
import { PillNavigation } from './pill-navigation';
import { Card, CardVariant } from '../../cards/card';
import { Icon, IconType } from '../../icon/icon';
import { IPillNavigationItemProps, PillNavigationItemType } from './pill-navigation.type';
import { PillNavigationDropdown } from './pill-navigation-dropdown';
import { PillNavigationDropdownItem } from './pill-navigation-dropdown-item';

export default {
  component: PillNavigation,
  title: 'Core Components/Navigation/Pill Navigation',
  parameters: {
    badges: [StoryBadge.NEEDS_508],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const whenToUse = (
  <>
    <b>Basic Pill Navigation </b>
    <p>The basic PillNavigation enables a user to load related cases on a single page and switch among them.</p>
    <p>
      <i>Sample Use Case:</i>When used in family packs, the basic PillNavigation allows the adjudicator to easily
      navigate among different applicants' cases that are grouped in one family pack by clicking on the
      PillNavigationItem for each family member.
    </p>
    <b>External Link PillNavigationItem</b>
    <p>
      When Pill Navigation navigation is used, the external link PillNavigationItem allows users to access a different
      area of ELIS in a different page or browser tab.
    </p>
    <p>
      Sample Use Case: When used for case details in concurrent filing, the external link PillNavigationItem allows the
      adjudicator to open the other cases in the applicant’s bundle in another page or browser tab they can use to
      display side by side for easy comparison.
    </p>
  </>
);

export const BasicPillNavigation: Story = () => {
  const template1 = (
    <Card id="pill-nav-template-1" title="Tempate 1">
      <p>This is a template for Item 1</p>
    </Card>
  );

  const template2 = (
    <Card id="pill-nav-template-2" title="Tempate 2" variant={CardVariant.gray}>
      <p>This is a template for Item 2</p>
    </Card>
  );

  const [displayedTemplate, setDisplayedTemplate] = useState<JSX.Element | null>(null);

  return (
    <>
      <PillNavigation id="basic-pill-navigation">
        <PillNavigationItem id="basic-item-1" onClick={(event) => setDisplayedTemplate(template1)}>
          <Icon type={IconType.user} />
          <strong>I-485</strong>
          {'LASTNAME, FIRSTNAME'}
          <Badge id="principal-badge-1" focusable={false} variant={BadgeVariant.default} showIcon={false}>
            Principal
          </Badge>
        </PillNavigationItem>
        <PillNavigationItem id="basic-item-2" onClick={(event) => setDisplayedTemplate(template2)}>
          <Icon type={IconType.user} />
          <strong>I-485</strong>
          {'LASTNAME, FIRSTNAME'}
        </PillNavigationItem>
      </PillNavigation>
      <br />
      {displayedTemplate}
    </>
  );
};

BasicPillNavigation.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Basic Pill Navigation"
      whenToUse={whenToUse}
      description='Pill navigation (so called because of their "Pill" shape) is a navigational element that enables a user to load information about related cases on a single page, such as cases in a family pack. This component should be used with multiple PillNavigationItems.'
    >
      <ComponentStory />
    </Documentation>
  ),
];

BasicPillNavigation.storyName = 'Pill Navigation';

export const DisabledPillNavigation: Story = () => {
  return (
    <PillNavigation id="disabled-pill-navigation">
      <PillNavigationItem id="disabled-item-2" disabled>
        Disabled Pill Navigation
      </PillNavigationItem>
    </PillNavigation>
  );
};

DisabledPillNavigation.storyName = 'Disabled Pill Navigation';

DisabledPillNavigation.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Disabled Pill Navigation"
      whenToUse={whenToUse}
      description="A pill navigation item can be disabled to disallow selection of the item."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const DropdownPillNavigation: Story = () => {
  return (
    <PillNavigation id="dropdown-pill-navigation" defaultSelected="dropdown-item-1">
      <PillNavigationItem
        href="#"
        id="dropdown-item-1"
        type={PillNavigationItemType.dropdown}
        dropDownComponent={
          <PillNavigationDropdown
            id="pillDropDown-item-1"
            title="Navigate through Tom's forms"
            selected
            dropDownComponentItems={
              <>
                <PillNavigationDropdownItem id="pillDropDownItem-item-1" href="#">
                  <Icon type={IconType.folder} />
                  <strong>I-485</strong>
                </PillNavigationDropdownItem>
                <PillNavigationDropdownItem id="pillDropDownItem-item-2" href="#" selected>
                  <Icon type={IconType.folder} />
                  <strong>I-130</strong>
                </PillNavigationDropdownItem>
                <PillNavigationDropdownItem id="pillDropDownItem-item-3" href="#">
                  <Icon type={IconType.folder} />
                  <strong>I-764</strong>
                </PillNavigationDropdownItem>
                <PillNavigationDropdownItem id="pillDropDownItem-item-4" href="#">
                  <Icon type={IconType.folder} />
                  <strong>I-131</strong>
                </PillNavigationDropdownItem>
              </>
            }
          >
            <strong>I-130</strong>
          </PillNavigationDropdown>
        }
      >
        <Icon type={IconType.user} />
        <span>LASTNAME, FIRSTNAME</span>
        <Badge id="principal-badge-2" focusable={false} variant={BadgeVariant.default} showIcon={false}>
          Principal
        </Badge>
      </PillNavigationItem>
      <PillNavigationItem
        href="#"
        id="dropdown-item-2"
        type={PillNavigationItemType.dropdown}
        dropDownComponent={
          <PillNavigationDropdown
            id="pillDropDown-item-2"
            title="Navigate through Tim's forms"
            dropDownComponentItems={
              <>
                <PillNavigationDropdownItem id="pillDropDownItem-item-5" href="#" selected>
                  <Icon type={IconType.folder} />
                  <strong>I-485</strong>
                </PillNavigationDropdownItem>
                <PillNavigationDropdownItem id="pillDropDownItem-item-6" href="#">
                  <Icon type={IconType.folder} />
                  <strong>I-130</strong>
                </PillNavigationDropdownItem>
                <PillNavigationDropdownItem id="pillDropDownItem-item-7" href="#">
                  <Icon type={IconType.folder} />
                  <strong>I-764</strong>
                </PillNavigationDropdownItem>
                <PillNavigationDropdownItem id="pillDropDownItem-item-8" href="#">
                  <Icon type={IconType.folder} />
                  <strong>I-131</strong>
                </PillNavigationDropdownItem>
              </>
            }
          >
            <strong>I-485</strong>
          </PillNavigationDropdown>
        }
      >
        <Icon type={IconType.user} />
        <span>LASTNAME, FIRSTNAME</span>
        <Badge id="principal-badge-3" focusable={false} variant={BadgeVariant.default} showIcon={false}>
          Principal
        </Badge>
      </PillNavigationItem>
    </PillNavigation>
  );
};

DropdownPillNavigation.storyName = 'Dropdown Single Pill Navigation Item';

DropdownPillNavigation.decorators = [
  (DropdownPillNavigationStory: Story) => (
    <Documentation
      name="Dropdown Pill Navigation"
      whenToUse={whenToUse}
      description="A pill navigation item can be used for dropdown navigation."
    >
      <DropdownPillNavigationStory />
    </Documentation>
  ),
];
export const ExternalPillNavigation: Story = () => {
  return (
    <PillNavigation id="external-pill-navigation" defaultSelected="enabled-item-1">
      <PillNavigationItem href="#" id="enabled-item-1" type={PillNavigationItemType.external}>
        <Icon type={IconType.folder} />
        <strong>I-130</strong>
        <span>Pill with href link</span>
      </PillNavigationItem>
      <PillNavigationItem href="#" id="enabled-item-2" type={PillNavigationItemType.external}>
        <Icon type={IconType.folder} />
        <strong>I-130</strong>
        <span>Pill with href link</span>
      </PillNavigationItem>
    </PillNavigation>
  );
};

ExternalPillNavigation.storyName = 'External Single Pill Navigation Item';

ExternalPillNavigation.decorators = [
  (ExternalPillNavigationStory: Story) => (
    <Documentation
      name="External Pill Navigation"
      whenToUse={whenToUse}
      description="A pill navigation item can be used for external navigation."
    >
      <ExternalPillNavigationStory />
    </Documentation>
  ),
];

export const DefaultSelectedPillNavigation: Story = () => {
  const template1 = (
    <Card id="pill-nav-template-1" title="Tempate 1">
      <p>This is a template for Item 1</p>
    </Card>
  );

  const template2 = (
    <Card id="pill-nav-template-2" title="Tempate 2" variant={CardVariant.gray}>
      <p>This is a template for Item 2</p>
    </Card>
  );

  const [displayedTemplate, setDisplayedTemplate] = useState(template2);

  return (
    <>
      <PillNavigation id="default-selected-pill-navigation" defaultSelected="default-selected-item-2">
        <PillNavigationItem id="default-selected-item-1" onClick={(event) => setDisplayedTemplate(template1)}>
          <Icon type={IconType.user} />
          <strong>I-485</strong>
          {'LASTNAME, FIRSTNAME'}
          <Badge id="principal-badge-4" focusable={false} variant={BadgeVariant.default} showIcon={false}>
            Principal
          </Badge>
        </PillNavigationItem>
        <PillNavigationItem id="default-selected-item-2" onClick={(event) => setDisplayedTemplate(template2)}>
          <Icon type={IconType.user} />
          <strong>I-485</strong>
          {'LASTNAME, FIRSTNAME'}
        </PillNavigationItem>
      </PillNavigation>
      <br />
      {displayedTemplate}
    </>
  );
};

DefaultSelectedPillNavigation.storyName = 'Pill Navigation with Default Selected';

DefaultSelectedPillNavigation.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Default Selected Pill Navigation"
      whenToUse={whenToUse}
      description="A pill navigation item can be set to be selected by default."
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const BasicPillNavigationItem: Story<IPillNavigationItemProps> = (props: IPillNavigationItemProps) => {
  const updatedProps = { ...props, id: 'basic-pill-navigation-item' };
  return (
    <div className="w-40">
      <PillNavigationItem {...updatedProps}>
        <Icon type={IconType.user} />
        <strong>I-485</strong>
        {'LASTNAME, FIRSTNAME'}
        <Badge id="principal-badge-5" focusable={false} variant={BadgeVariant.default} showIcon={false}>
          Principal
        </Badge>
      </PillNavigationItem>
    </div>
  );
};

BasicPillNavigationItem.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Pill Navigation Item"
      whenToUse={whenToUse}
      description='Pill navigation (so called because of their "Pill" shape) is a navigational element that enables a user to load information about related cases on a single page, such as cases in a family pack.'
    >
      <ComponentStory />
    </Documentation>
  ),
];

BasicPillNavigationItem.storyName = 'Single Pill Navigation Item';

BasicPillNavigationItem.args = {
  type: PillNavigationItemType.basic,
};

BasicPillNavigationItem.argTypes = {
  type: {
    control: dropdownFromEnum(PillNavigationItemType),
    defaultValue: PillNavigationItemType.basic,
  },
  selected: {
    defaultValue: false,
  },
  disabled: {
    defaultValue: false,
  },
  href: {
    control: null,
  },
  id: {
    control: null,
  },
  children: {
    control: null,
  },
  tracking: {
    control: null,
  },
};
