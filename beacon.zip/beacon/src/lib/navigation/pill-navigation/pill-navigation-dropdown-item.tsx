import classNames from 'classnames';
import { forwardRef } from 'react';
import { defaultTracking, trackableEvent } from '../../analytics';
import { Icon, IconType } from '../../icon/icon';
import { noop } from '../../utils';
import { IPillNavigationItemProps, PillNavigationItemType } from './pill-navigation.type';

const dropDownClassesCurrent = classNames({
  'beacon-pill-basic': true,
  'form-drop-down-navigation': true,
  current: true,
});

const dropDownClassesNotCurrent = classNames({
  'beacon-pill-basic': true,
  'form-drop-down-navigation': true,
  current: false,
});

export const PillNavigationDropdownItem = forwardRef<HTMLButtonElement & HTMLAnchorElement, IPillNavigationItemProps>(
  ({ type = PillNavigationItemType.dropdown, selected, onClick = noop, ...props }, ref) => {
    const trackingInfo = defaultTracking(props.tracking, {
      grouping: 'Ungrouped',
      action: 'Pill Navigation Item Clicked',
      trackingKey: `PillNavigationItem-${props.id}`,
    });

    return (
      <a
        onClick={trackableEvent(trackingInfo, onClick)}
        id={props.id}
        href={props.href}
        target={!selected ? '_blank' : undefined}
        className={selected ? dropDownClassesCurrent : dropDownClassesNotCurrent}
        ref={ref}
        rel="noreferrer"
      >
        <span className="spanPillPaddingDropDown">{props.children}</span>
        {selected && <Icon type={IconType.check} />}
        {selected && <span style={{ paddingRight: 8 }}></span>}
      </a>
    );
  }
);
