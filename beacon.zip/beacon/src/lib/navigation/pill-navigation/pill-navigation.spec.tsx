import React from 'react';
import { render } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Badge } from '../../notifications/badge/badge';
import { PillNavigationItem } from './pill-navigation-item';
import { PillNavigation } from './pill-navigation';
describe('PillNavigation Component', () => {
  it('renders basic PillNavigation', () => {
    const { baseElement } = render(basicPillNavigation);
    expect(baseElement).toMatchSnapshot();
  });

  it('handles click and sets currentSelected on a link', () => {
    const { baseElement } = render(basicPillNavigation);
    const item1 = baseElement.querySelector('#item-1');
    userEvent.click(item1);

    expect(item1.className.includes('current')).toBe(true);
    expect(baseElement).toMatchSnapshot();
  });

  it('handles click and sets currentSelected on button', () => {
    const { baseElement } = render(basicPillNavigation);
    const item2 = baseElement.querySelector('#item-2');
    userEvent.click(item2);

    expect(item2.className.includes('current')).toBe(true);
    expect(baseElement).toMatchSnapshot();
  });

  it('ignores child elements that are not PillNavigationItem', () => {
    const consoleSpy = jest.spyOn(console, 'warn').mockImplementation();
    const { baseElement } = render(withInvalidChild);

    expect(consoleSpy).toBeCalled();
    expect(baseElement).toMatchSnapshot();
  });

  it('warns that "selected" will be overwritten', () => {
    const consoleSpy = jest.spyOn(console, 'warn').mockImplementation();
    render(withDeclaredSelected);

    expect(consoleSpy).toBeCalled();
  });
  it('calls onClick on PillNavigation', () => {
    const fakeOnClick = jest.fn();
    const { baseElement } = render(withOnClickOnGroup(fakeOnClick));
    const item1 = baseElement.querySelector('#item-1');
    userEvent.click(item1);

    expect(fakeOnClick).toHaveBeenCalled();
  });

  it('renders basic PillNavigation with defaultSelected', () => {
    const { baseElement } = render(withDefaultSelected);
    expect(baseElement).toMatchSnapshot();
  });
});

const basicPillNavigation = (
  <PillNavigation id="basic-side-nav">
    <PillNavigationItem id="item-1" href="#">
      Item 1
    </PillNavigationItem>
    <PillNavigationItem id="item-2">
      Item 2 with <Badge id="badge-1">Badge</Badge>
    </PillNavigationItem>
  </PillNavigation>
);

const withInvalidChild = (
  <PillNavigation id="basic-side-nav">
    <button>This doesnt go here</button>
    <PillNavigationItem id="item-1">Item 1</PillNavigationItem>
  </PillNavigation>
);

const withDeclaredSelected = (
  <PillNavigation id="basic-side-nav">
    <PillNavigationItem id="item-1" selected>
      Item 1
    </PillNavigationItem>
  </PillNavigation>
);

const withOnClickOnGroup = (onClickFn: () => void) => (
  <PillNavigation id="basic-side-nav">
    <PillNavigationItem id="item-1" onClick={onClickFn}>
      Item 1
    </PillNavigationItem>
  </PillNavigation>
);

const withDefaultSelected = (
  <PillNavigation id="basic-side-nav" defaultSelected="item-1">
    <PillNavigationItem id="item-1">Item 1</PillNavigationItem>
  </PillNavigation>
);
