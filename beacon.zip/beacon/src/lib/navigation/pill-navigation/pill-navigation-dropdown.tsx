import classNames from 'classnames';
import { forwardRef, useState } from 'react';
import { noop } from '../../utils';
import { IPillNavigationDropDownProps, PillNavigationItemType } from './pill-navigation.type';

export const PillNavigationDropdown = forwardRef<HTMLButtonElement & HTMLAnchorElement, IPillNavigationDropDownProps>(
  ({ type = PillNavigationItemType.dropdown, selected, onClick = noop, ...props }, ref) => {
    const dropDownClasses = classNames({
      'beacon-pill-dropdown-right-content': true,
      'beacon-pill-basic': true,
      current: selected,
    });

    const [isShown, setIsShown] = useState(false);

    return (
      <>
        <button
          id={props.id}
          onMouseEnter={() => setIsShown(true)}
          onMouseLeave={() => setIsShown(false)}
          tabIndex={0}
          data-toggle="beacon-dropdown"
          className={dropDownClasses}
        >
          <span className="ml-1 mt-2 mb-2">
            <span className="mr-2">
              <strong>{props.children}</strong>
            </span>
            <em className={isShown ? 'fas fa-caret-up' : 'fas fa-caret-down'}></em>
          </span>
        </button>
        {isShown && (
          <div
            className="pill-navigation-dropdown-menu"
            aria-labelledby={props.id}
            id={'pillDropDownMenu' + props.id}
            onMouseEnter={() => setIsShown(true)}
            onMouseLeave={() => setIsShown(false)}
          >
            <div className="arrow"></div>
            <div className="dropdown-menu-content">
              <div className="dropdown-menu-title mb-2">{props.title}</div>
              {props.dropDownComponentItems}
            </div>
          </div>
        )}
      </>
    );
  }
);
