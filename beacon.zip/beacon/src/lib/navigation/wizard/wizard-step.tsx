import React, { ReactElement } from 'react';
import { TrackableEvent } from '../../analytics';
import { Icon, IconType } from '../../icon/icon';
import classNames from 'classnames';
import { WithId } from '../../with-id';
import { Heading, HeadingType } from '../../heading/heading';

export declare type StepRenderer = (step: IWizardStep) => ReactElement;
export declare type AllowNavigation = (currentStep: IWizardStep) => boolean;
export declare type OnMoveToStep = (currentStep: IWizardStep, nextStep: IWizardStep) => boolean;

export interface IWizardStep {
  /* The title of the step itself */
  title?: string;

  /* The content of the step itself */
  body: ReactElement | StepRenderer | null;

  /* Description to render on the wizard steps */
  description?: string;

  /* Function to handle validations for what happens when the user navigates to the next step,
  returns true if the navigation should be allowed to proceed, false otherwise. Defaults to a
  noop function which always returns true */
  onNext?: OnMoveToStep;

  /* Function to handle validations for what happens when the user navigates to the previous step,
  returns true if the navigation should be allowed to proceed, false otherwise. Defaults to a
  noop function which always returns true */
  onPrevious?: OnMoveToStep;

  /* Returns true if the next button should be enabled, otherwise disable the button. 
  Defaults to a noop function which always returns true */
  allowNext?: AllowNavigation;

  /* Returns true if the previous button should be enabled, otherwise disable the button.
  Defaults to a noop function which always returns true */
  allowPrevious?: AllowNavigation;

  /* The display text of the next button. Defaults to 'Next' */
  nextButtonText?: string;

  /* The display text of the previous button. Defaults to 'Back' */
  previousButtonText?: string;

  /* Used to gather Matomo analytics on the Next button */
  nextTracking?: TrackableEvent;

  /* Used to gather Matomo analytics on the Previous button */
  previousTracking?: TrackableEvent;
  /**
   * The type of heading used for the title.
   */
  headingType?: HeadingType;
}

interface IWizardStepProps extends IWizardStep, WithId {
  /* The index of the step in the list of steps */
  index: number;

  /*The status of the step*/
  stepStatus: WizardStepStatus;

  /* Is the current step the last on in the list */
  isEnd?: boolean;
}

enum WizardStepStatus {
  completed = -1,
  current = 0,
  pending = 1,
}

const isStatusCompleted = (status: WizardStepStatus) => status <= WizardStepStatus.completed;
const isStatusCurrent = (status: WizardStepStatus) => status === WizardStepStatus.current;
const isStatusPending = (status: WizardStepStatus) => status >= WizardStepStatus.pending;

export const WizardStep = (props: IWizardStepProps) => {
  let stepIcon = null;
  if (props.isEnd || isStatusCompleted(props.stepStatus)) {
    stepIcon = <Icon type={IconType.check} description="check" />;
  } else {
    stepIcon = <div>{props.index + 1}</div>;
  }
  const isDisabled = isStatusPending(props.stepStatus);
  const classes = classNames('step', {
    'step-end-state': props.isEnd,
    'flex-grow-0': props.isEnd && !props.description && !props.title,
    'flex-grow-1': !props.isEnd || props.description || props.title,
    'step-complete': isStatusCompleted(props.stepStatus) || (isStatusCurrent(props.stepStatus) && props.isEnd),
    disabled: isDisabled,
  });

  const iconClasses = classNames({
    'last-step': (props.description || props.title) && props.isEnd,
    'step-number': true,
  });

  return (
    <li className={classes} id={props.id}>
      <div className={iconClasses} aria-disabled={isDisabled}>
        {stepIcon}
      </div>
      <div className="step-title" aria-disabled={isDisabled}>
        {props.title && (
          <Heading headingType={props.headingType ? props.headingType : 'h2'} headingStyle="l">
            {props.title}
          </Heading>
        )}
      </div>
      <div className="step-description" aria-disabled={isDisabled}>
        {props.description}
      </div>
    </li>
  );
};
