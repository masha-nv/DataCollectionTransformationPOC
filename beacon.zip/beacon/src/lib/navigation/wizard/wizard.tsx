import React, { useEffect, useRef, useState } from 'react';
import { WithId } from '../../with-id';
import { Button, ButtonType } from '../../button/button';
import { defaultTracking } from '../../analytics/analytics';
import { WizardStep, IWizardStep, OnMoveToStep } from './wizard-step';
import { Icon, IconType } from '../../icon/icon';
import { TrackableEvent } from '../../analytics';
import './wizard.scss';
import { HeadingType } from '../../heading/heading';

export interface IWizardProps extends WithId {
  /**
   * The list of Wizard steps
   */
  steps: IWizardStep[];
  activeStepIndex?: number;
  /**
   * The type of heading used for the step titles.
   */
  headingType?: HeadingType;
}

const getDefaultTrackingInfo = (info: TrackableEvent | undefined, id: string) => {
  return defaultTracking(info, {
    grouping: 'Ungrouped',
    action: 'Clicked',
    trackingKey: id,
  });
};

const onMove = (
  onClick: OnMoveToStep | undefined,
  stepsArray: IWizardStep[],
  currentIndex: number,
  setIndex: React.Dispatch<React.SetStateAction<number>>,
  isNext?: boolean
): void => {
  const targetIndex = currentIndex + (isNext ? 1 : -1);
  const hasAStepAtTarget = typeof stepsArray[targetIndex] !== 'undefined';
  const isAllowedToProceed = (steps: IWizardStep[]) =>
    onClick ? onClick(steps[currentIndex], steps[targetIndex]) : true;
  if (hasAStepAtTarget && isAllowedToProceed(stepsArray)) {
    setIndex(targetIndex);
  }
};

export const Wizard = (props: IWizardProps) => {
  const [index, setIndex] = useState(0);
  const nextButtonRef = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    if (props.activeStepIndex !== undefined) {
      setIndex(props.activeStepIndex);
    }
  }, [props.activeStepIndex]);
  useEffect(() => {
    const step = props.steps[index];
    if (step?.allowNext && step) nextButtonRef?.current?.focus();
  }, [props.steps, index]);
  if (!props.steps || props.steps.length === 0) {
    console.warn('Wizard steps cannot be empty.');
    return null;
  }
  const currentStep = props.steps[index];
  const MAX_INDEX = props.steps.length - 1;
  const body = typeof currentStep.body === 'function' ? currentStep.body(currentStep) : currentStep.body;

  return (
    <>
      <div className="wizard">
        <ul className="steps d-flex">
          {props.steps.map((step: IWizardStep, arrIndex, arr) => (
            <WizardStep
              key={`${props.id}-step-${arrIndex}`}
              id={`${props.id}-step-${arrIndex}`}
              title={step.title}
              description={step.description}
              body={step.body}
              isEnd={arr.length - 1 === arrIndex}
              index={arrIndex}
              stepStatus={arr.indexOf(step) - index}
              headingType={props.headingType}
            />
          ))}
        </ul>
        <div>
          {index > 0 && index < MAX_INDEX && (
            <span className="float-left">
              <Button
                id={`${props.id}-previous-button`}
                disabled={currentStep.allowPrevious ? !currentStep.allowPrevious(currentStep) : false}
                tracking={getDefaultTrackingInfo(currentStep.previousTracking, `${props.id}-previous-button`)}
                onClick={() => onMove(currentStep.onPrevious, props.steps, index, setIndex, false)}
              >
                <Icon type={IconType.arrowLeft} description="arrow left" /> {currentStep.previousButtonText || 'Back'}
              </Button>
            </span>
          )}
          {index < MAX_INDEX && (
            <span className="float-right">
              <Button
                id={`${props.id}-next-button`}
                ref={nextButtonRef}
                type={ButtonType.primary}
                disabled={currentStep.allowNext ? !currentStep.allowNext(currentStep) : false}
                tracking={getDefaultTrackingInfo(currentStep.nextTracking, `${props.id}-next-button`)}
                onClick={() => onMove(currentStep.onNext, props.steps, index, setIndex, true)}
              >
                {currentStep.nextButtonText || 'Next'} <Icon type={IconType.arrowRight} description="arrow right" />
              </Button>
            </span>
          )}
        </div>
      </div>
      <hr />
      <div id={`${props.id}-step-${index}-body`}>{body}</div>
    </>
  );
};
