import React from 'react';
import { render, screen, findByText } from '@testing-library/react';
import { BasicExample, CookingExample, SkipAround } from './wizard.stories';
import userEvent from '@testing-library/user-event';
import { Wizard } from './wizard';
import { IWizardStep } from './wizard-step';

describe('Wizard Component', () => {
  it('render basic', () => {
    const { container } = render(<BasicExample />);
    expect(container).toMatchSnapshot();
  });

  it('clicks next', async () => {
    const { container } = render(<BasicExample />);
    userEvent.click(screen.getByText('Next'));
    await findByText(container, 'The current step says to Run npm install');
    expect(container).toMatchSnapshot();
  });

  it('clicks next when onNext return false', async () => {
    const { container } = render(<CookingExample />);
    userEvent.click(screen.getByText('Next'));
    userEvent.click(screen.getByText('onNext() return true'));
    userEvent.click(screen.getByText('Next'));
    await findByText(container, 'Cooking time!');
    expect(container).toMatchSnapshot();
  });

  it('clicks previous', async () => {
    const { container } = render(<BasicExample />);
    userEvent.click(screen.getByText('Next'));
    userEvent.click(screen.getByText('Next'));
    userEvent.click(screen.getByText('Back'));
    await findByText(container, 'The current step says to Run npm install');
    expect(container).toMatchSnapshot();
  });

  it('attempts to render with no steps', async () => {
    const consoleSpy = jest.spyOn(console, 'warn').mockImplementation();
    render(<Wizard id="wizard-default" steps={[]} />);
    expect(consoleSpy).toBeCalled();
  });

  it('attempts to render with empty data', async () => {
    const consoleSpy = jest.spyOn(console, 'warn').mockImplementation();
    render(<Wizard id="wizard-default" steps={[]} />);
    expect(consoleSpy).toBeCalled();
  });

  it('allows for skipping around', async () => {
    const { container } = render(<SkipAround />);
    userEvent.click(screen.getByText('Go to Step 3 (Matt)'));
    await findByText(container, 'step 3 name is: Matt');
  });

  it('renders with customized header', async () => {
    const steps: IWizardStep[] = [
      {
        title: 'Step 1',
        body: <p>Body</p>,
      },
      {
        title: '',
        body: null,
      },
    ];
    const { container } = render(<Wizard id="wizard-default" steps={steps} headingType="h1" />);
    expect(container).toMatchSnapshot();
  });

  it('focuses on next button if possible to go to next step', async () => {
    const steps: IWizardStep[] = [
      {
        title: 'Step 1',
        body: <p>Body</p>,
        allowNext: () => true,
      },
      {
        title: '',
        body: null,
      },
    ];
    render(<Wizard id="wizard-default" steps={steps} headingType="h1" />);
    const nextButton = screen.getByText('Next');
    expect(nextButton.matches(':focus')).toBeTruthy();
  });
});
