import React, { useState } from 'react';
import { Meta, Story } from '@storybook/react';
import { Documentation, dropdownFromHeadingTypes, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { Wizard } from './wizard';
import { IWizardStep } from './wizard-step';
import { Alert, AlertVariant } from '../../notifications/alert/alert';
import { Button, ButtonType } from '../../button/button';
import { noop } from '../../utils';
import { Checkbox } from '../../forms/checkboxes/checkbox';

export default {
  component: Wizard,
  title: 'Core Components/Navigation/Wizard Stepper',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const whenToUse = (
  <ul>
    <li>
      <strong className="text-success">Do</strong> use a horizontal stepper for a process where guiding users through a
      linear progression is important
    </li>
    <li>
      <strong className="text-danger">Don't</strong> use a horizontal stepper for a very long process. Consider using a
      left-navigation task list instead
    </li>
  </ul>
);

const accessibilityConsiderations = (
  <div>
    <p>Wizards must be keyboard accessible.</p>
    <p>
      Color contrast issues in the steps/progress section regarding future steps can be ignored since color constrast is
      should be ignored for inactive (or disabled) components
    </p>
  </div>
);

const argTypes = {
  headingType: {
    control: dropdownFromHeadingTypes(),
    defaultValue: 'h2',
  },
};

/**
 * Wizard
 */
export const BasicExample: Story = (props) => {
  const steps: IWizardStep[] = [
    {
      title: 'Clone the repo',
      body: (
        <p>
          First clone the repo from <code>git@git.uscis.dhs.gov:USCIS/react-beacon.git</code>
        </p>
      ),
      allowNext: () => true,
    },
    {
      title: 'Run npm install',
      body: (step) => {
        return <p>The current step says to {step.title}</p>;
      },
      allowPrevious: () => false,
      allowNext: () => true,
      onNext: (step, nextStep) => {
        return true;
      },
    },
    {
      title: 'Preventing navigation',
      body: <p>You cannot go any further now</p>,
      allowNext: (step) => false,
    },
    {
      body: null,
    },
  ];
  return <Wizard id="wizard-default" steps={steps} headingType={props.headingType} />;
};

BasicExample.storyName = 'Horizontal Stepper';
BasicExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Basic Wizard"
      description={
        <>
          <p>
            A wizard guides users through a series of well-defined steps. Wizards may help users with tasks that are
            complex, infrequently performed, or unfamiliar.
          </p>
          <h3>Horizontal Stepper</h3>
          <p>
            A horizontal stepper is a wizard that visually conveys users’ progress through numbered steps, shown left to
            right, that helps them know where they are in a process. These steppers also include optional subtext to
            describe a step to users. While the stepper is designed to encourage linear progression through the steps,
            requiring linear progression is optional, depending on the task.
          </p>
        </>
      }
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
BasicExample.argTypes = argTypes;

export const CookingExample: Story = (props) => {
  const [allowPevious, setAllowPrevious] = useState(true);
  const [allowNext, setAllowNext] = useState(true);
  const [allowOnNext, setAllowOnNext] = useState(true);

  const steps: IWizardStep[] = [
    {
      title: 'Prep your tools',
      description: 'Get all your tools in order for a clean cooking experience',
      allowNext: () => allowNext,
      body: (
        <>
          <h2>Prep your tools</h2>
          <p>Always remember that to use beacon, we must wrap our code with the beacon class.</p>
          <pre>
            <code className="language-html">
              {`
                <div className="beacon> 
                  <Button id="beacon-cooking-button" type={ButtonType.primary} onClick={noop}>
                    Primary button!
                  </Button>
                </div>`}
            </code>
          </pre>
        </>
      ),
    },
    {
      title: 'Specify File Transfer',
      description: 'Optional subtext to describe this step',
      allowNext: () => allowNext,
      allowPrevious: () => allowPevious,
      onNext: () => allowOnNext,
      body: (
        <>
          <h2>Cooking time!</h2>
          <Checkbox
            id="checkbox-previous"
            label="Allow previous step?"
            onChange={(event) => setAllowPrevious(event.target.checked)}
            defaultChecked={allowPevious}
          />
          <Checkbox
            id="checkbox-next"
            label="Allow next step?"
            onChange={(event) => setAllowNext(event.target.checked)}
            defaultChecked={allowNext}
          />
          <Checkbox
            id="checkbox-onNext"
            label={`onNext() return ${allowOnNext}`}
            onChange={(event) => setAllowOnNext(event.target.checked)}
            defaultChecked={allowOnNext}
          />
          <p>Now add all your ingredients to the Beacon pot and you're set!</p>
          <h3>Here is the result of our cooking:</h3>
          <Button id="beacon-cooking-button" type={ButtonType.primary} onClick={noop}>
            Primary button!
          </Button>
          <p>Beacon is as easy as 1-2-3!</p>
        </>
      ),
    },
    {
      title: '',
      body: <h2>Hope you enjoyed your Beacon!</h2>,
    },
  ];
  return <Wizard id="wizard-default" steps={steps} headingType={props.headingType} />;
};

CookingExample.storyName = 'Horizontal Stepper Cooking Example';

CookingExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Cooking with Beacon"
      description={
        <p>The Wizard's steps have a body property that is used to display the content for the current step.</p>
      }
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
CookingExample.argTypes = argTypes;

export const HandlersExample: Story = (props) => {
  const preFuncCalls: string[] = [],
    onFuncCalls: string[] = [],
    afterFuncCalls: string[] = [];
  const preFunc = () => {
    preFuncCalls.push(`Pre-function call: ${preFuncCalls.length + 1}`);
  };
  const onFunc = () => {
    onFuncCalls.push(`On-function call: ${onFuncCalls.length + 1}`);
    return true;
  };
  const afterFunc = () => {
    afterFuncCalls.push(`After-function call: ${afterFuncCalls.length + 1}`);
  };

  const onNext = (step: IWizardStep, nextStep: IWizardStep) => {
    // Using title to check if the next step is the end
    if (nextStep.title) {
      preFunc();
    }
    if (onFunc()) {
      afterFunc();
      return true;
    }
    return false;
  };

  const onPrevious = () => {
    preFunc();
    return true;
  };

  const body = () => (
    <Alert variant={AlertVariant.info}>
      <strong>Results</strong>
      <ul>
        <li>
          <strong>Pre-function calls:</strong>
          {JSON.stringify(preFuncCalls)}
        </li>
        <li>
          <strong>On-function calls:</strong>
          {JSON.stringify(onFuncCalls)}
        </li>
        <li>
          <strong>After-function calls:</strong>
          {JSON.stringify(afterFuncCalls)}
        </li>
      </ul>
    </Alert>
  );
  const steps: IWizardStep[] = [
    {
      title: 'Form Validation',
      description: 'Optional subtext to describe this step',
      body: body,
      onNext: onNext,
      onPrevious: onPrevious,
      nextButtonText: 'Complete Validation',
      allowNext: () => true,
    },
    {
      title: 'Specify File Transfer',
      description: 'Optional subtext to describe this step',
      body: body,
      onNext: onNext,
      onPrevious: onPrevious,
      allowNext: () => true,
    },
    {
      title: 'Finalize Transfer',
      description: 'Optional subtext to describe this step',
      body: body,
      onNext: onNext,
      onPrevious: onPrevious,
      nextButtonText: 'Complete Transfer',
      allowNext: () => true,
    },
    {
      title: '',
      body: body,
    },
  ];
  // Calling preFunc on load
  preFunc();
  return <Wizard id="wizard-default" steps={steps} headingType={props.headingType} />;
};

HandlersExample.storyName = 'Horizontal Stepper Next/Previous Handlers';

HandlersExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Wizard Handlers example"
      description={
        <>
          <p>
            The Wizard's steps have onNext and onPrevious properties that are call when the respective button is
            clicked. These handlers return a boolean to decide if the wizard should continue to the neighboring step.
          </p>
          <p>
            <strong>Beacon1 Migration Note:</strong> This example follows the example from beacon1. Beacon1 wizards used
            step-pre-fun, step-on-func, and step-after-func, this example will show how to use those functions using
            onNext and onPrevious handlers.
          </p>
        </>
      }
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
HandlersExample.argTypes = argTypes;

export const SkipAround: Story = (props) => {
  const [name, setName] = useState('No name');
  const [activeStep, setActiveStep] = useState(0);
  const steps: IWizardStep[] = [
    {
      title: 'Step 1',
      description: 'Optional subtext to describe this step',
      allowNext: () => true,
      body: (
        <div>
          <p>step 1 name is: {name}</p>
          <Button
            id="step2"
            onClick={() => {
              setName('John');
              setActiveStep(1);
            }}
          >
            Go to Step 2 (John)
          </Button>
          <Button
            id="step3"
            onClick={() => {
              setName('Matt');
              setActiveStep(2);
            }}
          >
            Go to Step 3 (Matt)
          </Button>
        </div>
      ),
    },
    {
      title: 'Step 2',
      description: 'Optional subtext to describe this step',
      allowNext: () => true,
      body: <div>step 2 name is: {name}</div>,
    },
    {
      title: 'Step 3',
      allowNext: () => true,
      body: <div>{`step 3 name is: ${name}`}</div>,
    },
    {
      title: 'Step 4',
      allowNext: () => true,
      description: 'Allows to reset',
      body: (
        <div>
          <p>step 4 name is: {name}</p>
          <Button
            id="reset"
            onClick={() => {
              setName('No name');
              setActiveStep(0);
            }}
          >
            Reset back to 1
          </Button>
        </div>
      ),
    },
    {
      title: 'Step 5',
      body: <div>step 3</div>,
    },
  ];

  return (
    <Documentation name="SkipAroundWizard">
      <Wizard id="potato-wizard" steps={steps} activeStepIndex={activeStep} headingType={props.headingType} />
    </Documentation>
  );
};
SkipAround.storyName = 'Skip Around in Horizontal Steppers';
SkipAround.argTypes = argTypes;
