import { fireEvent, render } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { TrackableEvent, defaultTracking, trackableEvent } from '../../analytics';
import { noop } from '../../utils';
import { ViewSwitcherOption } from './view-switcher-option';

// Mocks
jest.mock('../../analytics');

const trackableEventMock = trackableEvent as jest.MockedFunction<typeof trackableEvent>;
const defaultTrackingMock = defaultTracking as jest.MockedFunction<typeof defaultTracking>;

describe('View Switcher Option', () => {
  beforeEach(() => {
    trackableEventMock.mockReturnValue(jest.fn());
    defaultTrackingMock.mockReturnValue({});
  });

  it('renders correctly', () => {
    const { baseElement } = render(<ViewSwitcherOption id="option-1" label="I-90" />);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders disabled View Switcher Option correctly', () => {
    const { baseElement } = render(<ViewSwitcherOption id="option-1" label="I-90" disabled />);
    expect(baseElement).toMatchSnapshot();
  });

  it('view switcher option on click', () => {
    const { baseElement } = render(<ViewSwitcherOption id="option-1" label="I-90" onClick={noop} />);
    const option = baseElement.querySelector('#option-1');
    userEvent.click(option.children[0]);
    // First option should be selected
    expect(option?.getAttribute('aria-selected')).toBeTruthy();
    expect(defaultTrackingMock).toHaveBeenLastCalledWith(undefined, {
      grouping: 'Ungrouped',
      action: 'View Switcher Option Clicked',
      trackingKey: 'option-1',
    } as TrackableEvent);
  });

  it.each([
    { key: 'Enter', code: 'Enter', charCode: 13 },
    { key: ' ', code: 'Space' },
  ])('view switcher selected on "%p" key down', (options) => {
    const { baseElement } = render(<ViewSwitcherOption id="option-1" label="I-90" onClick={noop} />);
    const option = baseElement.querySelector('#option-1');

    fireEvent.keyDown(baseElement, { key: 'Tab', code: 'Tab', charCode: 9 });
    fireEvent.keyDown(option.children[0], options);

    // First option should be selected
    expect(option?.getAttribute('aria-selected')).toBeTruthy();
    expect(defaultTrackingMock).toHaveBeenLastCalledWith(undefined, {
      grouping: 'Ungrouped',
      action: 'View Switcher Option Clicked',
      trackingKey: 'option-1',
    } as TrackableEvent);
  });

  it('view switcher does not select on random key down', () => {
    const handleClickMock = jest.fn();

    trackableEventMock.mockReturnValue(handleClickMock);

    const { baseElement } = render(<ViewSwitcherOption id="option-1" label="I-90" onClick={noop} />);
    const option = baseElement.querySelector('#option-1');

    fireEvent.keyDown(baseElement, { key: 'Tab', code: 'Tab', charCode: 9 });
    fireEvent.keyDown(option.children[0], { key: 'e' });

    expect(option?.getAttribute('aria-selected')).toEqual('false');
    expect(handleClickMock).not.toHaveBeenCalled();
  });
});
