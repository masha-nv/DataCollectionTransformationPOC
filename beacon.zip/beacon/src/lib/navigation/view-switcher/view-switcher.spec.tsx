import { render, waitFor } from '@testing-library/react';
import { ViewSwitcherOption } from './view-switcher-option';
import { ViewSwitcher, SwitchType } from './view-switcher';
import userEvent from '@testing-library/user-event';
import { noop } from '../../utils';
import { track } from '../../analytics/matomo';
import { TrackableEvent } from '../../analytics';
import { Button, ButtonType } from '../../button/button';
import { useState } from 'react';
import { IconType, IconSize, IconVariant } from '../../icon/constants';
import { Icon } from '../../icon/icon';

jest.mock('../../analytics/matomo', () => {
  const module = jest.requireActual('../analytics/matomo');
  return {
    ...module,
    track: jest.fn(),
  };
});

const viewSwitcherSimple = (type: SwitchType, disabled: boolean) => (
  <ViewSwitcher id="view-switcher-id" type={type} disabled={disabled}>
    <ViewSwitcherOption id="option-1" label="I-90" />
    <ViewSwitcherOption id="option-2" label="N-400" />
  </ViewSwitcher>
);
describe('View Switcher', () => {
  it('renders default correctly', () => {
    const { baseElement } = render(
      <ViewSwitcher id="view-switcher" name="myNewViewSwitcher">
        <ViewSwitcherOption id="option-1" label="I-90" />
      </ViewSwitcher>
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('renders Primary View Switcher correctly', () => {
    const { baseElement } = render(viewSwitcherSimple(SwitchType.primary, false));
    expect(baseElement).toMatchSnapshot();
  });

  it('renders disabled View Switcher correctly', () => {
    const { baseElement } = render(viewSwitcherSimple(SwitchType.primary, true));
    expect(baseElement).toMatchSnapshot();
  });

  it('renders Secondary View Switcher correctly', () => {
    const { baseElement } = render(viewSwitcherSimple(SwitchType.secondary, false));
    expect(baseElement).toMatchSnapshot();
  });

  it('renders Secondary View Switcher with Icon', () => {
    const { baseElement } = render(
      <ViewSwitcher id="view-switcher-id" type={SwitchType.primary}>
        <ViewSwitcherOption
          id="option-1"
          label="I-90"
          icon={<Icon type={IconType.exclamationCircle} size={IconSize.regular} variant={IconVariant.danger} />}
        />
        <ViewSwitcherOption id="option-2" label="N-400" />
      </ViewSwitcher>
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('view switcher option on click', () => {
    const { baseElement } = render(
      <ViewSwitcher id="view-switcher" type={SwitchType.primary} name="myNewViewSwitcher" onChange={noop}>
        <ViewSwitcherOption id="view-switcher-option-1" label="I-485" />
        <ViewSwitcherOption id="view-switcher-option-2" label="I-130" />
      </ViewSwitcher>
    );
    const viewSwitcherElem = baseElement.querySelector('#view-switcher');
    // Click second option
    const secondOption = viewSwitcherElem.children[1];
    userEvent.click(secondOption.children[0]);
    // Second option should be selected
    expect(secondOption?.getAttribute('aria-selected')).toBe('true');

    // First option should not be selected
    const firstOption = viewSwitcherElem.children[0];
    expect(firstOption?.getAttribute('aria-selected') === 'false');
  });

  it('view switcher default option', () => {
    const defaultId = 'view-switcher-option-1';
    const { baseElement } = render(
      <ViewSwitcher
        id="view-switcher"
        type={SwitchType.primary}
        name="myNewViewSwitcher"
        onChange={noop}
        defaultSelected={defaultId}
      >
        <ViewSwitcherOption id={defaultId} label="I-485" />
        <ViewSwitcherOption id="view-switcher-option-2" label="I-130" />
      </ViewSwitcher>
    );
    const viewSwitcherElem = baseElement.querySelector('#view-switcher');
    expect(viewSwitcherElem.children[0]?.getAttribute('aria-selected')).toBe('true');
  });

  const ViewSwitcherElementWithExternalControl = () => {
    const [controlledElementId, setControlledElementId] = useState('view-switcher-option-1');
    return (
      <>
        <Button
          id="toggle-view-switcher-btn"
          type={ButtonType.primary}
          onClick={() => {
            setControlledElementId('view-switcher-option-2');
          }}
        >
          Toggle View Switcher Tab
        </Button>
        <ViewSwitcher
          id="view-switcher"
          type={SwitchType.primary}
          name="myNewViewSwitcher"
          selected={controlledElementId}
        >
          <ViewSwitcherOption id="view-switcher-option-1" label="I-485" />
          <ViewSwitcherOption id="view-switcher-option-2" label="I-130" />
        </ViewSwitcher>
      </>
    );
  };

  it('view switcher with active element selected via prop', async () => {
    const viewSwitcher = render(<ViewSwitcherElementWithExternalControl />);
    const viewSwitcherElem = viewSwitcher.baseElement.querySelector('#view-switcher');
    await waitFor(() => {
      expect(viewSwitcherElem.children.length).toEqual(2);
      expect(viewSwitcherElem.children[0].getAttribute('aria-selected')).toBe('true');
      expect(viewSwitcherElem.children[1].getAttribute('aria-selected')).toBe('false');
    });
    // External component changes the switcher value
    viewSwitcher.baseElement.querySelector<HTMLElement>('#toggle-view-switcher-btn').click();
    await waitFor(() => {
      expect(viewSwitcherElem.children[0].getAttribute('aria-selected')).toBe('false');
      expect(viewSwitcherElem.children[1].getAttribute('aria-selected')).toBe('true');
    });
    // User can still change switcher value by clicking on one of its tabs
    userEvent.click(viewSwitcherElem.children[0].children[0]);
    await waitFor(() => {
      expect(viewSwitcherElem.children[0].getAttribute('aria-selected')).toBe('true');
      expect(viewSwitcherElem.children[1].getAttribute('aria-selected')).toBe('false');
    });
  });

  it('view switcher track option click', () => {
    const { baseElement } = render(
      <ViewSwitcher id="view-switcher" type={SwitchType.primary} name="myNewViewSwitcher" onChange={noop}>
        <ViewSwitcherOption id="view-switcher-option-1" label="I-485" />
        <ViewSwitcherOption id="view-switcher-option-2" label="I-130" />
      </ViewSwitcher>
    );
    const viewSwitcherElem = baseElement.querySelector('#view-switcher');
    // Click second option
    const secondOption = viewSwitcherElem.children[1];
    userEvent.click(secondOption.children[0]);
    // Second option should be selected
    expect(secondOption?.getAttribute('aria-selected')).toBe('true');

    expect(track).toHaveBeenLastCalledWith({
      grouping: 'Ungrouped',
      action: 'View Switcher Option Clicked',
      trackingKey: 'view-switcher-option-2',
    } as TrackableEvent);
  });

  describe('errors', () => {
    let originalError: typeof console.error;
    beforeEach(() => {
      originalError = console.error;
      console.error = jest.fn();
    });

    it('does not allow non ViewSwitcherOption child components', () => {
      const renderAction = () => {
        render(
          <ViewSwitcher id={'view-switcher-id'} type={SwitchType.primary}>
            <ViewSwitcherOption id="view-switcher-option-1" label="I-90" />
            <div>N400</div>
          </ViewSwitcher>
        );
      };

      expect(renderAction).toThrowError(
        'ViewSwitcher component only allows children of type ViewSwitcherOption. Not div'
      );
    });

    afterEach(() => {
      console.error = originalError;
    });
  });
});
