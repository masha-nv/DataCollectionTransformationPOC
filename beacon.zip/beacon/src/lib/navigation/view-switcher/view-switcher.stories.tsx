import React from 'react';
import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { ViewSwitcherOption } from './view-switcher-option';
import { ViewSwitcher, SwitchType } from './view-switcher';
import { IDatatableColumn, Datatable } from '../../table/datatable/datatable';
import { Button, ButtonType } from '../../button/button';
import './view-switcher.stories.scss';
import { Icon, IconSize, IconType, IconVariant } from '../../icon/icon';

export default {
  component: ViewSwitcher,
  title: 'Core Components/Navigation/View Switcher',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const whenToUse = (
  <>
    <p>
      The View Switcher enables a user to display alternate or filtered views of the same information. To display views
      of different information, consider using Tabs.
    </p>
    <ul>
      <li>
        <strong className="beacon-icon-success">Do </strong>keep label within view switcher short and intuitive
      </li>
      <li>
        <strong className="beacon-icon-danger">Don't </strong> use more than four labels within view switcher
      </li>
      <li>
        <strong className="beacon-icon-danger">Don't </strong> wrap label text -- if the text is too long for the view
        switcher, shorten it
      </li>
      <li>
        <strong className="beacon-icon-danger">Don't </strong> change label text based on state of the view switcher
      </li>
    </ul>
    <p>
      <b>Sample Use Case: </b>When used with the datatable, the ViewSwitcher allows the adjudicator to easily navigate
      among different applicants' cases that are grouped by form type by clicking the corresponding labels.
    </p>
  </>
);
interface CaseData {
  receiptNumber: string;
  formType: string;
  caseStatus: string;
}

const data: CaseData[] = [
  { receiptNumber: 'IOE123456789', formType: 'I-130', caseStatus: 'Case Review' },
  { receiptNumber: 'IOE123456788', formType: 'I-129', caseStatus: 'Closed' },
  { receiptNumber: 'IOE123456787', formType: 'I-130', caseStatus: 'Rendering Decision' },
  { receiptNumber: 'IOE123456786', formType: 'I-485', caseStatus: 'Rendering Decision' },
  { receiptNumber: 'IOE123456785', formType: 'N-600', caseStatus: 'Supervisory Review' },
  { receiptNumber: 'IOE123456784', formType: 'N-600', caseStatus: 'Rendering Decision' },
  { receiptNumber: 'IOE123456783', formType: 'I-130', caseStatus: 'Ready for Adjudication' },
  { receiptNumber: 'IOE123456782', formType: 'I-485', caseStatus: 'Case Review' },
  { receiptNumber: 'IOE123456781', formType: 'I-130', caseStatus: 'Rendering Decision' },
];

const columns: IDatatableColumn<CaseData>[] = [
  {
    name: 'Receipt Number',
    selector: 'receiptNumber',
  },
  {
    name: 'Form Type',
    selector: 'formType',
  },
  {
    name: 'Status',
    selector: 'caseStatus',
  },
];
const allCase = 'All Case';

export const PrimaryViewSwitcherNavigation: Story = () => {
  const defaultOption = {
    id: 'view-switcher-option-2',
    label: 'I-485',
  };
  const [filterText, setFilterText] = React.useState(defaultOption.label);
  const filteredData = filterText === allCase ? data : data.filter((item) => item.formType.includes(filterText));
  const simpleTable = (
    <Datatable id="case-table" title="Primary View Switcher Table" columns={columns} data={filteredData} />
  );

  return (
    <>
      <ViewSwitcher
        id="view-switcher"
        onChange={(_, selection) => setFilterText(selection)}
        defaultSelected={defaultOption.id}
      >
        <ViewSwitcherOption id="view-switcher-option-1" label={allCase} />
        <ViewSwitcherOption id="view-switcher-option-2" label="I-485" />
        <ViewSwitcherOption id="view-switcher-option-3" label="I-129" />
      </ViewSwitcher>
      {simpleTable}
    </>
  );
};
PrimaryViewSwitcherNavigation.storyName = 'View Switcher';
PrimaryViewSwitcherNavigation.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Primary View Switcher"
      whenToUse={whenToUse}
      description="View switchers are used to display alternate or filtered views of the same information. For example, a view switcher could allow the user to switch between displaying all product lines and a specific product line within a table. The default type is primary which has a blue theme."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const PrimaryViewSwitcherNavigationWithIcon: Story = () => {
  const defaultOption = {
    id: 'view-switcher-icon-option-2',
    label: 'I-485',
  };
  const [filterText, setFilterText] = React.useState(defaultOption.label);
  const filteredData = filterText === allCase ? data : data.filter((item) => item.formType.includes(filterText));
  const simpleTable = (
    <Datatable id="case-table" title="Primary View Switcher Table" columns={columns} data={filteredData} />
  );

  return (
    <>
      <ViewSwitcher
        id="view-switcher"
        onChange={(_, selection) => setFilterText(selection)}
        defaultSelected={defaultOption.id}
      >
        <ViewSwitcherOption id="view-switcher-icon-option-1" label={allCase} />
        <ViewSwitcherOption
          id="view-switcher-icon-option-2"
          label="I-485"
          icon={<Icon type={IconType.exclamationCircle} size={IconSize.regular} variant={IconVariant.danger} />}
        />
        <ViewSwitcherOption id="view-switcher-icon-option-3" label="I-129" />
      </ViewSwitcher>
      {simpleTable}
    </>
  );
};
PrimaryViewSwitcherNavigationWithIcon.storyName = 'View Switcher with Icon';
PrimaryViewSwitcherNavigationWithIcon.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Primary View Switcher with Icon"
      whenToUse={whenToUse}
      description="Icons can be preprended to view switcher labels in order to convey additional information to the user, such as if the underlying content contains a field with missing data."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const ControlledViewSwitcherNavigation: Story = () => {
  const viewSwitcherTabs = [
    { id: 'view-switcher-controlled-option-1', label: allCase },
    { id: 'view-switcher-controlled-option-2', label: 'I-485' },
    { id: 'view-switcher-controlled-option-3', label: 'I-129' },
  ];
  const defaultOption = viewSwitcherTabs[1];
  const [filterText, setFilterText] = React.useState(defaultOption.label);
  const [controlledElementId, setControlledElementId] = React.useState(defaultOption.id);
  const filteredData = filterText === allCase ? data : data.filter((item) => item.formType.includes(filterText));
  const simpleTable = (
    <Datatable id="case-table" title="Controlled View Switcher Table" columns={columns} data={filteredData} />
  );

  return (
    <>
      <Button
        id="toggle-view-switcher-btn"
        type={ButtonType.primary}
        onClick={() => {
          const tabIndex = viewSwitcherTabs.findIndex((tab) => tab.id === controlledElementId);
          const newSwitcherTabIndex = (tabIndex + 1) % 3;
          setControlledElementId(viewSwitcherTabs[newSwitcherTabIndex].id);
          setFilterText(viewSwitcherTabs[newSwitcherTabIndex].label);
        }}
      >
        Toggle View Switcher Tab
      </Button>
      <ViewSwitcher
        id="view-switcher"
        onChange={(element, selection) => {
          if (element.target.parentElement) {
            setControlledElementId(element.target.parentElement.id);
          }
          setFilterText(selection);
        }}
        selected={controlledElementId}
      >
        {viewSwitcherTabs.map((viewSwitcherTab) => (
          <ViewSwitcherOption id={viewSwitcherTab.id} label={viewSwitcherTab.label} />
        ))}
      </ViewSwitcher>
      {simpleTable}
    </>
  );
};
ControlledViewSwitcherNavigation.storyName = 'Controlled View Switcher';
ControlledViewSwitcherNavigation.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Controlled View Switcher"
      whenToUse={whenToUse}
      description={`If a view switcher's state needs to be managed by the parent component, then this can be accomplished by passing the ID of the tab that you wish to be active, to the "selected" field.`}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const SecondaryViewSwitcherNavigation: Story = () => {
  const defaultOption = {
    id: 'view-switcher-secondary-option-1',
    label: allCase,
  };
  const [filterText, setFilterText] = React.useState(defaultOption.label);
  const filteredData = filterText === allCase ? data : data.filter((item) => item.formType.includes(filterText));
  const simpleTable = (
    <Datatable id="case-table" title="Secondary View Switcher Table" columns={columns} data={filteredData} />
  );

  return (
    <>
      <ViewSwitcher
        id="view-switcher"
        type={SwitchType.secondary}
        onChange={(_, selection) => setFilterText(selection)}
        defaultSelected={defaultOption.id}
      >
        <ViewSwitcherOption id="view-switcher-secondary-option-1" label={allCase} />
        <ViewSwitcherOption id="view-switcher-secondary-option-2" label="I-130" />
        <ViewSwitcherOption id="view-switcher-secondary-option-3" label="N-600" />
      </ViewSwitcher>
      {simpleTable}
    </>
  );
};

SecondaryViewSwitcherNavigation.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Secondary View Switcher"
      whenToUse={whenToUse}
      description="The secondary View switchers have a darker theme compare to primary."
    >
      <ComponentStory />
    </Documentation>
  ),
];
SecondaryViewSwitcherNavigation.storyName = 'Gray View Switcher';

export const DisabledViewSwitcherNavigation: Story = () => {
  return (
    <ViewSwitcher id="disabled-view-switcher" disabled>
      <ViewSwitcherOption id="view-switcher-disabled-option-1" label={allCase} />
      <ViewSwitcherOption id="view-switcher-disabled-option-2" label="I-130" />
      <ViewSwitcherOption id="view-switcher-disabled-option-3" label="N-600" />
    </ViewSwitcher>
  );
};

DisabledViewSwitcherNavigation.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Disabled View Switcher"
      whenToUse={whenToUse}
      description="View switchers that are disabled would not allow user to click."
    >
      <ComponentStory />
    </Documentation>
  ),
];
DisabledViewSwitcherNavigation.storyName = 'Disabled View Switcher';
