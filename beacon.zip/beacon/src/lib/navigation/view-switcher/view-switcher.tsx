import React, { Children, SyntheticEvent, useEffect, useState } from 'react';
import { WithId } from '../../with-id';
import { WithInput } from '../../with-input';
import { noop } from '../../utils';
import classNames from 'classnames';
import { IViewSwitcherOptionProps, ViewSwitcherOption } from './view-switcher-option';

export interface IViewSwitcherProps extends WithId, WithInput {
  /**
   * Type of the view switch, the default value is SwitchType.Primary.
   * User can choose SwitchType.Secondary for the second theme.
   */
  type?: SwitchType;
  /**
   * Must be of type viewSwitcherOption
   */
  children: React.ReactElement<IViewSwitcherOptionProps>[] | React.ReactElement<IViewSwitcherOptionProps>;
  /**
   * Set default selected option by viewSwitcherOption id
   */
  defaultSelected?: string;
  /**
   * Control selected option by viewSwitcherOption id
   */
  selected?: string;
}

/**
 * Type enum
 */
export enum SwitchType {
  primary = 'primary',
  secondary = 'secondary',
}

export const ViewSwitcher = ({
  id,
  children,
  disabled,
  type = SwitchType.primary,
  onChange = noop,
  defaultSelected,
  selected: controlledSelected,
}: IViewSwitcherProps) => {
  let initialState = '';
  if (controlledSelected) {
    initialState = controlledSelected;
  } else if (defaultSelected) {
    initialState = defaultSelected;
  }
  const [selected, setSelected] = useState<string>(initialState);
  const viewSwitchClass = classNames('toggle', {
    'toggle-primary': type === SwitchType.primary,
    'toggle-secondary': type === SwitchType.secondary,
    disabled: disabled,
  });

  useEffect(() => {
    if (controlledSelected) {
      setSelected(controlledSelected);
    }
  }, [controlledSelected]);

  const handleOnClick = (event: SyntheticEvent, optionProps: IViewSwitcherOptionProps) => {
    optionProps.onClick && optionProps.onClick(event);
    setSelected(optionProps.id);
  };

  return (
    <div id={id} className={viewSwitchClass}>
      {Children.map(children, (child) => {
        // Restrict children to a specific type
        if (child.type !== ViewSwitcherOption) {
          throw new Error(
            `${ViewSwitcher.name} component only allows children of type ${ViewSwitcherOption.name}. Not ${child.type}`
          );
        }

        const optionProps = child.props;
        return (
          <ViewSwitcherOption
            label={optionProps.label}
            icon={optionProps.icon}
            id={optionProps.id}
            onClick={(e: SyntheticEvent) => handleOnClick(e, optionProps)}
            selected={optionProps.id === selected}
            onChange={onChange}
          />
        );
      })}
    </div>
  );
};
ViewSwitcher.displayName = 'ViewSwitcher';
