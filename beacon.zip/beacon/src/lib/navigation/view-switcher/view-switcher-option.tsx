import React, { ReactNode, SyntheticEvent, useRef } from 'react';
import { noop } from '../../utils';
import { WithId } from '../../with-id';
import { WithInput } from '../../with-input';
import { defaultTracking, Trackable, trackableEvent } from '../../analytics';

export interface IViewSwitcherOptionProps extends WithId, WithInput, Trackable {
  /**
   * The label of the option header that bind to the onChange value
   */
  label: string;
  /**
   * Callback function executed when viewSwitcherOption is clicked upon
   * This is controlled by the parent viewSwitcher component if it is within a group.
   */
  onClick?: (event: SyntheticEvent) => void;
  /**
   * Determines if the viewSwitcherOption is in a "selected" state.
   * This is controlled by the parent viewSwitcher component if it is within a group.
   */
  selected?: boolean;

  icon?: ReactNode;
}

const isSpaceOrEnterKey = (e: React.KeyboardEvent<HTMLElement>) => e.key === ' ' || e.key === 'Enter';

export const ViewSwitcherOption = ({
  id,
  label,
  selected = false,
  onChange = noop,
  onClick = noop,
  icon,
  ...props
}: IViewSwitcherOptionProps) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const trackingInfo = defaultTracking(props.tracking, {
    grouping: 'Ungrouped',
    action: 'View Switcher Option Clicked',
    trackingKey: `${id}`,
  });

  return (
    <div
      className="toggle-option"
      id={id}
      aria-selected={selected}
      onKeyDown={(e) => {
        const { current } = inputRef;

        if (!isSpaceOrEnterKey(e) || !current) {
          return;
        }

        current.click();
      }}
    >
      <input
        ref={inputRef}
        className="toggle-option-input"
        onChange={(selection) => onChange(selection, label)}
        onClick={trackableEvent(trackingInfo, onClick)}
        checked={selected}
        id={`${id}-Input`}
        type="radio"
        tabIndex={-1}
      ></input>
      <label className="toggle-option-label" htmlFor={`${id}-Input`} tabIndex={0}>
        {icon} {label}
      </label>
    </div>
  );
};

ViewSwitcherOption.displayName = 'ViewSwitcherOption';
