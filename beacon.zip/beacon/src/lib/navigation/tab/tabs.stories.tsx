import React, { MutableRefObject, ReactElement, ReactNode, useRef, useState } from 'react';
import { Button, ButtonType } from '../../button/button';
import { Icon, IconSize, IconType, IconVariant } from '../../icon/icon';
import { Documentation } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { action } from '@storybook/addon-actions';
import { Tabs, TabSize, TabsRef, TabType } from './tabs';
import { IPaneProps, Pane } from './pane';
import { FormGroup } from '../../forms/form-group/form-group';
import { TextInput } from '../../forms/text-input/text-input';
import { Story } from '@storybook/react';
import { Badge, BadgeVariant } from '../../notifications/badge/badge';
import { Modal } from '../../modals/modal/modal';
import { ActionMenu } from '../../action-menu/dropdown-action-menu/action-menu';
import { Action } from '../../action-menu/dropdown-action-menu/action';
import { DatePicker } from '../../forms/date-picker/date-picker';
import { Direction } from '../../modals/modal-types';
import { Checkbox } from '../../forms/checkboxes/checkbox';

export default {
  component: Tabs,
  title: 'Core Components/Navigation/Tab',
  parameters: {
    badges: [],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
};

const whenToUse = (
  <p>
    <strong>Tabs</strong> should be used to seperate different sections or categories of a site. They can also be used
    to display closeable instances of page content.
  </p>
);
const accessibilityConsiderations = <p>Each tab must have a unique name. All tabs must be keyboard accessible.</p>;

const indicatorNote = (
  <p>
    <strong>Note:</strong> To maintain flexibilty of the elements used within the tab, spacing/styling should be handled
    by the developer{' '}
  </p>
);

const FocusableComponent = () => {
  return (
    <div style={{ marginTop: '10px' }} className="w-50">
      <FormGroup id="fg-id">
        <label htmlFor="firstName">First Name</label>
        <TextInput name="firstName" id="firstName" />
      </FormGroup>
    </div>
  );
};

const StatefulComponent = () => {
  const [value, setValue] = useState(10);
  const UpdateValue = (delta: number) => {
    setValue(value + delta);
  };

  return (
    <div style={{ marginTop: '10px' }}>
      <button onClick={() => UpdateValue(-1)}>
        <Icon type={IconType.chevronLeft} description="Subtract" />
      </button>

      <span style={{ marginLeft: '10px', marginRight: '10px' }}>{value}</span>

      <button onClick={() => UpdateValue(1)}>
        <Icon type={IconType.chevronRight} description="Add" />
      </button>
    </div>
  );
};

export const StandardTab: Story = () => {
  const [verticalNav, setVerticalNav] = useState(false);
  return (
    <>
      <Button
        id="focusBtn"
        type={ButtonType.primary}
        onClick={() => {
          console.log('test');
        }}
      >
        Focus Test
      </Button>
      <br />
      <br />
      <Checkbox
        id="verticalNavigation"
        label="Vertical Keyboard Navigation"
        checked={verticalNav}
        onClick={() => {
          setVerticalNav(!verticalNav);
        }}
      ></Checkbox>
      <Tabs
        id={'tab-id'}
        verticalKeyboardNavigation={verticalNav}
        onPaneClose={action('OnPanelClosed')}
        onPaneClick={action('OnPanelClick')}
      >
        <Pane id="first" label="First" closeable>
          <div>First Tab</div>
        </Pane>
        <Pane id="second" label="Second">
          <div>
            <h5>Second Tab - Focusable Component (Focus moves to first focusable element in the Pane) :</h5>
            <FocusableComponent />
          </div>
        </Pane>
        <Pane id="third" label="Third" closeable>
          <div>
            <div>Third tab - State is maintained (Click on either button to change internal state):</div>
            <StatefulComponent />
          </div>
        </Pane>
        <Pane id="fourth" label="Fourth">
          <div>Fourth Tab</div>
        </Pane>
        <Pane id="fifth" label="Fifth" closeable>
          <div>
            <div>Fifth tab</div>
          </div>
        </Pane>
      </Tabs>

      <br />
      <br />
      <Button
        id="focusBtnTwo"
        type={ButtonType.primary}
        onClick={() => {
          console.log('test2');
        }}
      >
        Focus Test Two
      </Button>
    </>
  );
};
StandardTab.storyName = 'Primary Tab';
StandardTab.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Primary Tab Component"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description="Primary tabs are used to quickly navigate among information views within the same context (for example, different categories of information within a single case)."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const StandardTabWithIcon: Story = () => {
  return (
    <Tabs id={'tab-id'} onPaneClose={action('OnPanelClosed')} onPaneClick={action('OnPanelClick')}>
      <Pane
        id="first"
        label="First"
        icon={<Icon type={IconType.exclamationTriangle} size={IconSize.regular} variant={IconVariant.warning} />}
        closeable
      >
        <div>First Tab</div>
      </Pane>
      <Pane id="second" label="Second">
        <div>
          <h5>Second Tab - Focusable Component (Focus moves to first focusable element in the Pane) :</h5>
          <FocusableComponent />
        </div>
      </Pane>
      <Pane id="third" label="Third" closeable>
        <div>
          <div>Third tab - State is maintained (Click on either button to change internal state):</div>
          <StatefulComponent />
        </div>
      </Pane>
      <Pane id="fourth" label="Fourth">
        <div>Fourth Tab</div>
      </Pane>
    </Tabs>
  );
};
StandardTabWithIcon.storyName = 'Primary Tab with Icon';
StandardTabWithIcon.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Primary Tab Component with Icon"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description="Icons can be preprended to tab labels in order to convey additional information to the user, such as if the tab content contains a field with missing data."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const StandardTabSmall: Story = () => {
  return (
    <Tabs id={'tab-id'} size={TabSize.small} onPaneClose={action('OnPanelClosed')}>
      <Pane id="first" label="First" closeable>
        <div>First Tab</div>
      </Pane>
      <Pane id="second" label="Second">
        <div>
          <h5>Second Tab - Focusable Component (Focus moves to first focusable element in the Pane) :</h5>
          <FocusableComponent />
        </div>
      </Pane>
      <Pane id="third" label="Third" closeable>
        <div>
          <div>Third tab - State is maintained (Click on either button to change internal state):</div>
          <StatefulComponent />
        </div>
      </Pane>
      <Pane id="fourth" label="Fourth">
        <div>Fourth Tab</div>
      </Pane>
    </Tabs>
  );
};
StandardTabSmall.storyName = 'Primary Tab Small';
StandardTabSmall.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Primary Tab Component - Small"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description="Primary tabs are used to quickly navigate among information views within the same context (for example, different categories of information within a single case)."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const SecondaryTab: Story = () => {
  return (
    <Tabs id={'tab-id'} type={TabType.secondary} onPaneClose={action('OnPanelClosed')}>
      <Pane id="first" label="First">
        <div>FIRST</div>
      </Pane>
      <Pane id="second" label="Second">
        <div>SECOND</div>
      </Pane>
      <Pane id="third" label="Third">
        <div>
          <div>State is maintained:</div>
          <StatefulComponent />
        </div>
      </Pane>
      <Pane id="fourth" label="Fourth" closeable>
        <div>Fourth</div>
      </Pane>
    </Tabs>
  );
};
SecondaryTab.storyName = 'Secondary Tab';
SecondaryTab.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Secondary Tab Component"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description="Secondary tabs (H3 and H4) present less visual focus than primary tabs, but function the same way. Secondary tabs can be used in modals or other places where primary tabs take up too much space."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const SecondaryTabSmall: Story = () => {
  return (
    <Tabs id={'tab-id'} type={TabType.secondary} size={TabSize.small} onPaneClose={action('OnPanelClosed')}>
      <Pane id="first" label="First">
        <div>FIRST</div>
      </Pane>
      <Pane id="second" label="Second">
        <div> SECOND</div>
      </Pane>
      <Pane id="third" label="Third">
        <div>
          <div>State is maintained:</div>
          <StatefulComponent />
        </div>
      </Pane>
      <Pane id="fourth" label="Fourth" closeable>
        <div> Fourth</div>
      </Pane>
    </Tabs>
  );
};
SecondaryTabSmall.storyName = 'Secondary Tab Small';
SecondaryTabSmall.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Seconday Tab Component - Small"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description="Secondary tabs (H3 and H4) present less visual focus than primary tabs, but function the same way. Secondary tabs can be used in modals or other places where primary tabs take up too much space."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const DynamicTabs: Story = () => {
  const tabData: { id: string; label: string; node: ReactNode }[] = [
    { id: 'first', label: 'First', node: <div className="pb-1">FIRST</div> },
    { id: 'second', label: 'Second', node: <div className="pb-1">SECOND</div> },
    {
      id: 'third',
      label: 'Third',
      node: (
        <>
          <div>State is maintained:</div>
          <StatefulComponent />
        </>
      ),
    },
    { id: 'fourth', label: 'Fourth', node: <div className="pb-1">Fourth</div> },
  ];
  const tabMapper = (item: { id: string; label: string; node: ReactNode }) => {
    return (
      <Pane id={item.id} label={item.label}>
        <div className="pb-1">{item.node}</div>
      </Pane>
    );
  };
  const [nextId, setNextId] = useState(1);
  const [tabsList, setTabsList] = useState<ReactElement[]>(tabData.map(tabMapper));
  const addTab = () => {
    tabsList.push(
      tabMapper({
        id: `new-${nextId}`,
        label: `New-${nextId}`,
        node: (
          <Pane id={`new-${nextId}`} label={`New-${nextId}`} closeable>
            <div className="pb-1"> New-{nextId}</div>
          </Pane>
        ),
      })
    );
    setTabsList([...tabsList]);
    setNextId(nextId + 1);
  };
  const onPanelClose = (index: number) => {
    tabsList.splice(index, 1);
    setTabsList([...tabsList]);
  };
  return (
    <>
      <Tabs id={'tab-id'} onPaneClose={onPanelClose}>
        {React.Children.map(tabsList, (child, index) => {
          const paneProps = child.props as IPaneProps;
          return React.cloneElement(child, paneProps);
        })}
      </Tabs>
      <Button id="btn" type={ButtonType.primary} onClick={() => addTab()}>
        Add Tab
      </Button>
    </>
  );
};
DynamicTabs.storyName = 'Dynamic Tabs';
DynamicTabs.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Tab Component with Dynamic tabs"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description="Tabs can be added and removed from the collection as needed"
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const StandardTabWithDefaultSelection: Story = () => {
  return (
    <Tabs id={'tab-id'} onPaneClose={action('OnPanelClosed')} defaultIndex={1}>
      <Pane id="first" label="First" closeable>
        <div>First Tab</div>
      </Pane>
      <Pane id="second" label="Second">
        <div>
          <strong>Second Tab - Focusable Component (Focus moves to first focusable element in the Pane) :</strong>
          <FocusableComponent />
        </div>
      </Pane>
      <Pane id="third" label="Third" closeable>
        <div>
          <div>Third tab - State is maintained (Click on either button to change internal state):</div>
          <StatefulComponent />
        </div>
      </Pane>
      <Pane id="fourth" label="Fourth">
        <div>Fourth Tab</div>
      </Pane>
    </Tabs>
  );
};
StandardTabWithDefaultSelection.storyName = 'Primary Tab With Default Selection';
StandardTabWithDefaultSelection.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Primary Tab with Default Selection"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description="Primary tabs are used to quickly navigate among information views within the same context (for example, different categories of information within a single case)."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const StandardTabWithCloseTabTooltipDirection: Story = () => {
  return (
    <Tabs id={'tab-id'} onPaneClose={action('OnPanelClosed')} defaultIndex={1}>
      <Pane id="first" label="First" closeable direction={Direction.right}>
        <div>First Tab - Right direction tooltip</div>
      </Pane>
      <Pane id="second" label="Second" closeable>
        <div>
          <strong>Second Tab - Default top direction tooltip</strong>
          <FocusableComponent />
        </div>
      </Pane>
      <Pane id="third" label="Third" closeable direction={Direction.left}>
        <div>
          <div>Third tab - Left direction tooltip</div>
          <StatefulComponent />
        </div>
      </Pane>
    </Tabs>
  );
};
StandardTabWithCloseTabTooltipDirection.storyName = 'Tab With Customizable Close Tab Tooltip Direction';
StandardTabWithCloseTabTooltipDirection.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Tab With Customizable Close Tab Tooltip Direction"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description="Tabs can be customized to change the direction of the tooltip that appears when selecting the close icon for a tab."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const StandardTabWithLazyLoading: Story = () => {
  const [label, setLabel] = useState('Total tabs loaded: 1');

  const onPaneClick = ({ id, children, selected }: IPaneProps) => {
    setTimeout(function () {
      setLabel(`Total tabs loaded: ${document.querySelectorAll('div.tab-pane').length}`);
    }, 0);
  };
  return (
    <>
      <Tabs id={'tab-id'} lazyLoading defaultIndex={0} onPaneClick={onPaneClick}>
        <Pane id="lazy-loading-tab1" label="First">
          <div />
        </Pane>
        <Pane id="azy-loading-tab2" label="Second">
          <div />
        </Pane>
        <Pane id="azy-loading-tab3" label="Third">
          <div />
        </Pane>
      </Tabs>
      <div>{label}</div>
    </>
  );
};

StandardTabWithLazyLoading.storyName = 'Primary Tab With Lazy Loading';
StandardTabWithLazyLoading.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Primary Tab with Lazy Loading"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description="Lazy-loaded tabs are useful for resource or network usage conservation. For example, if your application has an array of tabs whose contents all require data processing or API calls to be made to other services, you may wish for that to be delayed until the user actually accesses them."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const StandardTabWithIndicator: Story = () => {
  return (
    <Tabs id={'tab-id'} onPaneClose={action('OnPanelClosed')} onPaneClick={action('OnPanelClick')}>
      <Pane
        id="first"
        label={'First'}
        closeable
        tabInd={
          <Badge showIcon={false} variant={BadgeVariant.success} id={'tab-badge'}>
            Completed
          </Badge>
        }
      >
        <div>First Tab</div>
      </Pane>
      <Pane
        id="second"
        label={'Second'}
        tabInd={
          <Badge showIcon={false} variant={BadgeVariant.warning} id={'tab-badge'}>
            Pending
          </Badge>
        }
      >
        <div>
          <h5>Second Tab - Focusable Component (Focus moves to first focusable element in the Pane) :</h5>
          <FocusableComponent />
        </div>
      </Pane>
      <Pane id="third" label="Third" closeable>
        <div>
          <div>Third tab - State is maintained (Click on either button to change internal state):</div>
          <StatefulComponent />
        </div>
      </Pane>
      <Pane id="fourth" label="Fourth">
        <div>Fourth Tab</div>
      </Pane>
    </Tabs>
  );
};
StandardTabWithIndicator.storyName = 'Primary Tab With Indicator';
StandardTabWithIndicator.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Primary Tab with Indicator"
      whenToUse={
        <>
          {whenToUse}
          {indicatorNote}
        </>
      }
      accessibilityConsiderations={accessibilityConsiderations}
      description="Tabs are used in conjunction with Indicators in order to display some information related to a section at a quick glance without needing to select a tab."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const StandardTabWithCloseConfirmation: Story = () => {
  const closeConfirmation = async (index: number) => {
    return window.confirm(`Are you sure you want to delete tab ${index}?`);
  };
  return (
    <Tabs
      id={'tab-id'}
      onPaneClose={action('OnPanelClosed')}
      onPaneClick={action('OnPanelClick')}
      confirmClose={closeConfirmation}
    >
      <Pane id="first" label="First" closeable>
        <div>First Tab</div>
      </Pane>
      <Pane id="second" label="Second">
        <div>
          <h5>Second Tab - Focusable Component (Focus moves to first focusable element in the Pane) :</h5>
          <FocusableComponent />
        </div>
      </Pane>
      <Pane id="third" label="Third" closeable>
        <div>
          <div>Third tab - State is maintained (Click on either button to change internal state):</div>
          <StatefulComponent />
        </div>
      </Pane>
      <Pane id="fourth" label="Fourth">
        <div>Fourth Tab</div>
      </Pane>
    </Tabs>
  );
};
StandardTabWithCloseConfirmation.storyName = 'Primary Tab with Close Confirmation';
StandardTabWithCloseConfirmation.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Primary Tab Component with Close Confirmation"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description="Use the Close Confirmation callback in order to ensure the user truly meant to close the tab."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const StandardTabWithCloseConfirmationModal: Story = () => {
  const closeConfirmation = async (index: number): Promise<boolean> => {
    return new Promise((resolve) => {
      resolveFunction.current = resolve;
      setOpen(true);
    });
  };

  const onModalClose = (isConfirmed: boolean) => {
    setOpen(false);
    if (resolveFunction.current) {
      resolveFunction.current(isConfirmed);
    }
  };
  const resolveFunction: MutableRefObject<((value: boolean | PromiseLike<boolean>) => void) | undefined> = useRef();
  const [open, setOpen] = useState(false);

  const footerContent = (
    <>
      <Button id="cancel" type={ButtonType.secondary} onClick={() => onModalClose(false)}>
        Cancel
      </Button>
      <Button id="confirm" type={ButtonType.primary} onClick={() => onModalClose(true)}>
        Confirm Delete
      </Button>
    </>
  );

  return (
    <>
      <Tabs
        id={'tab-id'}
        onPaneClose={action('OnPanelClosed')}
        onPaneClick={action('OnPanelClick')}
        confirmClose={closeConfirmation}
      >
        <Pane id="first" label="First" closeable>
          <div>First Tab</div>
        </Pane>
        <Pane id="second" label="Second">
          <div>
            <h5>Second Tab - Focusable Component (Focus moves to first focusable element in the Pane) :</h5>
            <FocusableComponent />
          </div>
        </Pane>
        <Pane id="third" label="Third" closeable>
          <div>
            <div>Third tab - State is maintained (Click on either button to change internal state):</div>
            <StatefulComponent />
          </div>
        </Pane>
        <Pane id="fourth" label="Fourth">
          <div>Fourth Tab</div>
        </Pane>
      </Tabs>
      {open && (
        <Modal
          id="app-modal-id"
          title="Modal Title goes here"
          footer={footerContent}
          onRequestClose={() => onModalClose(false)}
          appElementSelector="#app-root"
          headingType={'h2'}
        >
          This is a modal
        </Modal>
      )}
    </>
  );
};
StandardTabWithCloseConfirmationModal.storyName = 'Primary Tab with Close Confirmation Modal';
StandardTabWithCloseConfirmationModal.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Primary Tab Component with Close Confirmation Modal"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description="Use the Close Confirmation callback in order to ensure the user truly meant to close the tab."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const ChangeableStandardTabSmall: Story = () => {
  const tabsRef = useRef<TabsRef>(null);
  const [date, setDate] = useState<string>();

  const selectTab = (index: number) => {
    if (tabsRef.current) {
      tabsRef.current.selectTab(index);
    }
  };

  const dateChange = (stringDate: string) => {
    setDate(stringDate);
    const convertedDate = new Date(stringDate);
    selectTab(convertedDate.getDay());
  };

  const labelStyle = {
    marginTop: '15px',
    marginBottom: '5px',
    fontWeight: 700,
  };

  function getRandomNumberSeven() {
    const array = new Uint32Array(1);
    crypto.getRandomValues(array);
    return array[0] % 7;
  }

  return (
    <>
      <label style={labelStyle}>A button that selects a random Tab:</label>
      <Button id="select-first-tab-button" type={ButtonType.primary} onClick={() => selectTab(getRandomNumberSeven())}>
        Select Random Tab
      </Button>
      <label style={labelStyle}>A action menu where you can select the tab:</label>
      <ActionMenu id="actionmenu-default" label="Select Tab">
        <Action id="action-first" onClick={() => selectTab(0)}>
          First Tab
        </Action>
        <Action id="action-second" onClick={() => selectTab(1)}>
          Second Tab
        </Action>
        <Action id="action-third" onClick={() => selectTab(2)}>
          Third Tab
        </Action>
        <Action id="action-fourth" onClick={() => selectTab(3)}>
          Fourth Tab
        </Action>
        <Action id="action-fifth" onClick={() => selectTab(4)}>
          Fifth Tab
        </Action>
        <Action id="action-sixth" onClick={() => selectTab(5)}>
          Sixth Tab
        </Action>
        <Action id="action-seventh" onClick={() => selectTab(6)}>
          Seventh Tab
        </Action>
      </ActionMenu>
      <label style={labelStyle}>Change tab based on date (sunday = first, monday = second, etc):</label>
      <DatePicker id="date-picker-id" name="date-picker-name" value={date} onChange={(e, value) => dateChange(value)} />
      <div style={{ marginBottom: '40px' }}></div>
      <Tabs ref={tabsRef} id={'tab-id'} size={TabSize.small} onPaneClose={action('OnPanelClosed')}>
        <Pane id="first" label="First">
          <div>First Tab</div>
        </Pane>
        <Pane id="second" label="Second">
          <div>
            <h5>Second Tab - Focusable Component (Focus moves to first focusable element in the Pane) :</h5>
            <FocusableComponent />
          </div>
        </Pane>
        <Pane id="third" label="Third">
          <div>
            <div>Third tab - State is maintained (Click on either button to change internal state):</div>
            <StatefulComponent />
          </div>
        </Pane>
        <Pane id="fourth" label="Fourth">
          <div>Fourth Tab</div>
        </Pane>
        <Pane id="fifth" label="fifth">
          <div>fifth Tab</div>
        </Pane>
        <Pane id="sixth" label="sixth">
          <div>sixth Tab</div>
        </Pane>
        <Pane id="seventh" label="seventh">
          <div>seventh Tab</div>
        </Pane>
      </Tabs>
    </>
  );
};
ChangeableStandardTabSmall.storyName = 'Primary Tab Selection using ref function';
ChangeableStandardTabSmall.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Primary Tab Selection using ref function"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description="A tab can be Selected with a ref function call, the following shows a couple examples using this."
    >
      <ComponentStory />
    </Documentation>
  ),
];
