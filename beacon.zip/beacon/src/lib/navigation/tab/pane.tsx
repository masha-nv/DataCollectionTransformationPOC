import React, { forwardRef, ReactNode, useEffect, useImperativeHandle, useRef, useState } from 'react';
import classNames from 'classnames';
import { WithId } from '../../with-id';
import { Direction } from '../../modals/modal-types';
import { containsFocusableChildById, focusOnFirstFocusableChildById } from '../../utils';

export interface IPaneProps extends WithId {
  /**
   * Tab Label
   */
  label: string;

  /**
   * Is this tab closable
   */
  closeable?: boolean;

  /**
   * Direction of closable tooltip
   */
  direction?: Direction;
  /**
   * Is this Tab selected
   */
  selected?: boolean;

  /**
   * Pane Contents
   */
  children: ReactNode;

  /**
   * Tab Indicator
   */
  tabInd?: ReactNode;

  /**
   * Icon
   */
  icon?: ReactNode;
}

export interface PaneRef {
  focus: () => void;
}

export const Pane = forwardRef(({ id, children, selected }: IPaneProps, ref: React.ForwardedRef<PaneRef>) => {
  const [containsFocusableChild, setContainsFocusableChild] = useState(false);
  const paneRef = useRef<HTMLDivElement>(null);
  const classes = classNames('tab-pane', {
    active: selected,
  });

  useEffect(() => {
    const foundElement = containsFocusableChildById(id);
    setContainsFocusableChild(!!foundElement);
  }, [id]);

  useImperativeHandle(ref, () => ({
    focus: () => {
      if (containsFocusableChild) {
        focusOnFirstFocusableChildById(id);
      } else {
        paneRef?.current?.focus();
      }
    },
  }));

  return (
    <div
      id={id}
      ref={paneRef}
      className={classes}
      aria-labelledby={`${id}-title`}
      role="tabpanel"
      tabIndex={containsFocusableChild ? -1 : 0}
    >
      {children}
    </div>
  );
});

Pane.displayName = 'Pane';
