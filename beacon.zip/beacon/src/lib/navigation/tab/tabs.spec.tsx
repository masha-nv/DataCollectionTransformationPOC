import React, { useRef } from 'react';
import { render, fireEvent, RenderResult, waitFor, screen } from '@testing-library/react';
import { Bubble, BubbleType } from '../../notifications/bubble/bubble';
import { Tabs, Pane, TabType, TabSize, TabsRef } from './tabs';
import { IconType, IconSize, IconVariant } from '../../icon/constants';
import { Icon } from '../../icon/icon';
import userEvent from '@testing-library/user-event';
import { act } from 'react-dom/test-utils';

describe('Tabs', () => {
  it('renders correctly', () => {
    render(
      <Tabs id={'tab-id'}>
        <Pane id="first" label="First">
          FIRST
        </Pane>
        <Pane id="second" label="Second">
          SECOND
        </Pane>
      </Tabs>
    );

    expect(screen.getByText('FIRST')).toBeTruthy();
    expect(screen.getByText('SECOND')).toBeTruthy();
  });

  it('renders Tabs with Icons correctly', () => {
    const { baseElement } = render(
      <Tabs id={'tab-id'}>
        <Pane
          id="first"
          label="First"
          icon={<Icon type={IconType.exclamationTriangle} size={IconSize.regular} variant={IconVariant.warning} />}
        >
          FIRST
        </Pane>
        <Pane id="second" label="Second">
          SECOND
        </Pane>
      </Tabs>
    );

    expect(screen.getByText('FIRST')).toBeTruthy();
    expect(screen.getByText('SECOND')).toBeTruthy();
    expect(baseElement.querySelector('i')).toBeTruthy();
  });

  it('renders Closable Tabs correctly', () => {
    render(
      <Tabs id={'tab-id'}>
        <Pane id="first" label="First" closeable>
          FIRST
        </Pane>
        <Pane id="second" label="Second">
          SECOND
        </Pane>
      </Tabs>
    );

    expect(screen.getByText('FIRST')).toBeTruthy();
    expect(screen.getByText('SECOND')).toBeTruthy();
    expect(screen.getByRole('button', { name: 'Close' })).toBeTruthy();
  });

  it('renders empty Tabs correctly', () => {
    const tabId = 'tab-id';
    const { container } = render(<Tabs id={tabId} />);

    expect(container.querySelector(`#${tabId}`)).toBeNull();
  });

  it('renders Secondary Tabs correctly', () => {
    render(
      <Tabs id={'tab-id'} type={TabType.secondary}>
        <Pane id="first" label="First">
          FIRST
        </Pane>
        <Pane id="second" label="Second">
          SECOND
        </Pane>
      </Tabs>
    );

    expect(screen.getByText('FIRST')).toBeTruthy();
    expect(screen.getByText('SECOND')).toBeTruthy();
  });

  it('renders Primary Small Tabs correctly', () => {
    render(
      <Tabs id={'tab-id'} type={TabType.primary} size={TabSize.small}>
        <Pane id="first" label="First">
          FIRST
        </Pane>
        <Pane id="second" label="Second">
          SECOND
        </Pane>
      </Tabs>
    );

    expect(screen.getByText('FIRST')).toBeTruthy();
    expect(screen.getByText('SECOND')).toBeTruthy();
  });

  it('renders Secondary Small Tabs correctly', () => {
    render(
      <Tabs id={'tab-id'} type={TabType.secondary} size={TabSize.small}>
        <Pane id="first" label="First">
          FIRST
        </Pane>
        <Pane id="second" label="Second">
          SECOND
        </Pane>
      </Tabs>
    );

    expect(screen.getByText('FIRST')).toBeTruthy();
    expect(screen.getByText('SECOND')).toBeTruthy();
  });

  describe('lazy loading', () => {
    let renderResult: RenderResult<typeof import('@testing-library/dom/types/queries'), HTMLElement>;

    beforeEach(() => {
      renderResult = render(
        <Tabs lazyLoading id={'tab-id'}>
          <Pane id="first" label="First">
            FIRST
          </Pane>
          <Pane id="second" label="Second">
            SECOND
          </Pane>
        </Tabs>
      );
    });

    it("renders only one tab's content upon initialization", () => {
      // verify only first tab has been rendered
      expect(renderResult.container.querySelector('#first')).toBeDefined();
      expect(renderResult.container.querySelector('#second')).toBeFalsy();
    });

    it('renders and activates second tab once it is clicked', () => {
      // verify only first tab has been rendered
      expect(renderResult.container.querySelector('#first')).toBeDefined();
      expect(renderResult.container.querySelector('#second')).toBeFalsy();
      fireEvent.click(renderResult.container.querySelectorAll('.nav-link')[1]);
      // verify that both tabs have been rendered, with the second one being active
      expect(renderResult.container.querySelector('#first')).toBeDefined();
      expect(renderResult.container.querySelector('#second')?.classList).toContain('active');
    });
  });

  describe('errors', () => {
    let originalError: typeof console.error;

    beforeEach(() => {
      originalError = console.error;
      console.error = jest.fn();
    });

    it('does not allow non Pane child components', () => {
      const renderAction = () => {
        render(
          <Tabs id={'tab-id'} type={TabType.secondary} size={TabSize.small}>
            <Pane id="first" label="First">
              FIRST
            </Pane>
            <div>Second</div>
          </Tabs>
        );
      };

      expect(renderAction).toThrowError('Tabs component only allows children of type Pane');
    });

    afterEach(() => {
      console.error = originalError;
    });
  });

  it('switches tab on click', () => {
    const { container } = render(
      <Tabs id={'tab-id'}>
        <Pane id="first" label="First">
          FIRST
        </Pane>
        <Pane id="second" label="Second">
          SECOND
        </Pane>
      </Tabs>
    );
    // click second tab button
    fireEvent.click(container.querySelectorAll('.nav-link')[1]);

    // verify only second tab is visible
    expect(container.querySelector('#first')?.classList).not.toContain('active');
    expect(container.querySelector('#second')?.classList).toContain('active');
  });

  it('closes tab successfully', async () => {
    const { container } = render(
      <Tabs id={'tab-id'}>
        <Pane id="first" label="First" closeable>
          FIRST
        </Pane>
        <Pane id="second" label="Second">
          SECOND
        </Pane>
      </Tabs>
    );

    // verify tabs
    expect(container.querySelector('#first')).not.toBeNull();
    expect(container.querySelector('#second')).not.toBeNull();

    // close first tab
    fireEvent.click(container.querySelector('#first-close-button') as Element);

    // verify that only one tab remains
    await waitFor(() => {
      expect(container.querySelector('#first')).toBeNull();
      expect(container.querySelector('#second')).not.toBeNull();
    });
  });

  it('closing last tab that is active makes the previos tab active', async () => {
    const { container } = render(
      <Tabs id={'tab-id'}>
        <Pane id="first" label="First">
          FIRST
        </Pane>
        <Pane id="second" label="Second">
          SECOND
        </Pane>
        <Pane id="third" label="Third" closeable>
          Third
        </Pane>
      </Tabs>
    );

    // Activate third tab
    fireEvent.click(container.querySelectorAll('.nav-link')[2]);

    // verify its active
    expect(container.querySelector('#third')?.classList).toContain('active');

    // close third tab
    fireEvent.click(container.querySelector('#third-close-button') as Element);

    // verify second tab is active now
    await waitFor(() => {
      expect(container.querySelector('#second')?.classList).toContain('active');
    });
  });

  it('sets default selected tab correctly', () => {
    const { container } = render(
      <Tabs id={'tab-id'} defaultIndex={1}>
        <Pane id="first" label="First">
          FIRST
        </Pane>
        <Pane id="second" label="Second">
          SECOND
        </Pane>
      </Tabs>
    );

    // verify only second tab is visible
    expect(container.querySelector('#first')?.classList).not.toContain('active');
    expect(container.querySelector('#second')?.classList).toContain('active');
  });

  it('switching tabs should trigger on pane click method', () => {
    const onPaneClick = jest.fn();
    const { container } = render(
      <Tabs id={'tab-id'} onPaneClick={onPaneClick}>
        <Pane id="first" label="First">
          FIRST
        </Pane>
        <Pane id="second" label="Second">
          SECOND
        </Pane>
      </Tabs>
    );
    // click second tab button
    fireEvent.click(container.querySelectorAll('.nav-link')[1]);

    // verify only second tab is visible
    expect(container.querySelector('#first')?.classList).not.toContain('active');
    expect(container.querySelector('#second')?.classList).toContain('active');
    expect(onPaneClick).toHaveBeenCalledWith({ children: 'SECOND', id: 'second', label: 'Second' });
  });

  it('renders tab with react node correctly', () => {
    const { baseElement } = render(
      <Tabs id={'tab-id'}>
        <Pane
          id="first"
          label={'First'}
          tabInd={
            <span className="ml-2">
              <Bubble type={BubbleType.default}>10</Bubble>
            </span>
          }
        >
          FIRST
        </Pane>
        <Pane id="second" label="Second">
          SECOND
        </Pane>
      </Tabs>
    );
    expect(baseElement.textContent).toContain('First');
    expect(baseElement.textContent).toContain('10');
  });

  it('Tab does not close when confirm close returns false', async () => {
    const returnFalse = async () => {
      return false;
    };
    const { container } = render(
      <Tabs id={'tab-id'} confirmClose={returnFalse}>
        <Pane id="first" label="First" closeable>
          FIRST
        </Pane>
        <Pane id="second" label="Second">
          SECOND
        </Pane>
      </Tabs>
    );

    // verify tabs
    expect(container.querySelector('#first')).not.toBeNull();
    expect(container.querySelector('#second')).not.toBeNull();

    // click close on first tab
    fireEvent.click(container.querySelector('#first-close-button'));

    // verify both tabs remain
    await waitFor(() => {
      expect(container.querySelector('#first')).not.toBeNull();
      expect(container.querySelector('#second')).not.toBeNull();
    });
  });

  it('should change focus from up and down arrow key presses when vertical keyboard navigation is enabled', () => {
    const onPaneClick = jest.fn();
    render(
      <Tabs id={'tab-id'} verticalKeyboardNavigation onPaneClick={onPaneClick}>
        <Pane id="first" label="First">
          FIRST
        </Pane>
        <Pane id="second" label="Second">
          SECOND
        </Pane>
      </Tabs>
    );

    const tab2 = screen.getByText('Second');
    // Focus second tab
    fireEvent.focus(tab2);
    // Select second tab
    userEvent.keyboard('{Enter}');

    // Move to first tab and select it
    userEvent.keyboard('{ArrowUp}{Enter}');
    const tab1 = screen.getByText('First');
    expect(/active/.test(tab1.className)).toBeTruthy();

    // Move to second tab and select it
    expect(onPaneClick).toHaveBeenCalled();
    userEvent.keyboard('{ArrowDown}{Enter}');
    expect(/active/.test(tab2.className)).toBeTruthy();

    // Second tab should still be selected, since horizontal keys are disabled
    userEvent.keyboard('{ArrowLeft}{Enter}');
    expect(/active/.test(tab2.className)).toBeTruthy();
  });

  it('Tab closes when confirm close returns true', async () => {
    const returnTrue = async () => {
      return true;
    };
    const { container } = render(
      <Tabs id={'tab-id'} confirmClose={returnTrue}>
        <Pane id="first" label="First" closeable>
          FIRST
        </Pane>
        <Pane id="second" label="Second">
          SECOND
        </Pane>
      </Tabs>
    );

    // verify tabs
    expect(container.querySelector('#first')).not.toBeNull();
    expect(container.querySelector('#second')).not.toBeNull();

    // click close on first tab
    fireEvent.click(container.querySelector('#first-close-button'));

    // verify that only one tab remains
    await waitFor(() => {
      expect(container.querySelector('#first')).toBeNull();
      expect(container.querySelector('#second')).not.toBeNull();
    });
  });

  it('selectTab function switches tabs', () => {
    const TestComponent = () => {
      const tabsRef = useRef<TabsRef>(null);

      const selectTab = (index: number) => {
        if (tabsRef.current) {
          tabsRef.current.selectTab(index);
        }
      };

      return (
        <div>
          <button onClick={() => selectTab(0)} id="select-first-tab-button"></button>
          <button onClick={() => selectTab(10)} id="faulty-select-tab-button"></button>
          <Tabs ref={tabsRef} id={'tab-id'}>
            <Pane id="first" label="First">
              FIRST
            </Pane>
            <Pane id="second" label="Second">
              SECOND
            </Pane>
          </Tabs>
        </div>
      );
    };

    const { container } = render(<TestComponent />);
    // click second tab
    fireEvent.click(container.querySelectorAll('.nav-link')[1]);

    // verify only second tab is visible
    expect(container.querySelector('#first')?.classList).not.toContain('active');
    expect(container.querySelector('#second')?.classList).toContain('active');

    // click on the first tab button that uses first selectTab
    fireEvent.click(container.querySelector('#select-first-tab-button'));

    // verify only first tab is visible
    expect(container.querySelector('#first')?.classList).toContain('active');
    expect(container.querySelector('#second')?.classList).not.toContain('active');

    // click on the button that calls a wrong id with selectTab
    fireEvent.click(container.querySelector('#faulty-select-tab-button'));

    // verify there are no changes
    expect(container.querySelector('#first')?.classList).toContain('active');
    expect(container.querySelector('#second')?.classList).not.toContain('active');
  });

  describe('508c tests ::', () => {
    it('should select tab with SPACE', () => {
      render(
        <Tabs id={'tab-id'}>
          <Pane id="first" label="First">
            FIRST
          </Pane>
          <Pane id="second" label="Second">
            SECOND
          </Pane>
        </Tabs>
      );

      const tab1 = screen.getByText('First');
      // Focus first tab
      fireEvent.focus(tab1);

      // Move to second tab and select it
      userEvent.keyboard('{ArrowRight} ');

      const tab2 = screen.getByText('Second');

      expect(/active/.test(tab2.className)).toBeTruthy();
    });

    it('should change focus to left tab when pressing arrow left', () => {
      const onPaneClick = jest.fn();
      render(
        <Tabs id={'tab-id'} onPaneClick={onPaneClick}>
          <Pane id="first" label="First">
            FIRST
          </Pane>
          <Pane id="second" label="Second">
            SECOND
          </Pane>
        </Tabs>
      );

      const tab2 = screen.getByText('Second');
      // Focus second tab
      fireEvent.focus(tab2);
      // Select second tab
      userEvent.keyboard('{Enter}');

      // Move to first tab and select it
      userEvent.keyboard('{ArrowLeft}{Enter}');

      const tab1 = screen.getByText('First');

      expect(/active/.test(tab1.className)).toBeTruthy();

      userEvent.keyboard('{ArrowDown}{Enter}');
      // First tab should still be active, since vertical keyboard navigation isn't enabled
      expect(/active/.test(tab1.className)).toBeTruthy();

      expect(onPaneClick).toHaveBeenCalled();
    });

    it('should be able to close tab with keyboard', async () => {
      render(
        <Tabs id={'tab-id'}>
          <Pane id="first" label="First" closeable>
            FIRST
          </Pane>
          <Pane id="second" label="Second">
            SECOND
          </Pane>
        </Tabs>
      );

      const tab2 = screen.getByText('Second');
      const tab1CloseBtn = screen.getByRole('button', { name: 'Close' });
      act(() => {
        tab1CloseBtn.focus();
      });

      await waitFor(() => {
        expect(document.activeElement).toBe(tab1CloseBtn);
      });

      userEvent.keyboard('{Enter}');

      // Waiting for removal of first tab
      await waitFor(() => {
        expect(screen.queryByText('First')).toBeFalsy();
      });

      expect(/active/.test(tab2.className)).toBeTruthy();
    });

    it('should be able to close tab with SPACE', async () => {
      render(
        <Tabs id={'tab-id'}>
          <Pane id="first" label="First" closeable>
            FIRST
          </Pane>
          <Pane id="second" label="Second">
            SECOND
          </Pane>
        </Tabs>
      );

      const tab1CloseBtn = screen.getByRole('button', { name: 'Close' });
      act(() => {
        tab1CloseBtn.focus();
      });

      await waitFor(() => {
        expect(document.activeElement).toBe(tab1CloseBtn);
      });

      userEvent.keyboard('asdf '); // asdf should do nothing, only when user hits SPACE key should close tab

      // Waiting for removal of first tab
      await waitFor(() => {
        expect(screen.queryByText('First')).toBeFalsy();
      });
    });

    it('should focus the close button when tab is focused and user hits TAB', async () => {
      render(
        <Tabs id={'tab-id'}>
          <Pane id="first" label="First" closeable>
            FIRST
          </Pane>
          <Pane id="second" label="Second">
            SECOND
          </Pane>
        </Tabs>
      );

      // focuses tab
      userEvent.tab();
      // focuses close button
      userEvent.tab();
      // removes tab
      userEvent.keyboard('{Enter}');

      // Waiting for removal of first tab
      await waitFor(() => {
        expect(screen.queryByText('First')).toBeFalsy();
      });
    });

    it('should focus focusable element within pane', async () => {
      render(
        <Tabs id={'tab-id'}>
          <Pane id="first" label="First">
            <button>Focus me</button>
          </Pane>
          <Pane id="second" label="Second">
            SECOND
          </Pane>
        </Tabs>
      );

      const tab1 = screen.getByText('First');
      userEvent.tab();

      expect(document.activeElement).toBe(tab1);

      // focuses first focusable element
      userEvent.tab();
      const focusBtn = screen.getByText('Focus me');
      expect(document.activeElement).toBe(focusBtn);
    });

    it('should focus first enabled, focusable element within pane', async () => {
      render(
        <Tabs id={'tab-id'}>
          <Pane id="first" label="First">
            <button disabled>Don't Focus me</button>
            <button>Focus me instead</button>
          </Pane>
          <Pane id="second" label="Second">
            SECOND
          </Pane>
        </Tabs>
      );

      const tab1 = screen.getByText('First');
      userEvent.tab();

      expect(document.activeElement).toBe(tab1);

      // focuses first focusable element
      userEvent.tab();
      const focusBtn = screen.getByText('Focus me instead');
      expect(document.activeElement).toBe(focusBtn);
    });

    it('should focus pane container if no focusable element found in pane when user hits TAB and tabItem is focused', async () => {
      render(
        <Tabs id={'tab-id'}>
          <Pane id="first" label="First">
            Pane1
          </Pane>
          <Pane id="second" label="Second">
            Pane2
          </Pane>
        </Tabs>
      );

      const tab1 = screen.getByText('First');
      tab1.focus();
      userEvent.keyboard('er'); // Does nothing, focus still on tab
      expect(document.activeElement).toBe(tab1);

      // focuses first focusable element
      userEvent.tab();
      const pane1 = screen.getByText('Pane1');
      expect(document.activeElement).toBe(pane1);
    });

    it('should navigate through the tabs', async () => {
      render(
        <Tabs id={'tab-id'}>
          <Pane id="first" label="First">
            FIRST
          </Pane>
          <Pane id="second" label="Second">
            SECOND
          </Pane>
          <Pane id="third" label="Third">
            THIRD
          </Pane>
        </Tabs>
      );

      const tab1 = screen.getByText('First');
      const tab2 = screen.getByText('Second');
      const tab3 = screen.getByText('Third');

      // Focus first tab
      userEvent.tab();
      expect(document.activeElement).toBe(tab1);

      // Go to second tab
      userEvent.keyboard('{ArrowRight}');
      expect(document.activeElement).toBe(tab2);

      // Go to third tab
      userEvent.keyboard('{ArrowRight}');
      expect(document.activeElement).toBe(tab3);
    });
  });
});
