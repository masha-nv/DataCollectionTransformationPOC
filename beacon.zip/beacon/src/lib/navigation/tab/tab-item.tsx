import React, {
  FocusEvent,
  KeyboardEvent,
  ReactNode,
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import classNames from 'classnames';
import { Icon, IconType } from '../../icon/icon';
import { Tooltip } from '../../modals/tooltip/tooltip';
import './tabs.scss';
import { Direction } from '../../modals/modal-types';

export interface ITabItemProps {
  /**
   * Tab Label
   */
  label: string;
  /**
   * Taget Pane's Id
   */
  targetPaneId: string;
  /**
   * Is this Tab selected
   */
  selected: boolean;
  /**
   * Is this tab closable
   */
  closeable: boolean;
  /**
   * Direction of closable tooltip
   */
  direction?: Direction;
  /**
   * On Tab click
   */
  onClick: () => void;
  /**
   * On Tab close
   */
  onClose: () => void;
  /**
   * On key down
   */
  onKeydown: (event: KeyboardEvent) => void;
  /**
   * On focus
   */
  onFocus: (event: FocusEvent<HTMLButtonElement>) => void;
  /**
   * Tab Indicator
   */
  tabInd?: ReactNode;
  /**
   * Tab Icon
   */
  icon?: ReactNode;
}

const ENTER = 'Enter';
const SPACE = ' ';

export interface TabItemRef {
  focusTab: () => void;
  focusCloseBtn: () => void;
}

export const TabItem = forwardRef(
  (
    {
      label,
      targetPaneId,
      selected,
      closeable,
      direction,
      onClick,
      onClose,
      onKeydown,
      onFocus,
      tabInd,
      icon,
    }: ITabItemProps,
    ref: React.ForwardedRef<TabItemRef>
  ) => {
    const [tabIndex, setTabIndex] = useState(selected ? 0 : -1);
    const tabRef = useRef<HTMLButtonElement>(null);
    const closeBtnRef = useRef<HTMLButtonElement>(null);
    const tabClasses = classNames('nav-link', {
      active: selected,
      closeable: closeable,
    });

    const closeBtnClasses = classNames('nav-item-action', {
      active: selected,
    });

    // Updating tab selection when other tabs selected
    useEffect(() => {
      if (!selected) setTabIndex(-1);
    }, [selected]);

    useImperativeHandle(ref, () => ({
      focusTab: () => {
        tabRef?.current?.focus();
      },
      focusCloseBtn: () => {
        closeBtnRef?.current?.focus();
      },
    }));

    return (
      <li className="nav-item">
        <button
          id={`${targetPaneId}-title`}
          ref={tabRef}
          className={`${tabClasses} h-100`}
          role="tab"
          aria-controls={`${targetPaneId}`}
          aria-selected={selected}
          onClick={onClick}
          onKeyDown={onKeydown}
          onFocus={(event) => {
            setTabIndex(0);
            onFocus(event);
          }}
          onBlur={() => {
            if (!selected) {
              setTabIndex(-1);
            }
          }}
          tabIndex={tabIndex}
        >
          {icon} {label} {tabInd}
          {selected && <span className="sr-only"> (selected)</span>}
        </button>
        {closeable && (
          <Tooltip
            id={`${targetPaneId}-close-tooltip`}
            content={`Click to close the "${label}" tab`}
            direction={direction}
          >
            <button
              id={`${targetPaneId}-close-button`}
              ref={closeBtnRef}
              className={closeBtnClasses}
              aria-label="Close"
              onClick={onClose}
              tabIndex={tabIndex}
              onKeyDown={(event) => {
                if (event.key === ENTER || event.key === SPACE) onClose();
              }}
            >
              <Icon type={IconType.times} />
            </button>
          </Tooltip>
        )}
      </li>
    );
  }
);
