import React, {
  ReactElement,
  ReactNode,
  useEffect,
  useMemo,
  useState,
  forwardRef,
  useImperativeHandle,
  createRef,
  RefObject,
  SetStateAction,
  Dispatch,
} from 'react';
import classNames from 'classnames';
import { noop } from '../../utils';
import { WithId } from '../../with-id';
import { IPaneProps, Pane, PaneRef } from './pane';
import { TabItem, TabItemRef } from './tab-item';
export interface ITabsProps extends WithId {
  /**
   * Tab Type
   */
  type?: TabType;
  /**
   * Tab Size
   */
  size?: TabSize;
  /**
   * Tab Contents. Only nodes of type Pane are allowed
   */
  children?: ReactNode;

  /**
   * Enable lazy loading - don't load a tab's content until it has been activated
   */
  lazyLoading?: boolean;

  /**
   * Index of the default selected tab
   */
  defaultIndex?: number;

  /**
   * On Pane Close event
   */
  onPaneClose?: (index: number) => void;

  /**
   * On Pane Click event
   */
  onPaneClick?: (paneProps: IPaneProps) => void;

  /**
   * On click close button event. Intercept close event so confirmation can be added
   */
  confirmClose?: (index: number) => Promise<boolean>;

  /**
   * Enable tabs to be navigated with up and down arrow keys, instead of left and right
   */
  verticalKeyboardNavigation?: boolean;
}

const openedTabIndices: number[] = [];
const ENTER = 'Enter';
const SPACE = ' ';
const ARROW_LEFT = 'ArrowLeft';
const ARROW_RIGHT = 'ArrowRight';
const ARROW_UP = 'ArrowUp';
const ARROW_DOWN = 'ArrowDown';
const TAB = 'Tab';

/**
 * Tab Types enum
 */
export enum TabType {
  primary,
  secondary,
}

/**
 * Tab Size enum
 */
export enum TabSize {
  large = 'large',
  small = 'small',
}

/**
 * Dummy return true object for default confirmClose
 * @returns Promise<true>
 */
const returnTrue = async (index: number) => {
  return true;
};

/**
 * Determines if the current tab pane is loaded
 * @param lazyLoading indicates whether tabs are preloaded or not. defaults to preloaded (false)
 * @param index index of pane to determine
 * @param openedTabs list of tabs already loaded
 * @returns boolean indicating pane index is already loaded
 */
const isPaneLoaded = (lazyLoading: boolean, index: number, openedTabs: number[]): boolean => {
  return lazyLoading ? openedTabs.includes(index) : true;
};

/**
 * Determines whether there are Panes to render
 * @param panes Panes of tabs to display
 * @returns boolean indicating whether there are Panes to show
 */
const arePanesEmpty = (panes: ReactElement[]) => {
  return !panes || panes.length === 0;
};

/**
 * Tab Reference
 */
export interface TabsRef {
  selectTab: (index: number) => void;
}

/**
 * Updates the children Panes with the selected state and ensures only the selected Pane is active.
 * LAOemoizes the result to prevent unnecessary re-renders.
 *
 * @param currentPaneItems - Array of Pane elements to be displayed.
 * @param selectedIndex - Index of the selected Pane.
 * @returns A new array of Pane elements with updated properties based on the selected index.
 */
const useChildPanes = (
  currentPaneItems: ReactElement[],
  selectedIndex: number,
  paneItemRefs: React.RefObject<PaneRef>[]
) => {
  return useMemo(
    () =>
      React.Children.map(currentPaneItems, (child, index) => {
        if (!openedTabIndices.includes(selectedIndex)) {
          openedTabIndices.push(selectedIndex);
        }
        const updatedProps = { ...child.props, ref: paneItemRefs[index] } as IPaneProps;
        updatedProps.selected = index === selectedIndex;
        return React.cloneElement(child, updatedProps);
      }),
    [currentPaneItems, selectedIndex, paneItemRefs]
  );
};

interface HandleTabKeyDownType {
  event: React.KeyboardEvent<Element>;
  index: number;
  focusIndex: number | null;
  closeable: boolean;
  tabItems: JSX.Element[];
  tabItemRefs: RefObject<TabItemRef>[];
  paneItemRefs: RefObject<PaneRef>[];
  setSelectedIndex: Dispatch<SetStateAction<number>>;
  setFocusIndex: (index: number) => void;
  selectedIndex: number;
  onEnter: () => void;
  verticalKeyboardNavigation: boolean;
}

const handleTabKeyDown = ({
  event,
  index,
  focusIndex,
  closeable,
  tabItems,
  tabItemRefs,
  paneItemRefs,
  setSelectedIndex,
  setFocusIndex,
  selectedIndex,
  onEnter,
  verticalKeyboardNavigation,
}: HandleTabKeyDownType) => {
  const forwardNavigationKey = verticalKeyboardNavigation ? ARROW_DOWN : ARROW_RIGHT;
  const backNavigationKey = verticalKeyboardNavigation ? ARROW_UP : ARROW_LEFT;
  if (event.key === ENTER || event.key === SPACE) {
    event.preventDefault();
    event.stopPropagation();

    setSelectedIndex(index);
    onEnter();
  } else if (event.key === backNavigationKey && typeof focusIndex === 'number' && focusIndex > 0) {
    event.preventDefault();
    event.stopPropagation();

    tabItemRefs[focusIndex - 1]?.current?.focusTab();
    setFocusIndex(focusIndex - 1);
  } else if (event.key === forwardNavigationKey && typeof focusIndex === 'number' && focusIndex < tabItems.length - 1) {
    event.preventDefault();
    event.stopPropagation();

    tabItemRefs[focusIndex + 1]?.current?.focusTab();
    setFocusIndex(focusIndex + 1);
  } else if (event.key === TAB && !!closeable && !event.shiftKey && typeof focusIndex === 'number') {
    event.preventDefault();
    event.stopPropagation();

    tabItemRefs[focusIndex]?.current?.focusCloseBtn();
  } else if (event.key === TAB && !event.shiftKey && typeof focusIndex === 'number') {
    event.preventDefault();
    event.stopPropagation();

    paneItemRefs[selectedIndex]?.current?.focus();
  }
};

const handleTabClose = async (
  index: number,
  confirmClose: (index: number) => Promise<boolean>,
  removeChild: (index: number) => void
) => {
  await confirmClose(index);
  removeChild(index);
};

/**
 * Tab Component
 */
export const Tabs = forwardRef(
  (
    {
      id,
      type = TabType.primary,
      size = TabSize.large,
      defaultIndex = 0,
      children,
      lazyLoading = false,
      onPaneClose: onPanelClose = noop,
      onPaneClick: onPanelClick = noop,
      confirmClose = returnTrue,
      verticalKeyboardNavigation = false,
    }: ITabsProps,
    ref: React.ForwardedRef<TabsRef>
  ) => {
    const [selectedIndex, setSelectedIndex] = useState(defaultIndex);
    const [focusIndex, setFocusIndex] = useState<number | null>(null);
    const [currentPaneItems, setCurrentPaneItems] = useState<ReactElement[]>([]);
    const [tabItemRefs, setTabItemRefs] = useState(React.Children.toArray(children).map(() => createRef<TabItemRef>()));
    const [paneItemRefs, setPaneItemRefs] = useState(React.Children.toArray(children).map(() => createRef<PaneRef>()));

    useEffect(() => {
      // Store local copy of the children prop on every change
      setCurrentPaneItems(React.Children.toArray(children) as ReactElement[]);

      // Updating TabItem refs and PaneItemRefs
      setTabItemRefs(React.Children.toArray(children).map(() => createRef<TabItemRef>()));
      setPaneItemRefs(React.Children.toArray(children).map(() => createRef<PaneRef>()));
    }, [children]);

    // Re-focuses tab when tabs are removed
    useEffect(() => {
      if (typeof focusIndex === 'number') {
        tabItemRefs[focusIndex]?.current?.focusTab();
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [tabItemRefs.length, focusIndex]);

    useImperativeHandle(ref, () => ({
      selectTab: (index: number) => {
        if (index >= 0 && index < currentPaneItems.length) {
          setSelectedIndex(index);
          const paneProps = currentPaneItems[index].props as IPaneProps;
          onPanelClick(paneProps);
        }
      },
    }));

    const tabItems = useMemo(() => {
      const removeChild = (index: number) => {
        currentPaneItems.splice(index, 1);

        /**
         * Update index for current active tab in case a prior tab gets closed
         * OR
         * Set index to last tab if is out of bounds
         */
        if (selectedIndex !== 0 && (index < selectedIndex || selectedIndex >= currentPaneItems.length)) {
          setSelectedIndex(selectedIndex - 1);
          // Also moving focus
          setFocusIndex(selectedIndex - 1);
        }

        setCurrentPaneItems([...currentPaneItems]);

        // Updating TabItem refs and PaneItemRefs
        setTabItemRefs(currentPaneItems.map(() => createRef<TabItemRef>()));
        setPaneItemRefs(currentPaneItems.map(() => createRef<PaneRef>()));

        onPanelClose(index);
      };

      return React.Children.map(currentPaneItems, (child, index) => {
        // Restrict children to a specific type
        if (child.type !== Pane) {
          throw new Error(
            `${Tabs.displayName} component only allows children of type ${Pane.displayName}. Not ${child.type}`
          );
        }

        const paneProps = child.props as IPaneProps;
        const selected = index === selectedIndex;

        return (
          <TabItem
            ref={tabItemRefs[index]}
            label={paneProps.label}
            targetPaneId={paneProps.id}
            selected={selected}
            direction={paneProps.direction}
            closeable={!!paneProps.closeable}
            onClick={() => {
              setSelectedIndex(index);
              onPanelClick(paneProps);
            }}
            onClose={() => {
              handleTabClose(index, confirmClose, removeChild);
            }}
            onFocus={() => {
              setFocusIndex(index);
            }}
            onKeydown={(event) => {
              handleTabKeyDown({
                event,
                index,
                focusIndex,
                closeable: !!paneProps.closeable,
                tabItems,
                tabItemRefs,
                paneItemRefs,
                setSelectedIndex,
                setFocusIndex,
                selectedIndex,
                onEnter: () => onPanelClick(paneProps),
                verticalKeyboardNavigation,
              });
            }}
            tabInd={paneProps.tabInd}
            icon={paneProps.icon}
          />
        );
      });
    }, [
      currentPaneItems,
      selectedIndex,
      onPanelClose,
      onPanelClick,
      confirmClose,
      focusIndex,
      tabItemRefs,
      paneItemRefs,
      verticalKeyboardNavigation,
    ]);

    const childPanes = useChildPanes(currentPaneItems, selectedIndex, paneItemRefs);

    // Do not render anything if there are not child Panes
    if (arePanesEmpty(currentPaneItems)) {
      return null;
    }

    const classes = classNames('nav', {
      'nav-tabs nav-tabs-large': size === TabSize.large,
      'nav-tabs nav-tabs-small': size === TabSize.small,
      'nav-tabs-secondary': type === TabType.secondary,
    });

    return (
      <div className="beacon-tab-container" id={id}>
        <ul className={classes} role="tablist">
          {tabItems}
        </ul>
        <div className="tab-content" id={`${id}-content`}>
          {childPanes.filter((pane, index) => {
            return isPaneLoaded(lazyLoading, index, openedTabIndices);
          })}
        </div>
      </div>
    );
  }
);

Tabs.displayName = 'Tabs';

export { Pane } from './pane';
