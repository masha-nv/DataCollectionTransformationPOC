import React from 'react';
import { render } from '@testing-library/react';
import { IconButton } from './icon-button';
import { Icon, IconType } from '../icon/icon';
import { noop } from '../utils';
import { IconButtonVariant } from '../icon/constants';

describe('Icon Button', () => {
  it('renders', () => {
    const { baseElement } = render(
      <IconButton id="delete-icon-btn" label="delete" onClick={noop}>
        <Icon type={IconType.trash} />
      </IconButton>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('disabled', () => {
    const { baseElement } = render(
      <IconButton id="delete-icon-btn" label="delete" onClick={noop} disabled>
        <Icon type={IconType.trash} />
      </IconButton>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('with title', () => {
    const { baseElement } = render(
      <IconButton id="delete-icon-btn" label="delete" onClick={noop} title="This button will delete something">
        <Icon type={IconType.trash} />
      </IconButton>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('without tooltip', () => {
    const { baseElement } = render(
      <IconButton
        hideTooltip
        id="delete-icon-btn"
        label="delete"
        onClick={noop}
        title="This button will delete something"
      >
        <Icon type={IconType.trash} />
      </IconButton>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('with variant predefined - default', () => {
    const { baseElement } = render(
      <IconButton
        variant={IconButtonVariant.default}
        id="delete-icon-btn"
        label="delete"
        onClick={noop}
        title="This button will delete something"
      >
        <Icon type={IconType.trash} />
      </IconButton>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('with variant predefined - permanent', () => {
    const { baseElement } = render(
      <IconButton
        variant={IconButtonVariant.permanent}
        id="delete-icon-btn"
        label="delete"
        onClick={noop}
        title="This button will delete something"
      >
        <Icon type={IconType.trash} />
      </IconButton>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('with variant predefined - gray', () => {
    const { baseElement } = render(
      <IconButton
        variant={IconButtonVariant.gray}
        id="delete-icon-btn"
        label="delete"
        onClick={noop}
        title="This button will delete something"
      >
        <Icon type={IconType.trash} />
      </IconButton>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('with variant custom', () => {
    const { baseElement } = render(
      <IconButton
        variant="green"
        id="delete-icon-btn"
        label="delete"
        onClick={noop}
        title="This button will delete something"
      >
        <Icon type={IconType.trash} />
      </IconButton>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('calls click handler', () => {
    const onClick = jest.fn();

    const { baseElement, getByLabelText } = render(
      <IconButton id="delete-icon-btn" label="delete" onClick={onClick}>
        <Icon type={IconType.trash} />
      </IconButton>
    );

    getByLabelText('delete').click();

    expect(onClick).toHaveBeenCalled();
  });

  it('with portal container', () => {
    const { baseElement } = render(
      <IconButton id="delete-icon-btn" label="delete" onClick={noop} portalContainer={document.body}>
        <Icon type={IconType.trash} />
      </IconButton>
    );

    expect(baseElement).toMatchSnapshot();
  });
});
