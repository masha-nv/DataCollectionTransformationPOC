import React, { ReactNode } from 'react';
import './button-group.scss';

export enum ButtonGroupDirection {
  LEFT = 'button-group-left',
  RIGHT = 'button-group-right',
}

export interface IButtonGroupProps {
  direction?: ButtonGroupDirection;
  wrap?: boolean;
  children: ReactNode;
}

export const ButtonGroup = ({ direction = ButtonGroupDirection.RIGHT, children, wrap }: IButtonGroupProps) => {
  const wrapClass = wrap ? 'button-group-wrap' : '';
  return <div className={`button-group ${direction} ${wrapClass}`}>{children}</div>;
};
