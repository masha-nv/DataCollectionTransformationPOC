import React, { forwardRef, ReactNode } from 'react';
import { Trackable } from '../analytics';
import { WithId } from '../with-id';
import { Button, ButtonType } from './button';
import { noop } from '../utils';

export interface ISubmitButtonProps extends WithId, Trackable {
  disabled?: boolean;
  /**
   * The content of this button
   */
  children: ReactNode;
  /**
   * The popup title of the button
   */
  title?: string;

  onClick?: (event: React.SyntheticEvent) => void;
}
/**
 * Submit Button component
 */
export const SubmitButton = forwardRef<HTMLButtonElement, ISubmitButtonProps>(({ onClick = noop, ...props }, ref) => {
  return (
    <Button
      id={props.id}
      disabled={props.disabled}
      type={ButtonType.primary}
      ref={ref}
      tracking={props.tracking}
      title={props.title}
      onClick={onClick}
      behavior="submit"
    >
      {props.children}
    </Button>
  );
});

SubmitButton.displayName = 'SubmitButton';
