import React from 'react';
import { render, screen } from '@testing-library/react';
import { Button, ButtonType, ButtonVariant } from './button';
import { ButtonGroups } from './button.stories';
import { track } from '../analytics/matomo';
import { TrackableEvent } from '../analytics';
import { noop } from '../utils';

jest.mock('../analytics/matomo', () => {
  const module = jest.requireActual('../analytics/matomo');
  return {
    ...module,
    track: jest.fn(),
  };
});

describe('Button', () => {
  it('renders a button with analytics by default', async () => {
    const myHandler = jest.fn();

    render(
      <Button id="button-id" onClick={myHandler}>
        Clickable
      </Button>
    );

    const button = screen.getByText('Clickable');
    button.click();

    expect(myHandler).toHaveBeenCalled();
    expect(track).toHaveBeenCalledWith({
      grouping: 'Ungrouped',
      action: 'Clicked',
      trackingKey: 'Button-Clickable',
    } as TrackableEvent);
  });

  it('renders a button with user provided analytics', async () => {
    const myHandler = jest.fn();
    const myCustomTracking: TrackableEvent = {
      grouping: 'Tests',
      action: 'Ran a test',
      trackingKey: 'Coolest of buttons',
    };

    render(
      <Button id="button-id" tracking={myCustomTracking} onClick={myHandler}>
        Clickable
      </Button>
    );

    const button = screen.getByText('Clickable');
    button.click();

    expect(myHandler).toHaveBeenCalled();
    expect(track).toHaveBeenCalledWith({
      grouping: 'Tests',
      action: 'Ran a test',
      trackingKey: 'Coolest of buttons',
    } as TrackableEvent);
  });

  it('renders primary buttons correctly', () => {
    const { baseElement } = render(
      <Button id="button-id" onClick={noop} type={ButtonType.primary}>
        Primary Button
      </Button>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders a secondary button correctly', () => {
    const { baseElement } = render(
      <Button id="button-id" onClick={noop}>
        Secondary Button
      </Button>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders a tertiary button correctly', () => {
    const { container } = render(
      <Button id="button-id" onClick={noop} type={ButtonType.tertiary}>
        Tertiary Button
      </Button>
    );

    expect(container).toMatchSnapshot();
  });

  it('renders a primary suggestion button correctly', () => {
    const { container } = render(
      <Button id="button-id" onClick={noop} type={ButtonType.primary} variant={ButtonVariant.suggestion}>
        Primary Suggestion Button
      </Button>
    );

    expect(container).toMatchSnapshot();
  });

  it('renders a primary important button correctly', () => {
    const { container } = render(
      <Button id="button-id" onClick={noop} type={ButtonType.primary} variant={ButtonVariant.important}>
        Primary Important Button
      </Button>
    );

    expect(container).toMatchSnapshot();
  });

  it('renders button groups correctly', () => {
    const { baseElement } = render(<ButtonGroups />);
    expect(baseElement).toMatchSnapshot();
  });

  describe('Read-Only Mode flags', () => {
    it('are undefined by default', () => {
      // When...
      render(
        <Button id="test" onClick={noop}>
          Clickable
        </Button>
      );
      // Then...
      const button = screen.getByRole('button');
      expect(button.attributes.getNamedItem('show-in-read-only-view')).toBeNull();
      expect(button.attributes.getNamedItem('disable-in-read-only-view')).toBeNull();
    });

    it('can be set to "true"', () => {
      // When...
      render(
        <Button id="test" onClick={noop} showInReadOnlyView={true} disableInReadOnlyView={true}>
          Clickable
        </Button>
      );
      // Then...
      const button = screen.getByRole('button');
      expect(button.getAttribute('show-in-read-only-view')).toEqual('true');
      expect(button.getAttribute('disable-in-read-only-view')).toEqual('true');
    });

    it('can be set to "false"', () => {
      // When...
      render(
        <Button id="test" onClick={noop} showInReadOnlyView={false} disableInReadOnlyView={false}>
          Clickable
        </Button>
      );
      // Then...
      const button = screen.getByRole('button');
      expect(button.getAttribute('show-in-read-only-view')).toEqual('false');
      expect(button.getAttribute('disable-in-read-only-view')).toEqual('false');
    });

    it('can be set to mixed values', () => {
      // When...
      render(
        <Button id="test" onClick={noop} showInReadOnlyView={true} disableInReadOnlyView={false}>
          Clickable
        </Button>
      );
      // Then...
      const button = screen.getByRole('button');
      expect(button.getAttribute('show-in-read-only-view')).toEqual('true');
      expect(button.getAttribute('disable-in-read-only-view')).toEqual('false');
    });
  });
});
