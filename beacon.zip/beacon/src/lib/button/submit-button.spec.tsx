import React from 'react';
import { render } from '@testing-library/react';
import { SubmitButton } from './submit-button';

jest.mock('../analytics/matomo', () => {
  const module = jest.requireActual('../analytics/matomo');
  return {
    ...module,
    track: jest.fn(),
  };
});

describe('SubmitButton', () => {
  it('renders submit button correctly', () => {
    const { baseElement } = render(<SubmitButton id="save-btn">Save</SubmitButton>);

    expect(baseElement).toMatchSnapshot();
  });
});
