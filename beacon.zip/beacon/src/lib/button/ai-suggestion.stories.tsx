import React, { SyntheticEvent } from 'react';
import { Button, ButtonType, ButtonVariant } from './button';
import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../stories';
import { action } from '@storybook/addon-actions';
import { a11yConfig } from '../stories/story.config';

export default {
  component: Button,
  title: 'Core Components/AI Suggestions/AI Suggestion Button',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
  },
} as Meta;

const whenToUse = (
  <>AI Suggestion Buttons should be used anytime ELIS is using AI or machine learning to make suggestions to users.</>
);

const accessibilityConsiderations = (
  <>Disable all motion if user has enabled prefers-reduced-motion in browser settings.</>
);

const languageGuidelines = (
  <>
    <p>Same as standard Beacon buttons, with the following exceptions:</p>
    <ul>
      <li>AI Suggestion Buttons should only be used for actions related to AI/ML suggestions or reviews.</li>
      <li>AI Suggestion Buttons should always be used instead of standard buttons inside of the AI Suggestion Card.</li>
    </ul>
  </>
);

/**
 * Primary
 */
export const Primary: Story = () => {
  const onClickHandler = (e: SyntheticEvent) => action('button-click')(e);
  const onDisabledClickHandler = (e: SyntheticEvent) => action('disabled-button-click')(e);

  return (
    <>
      <Button
        id="primary-button-sample"
        type={ButtonType.primary}
        variant={ButtonVariant.suggestion}
        onClick={onClickHandler}
      >
        Primary button
      </Button>{' '}
      <Button
        id="primary-button-sample-disabled"
        type={ButtonType.primary}
        variant={ButtonVariant.suggestion}
        onClick={onDisabledClickHandler}
        disabled
      >
        Primary button (Disabled)
      </Button>
    </>
  );
};

Primary.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Primary Button"
      description="Primary buttons indicate the most critical or important action on a form or page"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      languageGuidelines={languageGuidelines}
    >
      <ComponentStory />
    </Documentation>
  ),
];
Primary.storyName = 'Primary Button';
/**
 * Secondary
 */
export const Secondary: Story = () => {
  const onClickHandler = (e: SyntheticEvent) => action('button-click')(e);
  const onDisabledClickHandler = (e: SyntheticEvent) => action('disabled-button-click')(e);

  return (
    <>
      <Button
        id="secondary-button-sample"
        tracking={{ grouping: 'Secondary Storybook', action: 'Pressed it', trackingKey: 'The coolest button' }}
        type={ButtonType.secondary}
        variant={ButtonVariant.suggestion}
        onClick={onClickHandler}
      >
        Secondary button
      </Button>{' '}
      <Button
        id="secondary-button-sample-disabled"
        type={ButtonType.secondary}
        variant={ButtonVariant.suggestion}
        onClick={onDisabledClickHandler}
        disabled
      >
        Secondary button (Disabled)
      </Button>
    </>
  );
};

Secondary.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Secondary Button"
      description="Secondary buttons indicate less frequently used actions."
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      languageGuidelines={languageGuidelines}
    >
      <ComponentStory />
    </Documentation>
  ),
];
Secondary.storyName = 'Secondary Button';
/**
 * Tertiary
 */
export const Tertiary: Story = () => {
  const onClickHandler = (e: SyntheticEvent) => action('button-click')(e);
  const onDisabledClickHandler = (e: SyntheticEvent) => action('disabled-button-click')(e);

  return (
    <>
      <Button
        id="tertiary-button-sample"
        type={ButtonType.tertiary}
        variant={ButtonVariant.suggestion}
        onClick={onClickHandler}
      >
        Tertiary button
      </Button>{' '}
      <Button
        id="tertiary-button-sample-disabled"
        type={ButtonType.tertiary}
        variant={ButtonVariant.suggestion}
        onClick={onDisabledClickHandler}
        disabled
      >
        Tertiary button (Disabled)
      </Button>
    </>
  );
};

Tertiary.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Tertiary Button"
      description="Tertiary actions are for less commonly used actions, and as such have lower visual hierarchy than Primary and Secondary buttons."
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      languageGuidelines={languageGuidelines}
    >
      <ComponentStory />
    </Documentation>
  ),
];
Tertiary.storyName = 'Teritary Button';
