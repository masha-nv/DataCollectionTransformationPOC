import React, { SyntheticEvent, useState } from 'react';
import { Button, ButtonType, ButtonVariant } from './button';
import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../stories';
import { action } from '@storybook/addon-actions';
import { a11yConfig } from '../stories/story.config';
import { ButtonGroup, ButtonGroupDirection } from './button-group';
import { ActionMenu } from '../action-menu/dropdown-action-menu/action-menu';
import { Action } from '../action-menu/dropdown-action-menu/action';

export default {
  component: Button,
  title: 'Core Components/Buttons',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
  },
} as Meta;

/**
 * Primary
 */
export const Primary: Story = () => {
  const onClickHandler = (e: SyntheticEvent) => action('button-click')(e);
  const onDisabledClickHandler = (e: SyntheticEvent) => action('disabled-button-click')(e);

  return (
    <div className="beacon">
      <Button id="primary-button-sample" type={ButtonType.primary} onClick={onClickHandler}>
        Primary button
      </Button>{' '}
      <Button id="primary-button-sample-disabled" type={ButtonType.primary} onClick={onDisabledClickHandler} disabled>
        Primary button (Disabled)
      </Button>
    </div>
  );
};

Primary.decorators = [
  (Story: Story) => (
    <Documentation
      name="Primary Button"
      description="Primary buttons indicate the most critical or important action on a form or page"
      whenToUse={
        <>
          <p>
            Primary buttons -- buttons that execute primary actions — should be as visible as possible. Secondary and
            tertiary buttons should also be visible, but less prominent than primary buttons. The hierarchy should be
            clear. There should be only one primary button for a task.
          </p>
          <p>
            In general, if there is only one button, it should be a primary button. There are exceptions, however – see
            Secondary Buttons section below.
          </p>
          <ul>
            <li>
              <strong className="beacon-icon-success">Do</strong>{' '}
              <strong>use primary and secondary buttons together</strong> for combinations such as Save and Cancel. This
              clearly indicates the hierarchy of the call to action.
            </li>
            <li>
              <strong className="beacon-icon-success">Do</strong> <strong>group buttons flush right</strong>, especially
              in modals and pop-ups, with the primary button farthest right
            </li>
          </ul>
        </>
      }
      accessibilityConsiderations={
        <p>
          <strong>Buttons</strong> must be keyboard accessible.
        </p>
      }
    >
      <Story />
    </Documentation>
  ),
];
Primary.storyName = 'Primary Button';
/**
 * Secondary
 */
export const Secondary: Story = () => {
  const onClickHandler = (e: SyntheticEvent) => action('button-click')(e);
  const onDisabledClickHandler = (e: SyntheticEvent) => action('disabled-button-click')(e);

  return (
    <div className="beacon">
      <Button
        id="secondary-button-sample"
        tracking={{ grouping: 'Secondary Storybook', action: 'Pressed it', trackingKey: 'The coolest button' }}
        type={ButtonType.secondary}
        onClick={onClickHandler}
      >
        Secondary button
      </Button>{' '}
      <Button
        id="secondary-button-sample-disabled"
        type={ButtonType.secondary}
        onClick={onDisabledClickHandler}
        disabled
      >
        Secondary button (Disabled)
      </Button>
    </div>
  );
};

Secondary.decorators = [
  (Story: Story) => (
    <Documentation
      name="Secondary Button"
      description="Secondary buttons indicate less frequently used actions."
      whenToUse={
        <>
          <p>
            Secondary buttons offer users additional actions they can take in their task, such as Cancel or Back. While
            there's only one primary button per task, you can have more than one secondary button.
          </p>
          <p>
            Combinations such as Save and Cancel should always have a primary and secondary button to clearly indicate
            the hierarchy of the call to action.
          </p>
          <p>
            Occasionally it may be appropriate to use a secondary button by itself. One example would be a page where
            the user is primarily reviewing and editing a table of data. A button that refreshes data in the table might
            be a secondary button, since it's not the primary action on the page. In a case such as this, the focus is
            on the primary action within the page rather than a button.
          </p>
          <ul>
            <li>
              <strong className="beacon-icon-success">Do</strong>{' '}
              <strong>use primary and secondary buttons together</strong> for combinations such as Save and Cancel. This
              clearly indicates the hierarchy of the call to action.
            </li>
            <li>
              <strong className="beacon-icon-success">Do</strong> <strong>group buttons flush right</strong>, especially
              in modals and pop-ups, with the primary button farthest right
            </li>
          </ul>
          <p>
            Use the same language guidelines as for <a href="#/buttons#primary">primary buttons</a>.
          </p>
        </>
      }
      accessibilityConsiderations={
        <p>
          <strong>Buttons</strong> must be keyboard accessible.
        </p>
      }
    >
      <Story />
    </Documentation>
  ),
];
Secondary.storyName = 'Secondary Button';
/**
 * Tertiary
 */
export const Tertiary: Story = () => {
  const onClickHandler = (e: SyntheticEvent) => action('button-click')(e);
  const onDisabledClickHandler = (e: SyntheticEvent) => action('disabled-button-click')(e);

  return (
    <div className="beacon">
      <Button id="tertiary-button-sample" type={ButtonType.tertiary} onClick={onClickHandler}>
        Tertiary button
      </Button>{' '}
      <Button id="tertiary-button-sample-disabled" type={ButtonType.tertiary} onClick={onDisabledClickHandler} disabled>
        Tertiary button (Disabled)
      </Button>
    </div>
  );
};

Tertiary.decorators = [
  (Story: Story) => (
    <Documentation
      name="Tertiary Button"
      description="Tertiary actions are for less commonly used actions, and as such have lower visual hierarchy than Primary and Secondary buttons."
      whenToUse={
        <>
          <p>
            Since primary and secondary button styles cover most situations, tertiary buttons are rarely used. Most of
            the time their purpose is to offer a third option that is less important than the secondary button. They
            therefore have the least visual weight of all three styles.
          </p>
          <p>
            Use the same language guidelines as for <a href="#/buttons#primary">primary buttons</a>.
          </p>
        </>
      }
      accessibilityConsiderations={
        <p>
          <strong>Buttons</strong> must be keyboard accessible.
        </p>
      }
    >
      <Story />
    </Documentation>
  ),
];
Tertiary.storyName = 'Teritary Button';

export const ButtonGroups: Story = () => {
  const onClickHandler = (e: SyntheticEvent) => action('button-click')(e);
  const onDisabledClickHandler = (e: SyntheticEvent) => action('disabled-button-click')(e);

  return (
    <div className="beacon w-50 border px-2 py-4">
      <p>The following shows a button group being rendered with 3 buttons with the default render direction</p>
      <ButtonGroup>
        <Button id="group-sample-button-1" type={ButtonType.tertiary} onClick={onClickHandler}>
          Tertiary button
        </Button>{' '}
        <Button id="group-sample-button-2" type={ButtonType.secondary} onClick={onClickHandler}>
          Secondary button
        </Button>{' '}
        <Button id="group-sample-button-3" type={ButtonType.primary} onClick={onClickHandler}>
          Primary button
        </Button>{' '}
      </ButtonGroup>
      <hr />
      <p>The following shows a button group being rendered with 3 buttons left-aligned</p>
      <ButtonGroup direction={ButtonGroupDirection.LEFT}>
        <Button id="group-sample-button-4" type={ButtonType.tertiary} onClick={onClickHandler}>
          Tertiary button
        </Button>{' '}
        <Button id="group-sample-button-5" type={ButtonType.secondary} onClick={onClickHandler}>
          Secondary button
        </Button>{' '}
        <Button id="group-sample-button-6" type={ButtonType.primary} onClick={onClickHandler}>
          Primary button
        </Button>{' '}
      </ButtonGroup>
      <hr />
      <p>The following shows a button group being rendered with 5 buttons left-aligned and wrap enabled</p>
      <ButtonGroup direction={ButtonGroupDirection.LEFT} wrap={true}>
        <Button id="group-sample-button-7" type={ButtonType.tertiary} onClick={onClickHandler}>
          Tertiary button
        </Button>{' '}
        <Button id="group-sample-button-8" type={ButtonType.secondary} onClick={onClickHandler}>
          Secondary button
        </Button>{' '}
        <Button id="group-sample-button-9" type={ButtonType.primary} onClick={onClickHandler}>
          Primary button
        </Button>{' '}
        <Button id="group-sample-button-10" type={ButtonType.primary} onClick={onClickHandler}>
          Somewhat longer Button
        </Button>{' '}
        <Button id="group-sample-button-11" type={ButtonType.secondary} onClick={onClickHandler}>
          Secondary button
        </Button>{' '}
      </ButtonGroup>
    </div>
  );
};

ButtonGroups.decorators = [
  (Story: Story) => (
    <Documentation
      name="Button Group"
      description={
        <p>
          Button Groups are used as a layout tool in order to have the correct spacing when displaying a set of buttons.
          The layout will default to right-aligned buttons in the button group with a bit of spacing between them.
        </p>
      }
      whenToUse={
        <p>Use when there is a need to display a group of buttons in a line, for example footers on a modal.</p>
      }
    >
      <Story />
    </Documentation>
  ),
];

export const Variants: Story = () => {
  const onClickHandler = (e: SyntheticEvent) => action('button-click')(e);
  const [variant, setVariant] = useState(ButtonVariant.suggestion);
  const descriptions = {
    suggestion: 'Suggestion: Used for AI suggestions in the AI button suggestion element.',
    important: 'Important: Used when a button needs to be highlighted red to caution the user.',
  };

  return (
    <>
      <p>
        The following shows a priimary button, a secondary button, and a tertiary button using the button variant{' '}
        {variant}.
      </p>
      <Button id="group-sample-button-1" type={ButtonType.primary} variant={variant} onClick={onClickHandler}>
        Tertiary button
      </Button>{' '}
      <Button id="group-sample-button-2" type={ButtonType.secondary} variant={variant} onClick={onClickHandler}>
        Secondary button
      </Button>{' '}
      <Button id="group-sample-button-3" type={ButtonType.tertiary} variant={variant} onClick={onClickHandler}>
        Primary button
      </Button>{' '}
      <p>{descriptions[variant]}</p>
      <p>You can change the variant using the dropdown below.</p>
      <ActionMenu id="actionmenu-variant" label="Variants">
        {Object.values(ButtonVariant).map((thisVariant) => (
          <Action id={`action-${thisVariant}`} onClick={() => setVariant(thisVariant)}>
            {thisVariant}
          </Action>
        ))}
      </ActionMenu>
    </>
  );
};

Variants.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Variants"
      description={
        <p>
          Variants of a button are to be used when the button should have different styling. Each variant has a use case
          in addition to default button handling.
        </p>
      }
      whenToUse={
        <>
          <p>Each variant has a different use case:</p>
          <p>Suggestion: Used for AI suggestions in the AI button suggestion element.</p>
          <p>Important: Used when a button needs to be highlighted red to caution the user.</p>
        </>
      }
    >
      <ComponentStory />
    </Documentation>
  ),
];
Variants.storyName = 'Variants';
