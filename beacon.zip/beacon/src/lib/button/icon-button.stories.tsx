import { Meta, Story } from '@storybook/react';
import { IconButtonVariant, IconType } from '../icon/constants';
import { Icon } from '../icon/icon';
import { Documentation, StoryBadge } from '../stories';
import { a11yConfig } from '../stories/story.config';
import { noop } from '../utils';
import { ButtonGroup, ButtonGroupDirection } from './button-group';
import { IconButton } from './icon-button';

export default {
  component: IconButton,
  title: 'Core Components/Buttons',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
  },
} as Meta;

export const IconButtons: Story = () => {
  return (
    <section>
      <ButtonGroup direction={ButtonGroupDirection.LEFT}>
        <IconButton id="calendar-icon-button" label="calendar" onClick={noop}>
          <Icon type={IconType.calendar} />
        </IconButton>

        <IconButton id="calendar-disabled-icon-button" title="fsdfsdf" label="calendar" disabled onClick={noop}>
          <Icon type={IconType.calendar} />
        </IconButton>
      </ButtonGroup>
      <ButtonGroup direction={ButtonGroupDirection.LEFT}>
        <IconButton variant={IconButtonVariant.permanent} id="delete-icon-button" label="delete" onClick={noop}>
          <Icon type={IconType.trash} />
        </IconButton>

        <IconButton id="delete-disabled-icon-button" label="delete" disabled onClick={noop}>
          <Icon type={IconType.trash} />
        </IconButton>
      </ButtonGroup>
      <ButtonGroup direction={ButtonGroupDirection.LEFT}>
        <IconButton variant={IconButtonVariant.gray} hideTooltip id="info-icon-button" label="close" onClick={noop}>
          <Icon type={IconType.infoCircle} />
        </IconButton>

        <IconButton id="info-disabled-icon-button" label="close" disabled onClick={noop}>
          <Icon type={IconType.infoCircle} />
        </IconButton>
      </ButtonGroup>
    </section>
  );
};

IconButtons.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Icon Buttons"
      description={
        <p>
          Icon Buttons are buttons that contain icons and no <strong>(visible)</strong> accompanying text. They are
          often used in menus as triggers for common actions.
        </p>
      }
      whenToUse={
        <p>
          Icon Buttons should only be used for actions that very common. Usually these actions should already have been
          associated with the corresponding icon.
        </p>
      }
    >
      <ComponentStory />
    </Documentation>
  ),
];
IconButtons.storyName = 'Icon Button';
