import classNames from 'classnames';
import React, { forwardRef, ReactNode, SyntheticEvent } from 'react';
import { Trackable, getTrackableClickHandler } from '../analytics';
import { WithId } from '../with-id';
import './button.scss';

export interface IButtonProps extends Trackable, WithId {
  /**
   * The type of button to render, retrieve them from `ButtonType`
   */
  type?: ButtonType;

  /*
   * Button behavior
   */
  behavior?: 'submit' | 'reset' | 'button';
  /**
   * The color variant to apply to the button
   */
  variant?: ButtonVariant;
  /**
   * True if the button is disabled
   */
  disabled?: boolean;
  /**
   * The content of this button
   */
  children: ReactNode;
  /**
   * The popup title of the button
   */
  title?: string;
  /**
   * Accessible label for the button
   */
  label?: string;
  /**
   * click event handler
   */
  onClick: (param: SyntheticEvent) => void;
  /** set the value for the show-in-read-only-view attribute, which is used by ELIS to automatically hide elements when their container is in read-only mode */
  showInReadOnlyView?: boolean;
  /** set the value for the disiable-in-read-only-view attribute, which is used by ELIS to automatically disable elements when their container is in read-only mode */
  disableInReadOnlyView?: boolean;
}

export enum ButtonType {
  primary = 'primary',
  secondary = 'secondary',
  tertiary = 'tertiary',
}

export enum ButtonVariant {
  suggestion = 'suggestion',
  important = 'important',
}

/**
 * Button component
 */
export const Button = forwardRef<HTMLButtonElement, IButtonProps>(
  (
    {
      id,
      tracking,
      type = ButtonType.secondary,
      behavior,
      variant,
      disabled = false,
      children,
      title,
      label,
      onClick,
      showInReadOnlyView,
      disableInReadOnlyView,
    },
    ref
  ) => {
    const trackingDefaults = {
      grouping: 'Ungrouped',
      action: 'Clicked',
      trackingKey: `Button-${children?.toString()}`,
    };

    const buttonClasses = classNames(`btn btn-${type}`, {
      suggestion: variant === ButtonVariant.suggestion,
      important: variant === ButtonVariant.important,
    });

    return (
      <button
        ref={ref}
        id={id}
        className={buttonClasses}
        disabled={disabled}
        onClick={getTrackableClickHandler(tracking, trackingDefaults, onClick)}
        title={title}
        aria-label={label}
        type={behavior}
        show-in-read-only-view={showInReadOnlyView === undefined ? undefined : showInReadOnlyView.toString()}
        disable-in-read-only-view={disableInReadOnlyView === undefined ? undefined : disableInReadOnlyView.toString()}
      >
        {children}
      </button>
    );
  }
);

Button.displayName = 'Button';
