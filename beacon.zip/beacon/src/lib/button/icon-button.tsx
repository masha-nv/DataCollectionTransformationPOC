import classNames from 'classnames';
import React, { ReactNode, SyntheticEvent } from 'react';
import { IconButtonVariant, IconButtonVariantCSS } from '../icon/constants';
import { Tooltip } from '../modals/tooltip/tooltip';
import { WithId } from '../with-id';
import './icon-button.scss';

export enum IconButtonTheme {
  standard = 'standard',
  permanent = 'permanent',
  gray = 'gray',
}

export interface IIconButtonProps extends WithId {
  /**
   * The content of this button
   */
  children: ReactNode;
  /**
   * True if the button is disabled
   */
  disabled?: boolean;
  /**
   * The popup title of the button
   */
  title?: string;
  /**
   * Accessible label for the icon button
   */
  label: string;
  /**
   * Hides custom tooltip
   */
  hideTooltip?: boolean;
  /**
   * click event handler
   */
  onClick: (param: SyntheticEvent) => void;
  /**
   * Color variable. Either use available options or a custom color
   */
  variant?: IconButtonVariant | string;
  /**
   * The DOM element to render the tooltip in a portal
   */
  portalContainer?: Element;
  /**
   * z-index of the tooltip popover
   */
  zIndex?: number;
}

export const IconButton = (props: IIconButtonProps) => {
  const buttonClasses = classNames(`btn btn-icon`, IconButtonVariantCSS[props.variant as IconButtonVariant]);
  const buttonComponent = (
    <button
      id={props.id}
      className={buttonClasses}
      type="button"
      aria-label={props.label}
      onClick={props.onClick}
      title={props.title}
      disabled={props.disabled}
    >
      {props.children}
    </button>
  );
  return props.hideTooltip ? (
    buttonComponent
  ) : (
    <Tooltip content={props.label} portalContainer={props.portalContainer} zIndex={props.zIndex}>
      {buttonComponent}
    </Tooltip>
  );
};
