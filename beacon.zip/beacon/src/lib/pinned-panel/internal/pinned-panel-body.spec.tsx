import React from 'react';
import { render } from '@testing-library/react';
import { PinnedPanelBody } from './pinned-panel-body';

describe('PinnedPanelBody', () => {
  it('renders pinned-panel-body successfully', () => {
    const { baseElement } = render(
      <PinnedPanelBody>
        <p>Test</p>
      </PinnedPanelBody>
    );
    expect(baseElement).toMatchSnapshot();
  });
  it('renders pinned-panel-body with maxHeight', () => {
    const utils = render(
      <PinnedPanelBody maxHeight="10">
        <p>Test</p>
      </PinnedPanelBody>
    );
    expect(utils.queryAllByText('max-height:10'));
  });
});
