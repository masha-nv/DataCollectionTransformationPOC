import React, { SyntheticEvent } from 'react';
import { Bubble, BubbleType } from '../../notifications/bubble/bubble';
import { defaultTracking, Trackable, trackableEvent } from '../../analytics';
import { WithId } from '../../with-id';
import { Heading, HeadingType } from '../../heading/heading';
export interface IPinnedPanelTitleProps extends Trackable, WithId {
  /**
   * Value that will be displayed for pinned-panel
   */
  title: string;
  /**
   * (optional) An integer to display inside a bubble next to the title.
   */
  metaCount?: number;
  /**
   * (optional) Default state for disable/enabled when the component loads
   */
  disabled?: boolean;
  /**
   * Whether or not the pinnel panel for title is collapsed or not
   */
  collapsed?: boolean;
  /**
   * (optional) function to be executed when the panel title is clicked
   */
  onToggled?: (param: SyntheticEvent) => void;
  /**
   * The type of heading used for the title.
   */
  headingType?: HeadingType;
}

// eslint-disable-next-line @typescript-eslint/no-empty-function
const defaultOnToggled = () => {};

export const PinnedPanelTitle = ({
  id,
  title,
  metaCount,
  disabled,
  collapsed,
  onToggled = defaultOnToggled,
  tracking,
  headingType,
}: IPinnedPanelTitleProps) => {
  const buttonCollapsedStyle = collapsed ? 'collapsed' : '';
  const togglePanelIcon = (trackableClick: SyntheticEvent) => {
    onToggled(trackableClick);
  };
  enum TrackingActionType {
    expanded = 'Expanded',
    collapsed = 'Collapsed',
  }
  const trackingInfo = defaultTracking(tracking, {
    grouping: 'Ungrouped',
    trackingKey: 'PinnedPanel-' + id,
  });
  trackingInfo.action = collapsed ? TrackingActionType.expanded : TrackingActionType.collapsed;
  const trackableClick = trackableEvent(trackingInfo, togglePanelIcon);
  const titleClass = metaCount != null ? 'beacon-accordion-title mr-2' : 'beacon-accordion-title';

  return (
    <button
      id={id}
      className={`text-left pinned-panel-header ${buttonCollapsedStyle} ${disabled ? 'pinned-panel-disabled' : ''}`}
      disabled={disabled}
      onClick={trackableClick}
    >
      <span className={titleClass}>
        <Heading headingType={headingType ? headingType : 'h2'} headingStyle="m">
          {title}
        </Heading>
      </span>
      {metaCount != null && <Bubble type={BubbleType.default} children={metaCount}></Bubble>}
      {collapsed ? (
        <i className="toggle-icon fas fa-plus">
          <span className="sr-only">Expand {title}</span>
        </i>
      ) : (
        <i className="toggle-icon fas fa-minus">
          <span className="sr-only">Collapse {title}</span>
        </i>
      )}
    </button>
  );
};
