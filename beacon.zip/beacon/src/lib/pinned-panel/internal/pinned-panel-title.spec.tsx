import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { PinnedPanelTitle } from './pinned-panel-title';
import { track } from '../../analytics/matomo';
import { TrackableEvent } from '../../analytics';

jest.mock('../analytics/matomo', () => {
  const module = jest.requireActual('../analytics/matomo');
  return {
    ...module,
    track: jest.fn(),
  };
});

describe('PinnedPanelTitle', () => {
  const clickAction = jest.fn();
  it('renders successfully as collapsed', () => {
    const { baseElement } = render(<PinnedPanelTitle id="title1" title="TEST" collapsed />);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders successfully as expanded', () => {
    const { baseElement } = render(<PinnedPanelTitle id="title1" title="TEST" />);
    expect(baseElement).toMatchSnapshot();
  });

  it('clicking button calls the buttonClickAction', () => {
    render(<PinnedPanelTitle id="title1" title="TEST" onToggled={clickAction} />);

    fireEvent.click(screen.getByText('TEST'));

    expect(clickAction).toHaveBeenCalled();
  });

  it('logs analytics information when expanded', () => {
    render(<PinnedPanelTitle id="title1" title="TEST" collapsed />);

    fireEvent.click(screen.getByText('TEST'));
    expect(track).toHaveBeenCalledWith({
      grouping: 'Ungrouped',
      action: 'Expanded',
      trackingKey: 'PinnedPanel-title1',
    } as TrackableEvent);
  });

  it('logs analytics information when collapsed', () => {
    render(<PinnedPanelTitle id="title1" title="TEST" />);

    fireEvent.click(screen.getByText('TEST'));
    expect(track).toHaveBeenCalledWith({
      grouping: 'Ungrouped',
      action: 'Collapsed',
      trackingKey: 'PinnedPanel-title1',
    } as TrackableEvent);
  });

  it('allows overriding analytics grouping', () => {
    render(<PinnedPanelTitle id="title1" title="TEST" tracking={{ grouping: 'jest test' }} collapsed />);

    fireEvent.click(screen.getByText('TEST'));
    expect(track).toHaveBeenCalledWith({
      grouping: 'jest test',
      action: 'Expanded',
      trackingKey: 'PinnedPanel-title1',
    } as TrackableEvent);
  });

  it('allows overriding analytics tracking key', () => {
    render(<PinnedPanelTitle id="title1" title="TEST" tracking={{ trackingKey: 'jest test' }} collapsed />);

    fireEvent.click(screen.getByText('TEST'));
    expect(track).toHaveBeenCalledWith({
      grouping: 'Ungrouped',
      action: 'Expanded',
      trackingKey: 'jest test',
    } as TrackableEvent);
  });

  it('does not allow overriding analytics action', () => {
    render(<PinnedPanelTitle id="title1" title="TEST" tracking={{ action: 'jest test' }} collapsed />);

    fireEvent.click(screen.getByText('TEST'));
    expect(track).toHaveBeenCalledWith({
      grouping: 'Ungrouped',
      action: 'Expanded',
      trackingKey: 'PinnedPanel-title1',
    } as TrackableEvent);
  });

  it('renders with metaCount successfully', () => {
    render(<PinnedPanelTitle id="title1" title="TEST" metaCount={10} collapsed />);
    expect(screen.getByText('10')).toBeTruthy();
  });

  it('renders with disabled true successfully', () => {
    const { baseElement } = render(<PinnedPanelTitle id="title1" title="TEST" collapsed disabled />);
    expect(baseElement.querySelector('button')?.hasAttribute('disabled')).toBeTruthy();
  });
});
