import React, { ReactNode } from 'react';

export interface IPinnedPanelBodyProps {
  /**
   * (optional) Creates a scrollable body if the contents of the pinned-panel body is greater
   * than the max-height specified in here. This is open to the user and can either be used as a percentage or pixel. IE.
   */
  maxHeight?: string;
  /**
   * The actual contents of this particular pinned panel
   */
  children: ReactNode;
}

export const PinnedPanelBody = ({ maxHeight = '100%', children }: IPinnedPanelBodyProps) => {
  return (
    <div tabIndex={0} className="accordion-tab accordion-body pinned-panel-body" style={{ maxHeight: maxHeight }}>
      {children}
    </div>
  );
};
