import React from 'react';
import { render } from '@testing-library/react';
import { PinnedPanelGroup } from './pinned-panel-group';
import { PinnedPanel } from './pinned-panel';

describe('PinnedPannelGroup Component', () => {
  it('renders successfully', () => {
    const { baseElement } = render(
      <PinnedPanelGroup id="myPinnedPanel">
        <PinnedPanel id="panel1" title="panel1">
          Hello world
        </PinnedPanel>
      </PinnedPanelGroup>
    );

    expect(baseElement).toMatchSnapshot();
  });
});
