import React, { ReactNode, useState } from 'react';
import { Trackable } from '../analytics';
import { HeadingType } from '../heading/heading';
import { WithId } from '../with-id';
import { PinnedPanelBody } from './internal/pinned-panel-body';
import { PinnedPanelTitle } from './internal/pinned-panel-title';
import './pinned-panel.scss';
export interface IPinnedPanelProps extends Trackable, WithId {
  /**
   * Value that will be displayed for pinned-panel
   */
  title: string;
  /**
   * (optional) Creates a scrollable body if the contents of the pinned-panel body is greater than the max-height specified in here. This is open to the user and can either be used as a percentage or pixel. IE.
   */
  maxHeight?: string;
  /**
   * (optional) An integer to display inside a bubble next to the title.
   */
  metaCount?: number;
  /**
   * (optional) Default state for disable/enabled when the component loads
   */
  disabled?: boolean;
  /**
   * (optional) Whether or not this pinned panel is expanded by default
   */
  defaultExpanded?: boolean;
  /**
   * Child elements
   */
  children: ReactNode;
  /**
   * The type of heading used for the title.
   */
  headingType?: HeadingType;
}

export const PinnedPanel = ({
  id,
  title,
  maxHeight,
  metaCount: bubbleCount,
  disabled,
  defaultExpanded = false,
  children,
  tracking,
  headingType,
}: IPinnedPanelProps) => {
  const [collapsed, setCollapsed] = useState(!defaultExpanded);
  const togglePanel = () => {
    setCollapsed(!collapsed);
  };

  return (
    <div id={id} className={`accordion-tab pinned-panel-container ${disabled ? 'accordion-tab-disabled' : ''}`}>
      <PinnedPanelTitle
        tracking={tracking}
        id={`${id}-panel-title`}
        title={title}
        metaCount={bubbleCount}
        disabled={disabled}
        onToggled={togglePanel}
        collapsed={collapsed}
        headingType={headingType}
      />
      {!collapsed && !disabled && <PinnedPanelBody maxHeight={maxHeight} children={children}></PinnedPanelBody>}
    </div>
  );
};
