import React, { ReactElement } from 'react';
import { WithId } from '../with-id';
import { PinnedPanel } from './pinned-panel';

export interface IPinnedPanelGroupProps extends WithId {
  /**
   * The nodes inside this group
   */
  children: ReactElement<typeof PinnedPanel> | ReactElement<typeof PinnedPanel>[];
}

/**
 * Comment what the new component is for
 */
export const PinnedPanelGroup = (props: IPinnedPanelGroupProps) => {
  return (
    <div id={props.id} className="pinned-panel-list">
      {props.children}
    </div>
  );
};
