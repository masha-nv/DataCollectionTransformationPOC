import React from 'react';
import { render } from '@testing-library/react';
import { Beacon, WithId, Trackable } from '../index';

describe('Beacon', () => {
  it('should render successfully', () => {
    const { baseElement } = render(<Beacon version={'testing-version'} />);
    expect(baseElement).toMatchSnapshot();
  });
  it('should default to a given version', () => {
    const { baseElement } = render(<Beacon />);
    expect(baseElement).toMatchSnapshot();
  });

  /* yes these aren't necessary if it compiles, but I'm checking to see
   * if the interface is defined properly since these are being exposed to
   * the consumer of the library
   */
  it('should define WithId interface', () => {
    const withId: WithId = { id: 'hello' };
    expect(withId).toBeTruthy();
  });

  it('should define Trackable interface', () => {
    const trackable: Trackable = {
      tracking: {
        action: 'hello',
        grouping: 'world',
        trackingKey: 'custom key',
      },
    };
    expect(trackable).toBeTruthy();
  });
});
