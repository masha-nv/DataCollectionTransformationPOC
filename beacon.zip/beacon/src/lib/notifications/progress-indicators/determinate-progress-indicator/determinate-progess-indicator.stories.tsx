import { Meta, Story } from '@storybook/react';
import { useEffect, useState } from 'react';
import { Documentation, StoryBadge } from '../../../stories';
import { a11yConfig } from '../../../stories/story.config';
import { DeterminateProgressIndicator, IdeterminateProgressIndicatorProps } from './determinate-progress-indicator';
import './determinate-progress-indicator.scss';

export default {
  component: DeterminateProgressIndicator,
  title: 'Core Components/Notifications/Progress Indicator',
  parameters: {
    a11y: a11yConfig,
    badges: [StoryBadge.READY],
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

export const DeterminateProgressIndicatorExample: Story<IdeterminateProgressIndicatorProps> = ({
  id,
  title,
}: IdeterminateProgressIndicatorProps) => {
  const [progression, setProgression] = useState<number>(0);
  const [loadTimeDescriptor, setDescriptor] = useState('');
  const [labelText, setLabelText] = useState('Loading...');

  useEffect(() => {
    const timer = setInterval(() => {
      setProgression((oldProgression) => {
        if (oldProgression >= 99) {
          setLabelText('Completed');
        }
        if (oldProgression === 101) {
          setProgression(0);
        }
        if (oldProgression === 0) {
          setLabelText('Loading...');
        }
        const diff = Math.random() * 5;
        return Math.min(oldProgression + diff, 101);
      });
    }, 500);
    setDescriptor(timer.toString());
    return () => {
      clearInterval(timer);
    };
  }, []);

  return (
    <div className="beacon react-beacon">
      <div>
        <DeterminateProgressIndicator
          id={id}
          title={title}
          percentage={progression}
          loadTime={loadTimeDescriptor}
          defaultText={labelText}
        />
      </div>
      <br /> <br /> <br />
    </div>
  );
};

const whenToUse = (
  <>
    <p>
      Display a progress indicator when a process is in progress and users have to wait for upload from an API call. For
      example when loading data, generating a file, or another system process is happening.
    </p>
    <p>
      When a page has multiple loading sections, evaluate the load times and content when deciding whether to use one
      Large progress indicator or multiple indicators. What are the load times? Are there parts of the screen users
      could interact with before everything is done loading?
    </p>
  </>
);
DeterminateProgressIndicatorExample.decorators = [
  (DeterminateProgressIndicatorStory: Story) => (
    <Documentation
      name="Determinate Progress Indicator Example"
      description="Progress indicators can be determinate or indeterminate, where determinate shows users the loading progress such as with percentages. This component is determinate.
      They appear on the screen to improve the waiting experience and to let users know something is happening such as data being retrieved. They disappear when the system process is completed."
      whenToUse={whenToUse}
    >
      <DeterminateProgressIndicatorStory />
    </Documentation>
  ),
];
DeterminateProgressIndicatorExample.argTypes = {};
