import './determinate-progress-indicator.scss';
import { defaultTracking, track, Trackable } from '../../../analytics';
import { useEffect } from 'react';
import { WithId } from '../../../with-id';

export interface IdeterminateProgressIndicatorProps extends WithId, Trackable {
  title: string;
  description?: string;
  percentage: number;
  defaultText: string;
  loadTime: string;
}

export const DeterminateProgressIndicator = ({
  title,
  id,
  defaultText,
  percentage,
  tracking,
  loadTime,
}: IdeterminateProgressIndicatorProps) => {
  useEffect(() => {
    return function afterUnload() {
      const trackingInfo = defaultTracking(tracking, {
        grouping: 'Progress Indication',
        action: `Show ${title} Determinate Progress Indicator`,
        trackingKey: `DeterminateProgressIndicator-${id}`,
        value: `${loadTime}`,
      });
      track(trackingInfo);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [percentage]);

  return (
    <div className="determinate-progress-indicator-bar" id={`determinate-progress-indicator-${id}`}>
      <div className="determinate-progress-indicator-bar-filler" style={{ width: `${percentage}%` }}></div>
      <label>{defaultText}</label>
    </div>
  );
};
