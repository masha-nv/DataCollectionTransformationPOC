import { act, fireEvent, render, waitFor } from '@testing-library/react';
import { track, TrackableEvent } from '../../../analytics';
import { DeterminateProgressIndicator } from './determinate-progress-indicator';

jest.mock('../../analytics/matomo', () => {
  const module = jest.requireActual('../../analytics/matomo');
  return {
    ...module,
    track: jest.fn(),
  };
});

it('verifies load time analytics', async () => {
  let isShowingDeterminateProgressIndicator = true;
  const showDeterminateProgressIndicator = () => {
    isShowingDeterminateProgressIndicator = !isShowingDeterminateProgressIndicator;
  };

  const { baseElement, rerender } = render(
    <div id="button-id" onClick={() => showDeterminateProgressIndicator()}>
      {isShowingDeterminateProgressIndicator && (
        <DeterminateProgressIndicator
          id="determinate-progress-indicator-analytics"
          title={''}
          percentage={0}
          defaultText={'Loading...'}
          loadTime={'1234'}
        />
      )}
    </div>
  );

  expect(
    baseElement.querySelector('#determinate-progress-indicator-determinate-progress-indicator-analytics')
  ).not.toBeNull();
  const theDiv = baseElement.querySelector('#button-id');
  act(() => {
    fireEvent.click(theDiv);
  });
  rerender(
    <div id="button-id" onClick={() => showDeterminateProgressIndicator()}>
      {isShowingDeterminateProgressIndicator && (
        <DeterminateProgressIndicator
          id="determinate-progress-indicator-analytics"
          title={''}
          percentage={0}
          defaultText={''}
          loadTime={'1002'}
        />
      )}
    </div>
  );
  await waitFor(() =>
    expect(
      baseElement.querySelector('#determinate-progress-indicator-determinate-progress-indicator-analytics')
    ).toBeNull()
  );
  const positiveNumberRegex = /^[1-9]\d*$/;
  expect(track).toHaveBeenCalledWith({
    grouping: 'Progress Indication',
    action: `Show  Determinate Progress Indicator`,
    trackingKey: 'DeterminateProgressIndicator-determinate-progress-indicator-analytics',
    value: expect.stringMatching(positiveNumberRegex),
  } as TrackableEvent);
  act(() => {
    fireEvent.click(theDiv);
  });
  rerender(
    <div id="button-id" onClick={() => showDeterminateProgressIndicator()}>
      {isShowingDeterminateProgressIndicator && (
        <DeterminateProgressIndicator
          id="determinate-progress-indicator-analytics"
          title={''}
          percentage={0}
          defaultText={''}
          loadTime={'1234'}
        />
      )}
    </div>
  );
  await waitFor(() =>
    expect(
      baseElement.querySelector('#determinate-progress-indicator-determinate-progress-indicator-analytics')
    ).not.toBeNull()
  );
});

describe('DeterminateProgressIndicator Component', () => {
  it('renders determinateProgressIndicator', () => {
    const { baseElement } = render(
      <DeterminateProgressIndicator
        id="determinate-progress-indicator-example"
        title={''}
        percentage={0}
        defaultText={'Loading...'}
        loadTime={'1214'}
      />
    );
    expect(baseElement).toMatchSnapshot();
  });
});
