import { act, fireEvent, render, waitFor } from '@testing-library/react';
import { track, TrackableEvent } from '../../../analytics';
import { IndeterminateProgressIndicator, IndeterminateProgressIndicatorSize } from './indeterminate-progress-indicator';

jest.mock('../../analytics/matomo', () => {
  const module = jest.requireActual('../../analytics/matomo');
  return {
    ...module,
    track: jest.fn(),
  };
});

it('verifies load time analytics', async () => {
  let isShowingIndeterminateProgressIndicator = true;
  const showIndeterminateProgressIndicator = () => {
    isShowingIndeterminateProgressIndicator = !isShowingIndeterminateProgressIndicator;
  };

  const { baseElement, rerender } = render(
    <div id="button-id" onClick={() => showIndeterminateProgressIndicator()}>
      {isShowingIndeterminateProgressIndicator && (
        <IndeterminateProgressIndicator id="indeterminate-progress-indicator-analytics" />
      )}
    </div>
  );

  expect(
    baseElement.querySelector('#indeterminate-progress-indicator-indeterminate-progress-indicator-analytics')
  ).not.toBeNull();
  const theDiv = baseElement.querySelector('#button-id');
  act(() => {
    fireEvent.click(theDiv);
  });
  rerender(
    <div id="button-id" onClick={() => showIndeterminateProgressIndicator()}>
      {isShowingIndeterminateProgressIndicator && (
        <IndeterminateProgressIndicator id="indeterminate-progress-indicator-analytics" />
      )}
    </div>
  );
  await waitFor(() =>
    expect(
      baseElement.querySelector('#indeterminate-progress-indicator-indeterminate-progress-indicator-analytics')
    ).toBeNull()
  );
  const positiveNumberRegex = /^[1-9]\d*$/;
  expect(track).toHaveBeenCalledWith({
    grouping: 'Progress Indication',
    action: `Show Loading Indeterminate Progress Indicator`,
    trackingKey: 'IndeterminateProgressIndicator-indeterminate-progress-indicator-analytics',
    value: expect.stringMatching(positiveNumberRegex),
  } as TrackableEvent);
  act(() => {
    fireEvent.click(theDiv);
  });
  rerender(
    <div id="button-id" onClick={() => showIndeterminateProgressIndicator()}>
      {isShowingIndeterminateProgressIndicator && (
        <IndeterminateProgressIndicator id="indeterminate-progress-indicator-analytics" />
      )}
    </div>
  );
  await waitFor(() =>
    expect(
      baseElement.querySelector('#indeterminate-progress-indicator-indeterminate-progress-indicator-analytics')
    ).not.toBeNull()
  );
});

describe('IndeterminateProgressIndicator Component', () => {
  it('renders small IndeterminateProgressIndicator', () => {
    const { baseElement } = render(
      <IndeterminateProgressIndicator
        id="indeterminate-progress-indicator-example-small"
        size={IndeterminateProgressIndicatorSize.small}
        description="Small IndeterminateProgressIndicator"
      />
    );
    // small indeterminate-progress-indicator renders default title
    const titleElement = baseElement.querySelector('.indeterminate-progress-indicator-title');
    expect(titleElement).not.toBeNull();
    // small indeterminate-progress-indicator doesn't render description
    const descripttionElement = baseElement.querySelector('.indeterminate-progress-indicator-description');
    expect(descripttionElement).toBeNull();
    expect(baseElement).toMatchSnapshot();
  });
  it('renders medium IndeterminateProgressIndicator', () => {
    const { baseElement } = render(
      <IndeterminateProgressIndicator
        id="indeterminate-progress-indicator-example-medium"
        size={IndeterminateProgressIndicatorSize.medium}
        description="Medium IndeterminateProgressIndicator"
      />
    );
    // medium indeterminate-progress-indicator renders default title
    const titleElement = baseElement.querySelector('.indeterminate-progress-indicator-title');
    expect(titleElement).not.toBeNull();
    // medium indeterminate-progress-indicator doesn't render description
    const descripttionElement = baseElement.querySelector('.indeterminate-progress-indicator-description');
    expect(descripttionElement).toBeNull();
    expect(baseElement).toMatchSnapshot();
  });
  it('renders large IndeterminateProgressIndicator', () => {
    const { baseElement } = render(
      <IndeterminateProgressIndicator
        id="indeterminate-progress-indicator-example-large"
        size={IndeterminateProgressIndicatorSize.large}
        description="Large IndeterminateProgressIndicator"
      />
    );
    // large indeterminate-progress-indicator renders default title
    const titleElement = baseElement.querySelector('.indeterminate-progress-indicator-title');
    expect(titleElement).not.toBeNull();
    // large indeterminate-progress-indicator doesn't render description
    const descripttionElement = baseElement.querySelector('.indeterminate-progress-indicator-description');
    expect(descripttionElement).not.toBeNull();
    expect(baseElement).toMatchSnapshot();
  });
});
