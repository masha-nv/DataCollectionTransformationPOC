import { Meta, Story } from '@storybook/react';
import { Documentation, dropdownFromEnum, StoryBadge } from '../../../stories';
import { a11yConfig } from '../../../stories/story.config';
import {
  IIndeterminateProgressIndicatorProps,
  IndeterminateProgressIndicator,
  IndeterminateProgressIndicatorSize,
} from './indeterminate-progress-indicator';

export default {
  component: IndeterminateProgressIndicator,
  title: 'Core Components/Notifications/Progress Indicator',
  parameters: {
    a11y: a11yConfig,
    badges: [StoryBadge.READY],
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

export const IndeterminateProgressIndicatorExample: Story<IIndeterminateProgressIndicatorProps> = ({
  title,
  description,
  size,
}: IIndeterminateProgressIndicatorProps) => {
  return (
    <div style={{ width: '200px', height: '200px', margin: 'auto' }}>
      <IndeterminateProgressIndicator
        id={`indeterminate-progress-indicator-example-${size}`}
        title={title}
        description={description}
        size={size}
      />
    </div>
  );
};

const whenToUse = (
  <>
    <p>
      Display a progress indicator when a process is in progress and users have to wait. For example when loading data,
      generating a file, or another system process is happening. There are three indeterminate options:
    </p>
    <ul>
      <li>Large - default to this option </li>
      <li>Medium - use this when the container is too small for Large </li>
      <li>
        {' '}
        Small - for the smallest containers such as buttons and dropdowns, when clicking a button initiates a process
        and there isn't a seamless page or section of the page to show progress indicator such as uploading and
        searching
      </li>
    </ul>
    <p>
      When a page has multiple loading sections, evaluate the load times and content when deciding whether to use one
      Large progress indicator or multiple indicators. What are the load times? Are there parts of the screen users
      could interact with before everything is done loading?
    </p>
  </>
);
IndeterminateProgressIndicatorExample.decorators = [
  (IndeterminateProgressIndicatorStory: Story) => (
    <Documentation
      name="Indeterminate Progress Indicator Example"
      description="Progress indicators can be determinate or indeterminate, where determinate shows users the loading progress such as with percentages. This component is indeterminate.
      They appear on the screen to improve the waiting experience and to let users know something is happening such as data being retrieved. They disappear when the system process is completed."
      whenToUse={whenToUse}
    >
      <IndeterminateProgressIndicatorStory />
    </Documentation>
  ),
];
IndeterminateProgressIndicatorExample.argTypes = {
  size: {
    control: dropdownFromEnum(IndeterminateProgressIndicatorSize),
    defaultValue: IndeterminateProgressIndicatorSize.large,
  },
};
