import classNames from 'classnames';
import './indeterminate-progress-indicator.scss';
import { defaultTracking, track, Trackable } from '../../../analytics';
import { useEffect, useState } from 'react';
import { WithId } from '../../../with-id';

export interface IIndeterminateProgressIndicatorProps extends WithId, Trackable {
  title?: string;
  description?: string;
  size?: IndeterminateProgressIndicatorSize;
}

export enum IndeterminateProgressIndicatorSize {
  small = 'small',
  medium = 'medium',
  large = 'large',
}

export const IndeterminateProgressIndicatorSizeMap = {
  small: 24,
  medium: 40,
  large: 64,
};
const indeterminateprogressindicatorTitleBySize = (title: string, size: IndeterminateProgressIndicatorSize) => {
  const indeterminateProgressIndicatorTitleMap = {
    small: `${title}...`,
    medium: <h3>{`${title}...`}</h3>,
    large: <h2>{`${title}...`}</h2>,
  };
  return indeterminateProgressIndicatorTitleMap[size];
};

export const IndeterminateProgressIndicator = ({
  title = 'Loading',
  description,
  size = IndeterminateProgressIndicatorSize.large,
  id,
  tracking,
}: IIndeterminateProgressIndicatorProps) => {
  const [loadTime] = useState(new Date().getTime());

  useEffect(() => {
    return function afterUnload() {
      const currentTimeStamp = new Date().getTime();
      const trackingInfo = defaultTracking(tracking, {
        grouping: 'Progress Indication',
        action: `Show ${title} Indeterminate Progress Indicator`,
        trackingKey: `IndeterminateProgressIndicator-${id}`,
        value: `${currentTimeStamp - loadTime}`,
      });
      track(trackingInfo);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const indeterminateprogressindicatorContainerClasses = classNames('indeterminate-progress-indicator-container', {
    small: size === IndeterminateProgressIndicatorSize.small,
    medium: size === IndeterminateProgressIndicatorSize.medium,
    large: size === IndeterminateProgressIndicatorSize.large,
  });
  const indeterminateprogressindicatorTitle = indeterminateprogressindicatorTitleBySize(title, size);
  const indeterminateprogressindicatorSize = IndeterminateProgressIndicatorSizeMap[size];
  const indeterminateprogressindicatorCircleOrigin = IndeterminateProgressIndicatorSizeMap[size] / 2;

  return (
    <div
      id={`indeterminate-progress-indicator-${id}`}
      aria-live="assertive"
      title={title}
      className={indeterminateprogressindicatorContainerClasses}
    >
      <svg
        viewBox={`0 0 ${indeterminateprogressindicatorSize} ${indeterminateprogressindicatorSize} `}
        className="indeterminate-progress-indicator-sprite"
      >
        <title>{title}</title>
        <circle
          cx={`${indeterminateprogressindicatorCircleOrigin}`}
          cy={`${indeterminateprogressindicatorCircleOrigin}`}
          r={`${indeterminateprogressindicatorCircleOrigin - 4}`}
          className="outer-circle"
        />
        <circle
          cx={`${indeterminateprogressindicatorCircleOrigin}`}
          cy={`${indeterminateprogressindicatorCircleOrigin}`}
          r={`${indeterminateprogressindicatorCircleOrigin - 4}`}
          className="inner-circle"
        />
      </svg>
      <div className="indeterminate-progress-indicator-title">{indeterminateprogressindicatorTitle}</div>
      {size === IndeterminateProgressIndicatorSize.large && (
        <div className="indeterminate-progress-indicator-description">{description}</div>
      )}
    </div>
  );
};
