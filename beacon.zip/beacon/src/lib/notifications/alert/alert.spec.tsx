import React from 'react';
import { render, screen } from '@testing-library/react';
import { Alert, AlertVariant } from './alert';
import { Action, Dismissable } from './alert.stories';

describe('Alert', () => {
  it('renders info alert correctly', () => {
    const { baseElement } = render(<Alert>This is an information alert</Alert>);

    expect(baseElement).toMatchSnapshot();
  });

  it('renders success alert correctly', () => {
    const { baseElement } = render(<Alert variant={AlertVariant.success}>This is a success alert</Alert>);

    expect(baseElement).toMatchSnapshot();
  });

  it('renders warning alert correctly', () => {
    const { baseElement } = render(<Alert variant={AlertVariant.warning}>This is an warning alert</Alert>);

    expect(baseElement).toMatchSnapshot();
  });

  it('renders error alert correctly', () => {
    const { baseElement } = render(<Alert variant={AlertVariant.error}>This is an error alert</Alert>);

    expect(baseElement).toMatchSnapshot();
  });

  it('renders suggestion alert correctly', () => {
    const { baseElement } = render(<Alert variant={AlertVariant.suggestion}>This is a suggestion alert</Alert>);

    expect(baseElement).toMatchSnapshot();
  });

  it('renders alert correctly with optional title', () => {
    const { baseElement } = render(
      <Alert variant={AlertVariant.success} title="This is an optional title">
        This is a suggestion alert
      </Alert>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders alert with an action', () => {
    const { baseElement } = render(<Action>This is an information alert</Action>);

    expect(baseElement).toMatchSnapshot();
  });

  it('is focusable', () => {
    const { baseElement } = render(<Alert>This is an information alert</Alert>);
    const rootElement = baseElement.querySelector<HTMLElement>('.alert');
    rootElement.focus();

    expect(document.activeElement).toEqual(rootElement);
  });

  it('focuses on render', () => {
    const { container } = render(<Alert>This is an information alert</Alert>);

    const rootElement = container.querySelector<HTMLElement>('.alert');

    expect(document.activeElement).toBe(rootElement);
  });

  it('is not focused on render', () => {
    const { container } = render(<Alert skipFocus={true}>This is an information alert</Alert>);

    const rootElement = container.querySelector<HTMLElement>('.alert');

    expect(document.activeElement).not.toBe(rootElement);
  });

  it('renders close/dismiss button', () => {
    render(<Dismissable />);

    const closeButton = screen.getByTitle('Close');

    expect(closeButton).toBeDefined();
  });

  it('should not show dismiss button and logs a warning if withCloseButton is used without providing an onClose handler', () => {
    const consoleWarnSpy = jest.spyOn(console, 'warn').mockImplementation();
    render(<Alert withCloseButton>This is an information alert</Alert>);

    const closeButton = screen.queryByTitle('Close');

    expect(closeButton).toBeNull();
    expect(consoleWarnSpy).toBeCalledWith(
      'The "withCloseButton" prop must be used together with "onClose", but an "onClose" handler was not provided'
    );
  });

  it('should not show custom action button and logs a warning if "withActionButton" is used without providing an both an "actionButtonLabel" and "onActionClick" handler props', () => {
    const consoleWarnSpy = jest.spyOn(console, 'warn').mockImplementation();
    render(<Alert withActionButton>This is an information alert</Alert>);

    const actionButton = screen.queryByRole('button');

    expect(actionButton).toBeNull();
    expect(consoleWarnSpy).toBeCalledWith(
      'The "withActionButton" prop must be used in conjuction with "actionButtonLabel" and "onActionClick" props, but all three were not provided together'
    );
  });
});
