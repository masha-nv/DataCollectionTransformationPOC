import React, { SyntheticEvent } from 'react';
import { Alert, AlertVariant } from './alert';
import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';

export default {
  component: Alert,
  title: 'Core Components/AI Suggestions/AI Suggestion Butterbar',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
  },
} as Meta;

const whenToUse = (
  <>
    AI Suggestion Butterbar should be used anytime ELIS is using AI or machine learning to make suggestions to users.
    The AI Suggestion Butterbar serves as a way to describe the content related to AI/ML suggestions within a larger
    text paragraph
  </>
);

const languageGuidelines = (
  <ul>
    <li>AI Suggestion Butterbar should only be used to describe content related to within AI/ML suggestions.</li>
    <li>An AI Suggestion Icon should be included in the Butterbar to give context to the description.</li>
  </ul>
);

export const AISuggestionButterbar: Story = () => {
  const actionClickHandler = (e?: SyntheticEvent): void => {
    alert('An action has been triggered');
  };

  return (
    <Alert
      variant={AlertVariant.suggestion}
      withActionButton
      actionButtonLabel="Learn More"
      onActionClick={actionClickHandler}
    >
      The subjects highlighted below have been detected by ELIS
    </Alert>
  );
};
AISuggestionButterbar.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="AI Suggestion Butterbar"
      description="An alert indicate that something on the page has been AI suggested."
      whenToUse={whenToUse}
      languageGuidelines={languageGuidelines}
    >
      <ComponentStory />
    </Documentation>
  ),
];
