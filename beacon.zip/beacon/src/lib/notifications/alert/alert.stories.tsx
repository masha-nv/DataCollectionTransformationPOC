import React, { SyntheticEvent, useState } from 'react';
import { Alert, AlertVariant } from './alert';
import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../../stories';
import { Button, ButtonType } from '../../button/button';
import { a11yConfig } from '../../stories/story.config';

export default {
  component: Alert,
  title: 'Core Components/Notifications/Alerts',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
  },
} as Meta;

const whenToUse = (
  <>
    <p>When there is more than one butterbar alert, the sequence from first to last should be:</p>
    <ol>
      <li>Error Alert</li>
      <li>Warning Alert</li>
      <li>Info Alert</li>
      <li>Success Alert</li>
    </ol>
  </>
);

const accessibilityConsiderations = (
  <div>
    <p>
      When using alerts that show up dynamically after an action or request (i.e. not on page load), then they need to
      inside container element with `role="alert"` so that screen readers announce them as the show up or disappear.
    </p>
  </div>
);

export const ErrorAlert: Story = () => {
  return <Alert variant={AlertVariant.error}>This is an alert</Alert>;
};
ErrorAlert.storyName = 'Error Alert';
ErrorAlert.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Error Alert"
      description={
        <p>
          <span className="text-danger">error alert</span> - An error alert is displayed to indicate that the action the
          user attempted has not been completed successfully.The type of an alert can be specified with the{' '}
          <code>type</code> property.
        </p>
      }
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const InformationAlert: Story = () => {
  return <Alert variant={AlertVariant.info}>This is an information alert</Alert>;
};
InformationAlert.storyName = 'Information Alert';
InformationAlert.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Information Alert"
      description={
        <p>
          <span className="text-info">information alert</span> - an information alert is used to display information
          that is useful, but not time-sensitive or work-blocking.The type of an alert can be specified with the{' '}
          <code>type</code> property.
        </p>
      }
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const SuccessAlert: Story = () => {
  return <Alert variant={AlertVariant.success}>This is an success alert</Alert>;
};
SuccessAlert.storyName = 'Success Alert';
SuccessAlert.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Success Alert"
      description={
        <p>
          <span className="text-success">success alert</span> - A success alert is displayed to indicate that the action
          taken by a user was completed successfully.The type of an alert can be specified with the <code>type</code>{' '}
          property.
        </p>
      }
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const WarningAlert: Story = () => {
  return <Alert variant={AlertVariant.warning}>This is an warning alert</Alert>;
};
WarningAlert.storyName = 'Warning Alert';
WarningAlert.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Warning Alert"
      description={
        <p>
          <span className="text-warning">warning alert</span> - A warning alert is used to notify users of information
          that is high priority. These alerts can be displayed both after a user has taken an action, or without a user
          taking an action. (For example, they can be displayed on page load.) The type of an alert can be specified
          with the <code>type</code> property.
        </p>
      }
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const Action: Story = () => {
  const actionClickHandler = (e?: SyntheticEvent): void => {
    alert('An action has been triggered');
  };

  return (
    <Alert
      variant={AlertVariant.info}
      withActionButton
      actionButtonLabel="Perform action"
      onActionClick={actionClickHandler}
    >
      This is an alert
    </Alert>
  );
};
Action.storyName = 'Alerts with Action Links';
Action.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Alerts with Action"
      description={
        <>
          <p>
            Sometimes, alerts are directly related to action. Use the following properties to include a custom action:
          </p>
          <ul>
            <li>
              <code>withActionButton</code>
            </li>
            <li>
              <code>actionButtonLabel</code>
            </li>
            <li>
              <code>onActionClick</code>
            </li>
          </ul>
        </>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const Dismissable: Story = () => {
  const [alertVisible, setAlertVisible] = useState(true);

  const showAlert = () => {
    setAlertVisible(true);
  };

  const dismissAlert = () => {
    setAlertVisible(false);
  };

  return (
    <div>
      <div className="mb-2">
        <Button id="show-alert-btn" type={ButtonType.primary} disabled={alertVisible} onClick={showAlert}>
          Reveal Alerts
        </Button>
      </div>

      {alertVisible && (
        <Alert
          variant={AlertVariant.warning}
          withCloseButton
          onClose={dismissAlert}
          onActionClick={() => alert('Action taken!')}
        >
          This is an alert. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an
          unknown printer took a galley of type and scrambled it.
        </Alert>
      )}
    </div>
  );
};
Dismissable.storyName = 'Dismissible Alerts';
Dismissable.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Dismissable Alerts"
      description={
        <p>
          There are not any built in properties to make alerts dismissable. However, they can still be made dismissable
          by conditional rendering them and adding action button via the <code>action</code> property that shows/hides
          them.
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const SuccessAlertOnDark: Story = () => {
  const actionClickHandler = (): void => {
    alert('An action has been triggered');
  };

  return (
    <Alert variant={AlertVariant.success} actionButtonLabel="Perform action" onActionClick={actionClickHandler}>
      This is an success alert
    </Alert>
  );
};
SuccessAlertOnDark.storyName = 'Success Alert on Dark';
SuccessAlertOnDark.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Success Alert on Dark"
      description={
        <p>
          <span className="text-success">success alert</span> - A success alert is displayed to indicate that the action
          taken by a user was completed successfully.The type of an alert can be specified with the <code>type</code>{' '}
          property.
        </p>
      }
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      darkMode={true}
    >
      <ComponentStory />
    </Documentation>
  ),
];
