import React from 'react';
import { render } from '@testing-library/react';
import { Bubble, BubbleType } from './bubble';

describe('Bubble', () => {
  it('renders default bubble', () => {
    const { getByText } = render(<Bubble type={BubbleType.default} children={6}></Bubble>);
    const bubble = getByText('6');
    expect(bubble).toBeDefined();
  });

  it('renders default bubble, value is default to 0', () => {
    const { getByText } = render(<Bubble type={BubbleType.default}></Bubble>);
    const bubble = getByText('0');
    expect(bubble).toBeDefined();
  });

  it('renders default bubble, active state', () => {
    const { getByText } = render(<Bubble type={BubbleType.default} children={6} isActive={true}></Bubble>);
    const bubble = getByText('6');
    const activeState = bubble.getAttribute('class');
    expect(bubble).toBeDefined();
    expect(activeState).toContain('bubble-counter-active');
  });

  it('renders success bubble', () => {
    const { baseElement } = render(<Bubble type={BubbleType.success}></Bubble>);
    const activeState = baseElement.getElementsByClassName('bubble-counter-success');
    expect(activeState).toBeDefined();
  });

  it('renders success bubble, the value should remain 0', () => {
    const { queryByText } = render(<Bubble type={BubbleType.success} children={99999}></Bubble>);
    const bubble = queryByText('99999');
    expect(bubble).toBeNull();
  });

  it('renders success bubble, active state', () => {
    const { baseElement } = render(<Bubble type={BubbleType.success} isActive={true}></Bubble>);
    const activeState = baseElement.getElementsByClassName('bubble-counter-active');
    expect(activeState).toBeDefined();
  });

  it('renders primary bubble', () => {
    const { baseElement } = render(<Bubble type={BubbleType.success}></Bubble>);
    const activeState = baseElement.getElementsByClassName('label-primary');
    expect(activeState).toBeDefined();
  });

  it('renders error bubble', () => {
    const { baseElement } = render(<Bubble type={BubbleType.success}></Bubble>);
    const activeState = baseElement.getElementsByClassName('label-error');
    expect(activeState).toBeDefined();
  });
});
