import React from 'react';
import { Bubble, BubbleType, IBubbleProps } from './bubble';
import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge, dropdownFromEnum } from '../../stories';
import { a11yConfig } from '../../stories/story.config';

export default {
  component: Bubble,
  title: 'Core Components/Notifications/Count Bubble',
  parameters: {
    a11y: a11yConfig,
    badges: [StoryBadge.READY],
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const whenToUse = (
  <p>
    Count bubbles can be used to show the number of unread elements, unfinished tasks, or any other numeric information
    in a very simple way that can conveniently remind users.
  </p>
);

const bubbleTypes = (
  <>
    <h3>Default Count Bubbles</h3>
    <h4>Default State</h4>
    <p>Bubble component asks for an optional attribute "value"(number), which is displayed in the bubble.</p>
    <Bubble type={BubbleType.default} children={6}></Bubble>
    <br></br>
    <hr />

    <h4>Focus/Active State</h4>
    <p>
      Bubble component asks for an optional attribute "isActive". If true, the bubble is displayed with alternative
      version.
    </p>
    <Bubble type={BubbleType.default} children={6} isActive={true}></Bubble>
    <br></br>
    <hr />

    <h3>All Tasks/Hits Complete Count Bubble</h3>
    <h4>Default State</h4>
    <p>Bubble component asks for an optional attribute "value"(number) is set to 0 if the bubble type is 'success'.</p>
    <Bubble type={BubbleType.success}></Bubble>
    <br></br>
    <hr />

    <h4>Focus/Active State</h4>
    <p>
      Bubble component asks for an optional attribute "isActive". If true, the bubble is displayed with alternative
      version.
    </p>
    <Bubble type={BubbleType.success} isActive={true}></Bubble>
    <br></br>
    <hr />

    <h4>Deprecated Bubble Types</h4>
    <p>"Primary", "Error", Bubble type that exists in ELIS, and will be removed in the future.</p>
    <Bubble type={BubbleType.primary}></Bubble>
    <br></br>
    <Bubble type={BubbleType.error}></Bubble>
    <br></br>
    <hr />
  </>
);

export const BasicExample: Story<IBubbleProps> = () => {
  return bubbleTypes;
};
BasicExample.storyName = 'Count Bubble';
BasicExample.decorators = [
  (Story: Story) => (
    <Documentation
      name="Basic Example"
      whenToUse={whenToUse}
      description="Bubble are used to display the number of outstanding tasks."
    >
      <Story />
    </Documentation>
  ),
];

BasicExample.args = {
  type: BubbleType.default,
};

BasicExample.argTypes = {
  children: {
    control: false,
  },
  type: {
    control: dropdownFromEnum(BubbleType),
  },
};
