import React, { ReactNode } from 'react';
import './bubble.scss';
import classNames from 'classnames';

export interface IBubbleProps {
  /**
   * Bubble type from `BubbleType`
   */
  type: BubbleType;

  /**
   * The content of this bubble, if `BubbleType` is success, this value is defaulted to 0
   */
  children?: ReactNode;

  /**
   * Determine active/focus state on the parent Tab
   */
  isActive?: boolean;
}

/**
 * Load values from `BubbleType`
 */
export enum BubbleType {
  default = 'default',
  success = 'success',
  /**
   * Avoid using these `BubbleType`, they are being deprecated
   */
  primary = 'primary',
  error = 'error',
}

/**
 * Count bubbles are used to indicate how many active items require attention or have been selected.
 */
export const Bubble = ({ type, children, isActive }: IBubbleProps) => {
  if (!children) {
    children = 0;
  }
  if (type === BubbleType.success) {
    children = 0;
  }
  const bubbleClassNames = classNames(
    {
      'label-primary bubble-counter-default': type === BubbleType.default,
      'label-success bubble-counter-success': type === BubbleType.success,
      /**
       * Avoid using these `BubbleType`, they are being deprecated
       */
      'label-primary': type === BubbleType.primary,
      'label-error': type === BubbleType.error,
    },
    'label label-count-bubble',
    { 'bubble-counter-active': isActive }
  );
  return (
    <span className={bubbleClassNames}>
      {type === BubbleType.success ? (
        <i className="fa-sharp fa-solid fa-check fas bubble-counter-success-check"></i>
      ) : (
        children
      )}
    </span>
  );
};
