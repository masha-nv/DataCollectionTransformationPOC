import React, { ReactNode } from 'react';
import { Heading, HeadingType } from '../../heading/heading';
import './confirmation.scss';

export interface IConfirmationProps {
  /**
   * The content of this alert
   */
  children?: ReactNode;

  /**
   * The footer part of the alert (appears on the bottom).  This is where the actions will be like _links_ and _buttons_.
   */
  footer?: ReactNode;

  /**
   * Styles the title of this alert with an icon corresponding to the alert type
   */
  type?: ConfirmationType;

  /**
   * This will be the page title that was display at the top of the page-level alert.
   */
  title: string;
  /**
   * The type of heading used for the title.
   */
  headingType?: HeadingType;
}

export enum ConfirmationType {
  info = 'info',
  success = 'success',
  warning = 'warning',
  error = 'error',
}

const ConfirmationAlertCSS = {
  [ConfirmationType.info]: 'fa-info-circle',
  [ConfirmationType.success]: 'fa-check-circle',
  [ConfirmationType.warning]: 'fa-exclamation-triangle',
  [ConfirmationType.error]: 'fa-exclamation-circle',
};

/**
 * Confirmation pages provide users with confirmation that a task was completed, with space for additional information.
 */
export const Confirmation = ({
  type = ConfirmationType.success,
  title,
  children,
  footer,
  headingType,
}: IConfirmationProps) => {
  return (
    <div className={`page-level-alert page-level-alert-${type}`} aria-live="assertive">
      <div className="page-level-alert-title">
        <i className={`fas ${ConfirmationAlertCSS[type]}`} aria-hidden="true"></i>
        <div>
          <Heading headingType={headingType ? headingType : 'h2'}>{title}</Heading>
        </div>
      </div>
      <div className="page-level-alert-body-wrapper">
        {children && <div className="page-level-alert-body">{children}</div>}
        {footer && <div className="page-level-alert-actions">{footer}</div>}
      </div>
    </div>
  );
};
