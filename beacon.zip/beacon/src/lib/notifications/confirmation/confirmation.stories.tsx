import React from 'react';
import { Meta, Story } from '@storybook/react';
import { Confirmation, ConfirmationType, IConfirmationProps } from './confirmation';
import { Documentation, StoryBadge, dropdownFromEnum, dropdownFromHeadingTypes } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { Button } from '../../button/button';
import { noop } from '../../utils';
import { HeadingType } from '../../heading/heading';

export default {
  component: Confirmation,
  title: 'Core Components/Notifications/Confirmation Pages',
  parameters: {
    a11y: a11yConfig,
    badges: [StoryBadge.READY],
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const whenToUse = (
  <p>
    Confirmation pages are used to communicate that users successfully completed a task, particularly if the task is
    multi-step and when there is more information to communicate. For example, in addition to the success message, the
    confirmation page can also include a summary of the action users took (for example, “100 of 1,000 cases were
    transferred”) and should include a button or other call to action for any next step, or instructions on what users
    can do.
  </p>
);

const argTypes = {
  type: {
    control: dropdownFromEnum(ConfirmationType),
  },
  children: {
    control: false,
  },
  footer: {
    control: false,
  },
  headingType: {
    control: dropdownFromHeadingTypes(),
    defaultValue: 'h2',
  },
};

const footer = (
  <Button id="btn-action" onClick={noop}>
    Button for next action
  </Button>
);

const body = (title: string, type: ConfirmationType | undefined, headingType: HeadingType | undefined) => (
  <Confirmation title={title} type={type} footer={footer} headingType={headingType}>
    <p>This is a {title} page</p>
  </Confirmation>
);

export const ErrorConfirmationPage: Story<IConfirmationProps> = ({ type, title, headingType }: IConfirmationProps) => {
  return body(title, type, headingType);
};

ErrorConfirmationPage.decorators = [
  (ComponentStory: Story) => (
    <Documentation name="Error Confirmation Page" whenToUse={whenToUse}>
      <ComponentStory />
    </Documentation>
  ),
];

ErrorConfirmationPage.args = {
  type: ConfirmationType.error,
  title: 'Error Confirmation',
};

ErrorConfirmationPage.argTypes = argTypes;

export const InformationConfirmationPage: Story<IConfirmationProps> = ({
  type,
  title,
  headingType,
}: IConfirmationProps) => {
  return body(title, type, headingType);
};

InformationConfirmationPage.decorators = [
  (ComponentStory: Story) => (
    <Documentation name="Information Confirmation Page" whenToUse={whenToUse}>
      <ComponentStory />
    </Documentation>
  ),
];
InformationConfirmationPage.args = {
  type: ConfirmationType.info,
  title: 'Information Confirmation',
};

InformationConfirmationPage.argTypes = argTypes;
export const SuccessConfirmationPage: Story<IConfirmationProps> = ({
  type,
  title,
  headingType,
}: IConfirmationProps) => {
  return body(title, type, headingType);
};
SuccessConfirmationPage.decorators = [
  (ComponentStory: Story) => (
    <Documentation name="Success Confirmation Page" whenToUse={whenToUse}>
      <ComponentStory />
    </Documentation>
  ),
];
SuccessConfirmationPage.args = {
  type: ConfirmationType.success,
  title: 'Success Confirmation',
};

SuccessConfirmationPage.argTypes = argTypes;
export const WarningConfirmationPage: Story<IConfirmationProps> = ({
  type,
  title,
  headingType,
}: IConfirmationProps) => {
  return body(title, type, headingType);
};

WarningConfirmationPage.decorators = [
  (ComponentStory: Story) => (
    <Documentation name="Warning Confirmation Page" whenToUse={whenToUse}>
      <ComponentStory />
    </Documentation>
  ),
];
WarningConfirmationPage.args = {
  type: ConfirmationType.warning,
  title: 'Warning Confirmation',
};

InformationConfirmationPage.argTypes = argTypes;
