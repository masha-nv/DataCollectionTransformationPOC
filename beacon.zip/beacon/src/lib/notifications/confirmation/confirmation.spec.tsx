import React from 'react';
import { Confirmation, ConfirmationType } from './confirmation';
import { render } from '@testing-library/react';

describe('Confirmation', () => {
  it('renders default Confirmation', () => {
    const { baseElement } = render(<Confirmation title="sweet">corn</Confirmation>);

    expect(baseElement).toMatchSnapshot();
  });

  it('renders info Confirmation', () => {
    const { baseElement } = render(
      <Confirmation title="sweet" type={ConfirmationType.info}>
        corn
      </Confirmation>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders warning Confirmation', () => {
    const { baseElement } = render(
      <Confirmation title="sweet" type={ConfirmationType.warning}>
        corn
      </Confirmation>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders error Confirmation', () => {
    const { baseElement } = render(
      <Confirmation title="sweet" type={ConfirmationType.error}>
        corn
      </Confirmation>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders Confirmation with footer', () => {
    const footer = <div>amazing taste</div>;
    const { baseElement } = render(
      <Confirmation title="sweet" type={ConfirmationType.info} footer={footer}>
        corn
      </Confirmation>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders empty Confirmation', () => {
    const { baseElement } = render(<Confirmation title="empty" />);

    expect(baseElement).toMatchSnapshot();
  });

  it('renders with customized heading', () => {
    const { baseElement } = render(
      <Confirmation title="sweet" type={ConfirmationType.info} headingType="h1">
        corn
      </Confirmation>
    );

    expect(baseElement).toMatchSnapshot();
  });
});
