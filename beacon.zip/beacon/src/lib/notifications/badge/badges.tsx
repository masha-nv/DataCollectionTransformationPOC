import React from 'react';
import { Badge, BadgeVariant } from './badge';

export const Badges = {
  WARNING: () => (
    <Badge id="warning-badge" variant={BadgeVariant.warning}>
      Warning
    </Badge>
  ),
  SUCCESS: () => (
    <Badge id="success-badge" variant={BadgeVariant.success}>
      Success
    </Badge>
  ),
  INFO: () => (
    <Badge id="info-badge" variant={BadgeVariant.info}>
      Info
    </Badge>
  ),
  ERROR: () => (
    <Badge id="error-badge" variant={BadgeVariant.error}>
      Error
    </Badge>
  ),
  UPDATED: () => (
    <Badge id="updated-badge" showIcon={false} variant={BadgeVariant.warning}>
      Updated
    </Badge>
  ),
  ADDED: () => (
    <Badge id="added-badge" showIcon={false} variant={BadgeVariant.warning}>
      Added
    </Badge>
  ),
  SUGGESTION: () => (
    <Badge id="suggestion-badge" variant={BadgeVariant.suggestion}>
      Suggested by ELIS
    </Badge>
  ),
};
