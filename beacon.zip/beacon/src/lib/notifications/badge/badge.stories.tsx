import { Meta, Story } from '@storybook/react';
import React from 'react';
import { Documentation, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { Badge, BadgeVariant } from './badge';
import { Badges } from './badges';

export default {
  component: Badge,
  title: 'Core Components/Notifications/Badges',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
  },
} as Meta;

const whenToUse = (
  <p>
    A badge is used contextually near a specific piece of data. For example, a warning badge could appear next to the
    name of a person protected under VAWA, with tooltip text that warns the officer not to disclose the information.
  </p>
);
const accessibilityConsiderations = (
  <div>
    <p>
      Add ariaLabel and contextualHelp attributes to <strong>Badge</strong> components to allow accessibility
    </p>
  </div>
);
export const ErrorBadge: Story = () => {
  return (
    <>
      <p>Error Badge with icons</p>
      <div className="mb-3">
        <Badge id="error-badge-1" variant={BadgeVariant.error}>
          Error
        </Badge>
      </div>
      <p>Error Badge without icons</p>
      <div className="mb-3">
        <Badge id="error-badge-2" variant={BadgeVariant.error} showIcon={false}>
          Error
        </Badge>
      </div>
      <p>
        Predefined Error Badge in <code>Badges</code>
      </p>
      <div>
        <Badges.ERROR />
      </div>
    </>
  );
};

ErrorBadge.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Error Badge"
      description="Badges are used contextually next to a piece of data, such as in a table, to alert users to important information."
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const InformationBadge: Story = () => {
  return (
    <>
      <p>Information Badge with icons</p>
      <div className="mb-3">
        <Badge id="info-badge-1" variant={BadgeVariant.info}>
          Information
        </Badge>
      </div>
      <p>Information Badge without icons</p>
      <div className="mb-3">
        <Badge id="info-badge-2" variant={BadgeVariant.info} showIcon={false}>
          Information
        </Badge>
      </div>
      <p>
        Predefined Information Badge in <code>Badges</code>
      </p>
      <div>
        <Badges.INFO />
      </div>
    </>
  );
};
InformationBadge.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Information Badge"
      description="Badges are used contextually next to a piece of data, such as in a table, to alert users to important information."
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const SuccessBadge: Story = () => {
  return (
    <>
      <p>Success Badge with icons</p>
      <div className="mb-3">
        <Badge id="success-badge-1" variant={BadgeVariant.success}>
          Success
        </Badge>
      </div>
      <p>SuccessBadge without icons</p>
      <div className="mb-3">
        <Badge id="success-badge-2" variant={BadgeVariant.success} showIcon={false}>
          Success
        </Badge>
      </div>
      <p>
        Predefined Success Badge in <code>Badges</code>
      </p>
      <div>
        <Badges.SUCCESS />
      </div>
    </>
  );
};

SuccessBadge.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Success Badge"
      description="Badges are used contextually next to a piece of data, such as in a table, to alert users to important information."
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const WarningBadge: Story = () => {
  return (
    <>
      <p>Warning Badge with icons</p>
      <div className="mb-3">
        <Badge id="warning-badge-1" variant={BadgeVariant.warning}>
          Warning
        </Badge>
      </div>
      <p>Warning Badge without icons</p>
      <div className="mb-3">
        <Badge id="warning-badge-2" variant={BadgeVariant.warning} showIcon={false}>
          Warning
        </Badge>
      </div>
      <p>
        Predefined Warning Badge in <code>Badges</code>
      </p>
      <div>
        <Badges.WARNING />
      </div>
    </>
  );
};
WarningBadge.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Warning Badge"
      description="Badges are used contextually next to a piece of data, such as in a table, to alert users to important information."
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const CustomAriaLabels: Story = () => {
  return (
    <div>
      <Badge id="custom-label-badge-1" variant={BadgeVariant.default} ariaLabel="custom aria-label">
        Badge with custom aria-label
      </Badge>
    </div>
  );
};
CustomAriaLabels.storyName = 'Badges with Custom Aria Labels';
CustomAriaLabels.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Badges With Custom Aria Label"
      description="Badges with user-specified ariaLabel attribute."
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const CustomColorBadges: Story = () => {
  return (
    <div>
      <Badge id="custom-color-badge-1" variant={BadgeVariant.custom} badgeColor="blue">
        Blue badge with circle icon
      </Badge>
      <Badge id="custom-color-badge-2" variant={BadgeVariant.custom} badgeColor="blue" showIcon={false}>
        Blue badge with no icon
      </Badge>
    </div>
  );
};
CustomColorBadges.storyName = 'Badges with Custom Colors';
CustomColorBadges.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Badges With Custom Colors"
      description="Badges with user-specified border and icon color."
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const CustomContextualHelp: Story = () => {
  return (
    <Badge id="contextual-help-badge-1" variant={BadgeVariant.default} contextualHelp="Custom Contextual Help">
      Badge with custom contextual help
    </Badge>
  );
};
CustomContextualHelp.storyName = 'Badges with Custom Contextual Help';
CustomContextualHelp.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Badges With Custom Contextual Help"
      description="Badges with user-specified contextualHelp attribute."
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const IconsAndTooltips: Story = () => {
  return (
    <div>
      <Badge id="icon-badge-1" variant={BadgeVariant.default}>
        Default Badge
      </Badge>
      <Badge id="icon-badge-2" variant={BadgeVariant.default} showIcon={false}>
        No Icon
      </Badge>
    </div>
  );
};
IconsAndTooltips.storyName = 'Badges with Icons';
IconsAndTooltips.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Badges With Icons"
      description="Badges without any specified type."
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const Focusable: Story = () => {
  return (
    <div>
      <Badge id="focusable-badge-1" variant={BadgeVariant.default}>
        Badge that is focusable
      </Badge>
      <Badge id="focusable-badge-2" variant={BadgeVariant.default} focusable={false}>
        Badge that is not focusable
      </Badge>
    </div>
  );
};
Focusable.storyName = 'Focusable Badges';
Focusable.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Badge Focus Control"
      description="Badges with user-specified ability to focus on the element."
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const Spaceless: Story = () => {
  return (
    <div className="border-left">
      <div className="mb-3">
        <Badge id="spaced-badge" variant={BadgeVariant.info}>
          Badge that is offset
        </Badge>
      </div>
      <div className="mb-3">
        <Badge id="spaceless-badge" variant={BadgeVariant.info} noSpacing>
          Badge that is not offset
        </Badge>
      </div>
    </div>
  );
};
Spaceless.storyName = 'non-offset Badges';
Spaceless.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Badge Spacing"
      description="Badges that can be put at the start of a line."
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
