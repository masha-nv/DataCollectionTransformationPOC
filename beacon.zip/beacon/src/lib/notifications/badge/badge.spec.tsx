import React from 'react';
import { render } from '@testing-library/react';
import { Badge, BadgeVariant } from './badge';
import { Badges } from './badges';

describe('Badge Component', () => {
  it('renders default badge', () => {
    const { baseElement } = render(
      <Badge id="badge-test" variant={BadgeVariant.default}>
        Default
      </Badge>
    );

    expect(baseElement).toMatchSnapshot();
  });
  it('renders info badge', () => {
    const { baseElement } = render(
      <Badge id="badge-test" variant={BadgeVariant.info}>
        Info
      </Badge>
    );

    expect(baseElement).toMatchSnapshot();
  });
  it('renders success badge', () => {
    const { baseElement } = render(
      <Badge id="badge-test" variant={BadgeVariant.success}>
        Succeess
      </Badge>
    );

    expect(baseElement).toMatchSnapshot();
  });
  it('renders error badge', () => {
    const { baseElement } = render(
      <Badge id="badge-test" variant={BadgeVariant.error}>
        Error
      </Badge>
    );

    expect(baseElement).toMatchSnapshot();
  });
  it('renders custom badge', () => {
    const { baseElement } = render(
      <Badge id="badge-test" variant={BadgeVariant.custom}>
        Custom
      </Badge>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders suggestion badge', () => {
    const { baseElement } = render(
      <Badge id="badge-test" variant={BadgeVariant.suggestion}>
        Custom
      </Badge>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders custom badge with blue button', () => {
    const { baseElement } = render(
      <Badge id="badge-test" variant={BadgeVariant.custom} badgeColor="blue">
        Custom
      </Badge>
    );

    expect(baseElement).toMatchSnapshot();
  });
  it('renders custom badge with default color button', () => {
    const { baseElement } = render(
      <Badge id="badge-test" variant={BadgeVariant.custom} badgeColor="">
        Custom
      </Badge>
    );

    expect(baseElement).toMatchSnapshot();
  });
  it('renders custom badge with default color button and null badgeColor', () => {
    const { baseElement } = render(
      <Badge id="badge-test" variant={BadgeVariant.custom}>
        Custom
      </Badge>
    );

    expect(baseElement).toMatchSnapshot();
  });
  it('ignores badgeColor when badge type is set', () => {
    const { baseElement } = render(
      <Badge id="badge-test" variant={BadgeVariant.success} badgeColor="gray">
        Default
      </Badge>
    );

    expect(baseElement).toMatchSnapshot();
  });
  it('does not show icon with showIcon set to false', () => {
    const { baseElement } = render(
      <Badge id="badge-test" variant={BadgeVariant.success} showIcon={false}>
        Default
      </Badge>
    );

    expect(baseElement).toMatchSnapshot();
  });
  it('sets tab to -1 to be unfocusable', () => {
    const { baseElement } = render(
      <Badge id="badge-test" focusable={false}>
        Default
      </Badge>
    );

    expect(baseElement).toMatchSnapshot();
  });
  it('tests custom aria label setting', () => {
    const { baseElement } = render(
      <Badge id="badge-test" ariaLabel="This is a custom aria label">
        Default
      </Badge>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('tests no-spacing label setting', () => {
    const { baseElement } = render(
      <Badge id="badge-test" noSpacing>
        Default
      </Badge>
    );

    expect(baseElement).toMatchSnapshot();
  });
  it('tests custom contextualHelp setting', () => {
    const { baseElement } = render(
      <Badge id="badge-test" contextualHelp="This is a custom contextual helper">
        Default
      </Badge>
    );

    expect(baseElement).toMatchSnapshot();
  });
  it('renders badges', () => {
    const { baseElement } = render(
      <div>
        <Badges.INFO />
        <Badges.WARNING />
        <Badges.ERROR />
        <Badges.SUCCESS />
        <Badges.UPDATED />
        <Badges.ADDED />
        <Badges.SUGGESTION />
      </div>
    );

    expect(baseElement).toMatchSnapshot();
  });
});
