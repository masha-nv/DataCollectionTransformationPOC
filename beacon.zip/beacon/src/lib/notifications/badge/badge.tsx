import classNames from 'classnames';
import React, { ReactNode } from 'react';
import { Tooltip } from '../../modals/tooltip/tooltip';
import { WithId } from '../../with-id';
import './badge.scss';
import badgeStyle from './badge.module.scss';

export interface IBadgeProps extends WithId {
  /**
   * Variant of badge to render
   */
  variant?: BadgeVariant;
  /**
   * Controls visibility of icon
   */
  showIcon?: boolean;
  /**
   * Configure the ability to focus on this element. Default is set to be focusable
   */
  focusable?: boolean;
  /**
   * Color to show for badge when type = BadgeType.custom
   */
  badgeColor?: string;
  /**
   * Set the aria-label accesibily text of this element
   */
  ariaLabel?: string;
  /**
   * Set the title attribute of this element
   */
  contextualHelp?: string;

  /**
   * Removes the leading margin
   */
  noSpacing?: boolean;
  /**
   * The content of this badge
   */
  children: ReactNode;
}

export enum BadgeVariant {
  default = 'default',
  info = 'info',
  success = 'success',
  warning = 'warning',
  error = 'error',
  custom = 'custom',
  suggestion = 'suggestion',
}

const iconCSS = {
  [BadgeVariant.default]: 'fa-tag',
  [BadgeVariant.success]: 'fa-check-circle',
  [BadgeVariant.info]: 'fa-info-circle',
  [BadgeVariant.warning]: 'fa-exclamation-triangle',
  [BadgeVariant.error]: 'fa-exclamation-circle',
  [BadgeVariant.custom]: 'fa-circle',
  [BadgeVariant.suggestion]: 'fa-wand-magic-sparkles',
};
/**
 * Badge Component
 */
export const Badge = ({
  id,
  variant = BadgeVariant.default,
  showIcon = true,
  focusable = true,
  badgeColor,
  ariaLabel,
  contextualHelp,
  noSpacing = false,
  children,
}: IBadgeProps) => {
  const colorVal = () => {
    return variant === 'custom' && badgeColor && badgeColor.trim() !== '' ? badgeColor : '';
  };
  const borderStyle: React.CSSProperties = {
    borderColor: colorVal(),
  };
  const iconStyle: React.CSSProperties = {
    color: colorVal(),
  };

  const iconClasses = classNames(
    `fas ${iconCSS[variant]}`,
    { 'beacon-icon-suggestion': variant === 'suggestion' },
    'mr-1'
  );

  const spacingClass = noSpacing ? '' : badgeStyle['spaced-badge'];

  const icon = (
    <i className={iconClasses} style={iconStyle} aria-hidden="true">
      <span className="sr-only">{variant} badge</span>
    </i>
  );
  const badgeContent = (
    <span
      style={borderStyle}
      className={classNames('react-beacon-label', 'label', 'badge-label', `label-${variant}`, spacingClass, 'mr-1')}
      tabIndex={focusable ? 0 : -1}
      aria-label={ariaLabel}
      id={id}
    >
      {(showIcon || variant === 'suggestion') && icon}
      {children}
    </span>
  );

  if (contextualHelp != null) {
    return (
      <Tooltip id={`${id}-tooltip`} content={contextualHelp}>
        {badgeContent}
      </Tooltip>
    );
  } else {
    return badgeContent;
  }
};
