import { Meta, Story } from '@storybook/react';
import React from 'react';
import { Documentation, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { Badge, BadgeVariant } from './badge';

export default {
  component: Badge,
  title: 'Core Components/AI Suggestions',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
  },
} as Meta;

const whenToUse = (
  <p>
    The AI Suggestion Badge should be used anytime ELIS is using AI or machine learning to make suggestions to users.
    The badge should be placed contextually within any container that includes AI/ML suggested content.
  </p>
);
const accessibilityConsiderations = (
  <div>
    <p>Disable all motion if user has enabled prefers-reduced-motion in browser settings.</p>
  </div>
);

const languageGuidelines = (
  <div>
    <p>
      The tooltip text may be changed as needed to give context to various AI-assisted UI features. Badge content
      guidelines are the same as standard Beacon badges, with the following exceptions:
    </p>
    <ul>
      <li>
        An AI Suggestion Badge must be placed contextually within any container that includes AI/ML suggested content.
      </li>
      <li>The AI Suggestion Badge should only be used alongside content related to AI/ML suggestions or reviews.</li>
      <li>
        Consult with OCC to determine if the AI Suggestion Badge should remain attached to content after completion of
        manual user review.
      </li>
    </ul>
  </div>
);

export const AISuggestionBadge: Story = () => {
  const tooltip = 'This is a tag tooltip with information about why the alert is here.';
  return (
    <div>
      <Badge id="ai-suggestion-badge" variant={BadgeVariant.suggestion} contextualHelp={tooltip}>
        Suggested by ELIS
      </Badge>
    </div>
  );
};
AISuggestionBadge.storyName = 'AI Suggestion Badge';
AISuggestionBadge.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="AI Suggestion Badge"
      description="Badges which have been AI suggested."
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      languageGuidelines={languageGuidelines}
    >
      <ComponentStory />
    </Documentation>
  ),
];
