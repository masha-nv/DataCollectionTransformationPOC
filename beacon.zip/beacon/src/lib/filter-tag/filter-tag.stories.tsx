import React, { SyntheticEvent, useState } from 'react';
import { FilterTag } from './filter-tag';
import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../stories';
import { a11yConfig } from '../stories/story.config';
import { ButtonGroup, ButtonGroupDirection } from '../button/button-group';

export default {
  component: FilterTag,
  title: 'Core Components/Filter Tag',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
  },
} as Meta;

const description =
  'Filter tags let users know what criteria data results are based on and allows them to delete filter options.';
const whenToUse = (
  <p>
    A filter tag appears when a user selects a filter option. This could be from a checkbox, dropdown, or any form
    control for filtering search criteria.
  </p>
);
const accessibilityConsiderations = (
  <p>
    The component should be keyboard accessible and describe the content. The tab order goes from tag to tag. Clicking
    the tag will remove the tag.
  </p>
);

/**
 * Primary
 */
export const Primary: Story = () => {
  const [tags, setTags] = useState([
    { id: 'tag1', value: '1', label: 'Filter 1' },
    { id: 'tag2', value: '2', label: 'Filter 2' },
    { id: 'tag3', value: '3', label: 'Filter 3' },
  ]);

  const handleClick = (event: SyntheticEvent) => {
    const tagId = (event.target as HTMLElement).id;
    setTags(
      tags.filter((tag) => {
        return tag.id !== tagId;
      })
    );
  };

  return (
    <div>
      <ButtonGroup direction={ButtonGroupDirection.LEFT} wrap={true}>
        {tags.map((tag) => {
          return <FilterTag key={tag.id} id={tag.id} value={tag.value} label={tag.label} onClick={handleClick} />;
        })}
      </ButtonGroup>
    </div>
  );
};

Primary.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Filter Tag"
      description={description}
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
Primary.storyName = 'Filter Tag';

export const Disabled: Story = () => {
  return (
    <div>
      <ButtonGroup direction={ButtonGroupDirection.LEFT} wrap={true}>
        <FilterTag id="disabled-tag-1" value="1" label="Filter 1" disabled={true} />
      </ButtonGroup>
    </div>
  );
};

Disabled.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Disabled Filter Tag"
      description={description}
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
Disabled.storyName = 'Disabled Filter Tag';
