import { forwardRef, SyntheticEvent } from 'react';
import { WithId } from '../with-id';
import './filter-tag.scss';
import { defaultTracking, Trackable, TrackableEvent } from '../analytics';
import { Button, ButtonType } from '../button/button';
import { Icon, IconType } from '../icon/icon';

interface IFilterTagProps extends WithId, Trackable {
  /**
   * The string label to display in the tag
   */
  label: string;
  /**
   * The string value associated with the tag
   */
  value: string;
  /**
   * True if the tag is disabled
   */
  disabled?: boolean;
  /**
   * click event handler
   */
  onClick?: (event: SyntheticEvent) => void;
}

export const FilterTag = forwardRef<HTMLButtonElement, IFilterTagProps>(({ ...props }, ref) => {
  const onClickAction = (event: SyntheticEvent) => {
    event.stopPropagation();
    if (props.onClick) {
      props.onClick(event);
    }
  };

  const getTrackableChange = (trackingEvent: TrackableEvent | undefined, id: string, action: string) => {
    return defaultTracking(trackingEvent, {
      grouping: 'Ungrouped',
      action: action,
      trackingKey: `Filter-Tag-${id}`,
    });
  };

  const tracking = getTrackableChange(props.tracking, props.id, 'Filter Tag Deselected');

  return (
    <div className="filter-tag-container">
      <Button
        ref={ref}
        id={props.id}
        onClick={onClickAction}
        type={ButtonType.primary}
        tracking={tracking}
        disabled={props.disabled}
        label={`${props.label} - Select Enter to remove filter`}
      >
        <span>{props.label}</span> <Icon type={IconType.timesCircle}></Icon>
      </Button>
    </div>
  );
});
