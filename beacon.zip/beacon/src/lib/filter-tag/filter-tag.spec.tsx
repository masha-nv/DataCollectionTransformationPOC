import React from 'react';
import { render, screen } from '@testing-library/react';
import { FilterTag } from './filter-tag';

describe('Filter Tag', () => {
  let isClicked = false;
  const handleClick = () => {
    isClicked = true;
  };

  beforeEach(() => {
    isClicked = false;
  });

  it('renders default', () => {
    const { baseElement } = render(<FilterTag id="tag1" value="1" label="Tag 1" />);
    expect(baseElement).toMatchSnapshot();
  });

  it('does not handle onClick event', () => {
    render(<FilterTag id="tag1" value="1" label="Tag 1" />);
    const button = screen.getByText('Tag 1');
    button.click();

    expect(isClicked).toBe(false);
  });

  it('handles onClick event', () => {
    render(<FilterTag id="tag1" value="1" label="Tag 1" onClick={handleClick} />);
    const button = screen.getByText('Tag 1');
    button.click();

    expect(isClicked).toBe(true);
  });
});
