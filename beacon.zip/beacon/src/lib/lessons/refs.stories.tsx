import { yupResolver } from '@hookform/resolvers/yup';
import { Meta, Story } from '@storybook/react';
import React, { ForwardedRef, forwardRef, ReactNode, useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import * as yup from 'yup';
import { Button } from '../button/button';
import { SubmitButton } from '../button/submit-button';
import { FormGroup } from '../forms/form-group/form-group';
import { Form } from '../forms/form/form';
import { Radio } from '../forms/radio/radio';
import { RadioOption } from '../forms/radio/radio-option';
import { TextInput } from '../forms/text-input/text-input';
import { hookFormUtils } from '../forms/utils/hookform-utils';
import { Theme } from '../modals/modal-types';
import { Tooltip } from '../modals/tooltip/tooltip';
import { StoryBadge } from '../stories';
import { noop } from '../utils';

export default {
  title: 'Lessons/Refs',
  parameters: {
    badges: [StoryBadge.READY],
  },
} as Meta;

export const Refs: Story = () => {
  const textInputRef = useRef<HTMLInputElement>(null);

  return (
    <>
      <div className="mb-2">
        <Button id="focus-input-element" onClick={() => textInputRef.current?.focus()}>
          Focus Text Input
        </Button>
      </div>
      <TextInput ref={textInputRef} id="text-input-element" />
    </>
  );
};
Refs.storyName = 'Refs and the DOM';
Refs.decorators = [
  (Story: Story) => (
    <article className="beacon">
      <h2>Refs and the DOM</h2>
      <p>
        Refs are a React construct that provides a way to access DOM nodes (or HTML elements) for React elements (as
        opposed to querying the element via the document object or JQuery).
      </p>

      <p>In the following example, the button uses a ref to focus the corresponding text input.</p>

      <div className="mb-2">
        <Story />
      </div>

      <p>
        Refer to the <a href="https://reactjs.org/docs/refs-and-the-dom.html"> official React documentation</a> for more
        information about refs.
      </p>
    </article>
  ),
];

export const WhenToUse: Story = () => {
  const valueTextInputRef = useRef<HTMLInputElement>(null);
  const [value, setValue] = useState('');

  return (
    <>
      <div className="mb-2">
        <Button
          id="focus-input-element"
          onClick={() => {
            if (valueTextInputRef.current) {
              valueTextInputRef.current.value = 'chocolate';
            }
            setValue('croissant');
          }}
        >
          Change Input Values
        </Button>
      </div>
      <div className="mb-2">
        <strong>Ref Approach</strong>
        <TextInput id="ref-value-text-input" ref={valueTextInputRef} readOnly />
      </div>
      <div className="mb-2">
        <strong>Prop/State Approach</strong>
        <TextInput id="prop-value-text-input" value={value} readOnly />
      </div>
    </>
  );
};
WhenToUse.storyName = 'When To Use Refs';
WhenToUse.decorators = [
  (Story: Story) => {
    return (
      <article className="beacon">
        <p>There are a few good use cases for refs:</p>
        <ul>
          <li>
            Managing focus, text selection, and other parts of DOM elements that cannot be accessed or controlled
            through properties
          </li>
          <li>
            Integrating with third-party DOM libraries.{' '}
            <Tooltip
              id="tooltip"
              theme={Theme.light}
              content="This includes react-beacon as all of its modal components use refs to bind to elements"
            >
              <strong>[1]</strong>
            </Tooltip>
          </li>
        </ul>

        <p>
          However, refs should not be used very often. Refs inherently go against the declarative philospophy of React
          and are a easy way to overcomplicate React components.{' '}
          <span className="text-danger">Avoid using refs for anything that can be declaratively</span> (e.g. via React
          props and state).
        </p>

        <p>
          In the following example, the button is used to change the value of the corresponding text inputs. The first
          approach uses a ref to accomplish this. However, the second, more correct approach just uses props and state.
        </p>

        <div>
          <Story />
        </div>
      </article>
    );
  },
];

export const FormElements: Story = () => {
  const schema = yup.object().shape({
    formGrain: yup.string().nullable().required('This field is required'),
    formBread: yup.string().nullable(),
  });
  const resolver = yupResolver(schema);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({ resolver });

  return (
    <Form onSubmit={handleSubmit(noop)}>
      <FormGroup id="fg-firstName" errorMessages={hookFormUtils.getErrorMessages(errors, 'formGrain')}>
        <div>
          <strong>What is your favorite ingredient?</strong>
        </div>
        <Radio id="form-radio-grain" name="formGrain">
          <RadioOption id="form-potato" value={1} {...register('formGrain')}>
            potatoes
          </RadioOption>
          <RadioOption id="form-corn" value={2} {...register('formGrain')}>
            corn
          </RadioOption>
        </Radio>
      </FormGroup>
      <SubmitButton id="submit">Save</SubmitButton>
    </Form>
  );
};

FormElements.decorators = [
  (Story: Story) => (
    <article className="beacon">
      <p>
        React Beacon provides of a suite of form elements to be used in forms and other scenarios. However, these
        components should <strong>not</strong> be confused as simple wrappers around input elements. Some components use
        complicated markup to support their styling and feature needs.
        <strong>
          All form elements in React Beacon have a <code>ref</code> property that refers to the input element in each
          component as well as the <code>onChange</code> property
        </strong>
        .
      </p>

      <p>
        The react-hook-form in the example below uses the <code>onChange</code> property to collect changes from the
        form elements and uses the <code>ref</code> property to focus on the first control with a validation error when
        you click on the submit button. Both this properties along with name are returned by the{' '}
        <code>register(name)</code>
        function which is used with the spread operator as seen below
      </p>

      <Story />
    </article>
  ),
];

FormElements.storyName = 'Refs, Form Elements, and Forms';

export const CustomComponents: Story = () => {
  const buttonRef = useRef<HTMLButtonElement>(null);

  const CustomButton = forwardRef((props: { children: ReactNode }, ref: ForwardedRef<HTMLButtonElement>) => {
    return (
      <button className="btn btn-primary" ref={ref}>
        {props.children}
      </button>
    );
  });

  return (
    <div className="mb-2">
      <div className="mb-2">
        <Button id="focus-button-element" onClick={() => buttonRef.current?.focus()}>
          Focus Custom Button
        </Button>
      </div>

      <CustomButton ref={buttonRef}>This custom button component uses React.forwardRef</CustomButton>
    </div>
  );
};
CustomComponents.storyName = 'Refs and Custom Components';
CustomComponents.decorators = [
  (Story: Story) => (
    <article className="beacon">
      <p>
        All native HTML elements support refs. However, by default, React components do <strong>not</strong> support
        refs. They must configured to support them via{' '}
        <a href="https://reactjs.org/docs/forwarding-refs.html">React.fowardRef</a>.
      </p>

      <p>
        For example, the following CustomButton component uses React.forwardRef to expose the internal button and allow
        it to be focused programmatically.
      </p>

      <Story />

      <p>
        However, <strong>supporting refs is usually not necessary for custom components</strong>. If none of{' '}
        <a href="#when-to-use">these situations</a> are applicable, then the custom component should not be updated to
        support refs.
      </p>
    </article>
  ),
];
