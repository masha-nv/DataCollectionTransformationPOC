import React from 'react';
import { Meta, Story } from '@storybook/react';
import { StoryBadge } from '../stories';

export default {
  title: 'Lessons/Forms',
  parameters: {
    badges: [StoryBadge.READY],
  },
} as Meta;

export const ControlledUncontrolledForms: Story = () => {
  return (
    <article className="beacon">
      <h1>Controlled and Uncontrolled Forms</h1>
      <p>
        HTML form elements work a little bit differently from other DOM elements in React. Traditional form elements or{' '}
        <em>uncontrolled</em> form elements manage their own internal state and associate themselves with the form via
        the <code>name</code> attribute. In contrast, components in React are usually managed by some combination of
        properties (i.e. <code>prop</code>) and component state (i.e. <code>useState(...)</code>). However, React also
        supports form elements that are managed this way; that is, they are <em>controlled</em>.
      </p>

      <p>
        In react-beacon, <strong>all forms should be uncontrolled</strong>. All examples of forms are shown as so and
        developers are expected to create forms this way. However, outside of forms, react-beacon makes no such
        requirement for form elements. Developers should use whichever type seems appropriate for the situation.
      </p>

      <p>
        For more information about controlled and uncontrolled form elements, please refer the{' '}
        <a href="https://reactjs.org/docs/forms.html">React documentation</a>.
      </p>
    </article>
  );
};

ControlledUncontrolledForms.storyName = 'Controlled and Uncontrolled Forms';
