import React, { ReactNode, useState } from 'react';
import { Meta, Story } from '@storybook/react';
import { Documentation, dropdownFromHeadingStyles, dropdownFromHeadingTypes, StoryBadge } from '../stories';
import { a11yConfig } from '../stories/story.config';
import { DataView } from './data-view';
import { Badges } from '../notifications/badge/badges';
import { TextInput, TextInputType } from '../forms/text-input/text-input';
import { Radio } from '../forms/radio/radio';
import { RadioOption } from '../forms/radio/radio-option';
import { Button, ButtonType } from '../button/button';
import { DataViewLabelColumnWidth, IDataViewFieldProps, IDataViewProps } from './data-view-types';
import * as yup from 'yup';
import { FieldValues, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { action } from '@storybook/addon-actions';
import { FormGroup } from '../forms/form-group/form-group';
import { hookFormUtils } from '../forms/utils/hookform-utils';
import { Form } from '../forms/form/form';
import { Tooltip } from '../modals/tooltip/tooltip';
import { Icon, IconType, IconVariant } from '../icon/icon';
import { SubmitButton } from '../button/submit-button';
import { MultiSelect } from '../forms/multi-select/multi-select';
import { SelectOption } from '../forms/select/select';

export default {
  component: DataView,
  title: 'Core Components/Data View',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const whenToUse = (
  <>
    <p>
      This data view style is ideal for quickly scanning relatively small amount of data. As a result, they can be more
      visually compact than a sortable or data comparison table. They are primarily used for displaying information
      about an applicant.
    </p>
    <p>
      Generally, quick views should only have a label column and a single data column. If you have more than two
      columns, use a data comparison table or a sortable table.
    </p>
  </>
);

interface IMockStoryData {
  bodyMetrics?: {
    height?: string;
    weight?: string;
  };
  eye?: string;
  hair?: string;
  sex?: string;
  extraData?: unknown[];
  education?: string[];
  northAmerican?: string;
  name?: string;
}

const argTypes = {
  headingType: {
    control: dropdownFromHeadingTypes(),
    defaultValue: 'h3',
  },
  headingStyle: {
    control: dropdownFromHeadingStyles(),
    defaultValue: 's',
  },
};

const addData = (fields: IDataViewFieldProps<IMockStoryData>[], data: IMockStoryData) => {
  alert('Adding new data');
  const newFields = [...fields];
  if (!data.extraData) {
    data.extraData = [];
  }
  newFields.push({
    label: `Extra ${data.extraData.length}`,
    field: `extraData[${data.extraData.length}]`,
  });
  data.extraData.push(`testing ${data.extraData.length}`);
  return { data: data, fields: newFields };
};

const addButton = (
  data: IMockStoryData,
  fields: IDataViewFieldProps<IMockStoryData>[],
  setData: (data: IMockStoryData) => void,
  setFields: (fields: IDataViewFieldProps<IMockStoryData>[]) => void
) => {
  return (
    <Button
      id={`dataview-add-example-btn-add`}
      onClick={() => {
        const { fields: newFields, data: newData } = addData(fields, data);
        setData(newData);
        setFields(newFields);
      }}
      type={ButtonType.tertiary}
    >
      <Icon type={IconType.plusCircle} />
      Add Row
    </Button>
  );
};

/**
 * Data View
 */
export const BasicExample: Story<IDataViewProps<IMockStoryData>> = ({
  headingType,
  headingStyle,
}: IDataViewProps<IMockStoryData>) => {
  const data: IMockStoryData = {
    bodyMetrics: {
      height: '5 FT 11 IN',
      weight: '190 LBS',
    },
    eye: 'BROWN',
    hair: 'BROWN',
    sex: 'MALE',
    name: 'deactivatedName',
  };

  const fields: IDataViewFieldProps<IMockStoryData>[] = [
    {
      label: 'Height',
      field: 'bodyMetrics.height',
    },
    {
      label: 'Weight',
      field: 'bodyMetrics.weight',
    },
    {
      label: 'Eye Color',
      field: 'eye',
      readonly: (value: unknown, data: IMockStoryData, index: number): ReactNode => value as ReactNode,
      badge: (value: unknown, data: IMockStoryData) => <Badges.UPDATED />,
    },
    {
      label: 'Hair Color',
      field: 'hair',
    },
    {
      label: 'Sex',
      field: 'sex',
    },
    {
      label: 'Name',
      field: 'name',
      isDeactivated: true,
    },
  ];
  return (
    <div className="w-50">
      <DataView
        id="dataview-default"
        title="Table Title"
        fields={fields}
        data={data}
        headingType={headingType}
        headingStyle={headingStyle}
      />
    </div>
  );
};

BasicExample.storyName = 'Data View';

BasicExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Basic Data View"
      description="Data views are components that are used to display small amounts of data for quick viewing and comparing, such as data on an applicant."
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
BasicExample.argTypes = argTypes;

const actionFunction = (value: unknown, storyData: IMockStoryData, index: number, toggle: () => void) => {
  return [
    {
      label: 'Action Without Detail',
      onClick: () => alert('There is no detail here'),
    },
  ];
};
export const ActionsExample: Story<IDataViewProps<IMockStoryData>> = ({
  headingType,
  headingStyle,
}: IDataViewProps<IMockStoryData>) => {
  const fields: IDataViewFieldProps<IMockStoryData>[] = [
    {
      label: 'Height',
      field: 'bodyMetrics.height',
      actions: actionFunction,
    },
    {
      label: 'Weight',
      field: 'bodyMetrics.weight',
      isShiftedLeft: false,
      menuButtonTitle: 'This Menu is not shifted left',
      readonly: (value: unknown, storyData: IMockStoryData, index: number): ReactNode => value as ReactNode,
      actions: (value: unknown, storyData: IMockStoryData, index: number, toggle: () => void) => {
        return [
          {
            label: 'Action not shifted left',
            onClick: () => alert('Defined by setting the the is shifted left field prop to false'),
          },
        ];
      },
    },
    {
      label: 'Eye Color',
      field: 'eye',
    },
    {
      label: 'Hair Color',
      field: 'hair',
      menuButtonTitle: 'Hair Color Actions',
      actions: (value: unknown, storyData: IMockStoryData, index: number, toggle: () => void) => {
        return [
          {
            label: 'Action1',
            onClick: () => alert('action1'),
          },
          {
            label: 'Action2',
            onClick: () => alert('actions2'),
          },
        ];
      },
    },
  ];

  const data: IMockStoryData = {
    bodyMetrics: {
      height: '5 FT 11 IN',
      weight: '190 LBS',
    },
    eye: 'BROWN',
    hair: 'BROWN',
  };

  return (
    <div className="w-50">
      <DataView
        id="dataview-Actions"
        title="Actions Example"
        fields={fields}
        data={data}
        headingType={headingType}
        headingStyle={headingStyle}
      />
    </div>
  );
};

ActionsExample.storyName = 'Data View Actions';

ActionsExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Actions Property"
      description={<p>The Actions field property is used to include an ActionMenu to display a list of Actions.</p>}
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
ActionsExample.argTypes = argTypes;

export const AddExample: Story<IDataViewProps<IMockStoryData>> = ({
  headingType,
  headingStyle,
}: IDataViewProps<IMockStoryData>) => {
  const fieldsInit: IDataViewFieldProps<IMockStoryData>[] = [
    {
      label: 'Height',
      field: 'bodyMetrics.height',
    },
    {
      label: 'Weight',
      field: 'bodyMetrics.weight',
      isFieldRequired: true,
    },
    {
      label: 'Eye Color',
      field: 'eye',
    },
    {
      label: 'Hair Color',
      field: 'hair',
    },
    {
      label: 'Sex',
      field: 'sex',
    },
  ];

  const dataInit: IMockStoryData = {
    bodyMetrics: {
      height: '5 FT 11 IN',
      weight: '190 LBS',
    },
    eye: 'BROWN',
    hair: 'BROWN',
    sex: 'MALE',
    extraData: [],
  };

  const [data, setData] = useState(dataInit);
  const [fields, setFields] = useState(fieldsInit);

  const toolbar = <div>{addButton(data, fields, setData, setFields)}</div>;

  return (
    <div className="w-50">
      <DataView
        id="dataview-add-example"
        title="Add Button Example"
        fields={fields}
        data={data}
        toolbar={toolbar}
        headingType={headingType}
        headingStyle={headingStyle}
      />
    </div>
  );
};

AddExample.storyName = 'Data View with Add Button';

AddExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Add Button"
      description={
        <>
          <p>The Add Button is used to execute a callback function for whenever the add button is clicked.</p>
          <h5>Add related properties:</h5>
          <ul>
            <li>
              <strong>onAdd:</strong> used to set the Add button onClick callback{' '}
            </li>
            <li>
              <strong>addButtonText:</strong> used to set text for the Add button
            </li>
          </ul>
        </>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
AddExample.argTypes = argTypes;

export const DetailsExample: Story<IDataViewProps<IMockStoryData>> = ({
  headingType,
  headingStyle,
}: IDataViewProps<IMockStoryData>) => {
  const fields: IDataViewFieldProps<IMockStoryData>[] = [
    {
      label: 'Height',
      field: 'bodyMetrics.height',
      actions: actionFunction,
    },
    {
      label: 'Weight',
      field: 'bodyMetrics.weight',
      readonly: (value: unknown, storyData: IMockStoryData, index: number): ReactNode => value as ReactNode,
    },
    {
      label: 'Eye Color',
      field: 'eye',
      badge: () => <Badges.UPDATED />,
      details: (value: unknown, storyData: IMockStoryData, index: number): ReactNode => {
        return (
          <div>
            <p>Some interesting eye color details.</p>
            <ul>
              <li>Blue</li>
              <li>Brown</li>
              <li>Green</li>
            </ul>
          </div>
        );
      },
    },
    {
      label: 'Hair Color',
      field: 'hair',
      details: (value: unknown, storyData: IMockStoryData, index: number): ReactNode => {
        return <p>Some details about hair color. Could be the history of the previous hair color data.</p>;
      },
      actions: (value: unknown, storyData: IMockStoryData, index: number, toggle: () => void) => {
        return [
          {
            label: 'Show History',
            labelSecondary: 'Hide History',
            onClick: toggle,
          },
          {
            label: 'Action1',
            onClick: () => alert('action1'),
          },
          {
            label: 'ActionOn',
            labelSecondary: 'ActionOff',
            onClick: () => alert('Details is hidden'),
            onClickSecondary: () => alert('Details is showing'),
          },
        ];
      },
    },
  ];

  const data: IMockStoryData = {
    bodyMetrics: {
      height: '5 FT 11 IN',
      weight: '190 LBS',
    },
    eye: 'BROWN',
    hair: 'BROWN',
  };

  return (
    <div className="w-50">
      <DataView
        id="dataview-details"
        title="Table Title"
        fields={fields}
        data={data}
        headingType={headingType}
        headingStyle={headingStyle}
      />
    </div>
  );
};

DetailsExample.storyName = 'Data View Details';

DetailsExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Details Data View"
      description={
        <>
          <p>The Details field property is used to display the details of the readonly data for the DataView.</p>
          <p>If no actions are provided, then actions will default to 'Show Details'/'Hide Details'</p>
        </>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
DetailsExample.argTypes = argTypes;

export const EditExample: Story<IDataViewProps<IMockStoryData>> = ({
  headingType,
  headingStyle,
}: IDataViewProps<IMockStoryData>) => {
  const fields: IDataViewFieldProps<IMockStoryData>[] = [
    {
      label: 'Height',
      field: 'bodyMetrics.height',
    },
    {
      label: 'Weight',
      field: 'bodyMetrics.weight',
      isFieldRequired: true,
      edit: (value: unknown, data: IMockStoryData, index: number): ReactNode => {
        return (
          <FormGroup id={`fg-weight`} errorMessages={hookFormUtils.getErrorMessages(errors, 'weight')}>
            <TextInput
              id={`weight`}
              title="Enter a value for weight, with units"
              type={TextInputType.text}
              defaultValue={value as string}
              required
              {...register('weight')}
            />
          </FormGroup>
        );
      },
    },
    {
      label: 'Eye Color',
      field: 'eye',
      edit: (value: unknown, data: IMockStoryData, index: number): ReactNode => {
        return (
          <FormGroup id={`fg-eye`} errorMessages={hookFormUtils.getErrorMessages(errors, 'eye')}>
            <Radio id="eye-radio" name="eye" inline required>
              <RadioOption id="eye-brown" value={'BROWN'} defaultChecked={value === 'BROWN'} {...register('eye')}>
                brown
              </RadioOption>
              <RadioOption id="eye-blue" value={'BLUE'} defaultChecked={value === 'BLUE'} {...register('eye')}>
                blue
              </RadioOption>
              <RadioOption id="eye-green" value={'GREEN'} defaultChecked={value === 'GREEN'} {...register('eye')}>
                green
              </RadioOption>
            </Radio>
          </FormGroup>
        );
      },
    },
    {
      label: 'Hair Color',
      field: 'hair',
      edit: (value: unknown, data: IMockStoryData, index: number): ReactNode => {
        return (
          <FormGroup id={`fg-hair`} errorMessages={hookFormUtils.getErrorMessages(errors, 'hair')}>
            <Radio id="hair-radio" name="hair" inline required>
              <RadioOption id="hair-brown" value={'BROWN'} defaultChecked={value === 'BROWN'} {...register('hair')}>
                brown
              </RadioOption>
              <RadioOption id="hair-blue" value={'BLUE'} defaultChecked={value === 'BLUE'} {...register('hair')}>
                blue
              </RadioOption>
              <RadioOption id="hair-green" value={'GREEN'} defaultChecked={value === 'GREEN'} {...register('hair')}>
                green
              </RadioOption>
            </Radio>
          </FormGroup>
        );
      },
    },
    {
      label: 'Sex',
      field: 'sex',
    },
  ];

  const dataInit: IMockStoryData = {
    bodyMetrics: {
      height: '5 FT 11 IN',
      weight: '190 LBS',
    },
    eye: 'BROWN',
    hair: 'BROWN',
    sex: 'MALE',
  };

  type StoryFormData = {
    weight: string;
    eye: string;
    hair: string;
  };

  const [data, setData] = useState(dataInit);
  const [isEditable, setIsEditable] = useState<boolean | undefined>();

  const schema = yup.object({
    weight: yup.string().required('Weight Required'),
    eye: yup.string().required('Eye Required'),
    hair: yup.string().required('Hair Required'),
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  const onSubmit = (formData: StoryFormData) => {
    action('submit-action')(formData);
    if (!data.bodyMetrics) {
      data.bodyMetrics = {};
    }
    data.bodyMetrics.weight = formData.weight;
    data.eye = formData.eye;
    data.hair = formData.hair;
    setData(data);
    setIsEditable(false);
  };

  const onError = (formData: FieldValues) => action('error-action')(formData);

  const dataViewId = 'dataview-edit';

  const title = (
    <>
      {'Edit Example with Forms  '}
      <Tooltip
        id={`${dataViewId}-title-icon-tooltip`}
        content={'This tooltip is for extra information related to the title of this data view'}
      >
        <Icon type={IconType.infoCircle} variant={IconVariant.info} />
      </Tooltip>
    </>
  );

  const toolbar = (
    <Button
      id={`${dataViewId}-btn-edit`}
      type={ButtonType.tertiary}
      onClick={() => {
        setIsEditable(true);
      }}
    >
      <Icon type={IconType.pencilAlt} />
      Edit
    </Button>
  );

  const footerBar = [
    <Button
      id={`${dataViewId}-btn-cancel`}
      key={`${dataViewId}-btn-cancel`}
      onClick={() => setIsEditable(false)}
      type={ButtonType.secondary}
    >
      Cancel
    </Button>,
    <SubmitButton id={`${dataViewId}-btn-save`} key={`${dataViewId}-btn-save`}>
      Save
    </SubmitButton>,
  ];

  return (
    <div className="w-50">
      <Form onSubmit={handleSubmit(onSubmit, onError)}>
        <DataView
          id={dataViewId}
          fields={fields}
          data={data}
          isEditable={isEditable}
          title={title}
          toolbar={toolbar}
          footerBar={footerBar}
          headingType={headingType}
          headingStyle={headingStyle}
        />
      </Form>
    </div>
  );
};

EditExample.storyName = 'Data View with Edit Button';

EditExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Edit Data View"
      description={
        <>
          <p>The Edit field property is used to customize the edit view of the data section for the DataView.</p>
          <p>
            <strong>Note:</strong> The DataView should be wrapped in a form tag. The save button will submit the form
            and the postSave function should be called in the onSubmit. Any Save/Submit functionality should be handled
            in the onSubmit of the form.
          </p>
          <h5>Edit related properties:</h5>
          <ul>
            <li>
              <strong>isSaveEnabled:</strong> used to enable and disable the Save button
            </li>
            <li>
              <strong>onEdit:</strong> used to set the Activate button onClick callback
            </li>
            <li>
              <strong>onCancel:</strong> used to set the Activate button onClick callback
            </li>
            <li>
              <strong>ref:</strong> used to set the reference to the DataView outside of the tag in order to call the
              postSave function
            </li>
          </ul>
        </>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
EditExample.argTypes = argTypes;

export const Omit: Story<IDataViewProps<IMockStoryData>> = ({
  headingType,
  headingStyle,
}: IDataViewProps<IMockStoryData>) => {
  const [weightVisible, setWeightVisible] = useState(true);

  const fields: IDataViewFieldProps<IMockStoryData>[] = [
    {
      label: 'Height',
      field: 'bodyMetrics.height',
    },
    {
      label: 'Weight',
      field: 'bodyMetrics.weight',
      omit: !weightVisible,
    },
    {
      label: 'Eye Color',
      field: 'eye',
      omit: true,
    },
  ];

  const data: IMockStoryData = {
    bodyMetrics: {
      height: '5 FT 11 IN',
      weight: '190 LBS',
    },
    eye: 'BROWN',
  };

  const toggleWeightRow = () => setWeightVisible(!weightVisible);

  return (
    <div className="w-50">
      <Button id="toggle-weight-row-btn" onClick={toggleWeightRow}>
        Toggle Weight Row
      </Button>
      <DataView
        id="dataview-omit"
        title="Omit Example"
        fields={fields}
        data={data}
        headingType={headingType}
        headingStyle={headingStyle}
      />
    </div>
  );
};
Omit.storyName = 'Data View Omit Rows';
Omit.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Omitting Rows in the Data View"
      description={
        <p>
          The <code>omit</code> field property can be used to hide rows in the data view
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
Omit.argTypes = argTypes;

export const ReadonlyExample: Story = (props) => {
  const fields: IDataViewFieldProps<IMockStoryData>[] = [
    {
      label: 'Height',
      field: 'bodyMetrics.height',
    },
    {
      label: 'Weight',
      field: 'bodyMetrics.weight',
    },
    {
      label: 'Eye Color',
      field: 'eye',
      badge: () => <Badges.UPDATED />,
    },
    {
      label: 'Hair Color',
      readonly: (value: unknown, storyData: IMockStoryData, index: number): ReactNode => {
        return <i>{data.hair}</i>;
      },
    },
    {
      label: 'Sex',
      field: 'sex',
    },
    {
      label: 'Additional',
      field: 'sex',
      readonly: () => (
        <p>
          This basically shows an example where the label column width is specified when we need to control that to
          provide additional space for the value.
        </p>
      ),
    },
    {
      label: 'Education',
      readonly: (value: unknown, storyData: IMockStoryData): ReactNode => {
        const degrees: string[] = ['BS', 'MS', 'PhD', 'MBA', 'JD'];

        return (
          <MultiSelect id="education-filing-types" placeholder="Select achieved levels of education...">
            {degrees.map((degree: string) => {
              console.log('data:', data);
              const defaultSelected = {
                defaultSelected: data.education && data.education.length > 0 && data.education.indexOf(degree) !== -1,
              };
              return (
                <SelectOption key={degree} value={degree} {...defaultSelected}>
                  {degree}
                </SelectOption>
              );
            })}
          </MultiSelect>
        );
      },
    },
  ];

  const data: IMockStoryData = {
    bodyMetrics: {
      height: '5 FT 11 IN',
      weight: '190 LBS',
    },
    eye: 'BROWN',
    hair: 'BROWN',
    sex: 'MALE',
    education: ['BS', 'MS'],
  };
  return (
    <div className="w-50">
      <DataView
        id="dataview-readonly"
        labelColumnWidth={DataViewLabelColumnWidth.small}
        title="Readonly Example (with defined label column width)"
        fields={fields}
        data={data}
        headingType={props.headingType}
        headingStyle={props.headingStyle}
      />
    </div>
  );
};

ReadonlyExample.storyName = 'Read-only Data View';

ReadonlyExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Readonly Data View"
      description={
        <p>
          The <code>readonly</code> field property is used to customize how the readonly section is rendered or
          displayed for the DataView.
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
ReadonlyExample.argTypes = argTypes;

export const ReactElementExample: Story<IDataViewProps<IMockStoryData>> = ({
  headingType,
  headingStyle,
}: IDataViewProps<IMockStoryData>) => {
  const data: IMockStoryData = {
    bodyMetrics: {
      height: '5 FT 11 IN',
      weight: '190 LBS',
    },
    eye: 'BROWN',
    hair: 'BROWN',
    sex: 'MALE',
    northAmerican: 'YES',
  };

  const fields: IDataViewFieldProps<IMockStoryData>[] = [
    {
      label: 'Height',
      field: 'bodyMetrics.height',
    },
    {
      label: 'Weight',
      field: 'bodyMetrics.weight',
    },
    {
      label: 'Eye Color',
      field: 'eye',
      readonly: (value: unknown, storyData: IMockStoryData, index: number): ReactNode => value as ReactNode,
      badge: (value: unknown, storyData: IMockStoryData) => <Badges.UPDATED />,
    },
    {
      label: 'Hair Color',
      field: 'hair',
    },
    {
      label: 'Sex',
      field: 'sex',
    },
    {
      label: (
        <div>
          Is this person from one of the following countries?
          <ul>
            <br />
            <li>Canada</li>
            <li>United States</li>
            <li>Mexico</li>
          </ul>
        </div>
      ),
      field: 'northAmerican',
    },
  ];
  return (
    <div className="w-50">
      <DataView
        id="dataview-label-element"
        title="React Element Label Example"
        fields={fields}
        data={data}
        headingType={headingType}
        headingStyle={headingStyle}
      />
    </div>
  );
};

ReactElementExample.storyName = 'Data View with React Element Label';

ReactElementExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Data View with React Element Label"
      description={
        <p>
          A React Element can be passed into the <code>label</code> field property to customize how the label is
          displayed.
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];

ReactElementExample.argTypes = argTypes;

export const EmptyDataView: Story<IDataViewProps<IMockStoryData>> = ({
  headingType,
  headingStyle,
}: IDataViewProps<IMockStoryData>) => {
  const dataInit: IMockStoryData = {};

  const fieldsInit: IDataViewFieldProps<IMockStoryData>[] = [];

  const [data, setData] = useState(dataInit);
  const [fields, setFields] = useState(fieldsInit);

  const toolbar = <div>{addButton(data, fields, setData, setFields)}</div>;

  return (
    <div className="w-50">
      <DataView
        id="dataview-empty"
        title="Empty Data View Example"
        fields={fields}
        data={data}
        toolbar={toolbar}
        headingType={headingType}
        headingStyle={headingStyle}
      />
    </div>
  );
};

EmptyDataView.storyName = 'Data View With No Data';

EmptyDataView.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Data View With No data"
      description={
        <p>
          If an empty fields variable is passed into a Data View it will display a single row with the message 'No data
          available' while retaining the ability to add new rows
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];

EmptyDataView.argTypes = argTypes;
