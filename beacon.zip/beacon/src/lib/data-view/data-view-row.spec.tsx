import { render, waitFor } from '@testing-library/react';
import { DataViewRow } from './data-view-row';
import { IDataViewFieldProps } from './data-view-types';
import { ITestData } from './data-view.spec';

const getBasicField = (): IDataViewFieldProps<ITestData> => {
  return { field: 'basic', label: 'basic-label' };
};
const getBasicData = () =>
  ({
    basic: 'basic',
  } as ITestData);

const getBasicDataView = ({ data = getBasicData(), field = getBasicField() }) => (
  <DataViewRow id="dataview" data={data} field={field} isEditing={false} index={1} />
);

describe('DataView Component', () => {
  it('renders row', async () => {
    const field = getBasicField();
    const { baseElement } = render(getBasicDataView({ field: field }));
    await waitFor(() => {
      expect(baseElement).toMatchSnapshot();
    });
  });

  it('renders deactivated row', async () => {
    const field = getBasicField();
    field.isDeactivated = true;
    const { baseElement } = render(getBasicDataView({ field: field }));
    await waitFor(() => {
      expect(baseElement).toMatchSnapshot();
    });
  });
});
