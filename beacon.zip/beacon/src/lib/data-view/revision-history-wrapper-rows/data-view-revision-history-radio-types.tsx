import { IRevisionHistoryWrapperDataViewProp } from './data-view-revision-history-wrapper-types';
import { RadioOptionType } from '../../forms/radio/radio-option';

export interface IRevisionHistoryWrapperRadioOption {
  value: RadioOptionType;
  label: string;
  title?: string;
}

export interface IRevisionHistoryWrapperDataViewRadioProp extends IRevisionHistoryWrapperDataViewProp {
  /**
   * Options to display in edit mode
   */
  options: IRevisionHistoryWrapperRadioOption[];
}

export interface RadioDataViewRowProps<WrapperDataType, DataType extends RadioOptionType>
  extends IRevisionHistoryWrapperDataViewProp {
  valueExtractor: (data: WrapperDataType | null) => DataType | null;

  /**
   * This defines the list of options available
   */
  options: IRevisionHistoryWrapperRadioOption[];
}
