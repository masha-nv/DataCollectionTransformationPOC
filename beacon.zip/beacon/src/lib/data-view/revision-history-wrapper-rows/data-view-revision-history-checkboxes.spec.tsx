import React from 'react';
import { act, render, screen } from '@testing-library/react';
import { IDataViewFieldProps } from '../data-view-types';
import { IRevisionHistoryWrapperData } from './data-view-revision-history-wrapper-types';
import { DeepMap, FieldError, FieldValues } from 'react-hook-form';
import userEvent from '@testing-library/user-event';
import { ISimpleCheckboxOptionProp } from '../../forms/checkboxes/simple-checkboxes/simple-checkbox-list-types';
import { CheckboxValueType } from '../../forms/checkboxes/checkbox';
import { RevisionHistoryWrapperCheckboxesView } from './data-view-revision-history-checkboxes';

interface TestDataObj {
  firstEntry: IRevisionHistoryWrapperData<CheckboxValueType[]>;
}

const TEST_DATA = {
  firstEntry: {
    latest: {
      item: ['OPTION_1', 'OPTION_3', 'OPTION_5', 'An option that is no longer there'],
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1744819729168,
      sourceType: 'INTERNAL',
      revisionNumber: 3,
    },
    history: [
      {
        item: ['OPTION_1', 'OPTION_5', 'An option that is no longer there'],
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1744819694199,
        sourceType: 'EXTERNAL',
        revisionNumber: 2,
      },
      {
        item: null,
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1744819694199,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
};

const TEST_DATA_NULL = JSON.parse(JSON.stringify(TEST_DATA));
TEST_DATA_NULL.firstEntry.latest = null;

const CHECBOX_OPTIONS: ISimpleCheckboxOptionProp[] = [
  {
    value: 'OPTION_1',
    label: 'This is the first option',
  },
  {
    value: 'OPTION_2',
    label: 'This is the second option',
  },
  {
    value: 'OPTION_3',
    label: 'This is the third option',
  },
  {
    value: 'OPTION_4',
    label: 'This is the fourth option',
  },
  {
    value: 'OPTION_5',
    label: 'This is the fifth option',
  },
];

describe('DataView RevisionHistory Radio', () => {
  const formlessCheckboxView: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperCheckboxesView<TestDataObj>({
    field: 'firstEntry',
    label: 'label for entry',
    options: CHECBOX_OPTIONS,
  });

  const renderReadOnly = (data: TestDataObj) => {
    const { baseElement } = render(<>{formlessCheckboxView.readonly(data.firstEntry, data, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  };

  it('renders readonly', () => {
    renderReadOnly(TEST_DATA);
  });

  it('renders readonly null', () => {
    renderReadOnly(TEST_DATA_NULL);
  });

  it('renders details', () => {
    const { baseElement } = render(<>{formlessCheckboxView.details(TEST_DATA.firstEntry, TEST_DATA, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  });

  const renderEdit = (data: TestDataObj) => {
    const { baseElement } = render(<>{formlessCheckboxView.edit(data.firstEntry, data, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  };

  it('renders in edit mode', () => {
    renderEdit(TEST_DATA);
  });

  it('renders in edit mode -- null', () => {
    renderEdit(TEST_DATA_NULL);
  });

  const renderEditModeAndClick = (textToClick: string, expectedResults: string[]) => {
    const errors: DeepMap<FieldValues, FieldError> = {};
    const setValue = jest.fn();
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperCheckboxesView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      errors: errors,
      setValue: setValue,
      options: CHECBOX_OPTIONS,
    });

    render(<>{firstEntry.edit(TEST_DATA.firstEntry, TEST_DATA, 0)}</>);
    expect(setValue.mock.calls).toEqual([['firstEntry', ['OPTION_1', 'OPTION_3', 'OPTION_5']]]);

    act(() => {
      userEvent.click(screen.getByText(textToClick));
    });
    expect(setValue.mock.calls[setValue.mock.calls.length - 1]).toEqual(['firstEntry', expectedResults]);
  };

  it('renders in edit mode with form props and changes value -- Add OPTION_2', async () => {
    renderEditModeAndClick('This is the second option', ['OPTION_1', 'OPTION_3', 'OPTION_5', 'OPTION_2']);
  });

  it('renders in edit mode with form props and changes value -- Remove OPTION_1', async () => {
    renderEditModeAndClick('This is the first option', ['OPTION_3', 'OPTION_5']);
  });
});
