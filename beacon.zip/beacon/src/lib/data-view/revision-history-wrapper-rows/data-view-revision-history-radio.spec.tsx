import React from 'react';
import { act, render, screen } from '@testing-library/react';
import { IDataViewFieldProps } from '../data-view-types';
import { IRevisionHistoryWrapperData, RevisionHistory } from './data-view-revision-history-wrapper-types';
import { DeepMap, FieldError, FieldValues } from 'react-hook-form';
import userEvent from '@testing-library/user-event';
import { RevisionHistoryWrapperRadioDataView } from './data-view-revision-history-radio';
import { ISimpleRadioOptionProp } from '../../forms/radio/simple-radio/simple-radio.types';
import { RadioOptionType } from '../../forms/radio/radio-option';

interface TestDataObj {
  firstEntry: IRevisionHistoryWrapperData<RadioOptionType>;
}

const TEST_DATA_YES = {
  firstEntry: {
    latest: {
      item: 1,
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1743699400657,
      sourceType: 'INTERNAL',
      revisionNumber: 3,
    },
    history: [
      {
        item: 2,
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 2,
      },
      {
        item: 3,
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
};

const TEST_DATA_NULL = {
  firstEntry: {
    latest: null as RevisionHistory<RadioOptionType>,
    history: [
      {
        item: 2,
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 3,
      },
      {
        item: 3,
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 2,
      },
      {
        item: null,
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
};

const TEST_DATA_NO = {
  firstEntry: {
    latest: {
      item: 2,
      enteredBy: 'FIVE, CASEACCESS',
      sourceType: 'INTERNAL',
      dateOfAnswer: 1743699400657,
      revisionNumber: 1,
    },
    history: [] as RevisionHistory<string>[],
  },
};

const YES_NO_OPTIONS: ISimpleRadioOptionProp[] = [
  {
    value: 1,
    label: 'Yes',
  },
  {
    value: 2,
    label: 'No',
  },
];

describe('DataView RevisionHistory Radio', () => {
  const renderReadOnly = (data: TestDataObj) => {
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperRadioDataView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      options: YES_NO_OPTIONS,
    });

    const { baseElement } = render(<>{firstEntry.readonly(data.firstEntry, data, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  };

  it('renders readonly', () => {
    renderReadOnly(TEST_DATA_YES);
  });

  it('renders readonly null', () => {
    renderReadOnly(TEST_DATA_NULL);
  });

  it('renders details', () => {
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperRadioDataView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      options: YES_NO_OPTIONS,
    });

    const { baseElement } = render(<>{firstEntry.details(TEST_DATA_YES.firstEntry, TEST_DATA_YES, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  });

  const renderClearable = (data: TestDataObj) => {
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperRadioDataView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      options: YES_NO_OPTIONS,
      clearable: true,
    });

    const { baseElement } = render(<>{firstEntry.edit(data.firstEntry, data, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  };

  it('renders in edit mode', () => {
    renderClearable(TEST_DATA_YES);
  });

  it('renders in edit mode -- null', () => {
    renderClearable(TEST_DATA_NULL);
  });

  const renderNotClearable = (data: TestDataObj) => {
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperRadioDataView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      options: YES_NO_OPTIONS,
      clearable: false,
    });

    const { baseElement } = render(<>{firstEntry.edit(data.firstEntry, data, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  };

  it('renders in edit mode', () => {
    renderNotClearable(TEST_DATA_YES);
  });

  it('renders in edit mode -- null', () => {
    renderNotClearable(TEST_DATA_NULL);
  });

  const renderInline = (data: TestDataObj) => {
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperRadioDataView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      options: YES_NO_OPTIONS,
      inline: true,
    });

    const { baseElement } = render(<>{firstEntry.edit(data.firstEntry, data, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  };

  it('renders in edit mode', () => {
    renderInline(TEST_DATA_YES);
  });

  it('renders in edit mode -- null', () => {
    renderInline(TEST_DATA_NULL);
  });

  const renderBlock = (data: TestDataObj) => {
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperRadioDataView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      options: YES_NO_OPTIONS,
      inline: false,
    });

    const { baseElement } = render(<>{firstEntry.edit(data.firstEntry, data, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  };

  it('renders in edit mode', () => {
    renderBlock(TEST_DATA_YES);
  });

  it('renders in edit mode -- null', () => {
    renderBlock(TEST_DATA_NULL);
  });

  const renderHistory = (data: TestDataObj) => {
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperRadioDataView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      options: YES_NO_OPTIONS,
    });

    const { baseElement } = render(<>{firstEntry.details(data.firstEntry, data, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  };

  it('renders in details mode -- null', () => {
    renderHistory(TEST_DATA_NULL);
  });

  it('renders in edit mode with form props and changes value -- Click No', () => {
    const errors: DeepMap<FieldValues, FieldError> = {};
    const setValue = jest.fn();
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperRadioDataView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      errors: errors,
      setValue: setValue,
      options: YES_NO_OPTIONS,
    });

    render(<>{firstEntry.edit(TEST_DATA_YES.firstEntry, TEST_DATA_YES, 0)}</>);
    userEvent.click(screen.getByText('No'));
    expect(setValue.mock.calls).toEqual([
      ['firstEntry', 1],
      ['firstEntry', 2],
    ]);
  });

  it('renders in edit mode with form props and changes value -- Click Yes', () => {
    const errors: DeepMap<FieldValues, FieldError> = {};
    const setValue = jest.fn();
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperRadioDataView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      errors: errors,
      setValue: setValue,
      options: YES_NO_OPTIONS,
    });

    render(<>{firstEntry.edit(TEST_DATA_NO.firstEntry, TEST_DATA_NO, 0)}</>);
    userEvent.click(screen.getByText('Yes'));
    expect(setValue.mock.calls).toEqual([
      ['firstEntry', 2],
      ['firstEntry', 1],
    ]);
  });

  it('renders in edit mode with form props and clears value', () => {
    const errors: DeepMap<FieldValues, FieldError> = {};
    const setValue = jest.fn();
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperRadioDataView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      errors: errors,
      setValue: setValue,
      options: YES_NO_OPTIONS,
      clearable: true,
    });

    render(<>{firstEntry.edit(TEST_DATA_YES.firstEntry, TEST_DATA_YES, 0)}</>);
    act(() => {
      userEvent.click(screen.getByText('Clear'));
    });

    expect(setValue.mock.calls).toEqual([
      ['firstEntry', 1],
      ['firstEntry', undefined],
    ]);
  });
});
