import { useState } from 'react';
import {
  IRevisionHistoryWrapperData,
  IRevisionHistoryWrapperDataViewProp,
} from './data-view-revision-history-wrapper-types';
import { DeepMap, FieldError, FieldValues, UseFormSetValue } from 'react-hook-form';
import { IDataViewFieldProps } from '../data-view-types';
import { DataViewRow, getDisplayFromRevisionHistory } from './data-view-revision-history';
import { DatePicker } from '../../forms/date-picker/date-picker';
import { isDataViewRowReadOnly } from '../data-view-row';

export interface DateDataViewRowProps<DataType> extends IRevisionHistoryWrapperDataViewProp {
  valueExtractor: (data: DataType | null) => string | null;
}

const EditDate = (props: {
  field: string;
  value: string | null;
  setValue?: UseFormSetValue<FieldValues>;
  errors?: DeepMap<FieldValues, FieldError>;
  isReadOnly?: boolean;
}) => {
  const [selection, setSelection] = useState<string | null>(props.value);

  if (props.setValue) {
    props.setValue(props.field, selection);
  }

  return (
    <DatePicker
      id={props.field}
      name={props.field}
      value={selection != null ? selection : undefined}
      onChange={(e, value) => {
        if (props.setValue) {
          setSelection(value);
        }
      }}
      disabled={props.isReadOnly}
    />
  );
};

export const DateDataViewRow = <WrapperDataType,>(
  props: DateDataViewRowProps<WrapperDataType>
): IDataViewFieldProps<ResponseType> => {
  return DataViewRow({
    ...props,
    displayConverter: (val) => val,
    createEditMode: (typedValue: IRevisionHistoryWrapperData<WrapperDataType>) => {
      return (
        <EditDate
          field={props.field}
          value={getDisplayFromRevisionHistory(typedValue, props.valueExtractor, (item) => item)}
          setValue={props.setValue}
          errors={props.errors}
          isReadOnly={isDataViewRowReadOnly(props.isEditable)}
        />
      );
    },
  });
};

export const RevisionHistoryWrapperDatePickerView = <Data,>(
  props: IRevisionHistoryWrapperDataViewProp
): IDataViewFieldProps<Data> => {
  const textLineItemProps: DateDataViewRowProps<string> = {
    ...props,
    valueExtractor: function (data: string | null): string | null {
      return data;
    },
  };
  //DataViewFieldProps typing does not matter. It is typing a property that isn't even used
  //so we are telling typescript to coalesce it to the right parameterized type. The type we care
  //about is already called back to us as 'unknown' despite being a specific wanted type
  //We do not want to modify the parent though as it is used in other parts of ELIS
  //and would be a larger refactoring
  return DateDataViewRow(textLineItemProps) as unknown as IDataViewFieldProps<Data>;
};
