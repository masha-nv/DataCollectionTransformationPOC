import React from 'react';
import { render } from '@testing-library/react';
import { IDataViewFieldProps } from '../data-view-types';
import { IRevisionHistoryWrapperData, RevisionHistory } from './data-view-revision-history-wrapper-types';
import {
  CurrencyDataViewRow,
  PhoneDataViewRow,
  RevisionHistoryWrapperTextView,
} from './data-view-revision-history-text';
import { DeepMap, FieldError, FieldValues } from 'react-hook-form';
import userEvent from '@testing-library/user-event';

interface TestDataObj {
  firstEntry: IRevisionHistoryWrapperData<string>;
}

const TEST_DATA_MOCK = {
  firstEntry: {
    latest: {
      item: 'This is the latest entry',
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1743699400657,
      sourceType: 'INTERNAL',
      revisionNumber: 2,
    },
    history: [
      {
        item: 'This is a deactivated entry',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
        isDeactivated: true,
      },
      {
        item: 'This is a history entry',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
};

const TEST_DATA_NULL = {
  firstEntry: {
    latest: {
      item: null as string,
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1743699400657,
      sourceType: 'INTERNAL',
      revisionNumber: 2,
    },
    history: [
      {
        item: 'This is a history entry',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
};

const TEST_DATA_NULL_ITEM = {
  firstEntry: {
    latest: null as RevisionHistory<string>,
    history: [
      {
        item: null as string,
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
};

describe('DataView RevisionHistory Text', () => {
  const renderReadOnly = (data: TestDataObj) => {
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperTextView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
    });

    const { baseElement } = render(<>{firstEntry.readonly(data.firstEntry, data, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  };

  it('renders readonly', () => {
    renderReadOnly(TEST_DATA_MOCK);
  });

  it('renders readonly null', () => {
    renderReadOnly(TEST_DATA_NULL);
  });

  it('renders readonly null item', () => {
    renderReadOnly(TEST_DATA_NULL_ITEM);
  });

  it('renders details', () => {
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperTextView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
    });

    const { baseElement } = render(<>{firstEntry.details(TEST_DATA_MOCK.firstEntry, TEST_DATA_MOCK, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  });

  const renderEdit = (data: TestDataObj) => {
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperTextView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
    });

    const { baseElement } = render(<>{firstEntry.edit(data.firstEntry, data, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  };

  it('renders in edit mode', () => {
    renderEdit(TEST_DATA_MOCK);
  });

  it('renders in edit mode -- null', () => {
    renderEdit(TEST_DATA_NULL);
  });

  it('renders in edit mode', () => {
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperTextView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
    });

    const { baseElement } = render(<>{firstEntry.edit(TEST_DATA_MOCK.firstEntry, TEST_DATA_MOCK, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders in edit mode with uneditable field', () => {
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperTextView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      isEditable: false,
    });

    const { baseElement } = render(<>{firstEntry.edit(TEST_DATA_MOCK.firstEntry, TEST_DATA_MOCK, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders in edit mode with form props and changes value', () => {
    const errors: DeepMap<FieldValues, FieldError> = {};
    const setValue = jest.fn();
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperTextView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      errors: errors,
      setValue: setValue,
    });

    const { baseElement } = render(<>{firstEntry.edit(TEST_DATA_MOCK.firstEntry, TEST_DATA_MOCK, 0)}</>);
    const input = baseElement.getElementsByClassName('form-control')[0] as HTMLInputElement;
    userEvent.type(input, 'A');
    expect(setValue.mock.calls).toEqual([
      ['firstEntry', 'This is the latest entry'],
      ['firstEntry', 'This is the latest entryA'],
    ]);
  });
});

const TEST_DATA_PHONE_10_DIGITS = {
  firstEntry: {
    latest: {
      item: '3029579631',
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1743699400657,
      sourceType: 'INTERNAL',
      revisionNumber: 2,
    },
    history: [
      {
        item: '3029579632',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
};
const TEST_DATA_PHONE_11_DIGITS = {
  firstEntry: {
    latest: {
      item: '30295796311',
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1743699400657,
      sourceType: 'INTERNAL',
      revisionNumber: 2,
    },
    history: [
      {
        item: '30295796321',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
};

const PHONE_NUMBER_DATA_NULL = {
  firstEntry: {
    latest: {
      item: null as string,
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1743699400657,
      sourceType: 'INTERNAL',
      revisionNumber: 2,
    },
    history: [
      {
        item: '30295796321',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
};

describe('DataView RevisionHistory Text -- Phone Number Subclass', () => {
  const renderReadOnly = (data: TestDataObj) => {
    const phoneNumber = PhoneDataViewRow<string, TestDataObj>({
      field: 'phoneNumber',
      label: 'Phone Number',
      valueExtractor: function (value: string | null): string | null {
        return value ? value : null;
      },
    });

    const { baseElement } = render(<>{phoneNumber.readonly(data.firstEntry, null, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  };

  const renderEdit = (data: TestDataObj) => {
    const phoneNumber = PhoneDataViewRow<string, TestDataObj>({
      field: 'phoneNumber',
      label: 'Phone Number',
      valueExtractor: function (value: string | null): string | null {
        return value ? value : null;
      },
    });

    const { baseElement } = render(<>{phoneNumber.edit(data.firstEntry, null, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  };

  it('renders phone number view read only - 10 digits', () => {
    renderReadOnly(TEST_DATA_PHONE_10_DIGITS);
  });
  it('renders phone number view read only  - not 10 digits', () => {
    renderReadOnly(TEST_DATA_PHONE_11_DIGITS);
  });
  it('renders phone number view read only  - null', () => {
    renderReadOnly(PHONE_NUMBER_DATA_NULL);
  });

  it('renders phone number view edit - 10 digits', () => {
    renderEdit(TEST_DATA_PHONE_10_DIGITS);
  });
  it('renders phone number view edit  - not 10 digits', () => {
    renderEdit(TEST_DATA_PHONE_11_DIGITS);
  });
  it('renders phone number view edit  - null', () => {
    renderEdit(PHONE_NUMBER_DATA_NULL);
  });
});

const TEST_DATA_CURRENCY_WITH_DECIMAL = {
  firstEntry: {
    latest: {
      item: '105236.25',
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1743699400657,
      sourceType: 'INTERNAL',
      revisionNumber: 2,
    },
    history: [
      {
        item: '105256.25',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
};
const TEST_DATA_CURRENCY_NO_DECIMAL = {
  firstEntry: {
    latest: {
      item: '105256',
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1743699400657,
      sourceType: 'INTERNAL',
      revisionNumber: 2,
    },
    history: [
      {
        item: '105257',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
};

const CURRENCY_DATA_NULL = {
  firstEntry: {
    latest: {
      item: null as string,
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1743699400657,
      sourceType: 'INTERNAL',
      revisionNumber: 2,
    },
    history: [
      {
        item: '102489',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
};

describe('DataView RevisionHistory Text -- Currency Subclass', () => {
  const renderReadOnly = (data: TestDataObj) => {
    const currency = CurrencyDataViewRow<string, TestDataObj>({
      field: 'currency',
      label: 'Currency',
      valueExtractor: function (value: string | null): string | null {
        return value ? value : null;
      },
    });

    const { baseElement } = render(<>{currency.readonly(data.firstEntry, null, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  };

  const renderEdit = (data: TestDataObj) => {
    const currency = CurrencyDataViewRow<string, TestDataObj>({
      field: 'currency',
      label: 'Currency',
      valueExtractor: function (value: string | null): string | null {
        return value ? value : null;
      },
    });

    const { baseElement } = render(<>{currency.edit(data.firstEntry, null, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  };

  it('renders currency view read only - with decimal included in original data', () => {
    renderReadOnly(TEST_DATA_CURRENCY_WITH_DECIMAL);
  });
  it('renders currency view read only  - no decimal included in original data', () => {
    renderReadOnly(TEST_DATA_CURRENCY_NO_DECIMAL);
  });
  it('renders currency view read only  - null', () => {
    renderReadOnly(CURRENCY_DATA_NULL);
  });

  it('renders currency view edit - with decimal included in original data', () => {
    renderEdit(TEST_DATA_CURRENCY_WITH_DECIMAL);
  });
  it('renders currency view edit  - no decimal included in original data', () => {
    renderEdit(TEST_DATA_CURRENCY_NO_DECIMAL);
  });
  it('renders currency view edit  - null', () => {
    renderEdit(CURRENCY_DATA_NULL);
  });
});
