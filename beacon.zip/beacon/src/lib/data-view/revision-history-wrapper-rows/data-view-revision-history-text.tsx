import { useState } from 'react';
import {
  IRevisionHistoryWrapperData,
  IRevisionHistoryWrapperDataViewProp,
} from './data-view-revision-history-wrapper-types';
import { FormGroup } from '../../forms/form-group/form-group';
import { hookFormUtils } from '../../forms/utils/hookform-utils';
import { DeepMap, FieldError, FieldValues, UseFormSetValue } from 'react-hook-form';
import { IDataViewFieldProps } from '../data-view-types';
import { TextInput, TextInputType } from '../../forms/text-input/text-input';
import { getDisplayFromRevisionHistory, DataViewRow } from './data-view-revision-history';
import { isDataViewRowReadOnly } from '../data-view-row';

export interface TextDataViewRowProps<DataType>
  // IDataViewFieldProps requires an extra paramterization
  // that we don't actually rely on (nor does it, it's solely
  // used by subcomponents if they want it). Since we don't
  // rely on it there's no point in forcing our users to also
  // require setting it so using any
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  extends IRevisionHistoryWrapperDataViewProp {
  valueExtractor: (data: DataType | null) => string | null;
}

const EditText = (props: {
  field: string;
  value: string | null;
  setValue?: UseFormSetValue<FieldValues>;
  errors?: DeepMap<FieldValues, FieldError>;
  isReadOnly?: boolean;
}) => {
  const [selection, setSelection] = useState<string | null>(props.value ? props.value : null);
  if (props.setValue) {
    props.setValue(props.field, selection);
  }
  return (
    <FormGroup
      id={`${props.field}-fg`}
      errorMessages={props.errors ? hookFormUtils.getErrorMessages(props.errors, props.field) : undefined}
    >
      <TextInput
        id={`${props.field}-text`}
        type={TextInputType.text}
        value={selection != null ? selection : undefined}
        onChange={(event) => {
          setSelection(event.target.value);
        }}
        readOnly={props.isReadOnly}
      />
    </FormGroup>
  );
};

export const TextDataViewRow = <WrapperDataType, ResponseType>(
  props: TextDataViewRowProps<WrapperDataType>
): IDataViewFieldProps<ResponseType> => {
  return DataViewRow({
    ...props,
    displayConverter: (val) => val,
    createEditMode: createEditModeFunction(props),
  });
};

export const RevisionHistoryWrapperTextView = <Data,>(
  props: IRevisionHistoryWrapperDataViewProp
): IDataViewFieldProps<Data> => {
  const textLineItemProps: TextDataViewRowProps<string> = {
    ...props,
    valueExtractor: function (data: string | null): string | null {
      return data ? data : null;
    },
  };
  //DataViewFieldProps typing does not matter. It is typing a property that isn't even used
  //so we are telling typescript to coalesce it to the right parameterized type. The type we care
  //about is already called back to us as 'unknown' despite being a specific wanted type
  //We do not want to modify the parent though as it is used in other parts of ELIS
  //and would be a larger refactoring
  return TextDataViewRow(textLineItemProps) as unknown as IDataViewFieldProps<Data>;
};

const phoneNumberDisplayConverter = (phoneNumberOrig: string | null) => {
  if (phoneNumberOrig) {
    const strippedNumber = phoneNumberOrig.replace(/\D/g, '');
    if (10 === strippedNumber.length) {
      return '('
        .concat(strippedNumber.substring(0, 3))
        .concat(') ')
        .concat(strippedNumber.substring(3, 6))
        .concat('-')
        .concat(strippedNumber.substring(6));
    } else {
      return phoneNumberOrig;
    }
  } else {
    return phoneNumberOrig;
  }
};

const createEditModeFunction = <WrapperDataType,>(props: TextDataViewRowProps<WrapperDataType>) => {
  return (typedValue: IRevisionHistoryWrapperData<WrapperDataType>) => (
    <EditText
      field={props.field}
      value={getDisplayFromRevisionHistory(typedValue, props.valueExtractor, (item) => item)}
      setValue={props.setValue}
      errors={props.errors}
      isReadOnly={isDataViewRowReadOnly(props.isEditable)}
    />
  );
};

//Only allow numbers currently. Might want to consider alternatives in the future?
export const PHONE_REGEXP = new RegExp('^\\d*$');
export const PHONE_MATCHES_FAIL_MESSAGE = 'Enter numerical values only.';
export const PhoneDataViewRow = <WrapperDataType, ResponseType>(
  props: TextDataViewRowProps<WrapperDataType>
): IDataViewFieldProps<ResponseType> => {
  return DataViewRow({
    ...props,
    displayConverter: phoneNumberDisplayConverter,
    createEditMode: createEditModeFunction(props),
  });
};

const currencyDisplayConverter = (currencyOrig: string | null) => {
  if (currencyOrig) {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(Number(currencyOrig));
  } else {
    return currencyOrig;
  }
};

export const CurrencyDataViewRow = <WrapperDataType, ResponseType>(
  props: TextDataViewRowProps<WrapperDataType>
): IDataViewFieldProps<ResponseType> => {
  return DataViewRow({
    ...props,
    displayConverter: currencyDisplayConverter,
    createEditMode: createEditModeFunction(props),
  });
};
