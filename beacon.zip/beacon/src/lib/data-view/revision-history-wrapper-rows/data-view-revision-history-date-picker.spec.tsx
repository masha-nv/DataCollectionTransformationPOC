import React from 'react';
import { render } from '@testing-library/react';
import { IDataViewFieldProps } from '../data-view-types';
import { IRevisionHistoryWrapperData } from './data-view-revision-history-wrapper-types';
import { RevisionHistoryWrapperDatePickerView } from './data-view-revision-history-date-picker';
import { DeepMap, FieldError, FieldValues } from 'react-hook-form';
import userEvent from '@testing-library/user-event';

const mockCalenderSelectionDate = new Date(2020, 11, 11);

jest.mock('../../forms/date-picker/calendar', () => {
  const ComponentToMock = ({ onDateSelection }: { onDateSelection: (date: Date) => void }) => {
    const dateSelectionMockEvent = () => {
      onDateSelection(mockCalenderSelectionDate);
    };
    return (
      <div tabIndex={0}>
        <span>Calendar Mock</span>
        <input type="button" value="CalenderSelection" onClick={dateSelectionMockEvent} />
      </div>
    );
  };

  return {
    Calendar: ComponentToMock,
  };
});

interface TestDataObj {
  firstEntry: IRevisionHistoryWrapperData<string>;
}

const TEST_DATA_MOCK = {
  firstEntry: {
    latest: {
      item: '09/09/2099',
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1743699400657,
      sourceType: 'INTERNAL',
      revisionNumber: 2,
    },
    history: [
      {
        item: '01/01/1990',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
};

const TEST_DATA_MOCK_NULL = JSON.parse(JSON.stringify(TEST_DATA_MOCK));
TEST_DATA_MOCK_NULL.firstEntry.latest = null;

const formlessFirstEntry = RevisionHistoryWrapperDatePickerView<TestDataObj>({
  field: 'firstEntry',
  label: 'label for entry',
});

describe('DataView RevisionHistory Date Picker', () => {
  const renderReadOnly = (data: TestDataObj) => {
    const { baseElement } = render(<>{formlessFirstEntry.readonly(data.firstEntry, data, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  };

  it('renders readonly', () => {
    renderReadOnly(TEST_DATA_MOCK);
  });

  it('renders readonly null', () => {
    renderReadOnly(TEST_DATA_MOCK_NULL);
  });

  it('renders details', () => {
    const { baseElement } = render(<>{formlessFirstEntry.details(TEST_DATA_MOCK.firstEntry, TEST_DATA_MOCK, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  });

  const renderEdit = (data: TestDataObj) => {
    const { baseElement } = render(<>{formlessFirstEntry.edit(data.firstEntry, data, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  };

  it('renders in edit mode', () => {
    renderEdit(TEST_DATA_MOCK);
  });

  it('renders in edit mode -- null', () => {
    renderEdit(TEST_DATA_MOCK_NULL);
  });

  it('does not error in edit mode if not in form', async () => {
    const { container } = render(<>{formlessFirstEntry.edit(TEST_DATA_MOCK.firstEntry, TEST_DATA_MOCK, 0)}</>);

    const input = container.getElementsByClassName('date-picker-input')[0] as HTMLInputElement;
    userEvent.clear(input);
    userEvent.type(input, '12131999');
  });

  it('renders in edit mode with form props and changes value', async () => {
    const errors: DeepMap<FieldValues, FieldError> = {};
    const setValue = jest.fn();
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperDatePickerView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      errors: errors,
      setValue: setValue,
    });

    const { container } = render(<>{firstEntry.edit(TEST_DATA_MOCK.firstEntry, TEST_DATA_MOCK, 0)}</>);

    const input = container.getElementsByClassName('date-picker-input')[0] as HTMLInputElement;
    userEvent.clear(input);
    userEvent.type(input, '12131999');

    expect(setValue.mock.calls[setValue.mock.calls.length - 1]).toEqual(['firstEntry', '12/13/1999']);
  });
});
