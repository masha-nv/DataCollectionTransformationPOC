import { ISelectOption, SelectOptionValue } from '../../forms/select/select.types';
import { IRevisionHistoryWrapperDataViewProp } from './data-view-revision-history-wrapper-types';

export interface IRevisionHistoryWrapperDataViewSingleSelectProp extends IRevisionHistoryWrapperDataViewProp {
  /**
   * This defines the list of options available for select
   */
  options: ISelectOption[];
}

export interface SelectDataViewRowProps<WrapperDataType, DataType extends SelectOptionValue>
  extends IRevisionHistoryWrapperDataViewProp {
  valueExtractor: (data: WrapperDataType | null) => DataType | null;

  /**
   * This defines the list of options available for select
   */
  options: ISelectOption[];
}
