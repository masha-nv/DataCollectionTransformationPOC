import { IDataViewFieldProps } from '../data-view-types';
import { RevisionHistoryWrapperRadioDataView } from './data-view-revision-history-radio';
import {
  IRevisionHistoryWrapperDataViewRadioProp,
  IRevisionHistoryWrapperRadioOption,
} from './data-view-revision-history-radio-types';
import { IRevisionHistoryWrapperDataViewProp } from './data-view-revision-history-wrapper-types';

const YES_NO_OPTIONS: IRevisionHistoryWrapperRadioOption[] = [
  {
    value: 'Yes',
    label: 'Yes',
  },
  {
    value: 'No',
    label: 'No',
  },
];

export const RevisionHistoryWrapperYesNoDataView = <Data,>(
  props: IRevisionHistoryWrapperDataViewProp
): IDataViewFieldProps<Data> => {
  (props as IRevisionHistoryWrapperDataViewRadioProp).options = YES_NO_OPTIONS;
  (props as IRevisionHistoryWrapperDataViewRadioProp).inline = true;
  (props as IRevisionHistoryWrapperDataViewRadioProp).clearable = true;
  return RevisionHistoryWrapperRadioDataView(props as IRevisionHistoryWrapperDataViewRadioProp);
};
