import React from 'react';
import { render } from '@testing-library/react';
import { IDataViewFieldProps } from '../data-view-types';
import { IRevisionHistoryWrapperData } from './data-view-revision-history-wrapper-types';
import { RevisionHistoryWrapperYesNoDataView } from './data-view-revision-history-yes-no';

interface TestDataObj {
  firstEntry: IRevisionHistoryWrapperData<string>;
}

const TEST_DATA_YES = {
  firstEntry: {
    latest: {
      item: 'Yes',
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1743699400657,
      sourceType: 'INTERNAL',
      revisionNumber: 2,
    },
    history: [
      {
        item: 'No',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
};

describe('RevisionHistoryWrapperYesNoDataView', () => {
  it('renders in edit mode', () => {
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperYesNoDataView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
    });

    const { baseElement } = render(<>{firstEntry.edit(TEST_DATA_YES.firstEntry, TEST_DATA_YES, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  });
});
