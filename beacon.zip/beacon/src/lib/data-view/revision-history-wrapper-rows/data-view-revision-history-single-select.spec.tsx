import React from 'react';
import { render } from '@testing-library/react';
import { IDataViewFieldProps } from '../data-view-types';
import { IRevisionHistoryWrapperData } from './data-view-revision-history-wrapper-types';
import { RevisionHistoryWrapperSingleSelectView } from './data-view-revision-history-single-select';
import { DeepMap, FieldError, FieldValues } from 'react-hook-form';
import userEvent from '@testing-library/user-event';

interface TestDataObj {
  firstEntry: IRevisionHistoryWrapperData<string>;
}

const TEST_DATA_MOCK = {
  firstEntry: {
    latest: {
      item: '1243',
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1743699400657,
      sourceType: 'INTERNAL',
      revisionNumber: 3,
    },
    history: [
      {
        item: '56345',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 2,
      },
      {
        item: null,
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
};

const TEST_DATA_MOCK_NULL = JSON.parse(JSON.stringify(TEST_DATA_MOCK));
TEST_DATA_MOCK_NULL.firstEntry.latest = null;

const TEST_DATA_MOCK_INVALID_HISTORY_TEXT = {
  firstEntry: {
    latest: {
      item: '1243',
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1743699400657,
      sourceType: 'INTERNAL',
      revisionNumber: 2,
    },
    history: [
      {
        item: '9876',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
};

const TEST_OPTIONS = [
  {
    value: '1243',
    label: 'Field1',
  },
  {
    value: '56345',
    label: 'Field2',
  },
  {
    value: '7623',
    label: 'Field3',
  },
];

describe('DataView RevisionHistory Single Select', () => {
  const renderReadOnly = (data: TestDataObj) => {
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperSingleSelectView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      options: TEST_OPTIONS,
    });

    const { baseElement } = render(<>{firstEntry.readonly(data.firstEntry, data, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  };

  it('renders readonly', () => {
    renderReadOnly(TEST_DATA_MOCK);
  });

  it('renders readonly null', () => {
    renderReadOnly(TEST_DATA_MOCK_NULL);
  });

  it('renders details mode', async () => {
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperSingleSelectView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      options: TEST_OPTIONS,
    });

    const { baseElement, findByText } = render(<>{firstEntry.details(TEST_DATA_MOCK.firstEntry, TEST_DATA_MOCK, 0)}</>);
    await findByText('Field2');
    expect(baseElement).toMatchSnapshot();
  });

  it('renders details mode with invalid value in history', async () => {
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperSingleSelectView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      options: TEST_OPTIONS,
    });

    const { baseElement, findByText } = render(
      <>{firstEntry.details(TEST_DATA_MOCK_INVALID_HISTORY_TEXT.firstEntry, TEST_DATA_MOCK_INVALID_HISTORY_TEXT, 0)}</>
    );
    await findByText('9876');
    expect(baseElement).toMatchSnapshot();
  });

  const renderEdit = (data: TestDataObj) => {
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperSingleSelectView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      options: TEST_OPTIONS,
    });

    const { baseElement } = render(<>{firstEntry.edit(data.firstEntry, data, 0)}</>);
    expect(baseElement).toMatchSnapshot();
  };

  it('renders in edit mode', () => {
    renderEdit(TEST_DATA_MOCK);
  });

  it('renders in edit mode -- null', () => {
    renderEdit(TEST_DATA_MOCK_NULL);
  });

  it('renders in edit mode with form props and changes value -- select second option', async () => {
    const errors: DeepMap<FieldValues, FieldError> = {};
    const setValue = jest.fn();
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperSingleSelectView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      errors: errors,
      setValue: setValue,
      options: TEST_OPTIONS,
    });

    const { baseElement, getByText, findByText } = render(
      <>{firstEntry.edit(TEST_DATA_MOCK.firstEntry, TEST_DATA_MOCK, 0)}</>
    );
    const input = baseElement.getElementsByClassName('select-filterable')[0] as HTMLSelectElement;
    userEvent.click(input);
    await findByText('Field2');
    userEvent.click(getByText('Field2'));
    userEvent.click(input);
    await findByText('Field3');
    userEvent.click(getByText('Field3'));
    expect(setValue.mock.calls).toEqual([
      ['firstEntry', '1243'],
      ['firstEntry', '56345'],
      ['firstEntry', '7623'],
    ]);
  });

  it('renders in edit mode with form props and does not change value without setValue function passed', async () => {
    const errors: DeepMap<FieldValues, FieldError> = {};
    const firstEntry: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperSingleSelectView<TestDataObj>({
      field: 'firstEntry',
      label: 'label for entry',
      errors: errors,
      options: TEST_OPTIONS,
    });

    const { baseElement, getByText, findByText } = render(
      <>{firstEntry.edit(TEST_DATA_MOCK.firstEntry, TEST_DATA_MOCK, 0)}</>
    );
    const input = baseElement.getElementsByClassName('select-filterable')[0] as HTMLSelectElement;
    userEvent.click(input);
    await findByText('Field2');
    userEvent.click(getByText('Field2'));
    expect(baseElement).toMatchSnapshot();
  });
});
