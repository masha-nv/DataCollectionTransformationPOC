import {
  IRevisionHistoryWrapperData,
  IRevisionHistoryWrapperDataViewProp,
} from './data-view-revision-history-wrapper-types';
import { DeepMap, FieldError, FieldValues, UseFormSetValue } from 'react-hook-form';
import { IDataViewFieldProps } from '../data-view-types';
import { DataViewRow, getValueFromRevisionHistory } from './data-view-revision-history';
import { SimpleCheckboxList } from '../../forms/checkboxes/simple-checkboxes/simple-checkbox-list';
import { CheckboxValueType } from '../../forms/checkboxes/checkbox';
import { ISimpleCheckboxOptionProp } from '../../forms/checkboxes/simple-checkboxes/simple-checkbox-list-types';
import { isDataViewRowReadOnly } from '../data-view-row';

export interface IRevisionHistoryWrapperDataViewCheckboxListProp extends IRevisionHistoryWrapperDataViewProp {
  /**
   * Options to display in edit mode
   */
  options: ISimpleCheckboxOptionProp[];
}

export interface ChecklistDataViewRowProps<WrapperDataType, DataType extends CheckboxValueType[]>
  extends IRevisionHistoryWrapperDataViewProp {
  valueExtractor: (data: WrapperDataType[] | null) => DataType | null;

  /**
   * This defines the list of options available
   */
  options: ISimpleCheckboxOptionProp[];
}

const EditCheckboxesForm = (props: {
  field: string;
  value: CheckboxValueType[] | null;
  options: ISimpleCheckboxOptionProp[];
  setValue?: UseFormSetValue<FieldValues>;
  errors?: DeepMap<FieldValues, FieldError>;
  isReadOnly?: boolean;
}) => {
  return (
    <SimpleCheckboxList
      id={props.field}
      field={props.field}
      errors={props.errors}
      //Clear out older entries upon loading the edit checkbox list
      value={props.value ? props.value.filter((item) => props.options.some((option) => option.value === item)) : []}
      setValue={props.setValue}
      options={props.options}
      isReadOnly={props.isReadOnly}
    />
  );
};

const getDisplayValueForSingularItem = (value: CheckboxValueType, options: ISimpleCheckboxOptionProp[]) => {
  let text = undefined;
  options.forEach((option) => {
    if (value === option.value) {
      text = option.label;
    }
  });

  if (text) {
    return text;
  } else {
    return value;
  }
};

const convertToDisplayValue = (value: CheckboxValueType[] | null, options: ISimpleCheckboxOptionProp[]) => {
  return (
    <div>
      {value != null
        ? value.map((item) => <div key={item}>• {getDisplayValueForSingularItem(item, options)}</div>)
        : ''}
    </div>
  );
};

export const ChecklistDataViewRow = <WrapperDataType,>(
  props: ChecklistDataViewRowProps<WrapperDataType, CheckboxValueType[]>
): IDataViewFieldProps<ResponseType> => {
  const displayConverter = (value: CheckboxValueType[] | null) => convertToDisplayValue(value, props.options);

  return DataViewRow({
    ...props,
    displayConverter: displayConverter,
    createEditMode: (value: IRevisionHistoryWrapperData<WrapperDataType[]>) => {
      return (
        <EditCheckboxesForm
          field={props.field}
          value={getValueFromRevisionHistory(value, props.valueExtractor)}
          setValue={props.setValue}
          errors={props.errors}
          options={props.options}
          isReadOnly={isDataViewRowReadOnly(props.isEditable)}
        />
      );
    },
  });
};

export const RevisionHistoryWrapperCheckboxesView = <Data,>(
  props: IRevisionHistoryWrapperDataViewCheckboxListProp
): IDataViewFieldProps<Data> => {
  const radioDataViewRowProps: ChecklistDataViewRowProps<CheckboxValueType, CheckboxValueType[]> = {
    ...props,
    valueExtractor: function (data: CheckboxValueType[] | null): CheckboxValueType[] | null {
      return data;
    },
  };

  return ChecklistDataViewRow(radioDataViewRowProps) as unknown as IDataViewFieldProps<Data>;
};
