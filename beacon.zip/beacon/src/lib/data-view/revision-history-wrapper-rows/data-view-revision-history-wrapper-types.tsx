import { DeepMap, FieldError, FieldValues, UseFormSetValue } from 'react-hook-form';
import { IDataViewFieldProps } from '../data-view-types';

export interface RevisionHistory<T> {
  item: T;
  enteredBy: string;
  dateOfAnswer: number;
  sourceType: string;
  revisionNumber: number;
  isDeactivated?: boolean | null;
}

export interface IRevisionHistoryWrapperData<T> {
  latest: RevisionHistory<T> | null;
  history: RevisionHistory<T>[];
}

// IDataViewFieldProps requires an extra paramterization
// that we don't actually rely on (nor does it, it's solely
// used by subcomponents if they want it). Since we don't
// rely on it there's no point in forcing our users to also
// require setting it so using any
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export interface IRevisionHistoryWrapperDataViewProp extends IDataViewFieldProps<any> {
  /**
   * Where to store errors if one occurs
   */
  errors?: DeepMap<FieldValues, FieldError>;
  /**
   * Setter to call when the value updates
   */
  setValue?: UseFormSetValue<FieldValues>;
  /**
   * The type of dataview to create (e.g. yes-no, dropdown, free-text, etc)
   */
  type?: string;
  /**
   * The path to the data in the Data object
   */
  field: string;
  /**
   * Add clear button
   */
  clearable?: boolean;
  /**
   * Display options inline
   */
  inline?: boolean;
}
