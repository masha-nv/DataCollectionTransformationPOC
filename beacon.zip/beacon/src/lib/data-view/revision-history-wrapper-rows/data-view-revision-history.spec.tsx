import React from 'react';
import { render } from '@testing-library/react';
import { IRevisionHistoryWrapperData, RevisionHistory } from './data-view-revision-history-wrapper-types';
import { IDataViewFieldProps } from '../data-view-types';
import { RevisionHistoryWrapperYesNoDataView } from './data-view-revision-history-yes-no';
import { RevisionHistoryWrapperTextView } from './data-view-revision-history-text';

interface TestDataObj {
  withHistory: IRevisionHistoryWrapperData<string>;
  withDeactivatedHistory: IRevisionHistoryWrapperData<string>;
  withoutHistoryInternal: IRevisionHistoryWrapperData<string>;
  withoutHistoryExternal: IRevisionHistoryWrapperData<string>;
}

const TEST_DATA = {
  withHistory: {
    latest: {
      item: 'Yes',
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1743699400657,
      sourceType: 'INTERNAL',
      revisionNumber: 3,
    },
    history: [
      {
        item: 'No',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 2,
      },
      {
        item: null,
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  } as IRevisionHistoryWrapperData<string>,
  withDeactivatedHistory: {
    latest: {
      item: 'Yes',
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1743699400657,
      sourceType: 'INTERNAL',
      revisionNumber: 3,
    },
    history: [
      {
        item: 'No',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 2,
        isDeactivated: true,
      },
      {
        item: null,
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351185,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  } as IRevisionHistoryWrapperData<string>,
  withoutHistoryInternal: {
    latest: {
      item: 'Yes',
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1743699400657,
      sourceType: 'INTERNAL',
      revisionNumber: 1,
    },
    history: [] as RevisionHistory<string>[],
  } as IRevisionHistoryWrapperData<string>,
  withoutHistoryExternal: {
    latest: {
      item: 'Yes',
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1743699400657,
      sourceType: 'EXTERNAL',
      revisionNumber: 1,
    },
    history: [] as RevisionHistory<string>[],
  } as IRevisionHistoryWrapperData<string>,
};

const TEST_DATA_WITH_NULL_REVISION_HISTORY_OBJ = JSON.parse(JSON.stringify(TEST_DATA));
TEST_DATA_WITH_NULL_REVISION_HISTORY_OBJ.withHistory = null;

const withHistory: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperYesNoDataView<TestDataObj>({
  field: 'firstEntry',
  label: 'label for entry',
});

const withoutHistory: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperYesNoDataView<TestDataObj>({
  field: 'firstEntry',
  label: 'label for entry',
});

const withHistoryParamaterized: IDataViewFieldProps<TestDataObj> = RevisionHistoryWrapperTextView<TestDataObj>({
  field: 'firstEntry',
  label: 'label for entry',
});

describe('DataView RevisionHistory Common', () => {
  describe('read only view', () => {
    it('renders history paramaterized type', () => {
      const { baseElement } = render(<>{withHistoryParamaterized.readonly(TEST_DATA.withHistory, TEST_DATA, 0)}</>);
      expect(baseElement).toMatchSnapshot();
    });

    it('renders history paramaterized type with null revision', () => {
      //Mainly just ensuring we don't throw a null exception
      const { baseElement } = render(
        <>
          {withHistoryParamaterized.readonly(
            TEST_DATA_WITH_NULL_REVISION_HISTORY_OBJ.withHistory,
            TEST_DATA_WITH_NULL_REVISION_HISTORY_OBJ,
            0
          )}
        </>
      );
      expect(baseElement).toMatchSnapshot();
    });

    it('renders read only updated', async () => {
      const { baseElement, queryByText, findByText } = render(
        <>{withHistory.readonly(TEST_DATA.withHistory, TEST_DATA, 0)}</>
      );
      expect(queryByText('Added')).toBeFalsy();
      expect(await findByText('Updated')).toBeTruthy();
      expect(baseElement).toMatchSnapshot();
    });

    it('renders read only not updated and not added', async () => {
      const { baseElement, queryByText } = render(
        <>{withoutHistory.readonly(TEST_DATA.withoutHistoryExternal, TEST_DATA, 0)}</>
      );
      expect(queryByText('Added')).toBeFalsy();
      expect(queryByText('Updated')).toBeFalsy();
      expect(baseElement).toMatchSnapshot();
    });

    it('renders read only added', async () => {
      const { baseElement, findByText } = render(
        <>{withoutHistory.readonly(TEST_DATA.withoutHistoryInternal, TEST_DATA, 0)}</>
      );
      expect(await findByText('Added')).toBeTruthy();
      expect(baseElement).toMatchSnapshot();
    });
  });

  describe('edit mode', () => {
    it('renders editing view', () => {
      const { baseElement } = render(<>{withHistoryParamaterized.edit(TEST_DATA.withHistory, TEST_DATA, 0)}</>);
      expect(baseElement).toMatchSnapshot();
    });
  });

  describe('details view', () => {
    it('renders with history', async () => {
      const { baseElement, findAllByText } = render(
        <>{withHistoryParamaterized.details(TEST_DATA.withHistory, TEST_DATA, 0)}</>
      );
      expect(await findAllByText(/LOCKBOX/)).toBeTruthy();
      expect((await findAllByText(/LOCKBOX/)).length).toBe(2);
      expect(baseElement).toMatchSnapshot();
    });

    it('renders with history with a deactivated row', async () => {
      const { baseElement, findAllByText } = render(
        <>{withHistoryParamaterized.details(TEST_DATA.withDeactivatedHistory, TEST_DATA, 0)}</>
      );
      expect(await findAllByText(/LOCKBOX/)).toBeTruthy();
      expect((await findAllByText(/LOCKBOX/)).length).toBe(2);
      expect(baseElement).toMatchSnapshot();
    });
  });
});
