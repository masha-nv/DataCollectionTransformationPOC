import { IRevisionHistoryWrapperData } from './data-view-revision-history-wrapper-types';
import { DeepMap, FieldError, FieldValues, UseFormSetValue } from 'react-hook-form';
import { IDataViewFieldProps } from '../data-view-types';
import { DataViewRow, getValueFromRevisionHistory } from './data-view-revision-history';
import { ISimpleRadioOptionProp } from '../../forms/radio/simple-radio/simple-radio.types';
import { SimpleRadio } from '../../forms/radio/simple-radio/simple-radio';
import {
  IRevisionHistoryWrapperDataViewRadioProp,
  RadioDataViewRowProps,
} from './data-view-revision-history-radio-types';
import { RadioOptionType } from '../../forms/radio/radio-option';
import { isDataViewRowReadOnly } from '../data-view-row';

const EditRadioForm = (props: {
  field: string;
  value: RadioOptionType | null;
  options: ISimpleRadioOptionProp[];
  setValue?: UseFormSetValue<FieldValues>;
  errors?: DeepMap<FieldValues, FieldError>;
  inline?: boolean;
  clearable?: boolean;
  isReadOnly?: boolean;
}) => {
  return (
    <SimpleRadio
      id={props.field}
      field={props.field}
      label="Simple Radio:"
      errors={props.errors}
      value={props.value != null ? props.value : undefined}
      setValue={props.setValue}
      options={props.options}
      inline={props.clearable}
      clearable={props.clearable}
      isReadOnly={props.isReadOnly}
    />
  );
};

const convertToDisplayValue = (value: RadioOptionType | null, options: ISimpleRadioOptionProp[]): RadioOptionType => {
  if (value) {
    let text = undefined;
    options.forEach((option) => {
      if (value === option.value) {
        text = option.label;
      }
    });

    if (text) {
      return text;
    } else {
      return value;
    }
  } else {
    return '';
  }
};

export const RadioDataViewRow = <WrapperDataType,>(
  props: RadioDataViewRowProps<WrapperDataType, RadioOptionType>
): IDataViewFieldProps<ResponseType> => {
  const displayConverter = (value: RadioOptionType | null) => convertToDisplayValue(value, props.options);

  return DataViewRow({
    ...props,
    displayConverter: displayConverter,
    createEditMode: (typedValue: IRevisionHistoryWrapperData<WrapperDataType>) => {
      return (
        <EditRadioForm
          field={props.field}
          value={getValueFromRevisionHistory(typedValue, props.valueExtractor)}
          setValue={props.setValue}
          errors={props.errors}
          options={props.options}
          inline={props.inline}
          clearable={props.clearable}
          isReadOnly={isDataViewRowReadOnly(props.isEditable)}
        />
      );
    },
  });
};

export const RevisionHistoryWrapperRadioDataView = <Data,>(
  props: IRevisionHistoryWrapperDataViewRadioProp
): IDataViewFieldProps<Data> => {
  const radioDataViewRowProps: RadioDataViewRowProps<RadioOptionType, RadioOptionType> = {
    ...props,
    valueExtractor: function (data: RadioOptionType | null): RadioOptionType | null {
      return data;
    },
  };

  return RadioDataViewRow(radioDataViewRowProps) as unknown as IDataViewFieldProps<Data>;
};
