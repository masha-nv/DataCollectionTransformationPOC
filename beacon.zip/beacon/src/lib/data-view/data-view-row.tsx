import React, { useState, useEffect, ReactNode, SyntheticEvent, ReactElement } from 'react';
import { getPropertyValueFromPath } from '../utils';
import { IDataViewFieldAction, IDataViewRowProps } from './data-view-types';
import { ActionMenu, ActionMenuType } from '../action-menu/dropdown-action-menu/action-menu';
import { Action } from '../action-menu/dropdown-action-menu/action';
import { IconType } from '../icon/icon';
import { Label } from '../forms/label/label';
import './data-view.scss';
import { IBadgeProps } from '../notifications/badge/badge';

const getValueFromProps = <T,>(props: IDataViewRowProps<T>): unknown => {
  return props.field.field && getPropertyValueFromPath(props.data as Record<string, unknown>, props.field.field);
};

export const isDataViewRowReadOnly = (isEditable?: boolean) => {
  //Should've had this be isReadOnly but is already exported in the library
  //(We need this method because by making it isEditable and optional,
  //we are mapping undefined to true which is normally a false value)
  return !(isEditable ?? true);
};

const getView = <T,>(props: IDataViewRowProps<T>, value: unknown): ReactNode => {
  if (props.isEditing && props.field.edit) {
    return props.field.edit(value, props.data, props.index);
  } else if (props.field.isDeactivated) {
    return (
      <div>
        <s>{getDisplayValueNonEditMode(props, value)}</s>
      </div>
    );
  } else {
    return <div>{getDisplayValueNonEditMode(props, value)}</div>;
  }
};

const getDisplayValueNonEditMode = <T,>(props: IDataViewRowProps<T>, value: unknown) => {
  return props.field.readonly ? props.field.readonly(value, props.data, props.index) : (value as string);
};

const getActions = <T,>(props: IDataViewRowProps<T>) => {
  let actions = props.field.actions;
  if (!actions && props.field.details) {
    actions = (value: unknown, data: T, index: number, toggle: () => void) => {
      return [
        {
          label: 'Show Details',
          onClick: toggle,
          labelSecondary: 'Hide Details',
        },
      ];
    };
  }
  return actions;
};

const getCurrentLabel = (isShowingDetails: boolean, action: IDataViewFieldAction): string => {
  return isShowingDetails && action.labelSecondary ? action.labelSecondary : action.label;
};

const getCurrentOnClick = (
  isShowingDetails: boolean,
  action: IDataViewFieldAction
): ((param: SyntheticEvent) => void) => {
  return isShowingDetails && action.onClickSecondary ? action.onClickSecondary : action.onClick;
};

const getActionMenuTitle = <T,>(props: IDataViewRowProps<T>): string => {
  let actionMenuTitle = props.field.menuButtonTitle;
  if (!actionMenuTitle) {
    actionMenuTitle = typeof props.field.label === 'string' ? `Actions for "${props.field.label}"` : 'Actions';
  }
  return actionMenuTitle;
};

const getBadgeToRender = <T,>(props: IDataViewRowProps<T>, value: unknown): ReactElement<IBadgeProps> | null => {
  let badgeToRender = null;
  if (props.field.badge) {
    badgeToRender = props.field.badge(value, props.data, props.index);
  }
  return badgeToRender;
};

export const DataViewRow = <T,>(props: IDataViewRowProps<T>) => {
  const [isShowingDetails, setIsShowingDetails] = useState(false);

  useEffect(() => {
    setIsShowingDetails(!!props.isExpanded);
  }, [props.isExpanded]);

  const value = getValueFromProps<T>(props);
  // Set view for readonly or edit
  const view = getView<T>(props, value);
  // set action
  const actions = getActions<T>(props);

  const actionMenu = actions?.(value, props.data, props.index, () => setIsShowingDetails(!isShowingDetails)).map(
    (action) => {
      const currentLabel = getCurrentLabel(isShowingDetails, action);
      const currentOnClick = getCurrentOnClick(isShowingDetails, action);
      return (
        <Action
          key={`${props.id}-actionmenu-${currentLabel}`}
          id={`${props.id}-actionmenu-${currentLabel}`}
          onClick={currentOnClick}
        >
          {currentLabel}
        </Action>
      );
    }
  );

  const actionMenuTitle = getActionMenuTitle(props);

  const badgeToRender = getBadgeToRender(props, value);

  return (
    <>
      <tr
        id={props.id}
        className={`dataview-row ${props.isEditing ? 'table-quickview-edit-mode' : ''} ${
          props.field.details && isShowingDetails ? 'dataview-row-expanded' : 'dataview-row-collapsed'
        }`}
        tabIndex={0}
        aria-expanded={props.field.details ? isShowingDetails : undefined}
        aria-describedby={props.field.details ? `${props.id}-details` : undefined}
      >
        <td className="dataview-row-col-label">
          <Label required={props.isEditing && props.field.isFieldRequired} className="data-list-item-label">
            {props.field.label}
          </Label>
        </td>
        <td className="dataview-row-col-badge">{badgeToRender}</td>
        <td className="dataview-row-col-value">{view}</td>
        <td className="dataview-row-col-actions">
          {!!actionMenu && (
            <div className="beacon-row-col-actions-container">
              <span className="beacon-dataview-menu-ellipsis">
                <ActionMenu
                  id={`${props.id}-actionmenu`}
                  label="..."
                  iconLabelType={IconType.ellipsis}
                  isShiftedLeft={props.field.isShiftedLeft !== false}
                  menuButtonTitle={actionMenuTitle}
                  type={ActionMenuType.menuEllipsis}
                >
                  {actionMenu}
                </ActionMenu>
              </span>
            </div>
          )}
        </td>
      </tr>
      {props.field.details && (
        <tr id={`${props.id}-details`} className="dataview-details-row" hidden={!isShowingDetails}>
          <td colSpan={2}></td>
          <td className={`data-list-details`} colSpan={2}>
            {props.field.details(value, props.data, props.index)}
          </td>
        </tr>
      )}
    </>
  );
};
