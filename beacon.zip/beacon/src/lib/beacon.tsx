import React from 'react';
import './root-variables.scss';
export interface IBeaconProperties {
  /**
   * The current version of Beacon
   */
  version?: string;
}

const SonarBadge = ({ metric }: { metric: string }) => {
  return (
    <a
      href="http://sonar-enterprise.uscis.dhs.gov:9000/dashboard?id=gov.dhs.uscis.react-beacon"
      target="_blank"
      rel="noreferrer"
    >
      <img
        alt={`React Beacon ${metric}`}
        src={`https://elis-apigw-pp.apps2.ocp-nonprod.uscis.dhs.gov/elis-sonar/measure?project=gov.dhs.uscis.react-beacon&metric=${metric}`}
      />
    </a>
  );
};
/**
 * This is the main `Beacon` component, this component is not intended to be used, it's only here for documentation purposes
 */
export function Beacon({ version = 'local-development' }) {
  return (
    <main>
      <h1>
        Welcome to React Beacon{' '}
        <small>
          <code>({version})</code>
        </small>
      </h1>
      <p>This is the React Beacon project which contains the components for using Beacon in react</p>

      <h2>Installation</h2>
      <p>
        React Beacon is simple to install, just run <code>npm install --save @gov.dhs.uscis.elis/react-beacon</code>.
      </p>

      <h2>Additional Links</h2>
      <ul>
        <li>
          <a
            href="https://jenkins-elis-gss.uscis.dhs.gov/job/ELIS-Non-Prod/job/elis-user-interface/job/react-beacon-ci/"
            rel="noreferrer"
            target="_blank"
          >
            <img
              alt="React Beacon build status"
              src="https://jenkins-elis-gss.uscis.dhs.gov/buildStatus/icon?job=ELIS-Non-Prod%2Felis-user-interface%2Freact-beacon-ci"
            />
          </a>
        </li>
        <li>
          <SonarBadge metric="alert_status" />
        </li>
        <li>
          <SonarBadge metric="coverage" />
        </li>
        <li>
          <SonarBadge metric="code_smells" />
        </li>
      </ul>

      <h2>Support/Getting Help</h2>

      <p>
        Any <strong>development</strong> questions can be asked on the{' '}
        <a href="https://teams.microsoft.com/l/channel/19%3a1eb717f4d3a342a2aa2cd84751de029f%40thread.skype/React-reactions?groupId=68e8af3e-287e-48d0-83cf-9f200b00a864&tenantId=5e41ee74-0d2d-4a72-8975-998ce83205eb">
          React Beacon Teams Channel.
        </a>
      </p>
    </main>
  );
}

export default Beacon;
