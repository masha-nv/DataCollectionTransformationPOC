import React from 'react';
import { render, fireEvent, waitFor, act, screen } from '@testing-library/react';
import {
  MultiSelectBasic,
  MultiSelectLabel,
  MultiSelectDefault,
  MultiSelectDisabled,
  MultiSelectControlled,
} from './multi-select.stories';
import userEvent from '@testing-library/user-event';
import { SelectOption } from '../select/select';
import { MultiSelect } from './multi-select';

jest.mock('../analytics/matomo', () => {
  const module = jest.requireActual('../analytics/matomo');
  return {
    ...module,
    track: jest.fn(),
  };
});

describe('MultiSelect Component', () => {
  it('renders default', () => {
    const { baseElement } = render(<MultiSelectBasic />);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with label', () => {
    const { baseElement } = render(<MultiSelectLabel />);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with default selected', () => {
    const { baseElement } = render(<MultiSelectDefault />);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with disabled', () => {
    const { baseElement } = render(<MultiSelectDisabled />);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders controlled', () => {
    const { baseElement } = render(<MultiSelectControlled />);
    expect(baseElement).toMatchSnapshot();
  });

  it('can select options', async () => {
    const { baseElement, getByRole, getByText, findByText } = render(<MultiSelectBasic />);
    getByRole('button').click();
    await findByText('Third option');
    getByText('Third option').click();
    expect(baseElement).toMatchSnapshot();
  });

  it('can select all options manually', async () => {
    const { baseElement, getByRole, getByText, findByText } = render(<MultiSelectBasic />);
    getByRole('button').click();
    await findByText('First option');
    getByText('First option').click();
    await findByText('Second option');
    getByText('Second option').click();
    await findByText('Third option');
    getByText('Third option').click();
    await findByText('Fourth option');
    getByText('Fourth option').click();
    await findByText('Fifth option');
    getByText('Fifth option').click();
    expect(baseElement).toMatchSnapshot();
  });

  it('can deselect options', async () => {
    const { baseElement, getByText } = render(<MultiSelectDefault />);
    getByText('Fourth option', { selector: 'button' }).click();
    expect(baseElement).toMatchSnapshot();
  });

  it('can open dropdown with Up Arrow key', async () => {
    const { baseElement, getByRole, findByText } = render(<MultiSelectBasic />);
    getByRole('button').focus();
    userEvent.type(getByRole('button'), '{arrowup}', { skipClick: true });
    await findByText('First option');
    expect(baseElement).toMatchSnapshot();
  });

  it('can open dropdown with Down Arrow key', async () => {
    const { baseElement, getByRole, findByText } = render(<MultiSelectBasic />);
    getByRole('button').focus();
    userEvent.type(getByRole('button'), '{arrowdown}', { skipClick: true });
    await findByText('First option');
    expect(baseElement).toMatchSnapshot();
  });

  it('can focus dropdown with Tab key', async () => {
    const { baseElement, getByRole, findByText, getByText } = render(<MultiSelectBasic />);
    const selectButton = getByRole('button');
    selectButton.click();
    await findByText('Third option');
    fireEvent.keyDown(selectButton, { key: 'Tab', code: 'Tab' });
    expect(document.activeElement).toEqual(getByText('First option'));
    expect(baseElement).toMatchSnapshot();
  });

  it('can close dropdown with Escape key', async () => {
    const { baseElement, getByRole } = render(<MultiSelectBasic />);
    userEvent.type(getByRole('button'), '{esc}');
    expect(baseElement).toMatchSnapshot();
  });

  it('can close dropdown with Blur event', async () => {
    const { baseElement, getByRole, findByText, getByText } = render(<MultiSelectBasic />);
    getByRole('button').click();
    await findByText('Fifth option');
    getByText('Fifth option').focus();
    fireEvent.blur(getByText('Fifth option'));
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with placeholder text', () => {
    const { baseElement } = render(
      <MultiSelect id="multi-select-test" placeholder="Filter">
        <SelectOption value="Option 1">Option 1</SelectOption>
        <SelectOption value="Option 2">Option 2</SelectOption>
        <SelectOption value="Option 3">Option 3</SelectOption>
      </MultiSelect>
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('can select all options using Add All', async () => {
    const { baseElement, getByRole, findByText, getByText } = render(
      <MultiSelect id="multi-select-test" allowAddAll={true}>
        <SelectOption value="Option 1">Option 1</SelectOption>
        <SelectOption value="Option 2">Option 2</SelectOption>
        <SelectOption value="Option 3">Option 3</SelectOption>
      </MultiSelect>
    );
    getByRole('button').click();
    await findByText('Add All Options');
    getByText('Add All Options').click();
    expect(baseElement).toMatchSnapshot();
  });

  it('can select all options using alternate text', async () => {
    const { baseElement, getByRole, findByText, getByText } = render(
      <MultiSelect id="multi-select-test" allowAddAll={true} addAllText="Add All">
        <SelectOption value="Option 1">Option 1</SelectOption>
        <SelectOption value="Option 2">Option 2</SelectOption>
        <SelectOption value="Option 3">Option 3</SelectOption>
      </MultiSelect>
    );
    getByRole('button').click();
    await findByText('Add All');
    getByText('Add All').click();
    expect(baseElement).toMatchSnapshot();
  });

  it('can call onSelected function', async () => {
    const onSelected = jest.fn();
    const { getByRole, findByText, getByText } = render(
      <MultiSelect id="multi-select-test" onSelected={onSelected}>
        <SelectOption value="Value1">Option1</SelectOption>
        <SelectOption value="Value2">Option2</SelectOption>
      </MultiSelect>
    );
    getByRole('button').click();
    await findByText('Option1');
    getByText('Option1').click();
    expect(onSelected).toHaveBeenCalled();
  });

  it('can call onDeselected function', async () => {
    const onDeselected = jest.fn();
    const { getByText } = render(
      <MultiSelect id="multi-select-test" onDeselected={onDeselected}>
        <SelectOption value="Value1" defaultSelected={true}>
          Option1
        </SelectOption>
        <SelectOption value="Value2">Option2</SelectOption>
      </MultiSelect>
    );
    getByText('Option1', { selector: 'button' }).click();
    expect(onDeselected).toHaveBeenCalled();
  });

  it('raises onChange event on selection', async () => {
    const onChange = jest.fn();
    const { getByRole, findByText, getByText } = render(
      <MultiSelect id="multi-select-test" onChange={onChange}>
        <SelectOption value="Value1">Option1</SelectOption>
        <SelectOption value="Value2">Option2</SelectOption>
      </MultiSelect>
    );
    getByRole('button').click();
    await findByText('Option1');
    getByText('Option1', { selector: 'button' }).click();
    expect(onChange).toHaveBeenCalledWith(
      {
        target: expect.objectContaining({
          value: ['Value1'],
        }),
      },
      expect.arrayContaining([expect.objectContaining({ value: 'Value1' })])
    );
  });

  it('raises onChange event on selection', async () => {
    const onChange = jest.fn();
    const { getByText } = render(
      <MultiSelect id="multi-select-test" onChange={onChange}>
        <SelectOption value="Value1" defaultSelected={true}>
          Option1
        </SelectOption>
        <SelectOption value="Value2" defaultSelected={true}>
          Option2
        </SelectOption>
        <SelectOption value="Value3" defaultSelected={true}>
          Option3
        </SelectOption>
      </MultiSelect>
    );
    getByText('Option1', { selector: 'button' }).click();

    expect(onChange).toHaveBeenCalledWith(
      {
        target: expect.objectContaining({
          value: ['Value2', 'Value3'],
        }),
      },
      expect.arrayContaining([
        expect.objectContaining({ value: 'Value2' }),
        expect.objectContaining({ value: 'Value3' }),
      ])
    );
  });

  it('should render a controlled Multi-Select with props.selectedOptions', () => {
    const selectedOptions = ['Option 1'];
    const { baseElement } = render(
      <MultiSelect id="multi-select-test" selectedOptions={selectedOptions}>
        <SelectOption value="Option 1">Option 1</SelectOption>
        <SelectOption value="Option 2">Option 2</SelectOption>
        <SelectOption value="Option 3">Option 3</SelectOption>
      </MultiSelect>
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('no values found matching filter', async () => {
    const selectedOptions = ['Option 2', null];
    const { baseElement, findByText } = render(
      <MultiSelect id="multi-select-test" selectedOptions={selectedOptions} filterable>
        <SelectOption value="Option 1">Option 1</SelectOption>
        <SelectOption value="Option 2">Option 2</SelectOption>
        <SelectOption value={null}>Option 3</SelectOption>
        <SelectOption value="Option 4">Option 4</SelectOption>
      </MultiSelect>
    );

    const selectElement = baseElement.querySelector('#multi-select-test-button');
    act(() => {
      userEvent.click(selectElement);
    });
    const filterInput = baseElement.querySelector('#multi-select-test-filter');
    act(() => {
      fireEvent.click(filterInput);
    });
    userEvent.type(filterInput, '2');
    await waitFor(() => expect(filterInput.getAttribute('value')).toEqual('2'));

    await findByText('Your input does not match any options');
    expect(baseElement).toMatchSnapshot();
  });

  it('filtered value found', async () => {
    const selectedOptions = ['Option 2', null];
    const { baseElement } = render(
      <MultiSelect id="multi-select-test" selectedOptions={selectedOptions} filterable>
        <SelectOption value="Option 1">Option 1</SelectOption>
        <SelectOption value="Option 2">Option 2</SelectOption>
        <SelectOption value={null}>Option 3</SelectOption>
        <SelectOption value="Option 4">Option 4</SelectOption>
      </MultiSelect>
    );

    const selectElement = baseElement.querySelector('#multi-select-test-button');
    act(() => {
      userEvent.click(selectElement);
    });
    const filterInput = baseElement.querySelector('#multi-select-test-filter');
    act(() => {
      fireEvent.click(filterInput);
    });
    userEvent.type(filterInput, '4');
    await waitFor(() => expect(filterInput.getAttribute('value')).toEqual('4'));

    await waitFor(() => expect(baseElement.querySelector('#multi-select-test-options-menu-option-0')).not.toBeNull());
    expect(baseElement).toMatchSnapshot();
  });

  it('filtered by display text', async () => {
    const { baseElement } = render(
      <MultiSelect id="multi-select-test" filterable label="filter by text">
        <SelectOption value="1">Option 1</SelectOption>
        <SelectOption value="2">Option 2</SelectOption>
        <SelectOption value="3">Option 3</SelectOption>
        <SelectOption value="4">Option 4</SelectOption>
      </MultiSelect>
    );

    await screen.findByText('filter by text');
    const filterInput = baseElement.querySelector('#multi-select-test-filter');
    userEvent.type(filterInput, 'Option 3');
    await waitFor(() => expect(filterInput.getAttribute('value')).toEqual('Option 3'));
    await waitFor(() => expect(baseElement.querySelector('#multi-select-test-options-menu-option-0')).not.toBeNull());
    expect(baseElement.querySelector('#multi-select-test-options-menu-option-0').getAttribute('value')).toEqual('3');
  });

  it('default values assigned properly', async () => {
    const { baseElement } = render(
      <MultiSelect id="multi-select-test">
        <SelectOption value="Option 1">Option 1</SelectOption>
        <SelectOption value="Option 2" defaultSelected>
          Option 2
        </SelectOption>
        <SelectOption value={null}>Option 3</SelectOption>
        <SelectOption value="Option 4">Option 4</SelectOption>
      </MultiSelect>
    );
    await waitFor(() =>
      expect(baseElement.querySelector('[id="multi-select-test-selected-option-0-Option 2"]')).toBeTruthy()
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('selectedOptions values assigned properly when there is overlap between selectedOptions and defaultSelected', async () => {
    const { baseElement } = render(
      <MultiSelect id="multi-select-test" selectedOptions={['Option 1', 'Option 2']}>
        <SelectOption value="Option 1" defaultSelected>
          Option 1
        </SelectOption>
        <SelectOption value="Option 2" defaultSelected>
          Option 2
        </SelectOption>
        <SelectOption value="Option 3" defaultSelected>
          Option 3
        </SelectOption>
        <SelectOption value="Option 4">Option 4</SelectOption>
      </MultiSelect>
    );
    await waitFor(() =>
      expect(baseElement.querySelector('[id="multi-select-test-selected-option-0-Option 1"]')).toBeTruthy()
    );
    expect(baseElement.querySelector('[id="multi-select-test-selected-option-1-Option 2"]')).toBeTruthy();
    expect(baseElement.querySelector('[id="multi-select-test-selected-option-2-Option 3"]')).toBeFalsy();
  });

  it('clears filter and closes dropdown when last option is selected', async () => {
    const { baseElement, getByText } = render(
      <MultiSelect id="multi-select-test" filterable>
        <SelectOption value="Option 1">Option 1</SelectOption>
        <SelectOption value="Option 2">Option 2</SelectOption>
        <SelectOption value="Option 3">Option 3</SelectOption>
        <SelectOption value="Option 4">Option 4</SelectOption>
      </MultiSelect>
    );
    const selectElement = baseElement.querySelector('#multi-select-test-button');
    act(() => {
      userEvent.click(selectElement);
    });
    const filterInput = baseElement.querySelector('#multi-select-test-filter');
    act(() => {
      fireEvent.click(filterInput);
    });
    userEvent.type(filterInput, '2');

    await waitFor(() => expect(filterInput.getAttribute('value')).toEqual('2'));
    await waitFor(() => expect(baseElement.querySelector('#multi-select-test-options-menu-option-0')).not.toBeNull());

    getByText('Option 2').click();

    await waitFor(() => expect(filterInput.getAttribute('value')).toEqual(''));
    await waitFor(() => expect(baseElement.querySelector('#multi-select-test-options-menu-option-0')).toBeNull());

    expect(baseElement).toMatchSnapshot();
  });

  it('should render a controlled Multi-Select correctly when props.selectedOptions is cleared', async () => {
    const { baseElement, findByRole } = render(<MultiSelectControlled />);
    userEvent.click(await findByRole('button', { name: 'Options Dropdown' }));
    userEvent.click(await findByRole('button', { name: 'First option' }));
    await waitFor(() =>
      expect(baseElement.querySelector('[id="multi-select-controlled-selected-option-0-First option"]')).toBeTruthy()
    );
    userEvent.click(await findByRole('button', { name: 'Second option' }));
    await waitFor(() =>
      expect(baseElement.querySelector('[id="multi-select-controlled-selected-option-1-Second option"]')).toBeTruthy()
    );
    userEvent.click(await findByRole('button', { name: 'Clear Selected Options' }));
    await waitFor(() =>
      expect(baseElement.querySelector('[id="multi-select-controlled-selected-option-0-First option"]')).toBeFalsy()
    );
    expect(baseElement.querySelector('[id="multi-select-controlled-selected-option-1-Second option"]')).toBeFalsy();
  });
});
