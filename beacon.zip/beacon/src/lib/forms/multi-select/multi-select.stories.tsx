import React, { useState } from 'react';
import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { MultiSelect } from './multi-select';
import { SelectOption } from '../select/select';
import { Alert, AlertVariant } from '../../notifications/alert/alert';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { action } from '@storybook/addon-actions';
import { Form } from '../form/form';
import { FormGroup } from '../form-group/form-group';
import { hookFormUtils } from '../utils/hookform-utils';
import { SubmitButton } from '../../button/submit-button';
import { ISelectOption } from '../select/select.types';
import { Button, ButtonType } from '../../button/button';

export default {
  component: MultiSelect,
  title: 'Core Components/Form Controls/Dropdowns (Multi-select)',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

export const MultiSelectBasic: Story = () => {
  return (
    <div className="w-50">
      <MultiSelect id="multi-select-basic">
        <SelectOption value="First">First option</SelectOption>
        <SelectOption value="Second">Second option</SelectOption>
        <SelectOption value="Third">Third option</SelectOption>
        <SelectOption value="Fourth">Fourth option</SelectOption>
        <SelectOption value="Fifth">Fifth option</SelectOption>
      </MultiSelect>
    </div>
  );
};

MultiSelectBasic.storyName = 'Dropdown Multi-select';

MultiSelectBasic.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Basic Multi-select"
      description="A multi-select dropdown allows users to select multiple options from a list."
      whenToUse={
        <>
          <p>Use multi-select dropdowns to enable users to select more than on item from a list.</p>
          <ul>
            <li>
              <span className="text-danger">
                <strong>Don't</strong>
              </span>{' '}
              use multi-select dropdowns for shorter lists of options and situations where it’s better for users to see
              all options. In these cases, checkboxes are often a better choice.
            </li>
          </ul>
        </>
      }
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const MultiSelectFilter: Story = () => {
  return (
    <div className={'w-50 mb-3'}>
      <MultiSelect id="multi-select-filter" filterable={true} allowAddAll={true}>
        <SelectOption value="First">First option</SelectOption>
        <SelectOption value="Second">Second option</SelectOption>
        <SelectOption value="Third">Third option</SelectOption>
        <SelectOption value="Fourth">Fourth option</SelectOption>
        <SelectOption value="Fifth">Fifth option</SelectOption>
        <SelectOption value="123">Number option</SelectOption>
      </MultiSelect>
    </div>
  );
};
MultiSelectFilter.storyName = 'Filterable Dropdown Multi-select';

MultiSelectFilter.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Filter Options"
      description={
        <>
          The <strong>filterable</strong> option enables a text box to filter through the options menu.
        </>
      }
      whenToUse={''}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const MultiSelectFilterWithDefault: Story = () => {
  return (
    <div className={'w-50 mb-3'}>
      <MultiSelect
        id="multi-select-filter-with-default"
        filterable={true}
        allowAddAll={true}
        label="Second and Fourth are preselected"
      >
        <SelectOption value="First">First option</SelectOption>
        <SelectOption defaultSelected value="Second">
          Second option
        </SelectOption>
        <SelectOption value="Third">Third option</SelectOption>
        <SelectOption defaultSelected value="Fourth">
          Fourth option
        </SelectOption>
        <SelectOption value="Fifth">Fifth option</SelectOption>
      </MultiSelect>
    </div>
  );
};
MultiSelectFilterWithDefault.storyName = 'Filterable Dropdown Multi-select w/ default';

MultiSelectFilterWithDefault.decorators = MultiSelectFilter.decorators;

export const MultiSelectDisabled: Story = () => {
  return (
    <>
      <div className={'w-50 mb-3'}>
        <MultiSelect id="multi-select-disabled" disabled={true} label="Disabled Multi-Select Example:">
          <SelectOption value="First">First option</SelectOption>
          <SelectOption value="Second">Second option</SelectOption>
          <SelectOption value="Third">Third option</SelectOption>
          <SelectOption value="Fourth">Fourth option</SelectOption>
          <SelectOption value="Fifth">Fifth option</SelectOption>
        </MultiSelect>
      </div>
      <div className={'w-50'}>
        <MultiSelect id="multi-select-disabled-option" label="Disabled Option Example:">
          <SelectOption value="First">First option</SelectOption>
          <SelectOption value="Second" disabled={true}>
            Second option
          </SelectOption>
          <SelectOption value="Third">Third option</SelectOption>
          <SelectOption value="Fourth" disabled={true}>
            Fourth option
          </SelectOption>
          <SelectOption value="Fifth">Fifth option</SelectOption>
        </MultiSelect>
      </div>
    </>
  );
};
MultiSelectDisabled.storyName = 'Disabled Dropdown Multi-select';

MultiSelectDisabled.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Disabled Multi-Select"
      description={
        <>
          The <strong>disabled</strong> option disabled the Multi-Select when set to true.
        </>
      }
      whenToUse={''}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const MultiSelectDefault: Story = () => {
  return (
    <div className={'w-50'}>
      <MultiSelect id="multi-select-default">
        <SelectOption value="First" defaultSelected={true}>
          First option
        </SelectOption>
        <SelectOption value="Second">Second option</SelectOption>
        <SelectOption value="Third">Third option</SelectOption>
        <SelectOption value="Fourth" defaultSelected={true}>
          Fourth option
        </SelectOption>
        <SelectOption value="Fifth">Fifth option</SelectOption>
      </MultiSelect>
    </div>
  );
};
MultiSelectDefault.storyName = 'Dropdown Multi-select Item Selected by Default ';

MultiSelectDefault.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Default Selected"
      description={
        <p>
          The <strong>defaultSelected</strong> option on the <em>SelectOption</em> component is used to have options
          selected by default.
        </p>
      }
      whenToUse={''}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const MultiSelectLabel: Story = () => {
  return (
    <div className={'w-50'}>
      <MultiSelect id="multi-select-filter" label="Label Example:">
        <SelectOption value="First">First option</SelectOption>
        <SelectOption value="Second">Second option</SelectOption>
        <SelectOption value="Third">Third option</SelectOption>
        <SelectOption value="Fourth">Fourth option</SelectOption>
        <SelectOption value="Fifth">Fifth option</SelectOption>
      </MultiSelect>
    </div>
  );
};
MultiSelectLabel.storyName = 'Dropdown Multi-select Label';

MultiSelectLabel.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Label"
      description={
        <>
          The <strong>label</strong> option sets the display text of the Multi-Select when no options have been
          selected.
        </>
      }
      whenToUse={''}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const MultiSelectPlaceholder: Story = () => {
  return (
    <div className={'w-50'}>
      <MultiSelect id="multi-select-placeholder" placeholder="Using Custom Placeholder">
        <SelectOption value="First">First option</SelectOption>
        <SelectOption value="Second">Second option</SelectOption>
        <SelectOption value="Third">Third option</SelectOption>
        <SelectOption value="Fourth">Fourth option</SelectOption>
        <SelectOption value="Fifth">Fifth option</SelectOption>
      </MultiSelect>
    </div>
  );
};
MultiSelectPlaceholder.storyName = 'Placeholder text in Dropdown Multi-select';

MultiSelectPlaceholder.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Placeholder Display"
      description={
        <>
          When an option is selected the <strong>onSelected</strong> function is called. When an option is deselected
          the <strong>onDeselected</strong> function is called.
        </>
      }
      whenToUse={''}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const MultiSelectForm: Story = () => {
  const requiredMessage = 'This field is required';
  const schema = yup.object().shape({
    multiselectValue: yup.array().required(requiredMessage).min(1, requiredMessage),
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });
  const onSubmit = (data: { multiselectValue: string[] }) => {
    action('submit-action')(data);
    alert('MultiSelect Values: ' + JSON.stringify(data.multiselectValue));
  };

  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      <FormGroup id="fg-multi-select" errorMessages={hookFormUtils.getErrorMessages(errors, 'multiselectValue')}>
        <div className={'w-50'}>
          <MultiSelect id="multi-select-form" label="Form Example:" required={true} {...register('multiselectValue')}>
            <SelectOption value="First">First option</SelectOption>
            <SelectOption value="Second">Second option</SelectOption>
            <SelectOption value="Third">Third option</SelectOption>
            <SelectOption value="Fourth">Fourth option</SelectOption>
            <SelectOption value="Fifth">Fifth option</SelectOption>
          </MultiSelect>
        </div>
      </FormGroup>
      <SubmitButton id="button-submit-multiselect">Submit Select</SubmitButton>
    </Form>
  );
};
MultiSelectForm.storyName = 'Dropdown Multi-select in Form ';

MultiSelectForm.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Mult-Select in a Form"
      description={
        <>
          When used with form validation the options <strong>name</strong> and <strong>inputRef</strong> are required.
          The selected values are join into a comma separated string.
        </>
      }
      whenToUse={''}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const MultiSelectOnChange: Story = () => {
  const [totalSelected, setTotalSelected] = useState(0);
  const [totalDeselected, setTotalDeselected] = useState(0);

  const onSelected = () => {
    setTotalSelected(totalSelected + 1);
  };

  const onDeselected = () => {
    setTotalDeselected(totalDeselected + 1);
  };

  return (
    <div className={'w-50'}>
      <Alert variant={AlertVariant.info}>
        <strong>Selected:</strong> {totalSelected}, <strong>Deselected:</strong> {totalDeselected},{' '}
        <strong>Total Changed:</strong> {totalSelected + totalDeselected}
      </Alert>
      <MultiSelect id="multi-select-onchange" onSelected={onSelected} onDeselected={onDeselected}>
        <SelectOption value="First">First option</SelectOption>
        <SelectOption value="Second">Second option</SelectOption>
        <SelectOption value="Third">Third option</SelectOption>
        <SelectOption value="Fourth">Fourth option</SelectOption>
        <SelectOption value="Fifth">Fifth option</SelectOption>
      </MultiSelect>
    </div>
  );
};
MultiSelectOnChange.storyName = 'Dropdown Multi-select OnChange Event';

MultiSelectOnChange.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="OnChange Event"
      description={
        <>
          <p>
            When an option is selected the <strong>onSelected</strong> function is called.
          </p>
          <p>
            When an option is deselected the <strong>onDeselected</strong> function is called.
          </p>
        </>
      }
      whenToUse={''}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const MultiSelectControlled: Story = () => {
  const [selectedOptions, setSelectedOptions] = useState<string[]>([]);

  const onSelected = (selectedOption: ISelectOption) => {
    if (selectedOption.value === 'Only' || selectedOptions.includes('Only')) {
      setSelectedOptions(['Only']);
    } else {
      setSelectedOptions([...selectedOptions, selectedOption.value as string]);
    }
  };

  const onDeselected = (deSelectedOption: ISelectOption) => {
    setSelectedOptions([...selectedOptions].filter((option) => option !== deSelectedOption.value));
  };

  const showControlledOptions = (options: string[]) => {
    const result = options.map((option) => ` ${option}`);
    return `[ ${result} ]`;
  };

  return (
    <div className="w-50">
      <Alert variant={AlertVariant.info}>
        <strong>Selected:</strong> {showControlledOptions(selectedOptions)}
      </Alert>
      <div className="d-flex">
        <MultiSelect
          id="multi-select-controlled"
          selectedOptions={selectedOptions}
          onSelected={(selectedOption: ISelectOption) => onSelected(selectedOption)}
          onDeselected={(deSelectedOption: ISelectOption) => onDeselected(deSelectedOption)}
        >
          <SelectOption value="First">First option</SelectOption>
          <SelectOption value="Second">Second option</SelectOption>
          <SelectOption value="Third">Third option</SelectOption>
          <SelectOption value="Fourth">Fourth option</SelectOption>
          <SelectOption value="Fifth">Fifth option</SelectOption>
          <SelectOption value="Only">Only This Option</SelectOption>
        </MultiSelect>
        <div className="ml-4">
          <Button id="clear-all-filters" type={ButtonType.secondary} onClick={() => setSelectedOptions([])}>
            Clear Selected Options
          </Button>
        </div>
      </div>
    </div>
  );
};

MultiSelectControlled.storyName = 'Controlled Multi-select';

MultiSelectControlled.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Controlled Multi-Select"
      description="A controlled multi-select dropdown allows users to select multiple options from a list."
      whenToUse={
        <>
          <p>Use multi-select dropdowns to enable users to select more than on item from a list.</p>
          <ul>
            <li>
              <span className="text-danger">
                <strong>Don't</strong>
              </span>{' '}
              use multi-select dropdowns for shorter lists of options and situations where it’s better for users to see
              all options. In these cases, checkboxes are often a better choice.
            </li>
          </ul>
        </>
      }
    >
      <ComponentStory />
    </Documentation>
  ),
];
