import React, { useState, CSSProperties, forwardRef, useRef, SyntheticEvent, useEffect, useMemo } from 'react';
import { Button, ButtonType } from '../../button/button';
import { Icon, IconType, IconVariant } from '../../icon/icon';
import { usePopper } from 'react-popper';
import { matchWidth } from '../../utils/popper-modifiers/match-width';
import { getOptionInfo, SelectPopper } from '../select/select-popper';
import { ButtonGroup, ButtonGroupDirection } from '../../button/button-group';
import './multi-select.scss';
import { ISelectOption, ISelectOptionProps, SelectOptionValue } from '../select/select.types';
import { WithId } from '../../with-id';
import { Trackable, defaultTracking, trackableEvent, TrackableEvent } from '../../analytics';
import { WithInput } from '../../with-input';
import { focusOnFirstFocusableChild, noop } from '../../utils';
import { Label } from '../label/label';
export interface IMultiSelectProps extends WithId, Trackable, WithInput<HTMLSelectElement, ISelectOption[]> {
  /**
   * Must be a list of SelectOption elements
   */
  children: React.ReactElement<ISelectOptionProps>[];

  /**
   * Must be a list of SelectOption elements
   */
  selectedOptions?: SelectOptionValue[];

  /**
   * Text for the label of the Multi-Select
   */
  label?: string;

  /**
   * Text displayed when no items have been selected
   */
  placeholder?: string;

  /**
   * Set this to true to allow filtering on the list of items. Queries are done on the label text.
   */
  filterable?: boolean;

  /**
   * Void function that executes when an item has been selected.
   */
  onSelected?: (selectedOption: ISelectOption) => void;

  /**
   * Void function that executes when an item has been deselected.
   */
  onDeselected?: (deselectedOption: ISelectOption) => void;
  /**
   * Include Add All button in dropdown
   */
  allowAddAll?: boolean;
  /**
   * Custom display value for Add All button
   */
  addAllText?: string;
  /**
   * Trackable Event for Selecting an item
   */
  trackingSelected?: TrackableEvent;

  /**
   * Trackable Event for Deselecting an item
   */
  trackingDeselected?: TrackableEvent;
}

interface IMultiSelectSelectedOptionsProps extends WithId, Trackable {
  option: ISelectOption;
  disabled?: boolean;
  onClick: (option: ISelectOption) => void;
}

interface IMultiSelectDropdownMessagesProps {
  options: React.ReactElement<ISelectOptionProps>[];
  filterValue: string;
}

interface IMultiSelectLabelProps {
  label?: string;
  required: boolean | undefined;
  id: string;
}

const getTrackableChange = (tracking: TrackableEvent | undefined, id: string, action: string) => {
  return defaultTracking(tracking, {
    grouping: 'Ungrouped',
    action: action,
    trackingKey: `Multi-Select-${id}`,
  });
};

const handleSelectKeyEvents = (
  event: React.KeyboardEvent<HTMLDivElement>,
  dropdownRef: React.RefObject<HTMLDivElement>,
  popperElement: HTMLDivElement | null,
  dropdownOpen: boolean,
  setDropdownOpen: (value: React.SetStateAction<boolean>) => void
) => {
  if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
    setDropdownOpen(true);
    event.preventDefault();
  }

  if (event.key === 'Escape') {
    setDropdownOpen(false);
    dropdownRef.current && dropdownRef.current.focus();
  }

  if (event.key === 'Tab' && dropdownOpen && popperElement) {
    focusOnFirstFocusableChild(popperElement);
    event.preventDefault();
  }
};

const MultiSelectSelectedOption: React.FC<IMultiSelectSelectedOptionsProps> = (props) => {
  const onClickActionb = (event: SyntheticEvent) => {
    event.stopPropagation();
    props.onClick(props.option);
  };
  const tracking = getTrackableChange(props.tracking, props.id, 'Option Deselected');
  return (
    <Button
      id={props.id}
      onClick={onClickActionb}
      type={ButtonType.primary}
      tracking={tracking}
      disabled={props.disabled}
    >
      {props.option.label} <Icon type={IconType.timesCircle}></Icon>
    </Button>
  );
};

const MultiSelectDropdownMessages: React.FC<IMultiSelectDropdownMessagesProps> = (props) => {
  return (
    <div className="dropdown-messages">
      {props.filterValue && getFilteredOptions(props.options, props.filterValue).length === 0 && (
        <div className="dropdown-message">
          <Icon type={IconType.infoCircle} variant={IconVariant.info} />
          &nbsp;
          <strong>Your input does not match any options</strong>
        </div>
      )}
    </div>
  );
};

const MultiSelectLabel: React.FC<IMultiSelectLabelProps> = (props) => {
  return (
    <div>
      {props.label && (
        <Label required={props.required} htmlFor={`beacon-multi-select-container-${props.id}`}>
          {props.label}
        </Label>
      )}
    </div>
  );
};

const mapToISelectOptionArr = (options: React.ReactElement<ISelectOptionProps>[]) =>
  options.map((option: React.ReactElement<ISelectOptionProps>) => ({
    value: option.props.value,
    label: option.props.children,
    title: option.props.title,
  }));

const returnDropdownWithDeselected = (
  selectedOptions: ISelectOption[],
  deselectedOption: ISelectOption,
  children: React.ReactElement<ISelectOptionProps>[]
) => {
  return children.filter((option: React.ReactElement<ISelectOptionProps>) => {
    return deselectedOption.value === option.props.value
      ? true
      : !selectedOptions.find((selectedOption) => selectedOption.value === option.props.value);
  });
};

const getFilteredOptions = (options: React.ReactElement<ISelectOptionProps>[], filterValue: string) => {
  return options.filter(
    (child) =>
      child.props.value?.toString().toLocaleLowerCase().includes(filterValue.toString().toLowerCase()) ||
      child.props.value === filterValue.toString().toLowerCase() ||
      (typeof child.props.children === 'string' &&
        child.props.children.toLowerCase().includes(filterValue.toString().toLowerCase()))
  );
};

const getPopperOptions = (
  isFilterable: boolean | undefined,
  isFiltering: boolean,
  filterValue: string,
  options: React.ReactElement<ISelectOptionProps>[]
) => {
  if (isFilterable && isFiltering && filterValue) {
    return getFilteredOptions(options, filterValue);
  } else {
    return options;
  }
};

const getPlaceholder = (props: IMultiSelectProps): string => {
  if (props.placeholder) {
    return props.placeholder;
  } else if (!props.placeholder && props.filterable) {
    return 'Type or Select filter';
  } else {
    return 'Select filter';
  }
};

const getOptionValue = (option: ISelectOption): string | number => {
  return option.value ? option.value : '';
};

const getDisabledClass = (isDisabled: boolean | undefined) => {
  return isDisabled ? 'multi-select-button-disabled' : '';
};

const getTabIndex = (isDisabled: boolean | undefined) => {
  return isDisabled ? -1 : 0;
};

export const MultiSelect = forwardRef<HTMLSelectElement, IMultiSelectProps>(
  ({ onSelected = noop, onDeselected = noop, onChange = noop, name = '', ...props }, ref) => {
    const [dropdownOpen, setDropdownOpen] = useState(false);
    const [popperElement, setPopperElement] = useState<HTMLDivElement | null>(null);

    const [placeholderValue, setPlaceholderValue] = useState<string>(getPlaceholder(props));
    useEffect(() => {
      const placeholder = getPlaceholder(props);
      setPlaceholderValue(placeholder);
    }, [props]);

    const defaultSelectedOptions = useMemo(
      () =>
        mapToISelectOptionArr(
          props.children.filter((option: React.ReactElement<ISelectOptionProps>) => option.props.defaultSelected)
        ),
      [props.children]
    );

    const defaultAvailableOptions = useMemo(
      () => props.children.filter((option: React.ReactElement<ISelectOptionProps>) => !option.props.defaultSelected),
      [props.children]
    );

    const [selectedOptions, setSelectedOptions] = useState<ISelectOption[]>(defaultSelectedOptions);
    const [availableOptions, setAvailableOptions] =
      useState<React.ReactElement<ISelectOptionProps>[]>(defaultAvailableOptions);

    const [isFiltering, setIsFiltering] = useState(false);
    const [filterValue, setFilterValue] = useState<string>('');

    const dropdownButtonRef = useRef<HTMLDivElement>(null);
    const isOptionsEmpty = availableOptions.length === 0;

    const { styles, attributes } = usePopper(dropdownButtonRef.current, popperElement, {
      placement: 'bottom-start',
      modifiers: [matchWidth],
    });
    const popperStyles: CSSProperties = {
      ...styles.popper,
      zIndex: 9999,
    };

    const raiseOnChangeEvent = (options: ISelectOption[]) => {
      const selection = options.map((option) => option.value);

      onChange(
        {
          target: {
            name,
            value: selection,
          },
        } as unknown as React.ChangeEvent<HTMLSelectElement>,
        options
      );
    };

    const actualSelectedOptions: ISelectOption[] = selectedOptions;

    useEffect(() => {
      if (props.selectedOptions) {
        const [selectedList, unselectedList] = props.children.reduce(
          ([selected, unselected], option) =>
            props.selectedOptions?.includes(option.props.value)
              ? [[...selected, option], unselected]
              : [selected, [...unselected, option]],
          [[] as React.ReactElement<ISelectOptionProps>[], [] as React.ReactElement<ISelectOptionProps>[]]
        );
        setSelectedOptions(mapToISelectOptionArr(selectedList));
        setAvailableOptions(unselectedList);
      }
    }, [props.children, props.selectedOptions]);

    const addOptionToSelected = (option: ISelectOption) => {
      const updatedSelections = [...actualSelectedOptions, option];
      setSelectedOptions(updatedSelections);

      setAvailableOptions(availableOptions.filter((child) => child.props.value !== option.value));
      onSelected(option);

      raiseOnChangeEvent(updatedSelections);

      if (getPopperOptions(props.filterable, isFiltering, filterValue, availableOptions).length <= 1) {
        setFilterValue('');
        setDropdownOpen(false);
      }
    };

    const deselectOption = (deselectedOption: ISelectOption) => {
      const updatedSelections = actualSelectedOptions.filter((child) => child.value !== deselectedOption.value);
      setSelectedOptions(updatedSelections);
      setAvailableOptions(returnDropdownWithDeselected(actualSelectedOptions, deselectedOption, props.children));
      onDeselected(deselectedOption);

      raiseOnChangeEvent(updatedSelections);
    };

    const addAllOptionsToSelected = () => {
      const allOptions = [...actualSelectedOptions];
      const filteredAvailableOptions = getFilteredOptions(availableOptions, filterValue);
      filteredAvailableOptions.forEach((option) => {
        const selectOption: ISelectOption = getOptionInfo(option);
        allOptions.push(selectOption);
        onSelected(selectOption);
      });

      setSelectedOptions(allOptions);
      setAvailableOptions([]);

      raiseOnChangeEvent(allOptions);
      setFilterValue('');
      setDropdownOpen(false);
    };

    const handleFilterChanged = ({ target }: React.ChangeEvent<HTMLInputElement>) => {
      setFilterValue(target.value);
      setDropdownOpen(true);
      setIsFiltering(true);
    };

    const displayPlaceholder = selectedOptions.length ? '' : placeholderValue;

    return (
      <div id={`beacon-multi-select-container-${props.id}`} className={'beacon-multi-select w-100'}>
        <MultiSelectLabel label={props.label} id={props.id} required={props.required} />
        <div
          tabIndex={getTabIndex(props.disabled)}
          className={`multi-select-button btn btn-secondary d-flex w-100 ${getDisabledClass(props.disabled)}`}
          id={`${props.id}-button`}
          ref={dropdownButtonRef}
        >
          <div className="flex-grow-1 dropdown-container">
            <ButtonGroup direction={ButtonGroupDirection.LEFT} wrap={true}>
              {actualSelectedOptions.map((option, index) => (
                <MultiSelectSelectedOption
                  id={`${props.id}-selected-option-${index}-${option.label}`}
                  key={`${props.id}-selected-option-${index}-${option.label}`}
                  onClick={deselectOption}
                  option={option}
                  tracking={props.trackingDeselected}
                  disabled={props.disabled}
                />
              ))}

              <div
                className="flex-grow-1"
                role="region"
                aria-labelledby={`${props.id}-button`}
                onClick={trackableEvent(getTrackableChange(props.tracking, props.id, 'Toggle Multi-Select Menu'), () =>
                  setDropdownOpen(!dropdownOpen)
                )}
                onKeyDown={(event) =>
                  handleSelectKeyEvents(event, dropdownButtonRef, popperElement, dropdownOpen, setDropdownOpen)
                }
                tabIndex={0}
              >
                {props.filterable && (
                  <div className="flex-grow-1">
                    <input
                      aria-label={`${props.label} Filter Input`}
                      id={`${props.id}-filter`}
                      type="text"
                      title="Filter Values"
                      onChange={handleFilterChanged}
                      value={filterValue}
                      disabled={!props.filterable || props.disabled}
                      autoComplete="off"
                      className="form-control multi-select-filterable"
                      placeholder={displayPlaceholder}
                      tabIndex={0}
                      onFocus={() => setIsFiltering(true)}
                    />
                  </div>
                )}
                {!props.filterable && <div className={'flex-grow-1 multi-select-default'}>{displayPlaceholder}</div>}
              </div>
            </ButtonGroup>
          </div>
          <div
            className="dropdown-button-container"
            onClick={trackableEvent(getTrackableChange(props.tracking, props.id, 'Toggle Multi-Select Menu'), () =>
              setDropdownOpen(!dropdownOpen)
            )}
            onKeyDown={(event) =>
              handleSelectKeyEvents(event, dropdownButtonRef, popperElement, dropdownOpen, setDropdownOpen)
            }
            tabIndex={0}
            role="button"
            aria-label="Options Dropdown"
          >
            {dropdownOpen ? <Icon type={IconType.caretUp} /> : <Icon type={IconType.caretDown} />}
          </div>
          <select
            id={`${name}`}
            name={`${name}`}
            required={props.required}
            disabled={props.disabled}
            hidden={true}
            multiple={true}
            ref={ref}
          >
            {actualSelectedOptions.map((option) => {
              const value = getOptionValue(option);
              return (
                <option key={value} value={value}>
                  {option.label}
                </option>
              );
            })}
          </select>
        </div>
        {dropdownOpen && (
          <div
            className="beacon-multi-select select-container"
            ref={setPopperElement}
            style={popperStyles}
            {...attributes.popper}
          >
            <SelectPopper
              parentRef={dropdownButtonRef.current}
              id={`${props.id}-options-menu`}
              children={getPopperOptions(props.filterable, isFiltering, filterValue, availableOptions)}
              nullable={isOptionsEmpty}
              isNullOptionDisabled={true}
              tracking={getTrackableChange(props.trackingSelected, props.id, 'Option Selected')}
              OnSelection={addOptionToSelected}
              OnSelectAll={addAllOptionsToSelected}
              shouldBlurOnParentFocus={false}
              allowAddAll={props.allowAddAll}
              addAllText={props.addAllText}
              onRequestClose={() => {
                setDropdownOpen(false);
                dropdownButtonRef.current && dropdownButtonRef.current.focus();
              }}
            />
            <MultiSelectDropdownMessages options={availableOptions} filterValue={filterValue} />
          </div>
        )}
      </div>
    );
  }
);
