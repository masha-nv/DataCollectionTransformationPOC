import { Story } from '@storybook/react';
import React from 'react';
import { Documentation, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { RequiredFieldLegend } from './required-field-legend';

export default {
  component: RequiredFieldLegend,
  title: 'Core Components/Form Controls/Required Field Legend',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
};

export const Example: Story = () => {
  return <RequiredFieldLegend />;
};
Example.storyName = 'Required Field Legend';
Example.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Required Field Legend"
      description="The required field legend is a explanation of the symbol or indicator used to indicate that a field is required."
      whenToUse="The required field legend should be placed at the top of any form has required field (i.e. uses the corresponding required field indicator)."
    >
      <ComponentStory />
    </Documentation>
  ),
];
