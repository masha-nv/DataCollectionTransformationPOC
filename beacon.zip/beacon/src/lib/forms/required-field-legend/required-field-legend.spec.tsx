import React from 'react';
import { render } from '@testing-library/react';
import { RequiredFieldLegend } from './required-field-legend';

describe('RequiredFieldLegend', () => {
  it('renders correctly', async () => {
    const { baseElement } = render(<RequiredFieldLegend />);

    expect(baseElement).toMatchSnapshot();
  });
});
