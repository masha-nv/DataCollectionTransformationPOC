import React from 'react';

export const RequiredFieldLegend = () => {
  return (
    <div className="form-required-instructions">
      <span>*</span> Indicates Required Field
    </div>
  );
};
