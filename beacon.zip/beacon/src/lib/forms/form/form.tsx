import React from 'react';

export type IFormInputProps = Omit<JSX.IntrinsicElements['form'], 'noValidate'>;

export const Form = (props: IFormInputProps) => {
  return (
    <form {...props} noValidate>
      {props.children}
    </form>
  );
};
