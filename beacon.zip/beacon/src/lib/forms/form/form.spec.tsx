import React from 'react';
import { render } from '@testing-library/react';
import { Form } from './form';
import { TextInput } from '../text-input/text-input';

describe('Form component', () => {
  it('renders correctly', () => {
    const { baseElement } = render(
      <Form id="test-form">
        <TextInput id="input-id" name="input-name"></TextInput>
      </Form>
    );
    const input = baseElement.querySelector('#test-form');
    expect(input.attributes).toHaveProperty('novalidate');
    expect(baseElement).toMatchSnapshot();
  });

  it('renders native form attributes correctly', () => {
    const { container } = render(<Form name="test-form-name" id="test-form" />);
    const input = container.querySelector('#test-form');
    expect(input.attributes).toHaveProperty('name');
  });
});
