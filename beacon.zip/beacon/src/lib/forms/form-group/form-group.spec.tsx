import React from 'react';
import { render } from '@testing-library/react';
import { FormGroup } from './form-group';
import { TextInput } from '../text-input/text-input';

describe('FormGroup', () => {
  it('renders FormGroup correctly', () => {
    const { baseElement } = render(
      <FormGroup id="fg-id">
        <label htmlFor="firstName">First Name</label>
        <TextInput name="firstName" id="firstName" />
      </FormGroup>
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('renders FormGroup with error correctly', () => {
    const errorMessage = 'First Name is required';
    const { baseElement, container } = render(
      <FormGroup id="fg-id" errorMessages={[errorMessage]}>
        <label htmlFor="firstName">First Name</label>
        <TextInput name="firstName" id="firstName" />
      </FormGroup>
    );
    expect(baseElement).toMatchSnapshot();

    expect(container.querySelector('.form-error-message').textContent).toBe(errorMessage);
  });
});
