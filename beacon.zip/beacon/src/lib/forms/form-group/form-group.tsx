import React, { forwardRef, ReactNode } from 'react';
import { WithId } from '../../with-id';
import { ErrorMessages } from '../error-message/error-message';

export interface IFormGroupProps extends WithId {
  /**
   * The content of this button
   */
  children: ReactNode;

  /**
   * Error messages to display
   */
  errorMessages?: string[];
}

const hasError = (messageArr: string[]) => messageArr && messageArr.length > 0;

/**
 * Form group component
 */
export const FormGroup = forwardRef<HTMLDivElement, IFormGroupProps>(({ id, children, errorMessages = [] }, ref) => {
  return (
    <div ref={ref} id={id} className={`form-group ${hasError(errorMessages) ? 'form-group-error' : ''}`}>
      {children}
      {<ErrorMessages id={`${id}-error`} messages={errorMessages} />}
    </div>
  );
});
