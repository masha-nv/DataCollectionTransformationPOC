import { yupUtils } from './yup-utils';
import * as yup from 'yup';
import { DATE_FORMAT } from '../date-picker/constants';

describe('yupUtils', () => {
  it('validates date with default format correctly', async () => {
    const schema = yup.object().shape({
      date: yupUtils.yupDateWithFormat(),
    });

    const result = await schema.validate({
      date: '11/11/2009',
    });

    expect(result.date).toStrictEqual(new Date(2009, 10, 11));
  });

  it('throws exception of bad date format', async () => {
    const schema = yup.object().shape({
      date: yupUtils.yupDateWithFormat(),
    });

    await expect(
      schema.validate({
        date: '11/20',
      })
    ).rejects.toThrow(`Please use a valid date (${DATE_FORMAT})`);
  });
});
