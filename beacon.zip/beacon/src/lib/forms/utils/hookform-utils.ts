import { FieldError, FieldErrors, get } from 'react-hook-form';

/**
 * Get error message if field error is found
 * @param errors
 * @param fieldName
 */
const getErrorMessages = (errors: Record<string, unknown>, fieldName: string): string[] => {
  const error = get(errors, fieldName);
  if (error) {
    return [error.message];
  }
  return [];
};

export const getAllErrorMessages = <T extends Record<string, unknown>>(
  errors: FieldErrors<T>
): Record<string, string[]> => {
  const errorMap: Record<string, string[]> = {};
  Object.entries(errors).forEach(([fieldName, error]: [string, FieldError]) => {
    let message = error.message || '';
    if (!error.message && error.type === 'required') {
      message = 'This field is required';
    }
    errorMap[fieldName] = [message];
  });
  return errorMap;
};

export const hookFormUtils = {
  getErrorMessages,
  getAllErrorMessages,
};
