type CalendarBodyTypes = 'day' | 'month';

const focusIfExists = (element: HTMLButtonElement | null, event: React.KeyboardEvent<HTMLButtonElement>) => {
  if (element) {
    element.focus();
  }
  event.preventDefault();
};

export const handleCalendarKeys = (
  event: React.KeyboardEvent<HTMLButtonElement>,
  index: number,
  bodyType: CalendarBodyTypes,
  bodyRefs: React.MutableRefObject<HTMLButtonElement[]>,
  nextBtnRef: React.RefObject<HTMLButtonElement>
) => {
  const rowSize = bodyType === 'day' ? 7 : 4;
  if (event.key === 'ArrowUp') {
    focusIfExists(bodyRefs.current[index - rowSize], event);
  }
  if (event.key === 'ArrowLeft') {
    focusIfExists(bodyRefs.current[index - 1], event);
  }
  if (event.key === 'ArrowRight') {
    focusIfExists(bodyRefs.current[index + 1], event);
  }
  if (event.key === 'ArrowDown') {
    focusIfExists(bodyRefs.current[index + rowSize], event);
  }
  if (event.key === 'Tab') {
    focusIfExists(nextBtnRef.current, event);
  }
};
