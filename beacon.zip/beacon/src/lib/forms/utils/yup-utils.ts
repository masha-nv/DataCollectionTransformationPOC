import { DateSchema } from 'yup';
import * as yup from 'yup';
import moment from 'moment';
import { DATE_FORMAT } from '../date-picker/constants';
/**
 * Create yup date schema with custom date format
 */
const yupDateWithFormat = (
  format: string = DATE_FORMAT
): DateSchema<Date | undefined, Record<string, unknown>, Date | undefined> => {
  return yup
    .date()
    .typeError(`Please use a valid date (${format})`)
    .transform(function (_, originalValue) {
      const parsedValue = moment(originalValue, format, true);
      let newVal = null;
      if (parsedValue.isValid()) {
        newVal = parsedValue.toDate();
      } else {
        newVal = new Date('');
      }
      return newVal;
    });
};

export const yupUtils = {
  yupDateWithFormat,
};
