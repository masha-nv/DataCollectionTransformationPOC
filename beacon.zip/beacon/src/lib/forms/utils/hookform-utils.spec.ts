import { FieldErrors } from 'react-hook-form';
import { hookFormUtils, getAllErrorMessages } from './hookform-utils';

describe('hook form utils', () => {
  it('should get default required message', () => {
    const error = {
      type: 'required',
    };
    const errorMap: FieldErrors<Record<string, unknown>> = {
      field: error,
    };

    expect(getAllErrorMessages(errorMap)).toEqual({
      field: ['This field is required'],
    });
  });

  it('should get all errors message', () => {
    const error1 = {
      type: 'required',
      message: 'This is required',
    };
    const error2 = {
      type: 'minLength',
      message: 'This is not long enough',
    };
    const errorMap: FieldErrors<Record<string, unknown>> = {
      field: error1,
      anotherField: error2,
    };

    expect(getAllErrorMessages(errorMap)).toEqual({
      field: ['This is required'],
      anotherField: ['This is not long enough'],
    });
  });

  it('extracts error message correctly', () => {
    const errors = {
      lastName: { message: 'Last Name is required', type: 'required' },
      address: {
        streetaddress: { message: 'Street Address is required', type: 'required' },
      },
    };

    expect(hookFormUtils.getErrorMessages(errors, 'lastName')).toStrictEqual(['Last Name is required']);
    expect(hookFormUtils.getErrorMessages(errors, 'address.streetaddress')).toStrictEqual([
      'Street Address is required',
    ]);

    expect(hookFormUtils.getErrorMessages(errors, 'unknown.path')).toStrictEqual([]);
  });
});
