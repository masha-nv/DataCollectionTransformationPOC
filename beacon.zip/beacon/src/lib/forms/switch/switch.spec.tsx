import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import { Switch } from './switch';
import { track } from '../../analytics/matomo';
import { TrackableEvent } from '../../analytics';

jest.mock('../analytics/matomo', () => {
  const module = jest.requireActual('../analytics/matomo');
  return {
    ...module,
    track: jest.fn(),
  };
});

describe('Switch Component', () => {
  it('renders defualt switch', () => {
    const { baseElement } = render(<Switch id="switch-default" />);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders disabled switch', () => {
    const { baseElement } = render(<Switch id="switch-disabled" disabled />);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders default checked switch', () => {
    const { baseElement } = render(<Switch id="switch-disabled" defaultChecked />);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders custom label switch', () => {
    const label = (checked: boolean) => (checked ? 'on' : 'off');
    const { baseElement } = render(<Switch id="switch-disabled" label={label} />);
    expect(baseElement).toMatchSnapshot();
  });

  it('checks switch when clicked', () => {
    const { baseElement } = render(<Switch id="switch-disabled" />);
    const switchElement = baseElement.querySelector('input');
    fireEvent.click(switchElement);
    expect(track).toHaveBeenCalledWith({
      grouping: 'Ungrouped',
      action: 'Checked/Unchecked',
      trackingKey: 'Switch-switch-disabled',
    } as TrackableEvent);
    expect(switchElement.checked).toEqual(true);
  });

  it('checked when controlled', () => {
    const { baseElement } = render(<Switch id="id" checked={true} />);

    const switchElement = baseElement.querySelector<HTMLInputElement>('#id');

    expect(switchElement.checked).toBe(true);
  });
});
