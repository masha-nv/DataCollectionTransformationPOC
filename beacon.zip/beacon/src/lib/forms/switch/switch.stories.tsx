import React, { ChangeEvent, useState } from 'react';
import { Switch } from './switch';
import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../../stories';
import { useForm } from 'react-hook-form';
import { a11yConfig } from '../../stories/story.config';
import { FormGroup } from '../form-group/form-group';
import { SubmitButton } from '../../button/submit-button';
import { action } from '@storybook/addon-actions';
import { Form } from '../form/form';

export default {
  component: Switch,
  title: 'Core Components/Form Controls/Switch',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
  },
} as Meta;

const whenToUse = (
  <>
    <p>
      <strong>Toggles</strong> should be used to select one of multiple options.
    </p>
    <p>
      <strong>Switches</strong> should be used to opt-in or opt-out of an option.
    </p>
    <ul>
      <li>
        <strong className="text-danger">Don't</strong> use switches that require a button to implement. If a setting
        requires users to click a button to implement it, use a checkbox instead
      </li>
      <li>
        <strong className="text-danger">Don't</strong> use switches where a checkbox will do
      </li>
    </ul>
  </>
);

/**
 * Switch
 */
export const BasicExample: Story = () => {
  return (
    <>
      <label htmlFor="switch-default">Label</label>
      <Switch id="switch-default" />
    </>
  );
};

BasicExample.storyName = 'Switch';

BasicExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Basic Switch"
      description="Switches should be used to indicate that a setting has been turned on or off. Switches should also operate like real-life switches: they should implement the change immediately, rather than waiting for users to click a button."
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const SwitchDisabled: Story = () => {
  return (
    <>
      <label htmlFor="switch-disabled">Label</label>
      <Switch id="switch-disabled" disabled />
    </>
  );
};

SwitchDisabled.storyName = 'Disabled Switch';

SwitchDisabled.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Disabled control"
      description={
        <p>
          Switches can be disabled using the <code>disabled</code> property.
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const SwitchChangeEvent: Story = () => {
  const onChangeHandler = (e: ChangeEvent<HTMLInputElement>, value: boolean) => {
    action('switch-on-change')(value);
  };
  return (
    <>
      <label htmlFor="switch-labels">Label</label>
      <Switch id="switch-labels" onChange={onChangeHandler} />
    </>
  );
};
SwitchChangeEvent.storyName = 'Switch Change Event';
SwitchChangeEvent.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Change event for switch"
      description={
        <p>
          Events from the switch can be handled or responded using the <code>onChange</code> property.
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const DefaultChecked: Story = () => {
  return (
    <>
      <label htmlFor="switch-checked">Label</label>
      <Switch id="switch-checked" defaultChecked />
    </>
  );
};
DefaultChecked.storyName = 'Switch Check on by Default';
DefaultChecked.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Checked control"
      description={
        <p>
          Switches can be checked by default (i.e. on page load) using the <code>defaultChecked</code> property.
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const SwitchLabels: Story = () => {
  return (
    <>
      <label htmlFor="switch-labels">Label</label>
      <Switch id="switch-labels" label={(checked) => (checked ? '☺' : '☹')} />
    </>
  );
};

SwitchLabels.storyName = 'Switch Custom Label';

SwitchLabels.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Custom Labels"
      description={
        <p>
          A label can be added to a switch using the <code>label</code> property. In most cases, the label property will
          be a string (or text). However, switches also allow functions to be used for conditional rendering of the
          label.
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const SwitchValues: Story = () => {
  type FormInputs = {
    switchValue: boolean;
  };
  const { register, handleSubmit } = useForm<FormInputs>();
  const onSubmit = (data: FormInputs) => {
    action('submit-action')(data);
  };
  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      <FormGroup id="fg-switch">
        <label htmlFor="switch-values">Label</label>
        <Switch id="switch-values" {...register('switchValue')} />
      </FormGroup>
      <SubmitButton id="button-toggle">Submit Swtich</SubmitButton>
    </Form>
  );
};

SwitchValues.storyName = 'Switch in Form';

SwitchValues.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Form Switch using React-Hook-Form"
      description="Switches utilizing the React-Hook-Form library to submit the switch value."
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const ControlledSwitch: Story = () => {
  const [checkedSwitch, setCheckedSwitch] = useState<number>();
  return (
    <>
      <div>
        <label htmlFor="switch-1">Switch 1</label>
        <Switch id="switch-1" checked={checkedSwitch === 1} onChange={() => setCheckedSwitch(1)} />
      </div>
      <div>
        <label htmlFor="switch-2">Switch 2</label>
        <Switch id="switch-2" checked={checkedSwitch === 2} onChange={() => setCheckedSwitch(2)} />
      </div>
      <div>
        <label htmlFor="switch-3">Switch 3</label>
        <Switch id="switch-3" checked={checkedSwitch === 3} onChange={() => setCheckedSwitch(3)} />
      </div>
    </>
  );
};

ControlledSwitch.storyName = 'Controlled Switch';

ControlledSwitch.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Controlled Switch"
      description={
        <p>
          The value of a switch can be controlled progrmatically with the <code>checked</code> property. When using this
          property, the <code>onChange</code> handler property should be used to update the value when the user
          interacts the component.
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
