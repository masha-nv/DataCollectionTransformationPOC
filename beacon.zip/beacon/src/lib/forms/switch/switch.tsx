import React, { ChangeEvent, forwardRef } from 'react';
import { getTrackableClickHandler, Trackable } from '../../analytics';
import { WithId } from '../../with-id';
import { WithInput } from '../../with-input';
import './switch.scss';

export interface ISwitchProps extends Trackable, WithId, WithInput<HTMLInputElement, boolean> {
  /**
   * The function to return the label when the switch is checked or unchecked.
   */
  label?: (checked: boolean) => string;
  defaultChecked?: boolean;
  checked?: boolean;
}

const defaultLabel = (checked: boolean) => (checked ? 'yes' : 'no');

export const Switch = forwardRef<HTMLInputElement, ISwitchProps>(
  ({ id, label = defaultLabel, onChange, ...props }, ref) => {
    const trackingDefaults = {
      grouping: 'Ungrouped',
      action: 'Checked/Unchecked',
      trackingKey: `Switch-${id}`,
    };

    const onChangeEventHandler = (event: ChangeEvent<HTMLInputElement>) => {
      onChange && onChange(event, event.target.checked);
    };

    return (
      <span className={`switch ${props.disabled ? 'disabled' : ''}`}>
        <input
          id={id}
          type="checkbox"
          aria-roledescription="button"
          ref={ref}
          onChange={getTrackableClickHandler(props.tracking, trackingDefaults, onChangeEventHandler)}
          {...props}
        />
        <span className="switch-slider" label-on={label(true)} label-off={label(false)} />
      </span>
    );
  }
);

Switch.displayName = 'Switch';
