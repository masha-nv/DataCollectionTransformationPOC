import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react';
import { RadioOption } from './radio-option';
import { Radio } from './radio';
import { yupResolver } from '@hookform/resolvers/yup';
import { Form } from '../form/form';
import * as yup from 'yup';
import { FormGroup } from '../form-group/form-group';
import { SubmitButton } from '../../button/submit-button';
import { getAllErrorMessages } from '../utils/hookform-utils';
import { useForm } from 'react-hook-form';

describe('Radio', () => {
  it('groups by name', () => {
    const { baseElement } = render(
      <Radio id="radio" name="radio">
        <RadioOption id="option-1" defaultChecked>
          option 1
        </RadioOption>
        <RadioOption id="option-2">option 2</RadioOption>
      </Radio>
    );

    const radioOptions = baseElement.querySelectorAll<HTMLInputElement>('[name="radio"]');
    fireEvent.click(radioOptions[1]);

    expect(radioOptions[0].checked).toEqual(false);
    expect(radioOptions[1].checked).toEqual(true);
  });

  it('disabled', () => {
    const { baseElement } = render(
      <Radio id="radio" name="radio" disabled>
        <RadioOption id="option-1">option 1</RadioOption>
        <RadioOption id="option-2">option 2</RadioOption>
      </Radio>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('disabled option', () => {
    const { baseElement } = render(
      <Radio name="radio" id="radio">
        <RadioOption id="option-1" disabled>
          option 1
        </RadioOption>
        <RadioOption id="option-2">option 2</RadioOption>
      </Radio>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('inline', () => {
    const { baseElement } = render(
      <Radio id="radio" name="radio" inline>
        <RadioOption id="option-1">option 1</RadioOption>
        <RadioOption id="option-2">option 2</RadioOption>
      </Radio>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('disabled option', () => {
    const { baseElement } = render(
      <Radio id="radio" name="radio">
        <RadioOption id="option-1" inline>
          option 1
        </RadioOption>
        <RadioOption id="option-2">option 2</RadioOption>
      </Radio>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('calls change handler when an option checked', () => {
    const onChangeHandler = jest.fn();

    const { baseElement } = render(
      <Radio id="radio" name="radio" onChange={onChangeHandler}>
        <RadioOption id="option-1">option 1</RadioOption>
        <RadioOption id="option-2">option 2</RadioOption>
      </Radio>
    );

    const radioOption2 = baseElement.querySelector<HTMLInputElement>('[id="option-2"]');
    fireEvent.click(radioOption2);

    expect(onChangeHandler.mock.calls[0][0].target).toEqual(radioOption2);
  });

  it('calls change handler on option when an option checked', () => {
    const onChangeHandler = jest.fn();

    const { baseElement } = render(
      <Radio id="radio" name="radio">
        <RadioOption id="option-1">option 1</RadioOption>
        <RadioOption id="option-2" onChange={onChangeHandler}>
          option 2
        </RadioOption>
      </Radio>
    );

    const radioOption2 = baseElement.querySelector<HTMLInputElement>('[id="option-2"]');
    fireEvent.click(radioOption2);

    expect(onChangeHandler).toHaveBeenCalled();
  });

  it('validates radio group in form', async () => {
    const { baseElement } = render(<RadioFormTest />);

    fireEvent.click(baseElement.querySelector('#submit-button'));

    await waitFor(() => {
      const errorMessage = baseElement.querySelector('.form-error-message');
      expect(errorMessage.textContent).toEqual('This field is required');
    });
  });
});

const RadioFormTest = () => {
  const schema = yup.object().shape({
    formGrain: yup.string().nullable().required('This field is required'),
    formBread: yup.string().nullable(),
  });
  const resolver = yupResolver(schema);
  const {
    register,
    formState: { errors },
    handleSubmit,
    setValue,
  } = useForm({
    resolver,
    defaultValues: {
      formGrain: null,
      formBread: '4',
    },
  });
  const errorMessages = getAllErrorMessages(errors);

  const onSubmit = (data: { selectValue: string }) => {
    console.log(data);
  };

  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      <label>Required Radio group</label>
      <FormGroup id="radio-grain-form-group" errorMessages={errorMessages['formGrain']}>
        <Radio id="form-radio-grain" name="formGrain" required>
          <RadioOption id="form-potato" value={1} {...register('formGrain')}>
            potato
          </RadioOption>
          <RadioOption id="form-corn" value={2} {...register('formGrain')}>
            corn
          </RadioOption>
        </Radio>
      </FormGroup>
      <span className="mr-1">
        <SubmitButton id="submit-button">Submit</SubmitButton>
      </span>
    </Form>
  );
};
