import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import { RadioOption } from './radio-option';
import { track } from '../../analytics/matomo';
import { TrackableEvent } from '../../analytics';

jest.mock('../analytics/matomo', () => {
  const module = jest.requireActual('../analytics/matomo');
  return {
    ...module,
    track: jest.fn(),
  };
});

describe('RadioOption', () => {
  it('disabled', () => {
    const { baseElement } = render(
      <RadioOption id="id" disabled>
        option
      </RadioOption>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('checked by default', () => {
    const { baseElement } = render(
      <RadioOption id="id" defaultChecked>
        option
      </RadioOption>
    );

    const radioOption = baseElement.querySelector<HTMLInputElement>('#id');

    expect(radioOption.checked).toEqual(true);
  });

  it('checked when controlled', () => {
    const { baseElement } = render(
      <RadioOption id="id" checked={true}>
        option
      </RadioOption>
    );

    const radioOption = baseElement.querySelector<HTMLInputElement>('#id');

    expect(radioOption.checked).toBe(true);
  });

  it('unchecked when controlled', () => {
    const { baseElement } = render(
      <RadioOption id="id" checked={false}>
        option
      </RadioOption>
    );

    const radioOption = baseElement.querySelector<HTMLInputElement>('#id');

    expect(radioOption.checked).toBe(false);
  });

  it('inline', () => {
    const { baseElement } = render(
      <RadioOption id="id" inline>
        option
      </RadioOption>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('named', () => {
    const { baseElement } = render(
      <RadioOption id="id" name="radio">
        option
      </RadioOption>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('hidden label', () => {
    const { baseElement } = render(
      <RadioOption id="id" name="radio" hiddenLabel>
        option
      </RadioOption>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('grouped by name', () => {
    const { baseElement } = render(
      <div>
        <RadioOption id="id1" name="radio" defaultChecked>
          option 1
        </RadioOption>
        <RadioOption id="id2" name="radio">
          option 2
        </RadioOption>
      </div>
    );

    const radioOptions = baseElement.querySelectorAll<HTMLInputElement>('[name="radio"]');
    fireEvent.click(radioOptions[1]);

    expect(radioOptions[0].checked).toEqual(false);
    expect(radioOptions[1].checked).toEqual(true);
  });

  it('calls change handler when checked', async () => {
    const onChangeCallback = jest.fn();

    const { baseElement } = render(
      <RadioOption id="id" onChange={onChangeCallback}>
        option
      </RadioOption>
    );

    const radioOption = baseElement.querySelector<HTMLInputElement>('#id');
    fireEvent.click(radioOption);

    expect(radioOption.checked).toEqual(true);
    expect(onChangeCallback).toHaveBeenCalled();
    expect(track).toHaveBeenCalledWith({
      grouping: 'Ungrouped',
      action: 'Checked',
      trackingKey: 'Radio-id',
    } as TrackableEvent);
  });

  it('calls change handler when checked with user provided analytics', async () => {
    const onChangeCallback = jest.fn();

    const myCustomTracking: TrackableEvent = {
      grouping: 'Tests',
      action: 'checking',
      trackingKey: 'radio button',
    };

    const { baseElement } = render(
      <RadioOption id="id" tracking={myCustomTracking} onChange={onChangeCallback}>
        option
      </RadioOption>
    );

    const radioOption = baseElement.querySelector<HTMLInputElement>('#id');
    fireEvent.click(radioOption);

    expect(radioOption.checked).toEqual(true);
    expect(onChangeCallback).toHaveBeenCalled();
    expect(track).toHaveBeenCalledWith({
      grouping: 'Tests',
      action: 'checking',
      trackingKey: 'radio button',
    } as TrackableEvent);
  });
});
