import React, { ChangeEvent, forwardRef, ReactElement } from 'react';
import { WithId } from '../../with-id';
import { WithInput } from '../../with-input';
import { IRadioOptionProps } from './radio-option';

export interface IRadioProps extends WithId, Omit<WithInput, 'name'> {
  /**
   * The content or radio options of this radio group
   */
  children: ReactElement<IRadioOptionProps>[];
  /**
   * Displays all the radio options horizontally (inline), instead of the default vertically
   */
  inline?: boolean;
  /**
   * Event handler for when any of the radio options are changed
   */
  onChange?: (event: ChangeEvent<HTMLInputElement>, value: string) => void;
  /**
   * Name of radio group when using radio options inside of form
   */
  name: string;
}

export const Radio = forwardRef<HTMLDivElement, IRadioProps>((props, ref) => {
  return (
    <div id={props.id} ref={ref}>
      {props.children.map((child) => {
        const { props: radioOptionProps } = child;
        return React.cloneElement(child, {
          name: props.name,
          disabled: props.disabled || radioOptionProps.disabled,
          inline: props.inline || radioOptionProps.inline,
          required: props.required || radioOptionProps.required,
          onChange: props.onChange || radioOptionProps.onChange,
          key: radioOptionProps.id,
        });
      })}
    </div>
  );
});

Radio.displayName = 'Radio';
