import { Meta, Story } from '@storybook/react';
import React, { ChangeEvent, useState } from 'react';
import { useForm } from 'react-hook-form';
import { Button } from '../../button/button';
import { SubmitButton } from '../../button/submit-button';
import { Documentation, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { action } from '@storybook/addon-actions';
import { FormGroup } from '../form-group/form-group';
import { getAllErrorMessages } from '../utils/hookform-utils';
import { Radio } from './radio';
import { RadioOption } from './radio-option';
import * as yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { Form } from '../form/form';

export default {
  component: Radio,
  subcomponents: { RadioOption },
  title: 'Core Components/Form Controls/Radio Buttons',
  parameters: {
    a11y: a11yConfig,
    badges: [StoryBadge.READY],
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const languageGuidelines = (
  <p>
    Use <strong>sentence case</strong> for list items. Capitalize the first word of the sentence or phrase, as well as
    any proper nouns.
  </p>
);

export const Example: Story = () => {
  return (
    <Radio id="radio" name="test">
      <RadioOption id="option-1" value={1}>
        potato
      </RadioOption>
      <RadioOption id="option-2" value={2}>
        corn
      </RadioOption>
    </Radio>
  );
};
Example.storyName = 'Radio Button';
Example.decorators = [
  (Story: Story) => (
    <Documentation
      name="Basic Example"
      description="Radio buttons allow users to see all available choices at once and select only one option."
      languageGuidelines={languageGuidelines}
    >
      <Story />
    </Documentation>
  ),
];
export const Controlled: Story = () => {
  const [selectedValue, setValue] = useState(0);

  const onChangeCallback = (e: ChangeEvent<HTMLInputElement>, value: string) => {
    setValue(Number(value));
  };

  return (
    <fieldset>
      <legend>What is your favorite food?</legend>
      <Radio name="test" id="controlled-radio" onChange={onChangeCallback}>
        <RadioOption id="controlled-potato" value={1} checked={selectedValue === 1}>
          potatoes
        </RadioOption>
        <RadioOption id="controlled-corn" value={2} checked={selectedValue === 2}>
          corn
        </RadioOption>
        <RadioOption id="controlled-croissant" value={3} checked={selectedValue === 3}>
          croissants
        </RadioOption>
      </Radio>
      {`selected value: ${selectedValue}`}
    </fieldset>
  );
};
Controlled.storyName = 'Controlled Radio Button';
Controlled.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Controlled Radio Buttons"
      description={
        <p>
          The value of a radio button can be controlled progrmatically with the <code>value</code> property. When using
          this property, the <code>onChange</code> handler property should be used to update the value when the user
          interacts the component.
        </p>
      }
      languageGuidelines={languageGuidelines}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const Disabled: Story = () => {
  return (
    <div>
      <Radio id="disable-multiple-radio" name="disable-multiple" disabled>
        <RadioOption id="disable-multiple-potato" value={1}>
          potato
        </RadioOption>
        <RadioOption id="disable-multiple-corn" value={2}>
          corn
        </RadioOption>
      </Radio>
      <hr />
      <Radio id="disable-single-radio" name="disable-single">
        <RadioOption id="disable-single-potato" value={1} disabled>
          potato
        </RadioOption>
        <RadioOption id="disable-single-corn" value={2}>
          corn
        </RadioOption>
      </Radio>
    </div>
  );
};
Disabled.storyName = 'Disabled Radio Button';
Disabled.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Disable"
      description={
        <p>
          Radio groups can be disabled with the <code>disabled</code> property. This property can also be used directly
          on radio buttons to disable specific buttons.
        </p>
      }
      languageGuidelines={languageGuidelines}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const Inline: Story = () => {
  return (
    <div>
      <Radio id="inline-radio" name="inline" inline>
        <RadioOption id="inline-potato" value={1}>
          potato
        </RadioOption>
        <RadioOption id="inline-corn" value={2}>
          corn
        </RadioOption>
      </Radio>
    </div>
  );
};
Inline.storyName = 'Inline Radio Button';
Inline.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Inline"
      description={
        <p>
          By default, buttons in radio groups are arranged vertically. However, they can be arranged horizonizontally
          with the <code>inline</code> keyword.
        </p>
      }
      languageGuidelines={languageGuidelines}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const DefaultChecked: Story = () => {
  const options = [
    {
      label: 'bread',
      value: 1,
    },
    {
      label: 'croissant',
      value: 2,
      defaultOption: true,
    },
  ];

  return (
    <div>
      <label>Mark-up Driven</label>
      <Radio id="default-radio" name="default">
        <RadioOption id="default-potato" value={1} defaultChecked>
          potato
        </RadioOption>
        <RadioOption id="default-corn" value={2}>
          corn
        </RadioOption>
      </Radio>

      <label>Logic Driven</label>
      <Radio id="default-radio-condition" name="default-condition">
        {options.map(({ label, value, defaultOption }) => (
          <RadioOption id={`default-${label}`} value={value} defaultChecked={defaultOption}>
            {label}
          </RadioOption>
        ))}
      </Radio>
    </div>
  );
};
DefaultChecked.storyName = 'Radio Button Default Selected';
DefaultChecked.decorators = [
  (Story: Story) => (
    <Documentation
      name="Default Selection/Checked"
      description={
        <div>
          <p>
            The <code>defaultChecked</code> property can be used to specify which radio option is checked by default.
          </p>
          <p>
            Since this property only affects the default selection (e.g. when the page is loaded), it will have no
            affect on changes to the selection made by users.
          </p>
          <p>
            This property should only be used with uncontrolled radio buttons. Therefore, it should{' '}
            <strong>never</strong> be used with radio options controlled by <code>checked</code> property.
          </p>
        </div>
      }
      languageGuidelines={languageGuidelines}
    >
      <Story />
    </Documentation>
  ),
];
export const RadioForm: Story = () => {
  const schema = yup.object().shape({
    formGrain: yup.string().nullable().required('This field is required'),
    formBread: yup.string().nullable(),
  });
  const resolver = yupResolver(schema);
  const {
    register,
    formState: { errors },
    handleSubmit,
    setValue,
  } = useForm({
    resolver,
    defaultValues: {
      formGrain: null,
      formBread: '4',
    },
  });
  const errorMessages = getAllErrorMessages(errors);

  const clearRadio = () => setValue('formBread', '');

  const onSubmit = (data: { selectValue: string }) => {
    action('submit-action')(data);
  };
  const onError = (data: unknown) => action('error-action')(data);

  return (
    <Form onSubmit={handleSubmit(onSubmit, onError)}>
      <label>Required Radio group</label>
      <FormGroup id="radio-grain-form-group" errorMessages={errorMessages['formGrain']}>
        <Radio id="form-radio-grain" name="formGrain" required>
          <RadioOption id="form-potato" value={1} {...register('formGrain')}>
            potato
          </RadioOption>
          <RadioOption id="form-corn" value={2} {...register('formGrain')}>
            corn
          </RadioOption>
        </Radio>
      </FormGroup>

      <label>Optional Radio group</label>
      <FormGroup id="radio-bread-form-group" errorMessages={errorMessages['formBread']}>
        <Radio id="form-radio-bread" name="formBread">
          <RadioOption id="form-bread" value={3} {...register('formBread')}>
            bread
          </RadioOption>
          <RadioOption id="form-croissant" value={4} {...register('formBread')}>
            croissant
          </RadioOption>
        </Radio>
      </FormGroup>

      <span className="mr-1">
        <SubmitButton id="submit-button">Submit</SubmitButton>
      </span>
      <Button id="clear-button" onClick={clearRadio}>
        Clear Optional Fields
      </Button>
    </Form>
  );
};
RadioForm.storyName = 'Radio Buttons in Form';
RadioForm.decorators = [
  (Story: Story) => (
    <Documentation
      name="Forms with Radio Buttons"
      description={
        <div>
          <p>Like other form controls, radio groups can be used be used as a field in a forms</p>

          <p>
            Radio groups can be made a required field by registering them using the <code>register</code> function from
            the <code>useForm</code> hook. (<strong>Note: </strong>Every option must be registered.)
          </p>

          <p>
            Radio groups that <strong>are not</strong> a required field <strong>should</strong> include a deselect or
            clear button. Likewise, radio groups that <strong>are</strong> a required field <strong>should not</strong>{' '}
            include a deselect or clear button
          </p>
        </div>
      }
      languageGuidelines={languageGuidelines}
    >
      <Story />
    </Documentation>
  ),
];

export const Empty: Story = () => {
  return (
    <RadioOption id="hidden-label-radio" value={1} hiddenLabel>
      The content is not visible
    </RadioOption>
  );
};
Empty.storyName = 'Radio button Without Labels';
Empty.decorators = [
  (Story: Story) => (
    <Documentation
      name="Empty Radio Buttons"
      description={
        <p>
          Radio Buttons can be displayed without the label visible with the <code>hiddenLabel</code> property.
        </p>
      }
      languageGuidelines={languageGuidelines}
    >
      <Story />
    </Documentation>
  ),
];
