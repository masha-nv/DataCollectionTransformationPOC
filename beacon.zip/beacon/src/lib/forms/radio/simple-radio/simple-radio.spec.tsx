import React from 'react';
import { act, render, screen } from '@testing-library/react';
import { DeepMap, FieldError, FieldValues } from 'react-hook-form';
import userEvent from '@testing-library/user-event';
import { ISimpleRadioOptionProp } from './simple-radio.types';
import { SimpleRadio } from './simple-radio';
const YES_NO_OPTIONS: ISimpleRadioOptionProp[] = [
  {
    value: 'Yes',
    label: 'Yes',
  },
  {
    value: 'No',
    label: 'No',
  },
];

const ID = 'ID';
const FIELD = 'FIELD';
const CLEARABLE = true;

describe('Simple Radio', () => {
  let errors: DeepMap<FieldValues, FieldError> = {};
  let setValue = jest.fn();

  const createSimpleRadio = (defaultValue: string | undefined, clearable: boolean) => {
    errors = {};
    setValue = jest.fn();

    return render(
      <SimpleRadio
        id={ID}
        field={FIELD}
        label="Simple Radio:"
        errors={errors}
        value={defaultValue}
        setValue={setValue}
        options={YES_NO_OPTIONS}
        clearable={clearable}
      />
    );
  };

  it('renders without default value', () => {
    const defaultValue: string = undefined;
    const { baseElement } = createSimpleRadio(defaultValue, !CLEARABLE);
    expect(baseElement).toMatchSnapshot();
    expect(setValue.mock.calls).toEqual([[FIELD, defaultValue]]);
  });

  it('renders with default value', () => {
    const defaultValue = 'Yes';
    const { baseElement } = createSimpleRadio(defaultValue, !CLEARABLE);
    expect(baseElement).toMatchSnapshot();
    expect(setValue.mock.calls).toEqual([[FIELD, defaultValue]]);
  });

  it('renders clearable', () => {
    const defaultValue = 'Yes';
    const { baseElement } = createSimpleRadio(defaultValue, CLEARABLE);
    expect(baseElement).toMatchSnapshot();
    expect(setValue.mock.calls).toEqual([[FIELD, defaultValue]]);
  });

  it('clear works', async () => {
    const defaultValue = 'Yes';
    const { baseElement } = createSimpleRadio(defaultValue, CLEARABLE);
    await act(async () => {
      userEvent.click(screen.getByText('Clear'));
    });
    expect(baseElement).toMatchSnapshot();
    expect(setValue.mock.calls).toEqual([
      [FIELD, defaultValue],
      [FIELD, undefined],
    ]);
  });

  it('change selection works', async () => {
    const defaultValue = 'Yes';
    const { baseElement } = createSimpleRadio(defaultValue, CLEARABLE);
    await act(async () => {
      userEvent.click(screen.getByText('No'));
    });

    expect(baseElement).toMatchSnapshot();
    expect(setValue.mock.calls).toEqual([
      [FIELD, defaultValue],
      [FIELD, 'No'],
    ]);
  });
});
