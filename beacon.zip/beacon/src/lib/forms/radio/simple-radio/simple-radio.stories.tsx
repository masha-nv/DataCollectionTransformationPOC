import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../../../stories';
import { a11yConfig } from '../../../stories/story.config';
import { SimpleRadio } from './simple-radio';
import { ISimpleRadioOptionProp, ISimpleRadioProps } from './simple-radio.types';

export default {
  component: SimpleRadio,
  title: 'Core Components/Form Controls/Radio Buttons',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const whenToUse = (
  <p>
    Use SimpleRadio when you have a pre-defined list of options and don't want to manually create all of the
    RadioOptions.
  </p>
);

const simpleRadioOptions: ISimpleRadioOptionProp[] = [
  {
    value: 1234,
    label: 'Option 1',
  },
  {
    value: 6927,
    label: 'Option 2',
  },
  {
    value: 9082,
    label: 'Option 3',
  },
];

export const SimpleRadioStory: Story<ISimpleRadioProps> = () => {
  return (
    <div className="w-75">
      <div>
        <SimpleRadio
          id="simple-radio"
          field="simpleRadio"
          label="Simple Radio:"
          value={1234}
          options={simpleRadioOptions}
        />
      </div>
    </div>
  );
};

SimpleRadioStory.storyName = 'Simple Radio';

SimpleRadioStory.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Simple Radio : Auto-Populating Radio"
      description="This radio handles the population of the <IRadioOptionProps> tags for you."
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const SimpleRadioStoryWithClearable: Story<ISimpleRadioProps> = () => {
  return (
    <div className="w-75">
      <div>
        <SimpleRadio
          id="simple-radio"
          field="simpleRadio"
          label="Simple Radio:"
          value={1234}
          options={simpleRadioOptions}
          clearable={true}
        />
      </div>
    </div>
  );
};

SimpleRadioStoryWithClearable.storyName = 'Simple Radio w/ Clear Option';

SimpleRadioStoryWithClearable.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Simple Radio w/ Clear Option"
      description="This radio handles the population of the <IRadioOptionProps> tags for you and you need it to be clearable."
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
