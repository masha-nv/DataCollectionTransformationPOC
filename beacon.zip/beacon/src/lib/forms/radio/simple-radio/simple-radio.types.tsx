import { DeepMap, FieldError, FieldValues, UseFormSetValue } from 'react-hook-form';
import { RadioOptionType } from '../radio-option';

export interface ISimpleRadioOptionProp {
  /**
   * Text to display
   */
  label: string;
  /**
   * Value to set when selected
   */
  value: RadioOptionType;
}

export interface ISimpleRadioProps {
  /**
   * The id for the component
   */
  id: string;
  /**
   * Necessary for error messages if using errors, determiens the id of the form group
   */
  field: string;
  /**
   * The options that will populate the radio buttons
   */
  options: ISimpleRadioOptionProp[];
  /**
   * Sets the label for the field if provided
   */
  label?: string;
  /**
   * The current value of the selector
   */
  value?: string | number | readonly string[];
  /**
   * Method for setting the value of the selector when using ReactHookForm
   */
  setValue?: UseFormSetValue<FieldValues>;
  /**
   * Error determination
   */
  errors?: DeepMap<FieldValues, FieldError>;
  /**
   * Add clear button
   */
  clearable?: boolean;
  /**
   * Display options inline
   */
  inline?: boolean;

  isReadOnly?: boolean;
}
