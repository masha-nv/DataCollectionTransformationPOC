import { useState } from 'react';
import { FormGroup } from '../../form-group/form-group';
import { hookFormUtils } from '../../utils/hookform-utils';
import { Radio } from '../radio';
import { RadioOption, RadioOptionType } from '../radio-option';
import { ISimpleRadioOptionProp, ISimpleRadioProps } from './simple-radio.types';
import { Button, ButtonType } from '../../../button/button';

type RadioOptionTypeOrUndefined = RadioOptionType | undefined;

const getRadioOption = (
  props: ISimpleRadioProps,
  entry: ISimpleRadioOptionProp,
  selection: RadioOptionTypeOrUndefined,
  setSelection: React.Dispatch<React.SetStateAction<RadioOptionTypeOrUndefined>>
) => {
  const checked = selection ? selection === entry.value : false;
  return (
    <RadioOption
      key={`${props.field}-${entry.label}`}
      id={`${props.field}-${entry.label}`}
      value={props.value}
      checked={checked}
      onChange={() => {
        setSelection(entry.value);
      }}
    >
      {entry.label}
    </RadioOption>
  );
};

export const SimpleRadio = (props: ISimpleRadioProps) => {
  const [selection, setSelection] = useState<RadioOptionTypeOrUndefined>(props.value);
  if (props.setValue) {
    props.setValue(props.field, selection);
  }
  const options = props.options.map((entry: ISimpleRadioOptionProp) =>
    getRadioOption(props, entry, selection, setSelection)
  );
  if (props.clearable) {
    options.push(
      <Button
        type={ButtonType.tertiary}
        onClick={() => {
          setSelection(undefined);
        }}
        id={`${props.field}-clear`}
        key={`${props.field}-clear`}
        behavior={'button'}
      >
        Clear
      </Button>
    );
  }

  return (
    <FormGroup
      id={`${props.field}-fg`}
      errorMessages={props.errors ? hookFormUtils.getErrorMessages(props.errors, props.field) : undefined}
    >
      <Radio id={`${props.field}-radio`} name={props.field} inline={props.inline} disabled={props.isReadOnly}>
        {options}
      </Radio>
    </FormGroup>
  );
};
