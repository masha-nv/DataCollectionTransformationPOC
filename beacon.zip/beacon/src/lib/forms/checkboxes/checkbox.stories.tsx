import React, { ChangeEvent, useState } from 'react';
import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { Checkbox } from './checkbox';
import { useForm } from 'react-hook-form';
import { action } from '@storybook/addon-actions';
import { FormGroup } from '../form-group/form-group';
import { SubmitButton } from '../../button/submit-button';
import { Form } from '../form/form';
import * as yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { getAllErrorMessages, hookFormUtils } from '../utils/hookform-utils';
import { Label } from '../label/label';
import { RequiredFieldLegend } from '../required-field-legend/required-field-legend';
import { CheckboxList } from './checkbox-list';

export default {
  component: Checkbox,
  title: 'Core Components/Form Controls/Checkboxes',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const whenToUse = (
  <p>
    <strong>Checkbox</strong> should be used to check one of more options from a list. For multiple otions, use the
    CheckboxList component.
  </p>
);

export const BasicExample: Story = () => {
  return <Checkbox id="checkbox-default" label="Basic Checkbox" />;
};

BasicExample.storyName = 'Single Checkbox';

BasicExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Single Checkbox"
      description="Checkbox can be used to select one or more options"
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const BasicCheckboxList: Story = () => {
  return (
    <CheckboxList id="basic-checkbox-list" legend="Basic CheckboxList">
      <Checkbox id="option-1" value={1} label="Checkbox 1" />
      <Checkbox id="option-2" value={2} label="Checkbox 2" />
    </CheckboxList>
  );
};

BasicCheckboxList.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Basic CheckboxList"
      whenToUse={whenToUse}
      description="CheckboxList consists of multiple Checkbox elements."
    >
      <ComponentStory />
    </Documentation>
  ),
];

BasicCheckboxList.storyName = 'Checkbox List';

export const CheckboxListInAForm: Story = () => {
  const schema = yup.object().shape({
    testCheckboxList: yup.array().min(2, 'At least two options must be selected'),
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: 'onTouched',
    resolver: yupResolver(schema) /* A valid yup schema*/,
  });
  const onSubmit = (data: unknown) => {
    action('submit-action')(data);
    alert('Checked Value: ' + JSON.stringify(data));
  };

  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      <RequiredFieldLegend />
      <FormGroup id="fg-checkboxList" errorMessages={hookFormUtils.getErrorMessages(errors, 'testCheckboxList')}>
        <CheckboxList
          required
          selectAll
          id="checkbox-list-form-id-1"
          legend="CheckboxList in Form"
          {...register('testCheckboxList')}
          defaultChecked={['Option 2']}
        >
          <Checkbox id="form-option-1" value="Option 1" label="Option 1" />
          <Checkbox id="form-option-2" value="Option 2" label="Option 2" />
          <Checkbox id="form-option-3" value="Option 3" label="Option 3" />
          <Checkbox id="form-option-4" value="Option 4" label="Option 4" />
        </CheckboxList>
      </FormGroup>
      <SubmitButton id="button-toggle">Submit CheckboxList</SubmitButton>
    </Form>
  );
};

CheckboxListInAForm.storyName = 'Checkbox List in a Form';

CheckboxListInAForm.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Form Usage"
      whenToUse={whenToUse}
      description="CheckboxList can be used in forms, and works with yup validation."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const CustomLabelCheckbox: Story = () => {
  return <Checkbox id="checkbox-custom-label" label={<strong>Custom label</strong>} />;
};
CustomLabelCheckbox.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Custom Label Checkbox"
      whenToUse={whenToUse}
      description="CheckboxList consists of multiple Checkbox elements."
    >
      <ComponentStory />
    </Documentation>
  ),
];
CustomLabelCheckbox.storyName = 'Custom Label Checkbox';

export const CheckboxChecked: Story = () => {
  return <Checkbox id="checkbox-default-checked" label="Checked by default" defaultChecked />;
};

CheckboxChecked.storyName = 'Checkbox Checked by Default';

CheckboxChecked.decorators = [
  (CompoentStory: Story) => (
    <Documentation
      name="	Checkbox Checked by Default"
      description={
        <p>
          Checkboxes can be checked by default (or page load) with <code>defaultChecked</code> property.
        </p>
      }
      whenToUse={whenToUse}
    >
      <CompoentStory />
    </Documentation>
  ),
];
export const CheckboxDisabled: Story = () => {
  return <Checkbox id="checkbox-default-disabled" label="Disabled Checkbox" disabled />;
};

CheckboxDisabled.storyName = 'Disabled Checkbox';

CheckboxDisabled.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Disabled Checkbox"
      description={
        <p>
          Checkboxes can be disabled with the <code>disable</code> property.
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const DisabledSelectAllCheckbox: Story = () => {
  return (
    <>
      <div className="mb-4">
        <CheckboxList selectAll id="fully-disabled-checkbox-list" legend="Fully Disabled CheckboxList" disabled>
          <Checkbox id="disabled-option-1" value={1} label="Disabled Checkbox 1" />
          <Checkbox id="disabled-option-2" value={2} label="Disabled Checkbox 2" />
        </CheckboxList>
      </div>
      <CheckboxList selectAll id="partially-disabled-checkbox-list" legend="Partially Disabled CheckboxList">
        <Checkbox id="disabled-partial-option-1" value={1} label="Disabled Checkbox 1" disabled />
        <Checkbox id="enabled-partial-option-2" value={2} label="Enabled Checkbox 2" />
      </CheckboxList>
    </>
  );
};

DisabledSelectAllCheckbox.storyName = 'Disabled Select All Checkbox';

DisabledSelectAllCheckbox.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Disabled Checklist"
      whenToUse={whenToUse}
      description="Checkboxes in a list can be either disabled at the group level, or at individual levels."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const DefaultCheckedSelectAllCheckbox: Story = () => {
  return (
    <CheckboxList
      selectAll
      id="default-checked-checkbox-list"
      legend="Default Checked CheckboxList"
      defaultChecked={['a']}
    >
      <Checkbox id="default-checked-option-1" value={'a'} label="Default Checked Checkbox" />
      <Checkbox id="default-unchecked-option-2" value={'b'} label="Unchecked Checkbox 2" />
    </CheckboxList>
  );
};

DefaultCheckedSelectAllCheckbox.storyName = 'Default Checked Select All Checkbox';

DefaultCheckedSelectAllCheckbox.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Default Checked Checklist"
      whenToUse={whenToUse}
      description="Checkboxes in a list can be set to checked by default, by inputing a list of strings in the defaultChecked prop."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const SelectAllCheckboxList: Story = () => {
  return (
    <CheckboxList selectAll id="select-all-checkbox-list" legend="Select All CheckboxList">
      <Checkbox id="select-all-option-1" value={1} label="Checkbox 1" />
      <Checkbox id="select-all-option-2" value={2} label="Checkbox 2" />
    </CheckboxList>
  );
};
SelectAllCheckboxList.storyName = 'Select All Checkbox';

SelectAllCheckboxList.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Select All Option"
      whenToUse={whenToUse}
      description="Select all option enables the user to select or deselect all options with one click."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const CheckboxChangeEvent: Story = () => {
  const [value, setValue] = useState('');
  const onChange = (event: ChangeEvent<HTMLInputElement>, value: string) => {
    setValue(`value: (${value}), checked: (${event.target.checked})`);
  };

  return (
    <div>
      <Checkbox id="checkbox-on-change-event" label="Checkbox with value" value={'CHK_VALUE'} onChange={onChange} />
      <hr />
      <Label>Checkbox On Change event:</Label>
      <span>{value}</span>
    </div>
  );
};

CheckboxChangeEvent.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Checkbox Change Event"
      description={
        <p>
          Events or changes to checkboxes can be responded to or handled via the <code>onChange</code> event handler
          property.
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];

CheckboxChangeEvent.storyName = 'Checkbox Change Event';

export const CheckboxForm: Story = () => {
  const schema = yup.object().shape({
    favoriteFruit: yup.array().min(1, 'Please select at least one fruit'),
    signupNewsletter: yup.boolean(),
    termsAndConditions: yup.boolean().oneOf([true], 'Please agree to all the terms and conditions before submitting'),
  });
  const resolver = yupResolver(schema);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver,
    mode: 'onChange',
    defaultValues: { termsAndConditions: false, favoriteFruit: ['banana'], signupNewsletter: true },
  });

  const errorMessages = getAllErrorMessages(errors);

  const onSubmit = (data: unknown) => {
    action('submit-action')(data);
  };

  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      <RequiredFieldLegend />
      <FormGroup id="form-group-favorite-fruit" errorMessages={errorMessages['favoriteFruit']}>
        <fieldset>
          <legend>
            <Label required>Which are your favorite fruits? (Select at least one option)</Label>
          </legend>
          <Checkbox id="checkbox-apple" label="apple" value="apple" {...register('favoriteFruit')} required />
          <Checkbox id="checkbox-banana" label="banana" value="banana" {...register('favoriteFruit')} required />
        </fieldset>
      </FormGroup>

      <hr />

      <FormGroup id="form-group-newsletter">
        <Checkbox
          id="checkbox-newsletter"
          label="Sign up for Fruit Newsleter (Please...)"
          {...register('signupNewsletter')}
        />
      </FormGroup>

      <FormGroup id="form-group-termsAndConditions" errorMessages={errorMessages['termsAndConditions']}>
        <Label required>Please provide the following indication:</Label>
        <Checkbox
          id="checkbox-termsAndConditions"
          label="I've read and accept the terms and conditions"
          {...register('termsAndConditions')}
          required
        />
      </FormGroup>
      <SubmitButton id="button-toggle">Submit Checkbox</SubmitButton>
    </Form>
  );
};

CheckboxForm.storyName = 'Checkbox Form';

CheckboxForm.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Form Checkbox using React-Hook-Form"
      description="Checkbox utilizing the React-Hook-Form library to submit the checkbox value."
      whenToUse={whenToUse}
      accessibilityConsiderations="When making checkboxes selectively required (e.g. at least one must be checked), provide a brief description of the criteria through the checkbox legend"
    >
      <ComponentStory />
    </Documentation>
  ),
];
