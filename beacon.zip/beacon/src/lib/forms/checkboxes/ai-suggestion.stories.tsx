import React from 'react';
import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { Checkbox, CheckboxVariant } from './checkbox';

export default {
  component: Checkbox,
  title: 'Core Components/AI Suggestions/Form Controls',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const description = <>Checkbox can be used to select one or more options</>;

const whenToUse = (
  <>
    AI Suggestion Checkboxes should be used anytime ELIS is using AI or machine learning to make suggestions to users.
  </>
);

const languageGuidelines = (
  <>
    <p>Same as standard Beacon checkbox, with the following exceptions:</p>
    <ul>
      <li>AI Suggestion checkboxes should only be used for actions related to AI/ML suggestions or reviews.</li>
      <li>
        AI Suggestion checkboxes should always be used instead of standard checkboxes inside of the AI Suggestion Card.
      </li>
    </ul>
  </>
);

export const AISuggestionCheckbox: Story = () => {
  return (
    <Checkbox id="checkbox-suggestion" label="Checkbox example" variant={CheckboxVariant.suggestion} defaultChecked />
  );
};

AISuggestionCheckbox.decorators = [
  (CompoentStory: Story) => (
    <Documentation
      name="AI Suggestion Checkbox"
      description={description}
      whenToUse={whenToUse}
      languageGuidelines={languageGuidelines}
    >
      <CompoentStory />
    </Documentation>
  ),
];
