import classNames from 'classnames';
import React, { ChangeEvent, forwardRef, ReactNode } from 'react';
import { getTrackableClickHandler, Trackable } from '../../analytics';
import { WithId } from '../../with-id';
import { WithInput } from '../../with-input';
import './checkbox.scss';

//Should be able to support number as well but checkbox-list is setup to require
//string. Leaving this type here so if it changes in the future we do not
//need to update everywhere else as the parameterization will handle it
export type CheckboxValueType = string;

export interface ICustomCheckboxProps extends Trackable, WithId, WithInput<HTMLInputElement, CheckboxValueType> {
  /**
   * Label can be as simple as a string, or can be customized by inserting your own html.
   */
  label: ReactNode;
  /**
   * The color variant to apply to the control
   */
  variant?: CheckboxVariant;
}

export enum CheckboxVariant {
  suggestion = 'suggestion',
}

export type ICheckboxProps = ICustomCheckboxProps &
  Omit<JSX.IntrinsicElements['input'], 'className' | 'ref' | 'type' | 'onChange' | 'onBlur'>;

export const Checkbox = forwardRef<HTMLInputElement, ICheckboxProps>(({ label, ...props }, ref) => {
  const { onChange, tracking, id } = props;

  const trackingDefaults = {
    grouping: 'Ungrouped',
    action: 'Checked/Unchecked',
    trackingKey: `Checkbox-${id}`,
  };

  const onChangeEventHandler = (event: ChangeEvent<HTMLInputElement>) => {
    onChange && onChange(event, event.target.value);
  };

  const controlClasses = classNames('custom-control custom-checkbox', {
    suggestion: props.variant === CheckboxVariant.suggestion,
  });

  return (
    <div className="beacon-checkbox">
      <label className={controlClasses}>
        <input
          {...props}
          type="checkbox"
          className="custom-control-input checkbox-input-realign"
          ref={ref}
          onChange={getTrackableClickHandler(tracking, trackingDefaults, onChangeEventHandler)}
        />
        <label htmlFor={id} className="custom-control-label custom-checkbox-group-label">
          {label}
        </label>
      </label>
    </div>
  );
});

Checkbox.displayName = 'Checkbox';
