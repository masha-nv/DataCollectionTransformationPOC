import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { Checkbox } from './checkbox';
import { track } from '../../analytics/matomo';
import { TrackableEvent } from '../../analytics';

jest.mock('../analytics/matomo', () => {
  const module = jest.requireActual('../analytics/matomo');
  return {
    ...module,
    track: jest.fn(),
  };
});

describe('Checkbox Component', () => {
  it('renders defualt checkbox', () => {
    const { baseElement } = render(<Checkbox id="text-checkbox" label="Test Checkbox" />);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders disabled checkbox', () => {
    const { baseElement } = render(<Checkbox id="text-checkbox-disabled" label="Test Checkbox Disabled" disabled />);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders default checked checkbox', () => {
    const { baseElement } = render(
      <Checkbox id="text-checkbox-checked" label="Test Checkbox Checked" defaultChecked />
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('renders default checked checkbox', () => {
    const { baseElement } = render(
      <Checkbox id="text-checkbox-checked" label="Test Checkbox Checked" defaultChecked />
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('checks checkbox when clicked', () => {
    const { baseElement } = render(<Checkbox id="text-checkbox-click" label="Test Checkbox Click" />);
    const inputElement = baseElement.querySelector('input');
    const checkboxLabelElement = screen.getByText('Test Checkbox Click');
    fireEvent.click(checkboxLabelElement);
    expect(track).toHaveBeenCalledWith({
      grouping: 'Ungrouped',
      action: 'Checked/Unchecked',
      trackingKey: 'Checkbox-text-checkbox-click',
    } as TrackableEvent);
    expect(inputElement?.checked).toEqual(true);
    expect(baseElement).toMatchSnapshot();
  });
});
