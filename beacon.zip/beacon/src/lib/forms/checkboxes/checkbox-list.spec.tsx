import React, { ChangeEvent, SyntheticEvent } from 'react';
import { render, fireEvent } from '@testing-library/react';
import { CheckboxList } from './checkbox-list';
import { Checkbox, CheckboxVariant } from './checkbox';

describe('Checkbox Group Component', () => {
  it('renders checkbox group successfully', () => {
    const { baseElement } = render(standardCheckboxList);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders disabled checkbox group', () => {
    const { baseElement } = render(disabledCheckboxList);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders single disabled option', () => {
    const { baseElement } = render(singleDisabledCheckboxList);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders checkbox group with default values', () => {
    const { baseElement } = render(selectAllOptonCheckboxListWithDefault);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders checkbox group with required attribute', () => {
    const { baseElement } = render(requiredCheckboxList);
    expect(baseElement).toMatchSnapshot();
  });

  it('runs custom onChange function', () => {
    let selectedValues: string[] = [];
    const onChangeHandler = (e: ChangeEvent<HTMLInputElement>, values: string[]) => {
      selectedValues = [...values];
    };
    const { baseElement, getByLabelText } = render(
      <CheckboxList id="checkbox-list-test-select-all" name="CheckboxListTestSelectAll" onChange={onChangeHandler}>
        <Checkbox id="test-checkbox-1" value={'1'} label="Test Checkbox 1"></Checkbox>
        <Checkbox id="test-checkbox-2" value={'2'} label="Test Checkbox 2"></Checkbox>
      </CheckboxList>
    );

    const checkbox1 = getByLabelText('Test Checkbox 1');
    const checkbox2 = getByLabelText('Test Checkbox 2');

    fireEvent.click(checkbox1);
    fireEvent.click(checkbox2);

    expect(selectedValues).toEqual(['1', '2']);
  });

  it('renders checkbox group with selectAll option', () => {
    const { baseElement } = render(selectAllOptonCheckboxList);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders checkbox group with variant', () => {
    const { baseElement } = render(
      <Checkbox id="checkbox-variant" label="Checkbox 1" variant={CheckboxVariant.suggestion}></Checkbox>
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('sets indeterminate attribute to Select All input when only some checkboxes are selected', () => {
    const { baseElement, getByLabelText } = render(selectAllOptonCheckboxList);
    const checkbox1 = getByLabelText('Test Checkbox 1');
    fireEvent.click(checkbox1);

    const selectAllCheckbox = getByLabelText('Select All');
    expect(selectAllCheckbox.getAttributeNames().includes('indeterminate')).toBe(true);

    const checkbox2 = getByLabelText('Test Checkbox 2');
    expect((checkbox1 as HTMLInputElement).checked).toBe(true);
    expect((checkbox2 as HTMLInputElement).checked).toBe(false);
  });

  it('removes indeterminate and sets Select All to checked when all children are checked', () => {
    const { baseElement, getByLabelText } = render(selectAllOptonCheckboxListWithDefault);

    const secondCheckboxLabel = getByLabelText('Test Checkbox 2');
    fireEvent.click(secondCheckboxLabel);

    const selectAllCheckbox = getByLabelText('Select All');
    expect(selectAllCheckbox.getAttributeNames().includes('indeterminate')).toBe(false);

    const checkbox1 = getByLabelText('Test Checkbox 1');
    const checkbox2 = getByLabelText('Test Checkbox 2');
    expect((checkbox1 as HTMLInputElement).checked).toBe(true);
    expect((checkbox2 as HTMLInputElement).checked).toBe(true);
  });

  it('deselects all checkboxes', () => {
    const { baseElement, getByLabelText } = render(selectAllOptonCheckboxListWithAllSelected);

    const selectAllInput = getByLabelText('Select All');
    fireEvent.click(selectAllInput, {
      target: { checked: false },
    });
    const checkbox1 = getByLabelText('Test Checkbox 1');
    const checkbox2 = getByLabelText('Test Checkbox 2');

    expect((selectAllInput as HTMLInputElement).checked).toBe(false);
    expect((checkbox1 as HTMLInputElement).checked).toBe(false);
    expect((checkbox2 as HTMLInputElement).checked).toBe(false);
  });

  it('selects all checkboxes', () => {
    const { baseElement, getByLabelText } = render(selectAllOptonCheckboxList);

    const selectAllInput = getByLabelText('Select All');

    fireEvent.click(selectAllInput);
    expect((selectAllInput as HTMLInputElement).checked).toBe(true);

    const checkbox1 = getByLabelText('Test Checkbox 1');
    const checkbox2 = getByLabelText('Test Checkbox 2');
    expect((checkbox1 as HTMLInputElement).checked).toBe(true);
    expect((checkbox2 as HTMLInputElement).checked).toBe(true);
  });

  it('selects all after selecting one checkbox first', () => {
    const { baseElement, getByLabelText } = render(selectAllOptonCheckboxList);

    const selectAllInput = getByLabelText('Select All');
    const checkbox1 = getByLabelText('Test Checkbox 1');
    const checkbox2 = getByLabelText('Test Checkbox 2');

    fireEvent.click(checkbox1);
    fireEvent.click(selectAllInput);

    expect((selectAllInput as HTMLInputElement).checked).toBe(true);
    expect((checkbox1 as HTMLInputElement).checked).toBe(true);
    expect((checkbox2 as HTMLInputElement).checked).toBe(true);
  });

  it('ignores disabled checkboxes when selecting all', () => {
    const { baseElement, getByLabelText } = render(selectAllWithPartialDisabled);
    const selectAllInput = getByLabelText('Select All');
    const checkbox1 = getByLabelText('Test Checkbox 1');
    const checkbox2 = getByLabelText('Test Checkbox 2');

    fireEvent.click(selectAllInput);

    expect(selectAllInput.getAttributeNames().includes('indeterminate')).toBe(true);
    expect((checkbox1 as HTMLInputElement).checked).toBe(false);
    expect((checkbox2 as HTMLInputElement).checked).toBe(true);
  });

  it('ignores onChange in children', () => {
    const consoleSpy = jest.spyOn(console, 'warn').mockImplementation();

    const onChangeHandler = (e: SyntheticEvent) => {
      return;
    };
    render(
      <CheckboxList id="checkbox-list-test-select-all" name="CheckboxListTestSelectAll">
        <Checkbox id="test-checkbox-1" value={'1'} label="Test Checkbox 1" onChange={onChangeHandler}></Checkbox>
        <Checkbox id="test-checkbox-2" value={'2'} label="Test Checkbox 2"></Checkbox>
      </CheckboxList>
    );

    expect(consoleSpy).toBeCalled();
  });

  it('ignores defaultChecked attribute in children', () => {
    const consoleSpy = jest.spyOn(console, 'warn').mockImplementation();

    const { baseElement } = render(
      <CheckboxList id="checkbox-list-test-select-all" name="CheckboxListTestSelectAll" defaultChecked={['2']}>
        <Checkbox id="test-checkbox-1" value={'1'} label="Test Checkbox 1" defaultChecked></Checkbox>
        <Checkbox id="test-checkbox-2" value={'2'} label="Test Checkbox 2"></Checkbox>
      </CheckboxList>
    );
    const firstInput = baseElement.querySelector('#test-checkbox-1');
    const secondInput = baseElement.querySelector('#test-checkbox-2');

    expect(consoleSpy).toBeCalled();
    expect(firstInput.getAttributeNames().includes('checked')).toBe(false);
    expect(secondInput.getAttributeNames().includes('checked')).toBe(true);
  });

  it('ignores name attribute in children', () => {
    const consoleSpy = jest.spyOn(console, 'warn').mockImplementation();

    const { baseElement } = render(
      <CheckboxList id="checkbox-list-test-select-all" name="CheckboxListTestSelectAll">
        <Checkbox id="test-checkbox-1" name="ignoredName" value={'1'} label="Test Checkbox 1"></Checkbox>
        <Checkbox id="test-checkbox-2" value={'2'} label="Test Checkbox 2"></Checkbox>
      </CheckboxList>
    );
    const firstInput = baseElement.querySelector('#test-checkbox-1');

    expect(consoleSpy).toBeCalled();
    expect(firstInput.getAttribute('name')).toEqual('CheckboxListTestSelectAll');
  });

  it('removes indeterminate and sets Select All to unchecked when all children are unchecked', () => {
    const { baseElement, getByLabelText } = render(
      <CheckboxList
        id="checkbox-list-test-select-all"
        name="CheckboxListTestSelectAll"
        selectAll
        defaultChecked={['a']}
      >
        <Checkbox id="test-checkbox-1" value={'a'} label="Test Checkbox 1"></Checkbox>
        <Checkbox id="test-checkbox-2" value={'b'} label="Test Checkbox 2"></Checkbox>
      </CheckboxList>
    );

    const firstCheckboxLabel = getByLabelText('Test Checkbox 1');
    fireEvent.click(firstCheckboxLabel);
    const selectAllCheckbox = getByLabelText('Select All');
    expect(selectAllCheckbox.getAttributeNames().includes('indeterminate')).toBe(false);
  });
});

const standardCheckboxList = (
  <CheckboxList id="checkbox-list-test-standard" name="CheckboxListTestStandard">
    <Checkbox id="test-checkbox-1" value={'a'} label="Test Checkbox 1"></Checkbox>
    <Checkbox id="test-checkbox-2" value={'b'} label="Test Checkbox 2"></Checkbox>
    <Checkbox id="test-checkbox-2" value={'c'} label="Test Checkbox 2"></Checkbox>
  </CheckboxList>
);

const disabledCheckboxList = (
  <CheckboxList id="checkbox-list-test-disabled" name="CheckboxListTestDisabled" disabled>
    <Checkbox id="test-checkbox-1" value={'a'} label="Test Checkbox 1"></Checkbox>
    <Checkbox id="test-checkbox-2" value={'b'} label="Test Checkbox 2"></Checkbox>
  </CheckboxList>
);

const singleDisabledCheckboxList = (
  <CheckboxList id="checkbox-list-test-disabled" name="CheckboxListTestDisabled">
    <Checkbox id="test-checkbox-1" value={'a'} label="Test Checkbox 1" disabled></Checkbox>
    <Checkbox id="test-checkbox-2" value={'b'} label="Test Checkbox 2"></Checkbox>
  </CheckboxList>
);

const selectAllOptonCheckboxList = (
  <CheckboxList id="checkbox-list-test-select-all" name="CheckboxListTestSelectAll" selectAll>
    <Checkbox id="test-checkbox-1" value={'a'} label="Test Checkbox 1"></Checkbox>
    <Checkbox id="test-checkbox-2" value={'b'} label="Test Checkbox 2"></Checkbox>
  </CheckboxList>
);

const requiredCheckboxList = (
  <CheckboxList id="checkbox-list-test-select-all" name="CheckboxListTestSelectAll" required>
    <Checkbox id="test-checkbox-1" value={'a'} label="Test Checkbox 1"></Checkbox>
    <Checkbox id="test-checkbox-2" value={'b'} label="Test Checkbox 2"></Checkbox>
  </CheckboxList>
);

const selectAllOptonCheckboxListWithAllSelected = (
  <CheckboxList
    id="checkbox-list-test-select-all"
    name="CheckboxListTestSelectAll"
    selectAll
    defaultChecked={['a', 'b']}
  >
    <Checkbox id="test-checkbox-1" value={'a'} label="Test Checkbox 1"></Checkbox>
    <Checkbox id="test-checkbox-2" value={'b'} label="Test Checkbox 2"></Checkbox>
  </CheckboxList>
);

const selectAllOptonCheckboxListWithDefault = (
  <CheckboxList id="checkbox-list-test-select-all" name="CheckboxListTestSelectAll" selectAll defaultChecked={['a']}>
    <Checkbox id="test-checkbox-1" value={'a'} label="Test Checkbox 1"></Checkbox>
    <Checkbox id="test-checkbox-2" value={'b'} label="Test Checkbox 2"></Checkbox>
  </CheckboxList>
);

const selectAllWithPartialDisabled = (
  <CheckboxList id="checkbox-list-test-select-all" name="CheckboxListTestSelectAll" selectAll>
    <Checkbox id="test-checkbox-1" value={'a'} label="Test Checkbox 1" disabled></Checkbox>
    <Checkbox id="test-checkbox-2" value={'b'} label="Test Checkbox 2"></Checkbox>
  </CheckboxList>
);
