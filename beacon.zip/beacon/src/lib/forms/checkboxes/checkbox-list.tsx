import React, { ChangeEvent, Children, forwardRef, SyntheticEvent, useEffect, useState } from 'react';
import { getTrackableClickHandler, Trackable } from '../../analytics';
import { WithId } from '../../with-id';
import { WithInput } from '../../with-input';
import { Checkbox, ICheckboxProps } from './checkbox';
import './checkbox-list.scss';

// eslint-disable-next-line @typescript-eslint/no-empty-function
const emptyOnChangeHandler = (e: ChangeEvent<HTMLInputElement>, value: string[]) => {};
interface ICheckboxListProp extends WithId, Trackable, WithInput<HTMLInputElement, string[]> {
  /**
   * Display label for the CheckboxList
   */
  legend?: string;
  /**
   * List of values to be checked by default
   */
  defaultChecked?: string[];
  /**
   * Shows a Select All checkbox at the top of the CheckboxList
   */
  selectAll?: boolean;

  children: React.ReactElement<ICheckboxProps>[];
}

export const CheckboxList = forwardRef<HTMLInputElement, ICheckboxListProp>(
  (
    {
      id,
      name,
      legend,
      defaultChecked = [],
      disabled = false,
      required = false,
      selectAll = false,
      onChange,
      children,
      tracking,
    },
    ref
  ) => {
    const onChangeResolved = onChange ? onChange : emptyOnChangeHandler;

    const [checkedList, setCheckedList] = useState(defaultChecked);
    const [allSelectedChecked, setAllSelectedChecked] = useState(false);

    useEffect(() => {
      onChangeResolved(
        {
          target: {
            name: name || '',
            value: checkedList,
          },
        } as unknown as React.ChangeEvent<HTMLInputElement>,
        checkedList
      );

      // manually set all checked to false when no values are checked
      if (checkedList.length === 0) {
        setAllSelectedChecked(false);
      }

      // manually set all checked to true when all values are checked
      if (checkedList.length === Children.count(children)) {
        setAllSelectedChecked(true);
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [checkedList]);

    // add all checkbox values to checked list when allSelectedChecked is toggled to true, empty otherwise
    const handleAllSelectedChange = ({ target }: SyntheticEvent) => {
      setAllSelectedChecked(!allSelectedChecked);
      if (!allSelectedChecked) {
        Children.map(children, (child) => {
          if (child.props.value && !child.props.disabled) {
            addToCheckedList(child.props.value.toString());
          }
        });
      } else {
        setCheckedList([]);
      }
    };

    const addToCheckedList = (value: string) => {
      if (!checkedList.includes(value)) {
        setCheckedList((prev) => {
          prev.push(value);
          return [...prev];
        });
      }
    };
    const removeFromCheckedList = (value: string) => {
      const index = checkedList.indexOf(value);
      setCheckedList((prev) => {
        prev.splice(index, 1);
        return [...prev];
      });
    };

    const trackingDefaults = {
      grouping: 'Ungrouped',
      action: 'All Checked/All Unchecked',
      trackingKey: `Checkbox-${id}`,
    };

    // set props up here to avoid ts checking of the "indeterminate" attribute that we use to style all checked box
    const isIndeterminate = checkedList.length !== 0 && checkedList.length !== Children.count(children);
    const selectAllInputProps = {
      type: 'checkbox',
      className: 'custom-control-input',
      id: id,
      checked: allSelectedChecked,
      'aria-checked': (isIndeterminate ? 'mixed' : allSelectedChecked) as 'mixed' | boolean,
      'aria-controls': children.map((item) => item.props.id).join(' '),
      onChange: getTrackableClickHandler(tracking, trackingDefaults, handleAllSelectedChange),
      disabled: disabled,
      indeterminate: isIndeterminate ? 'true' : undefined, // custom attribute used to style this select all checkbox
    };

    return (
      <fieldset>
        <legend>
          <label htmlFor={name} className={required ? 'form-label-required' : ''}>
            {legend}
          </label>
        </legend>
        {selectAll && (
          <div className="checkbox-metacontrol">
            <div className="custom-control custom-checkbox custom-select-all">
              <input {...selectAllInputProps}></input>
              <label className="custom-control-label" htmlFor={id}>
                Select All
              </label>
            </div>
          </div>
        )}
        {Children.map(children, (checkbox) => {
          const checkboxProps: ICheckboxProps = {
            ...checkbox.props,
          };

          if (checkboxProps.onChange != null) {
            console.warn(
              'When using an Checkboxes, define the "onChange" at the group level, the individual one will be ignored'
            );
          }
          if (checkboxProps.name != null) {
            console.warn(
              'When using an Checkboxes, define the "name" attribute at the group level, the individual one will be ignored'
            );
          }
          if (checkboxProps.defaultChecked != null) {
            console.warn(
              'When using an Checkboxes, provide the "defaultChecked" values at the group level, the individual one will be ignored'
            );
          }

          const onChangeHandler = ({ target }: ChangeEvent<HTMLInputElement>) => {
            if (target.checked) {
              addToCheckedList(target.value);
            } else {
              removeFromCheckedList(target.value);
            }
          };

          checkboxProps.name = name;

          return (
            <Checkbox
              {...checkboxProps}
              ref={ref}
              checked={checkedList.includes(checkboxProps.value ? checkboxProps.value.toString() : '')}
              disabled={checkboxProps.disabled || disabled}
              onChange={onChangeHandler}
              required={required}
            />
          );
        })}
      </fieldset>
    );
  }
);

CheckboxList.displayName = 'CheckboxList';
