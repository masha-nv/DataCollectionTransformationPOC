import { Checkbox, CheckboxValueType } from '../checkbox';
import { useState } from 'react';
import { FormGroup } from '../../form-group/form-group';
import { hookFormUtils } from '../../utils/hookform-utils';
import { CheckboxList } from '../checkbox-list';
import { ISimpleCheckboxOptionProp, ISimpleCheckboxProps } from './simple-checkbox-list-types';

const getCheckboxList = (props: ISimpleCheckboxProps, entry: ISimpleCheckboxOptionProp) => {
  return (
    <Checkbox
      key={`${props.field}-${entry.label}`}
      id={`${props.field}-${entry.label}`}
      value={entry.value}
      label={entry.label}
    ></Checkbox>
  );
};

export const SimpleCheckboxList = (props: ISimpleCheckboxProps) => {
  const [selection, setSelection] = useState<CheckboxValueType[]>(props.value);
  if (props.setValue) {
    props.setValue(props.field, selection);
  }
  const options = props.options.map((entry: ISimpleCheckboxOptionProp) => getCheckboxList(props, entry));

  return (
    <FormGroup
      id={`${props.field}-fg`}
      errorMessages={props.errors ? hookFormUtils.getErrorMessages(props.errors, props.field) : undefined}
    >
      <CheckboxList
        id={`${props.field}-checkboxlist`}
        name={props.field}
        defaultChecked={selection}
        onChange={(e, value) => {
          setSelection(value);
        }}
        disabled={props.isReadOnly}
      >
        {options}
      </CheckboxList>
    </FormGroup>
  );
};
