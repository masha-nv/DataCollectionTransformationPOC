import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../../../stories';
import { a11yConfig } from '../../../stories/story.config';
import { ISimpleCheckboxOptionProp, ISimpleCheckboxProps } from './simple-checkbox-list-types';
import { SimpleCheckboxList } from './simple-checkbox-list';

export default {
  component: SimpleCheckboxList,
  title: 'Core Components/Form Controls/Checkboxes',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const whenToUse = (
  <p>
    Use SimpleCheckboxList when you have a pre-defined list of options and don't want to manually create all of the
    checkboxes and the surrounding code.
  </p>
);

const simpleCheckboxOptions: ISimpleCheckboxOptionProp[] = [
  {
    value: '1234',
    label: 'Option 1',
  },
  {
    value: '6927',
    label: 'Option 2',
  },
  {
    value: '9082',
    label: 'Option 3',
  },
];

export const SimpleCheckboxListStory: Story<ISimpleCheckboxProps> = () => {
  return (
    <div className="w-75">
      <div>
        <SimpleCheckboxList
          id="simple-checkbox-list"
          field="simpleCheckboxList"
          label="Simple Checkbox List:"
          value={[simpleCheckboxOptions[0].value, simpleCheckboxOptions[2].value]}
          options={simpleCheckboxOptions}
        />
      </div>
    </div>
  );
};

SimpleCheckboxListStory.storyName = 'Simple Checkbox';

SimpleCheckboxListStory.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Simple Checkbox : Auto-Populating Checkbox List"
      description="This radio handles the population of the <Checkbox> tags for you."
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
