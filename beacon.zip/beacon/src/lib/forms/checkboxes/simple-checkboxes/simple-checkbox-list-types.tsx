import { DeepMap, FieldError, FieldValues, UseFormSetValue } from 'react-hook-form';
import { CheckboxValueType } from '../checkbox';

export interface ISimpleCheckboxOptionProp {
  /**
   * Text to display
   */
  label: string;
  /**
   * Value to set when selected
   */
  value: CheckboxValueType;
}

export interface ISimpleCheckboxProps {
  /**
   * The id for the component
   */
  id: string;
  /**
   * Necessary for error messages if using errors, determiens the id of the form group
   */
  field: string;
  /**
   * The options that will populate the radio buttons
   */
  options: ISimpleCheckboxOptionProp[];
  /**
   * Sets the label for the field if provided
   */
  label?: string;
  /**
   * The currently selected checkboxes
   */
  value: CheckboxValueType[];
  /**
   * Method for setting the value of the selector when using ReactHookForm
   */
  setValue?: UseFormSetValue<FieldValues>;
  /**
   * Error determination
   */
  errors?: DeepMap<FieldValues, FieldError>;

  isReadOnly?: boolean;
}
