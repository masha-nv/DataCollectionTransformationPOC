import React from 'react';
import { act, render, screen } from '@testing-library/react';
import { DeepMap, FieldError, FieldValues, UseFormSetValue } from 'react-hook-form';
import userEvent from '@testing-library/user-event';
import { ISimpleCheckboxOptionProp } from './simple-checkbox-list-types';
import { SimpleCheckboxList } from './simple-checkbox-list';

const CHECBOX_OPTIONS: ISimpleCheckboxOptionProp[] = [
  {
    value: 'OPTION_1',
    label: 'This is the first option',
  },
  {
    value: 'OPTION_2',
    label: 'This is the second option',
  },
  {
    value: 'OPTION_3',
    label: 'This is the this option',
  },
  {
    value: 'OPTION_4',
    label: 'This is the fourth option',
  },
  {
    value: 'OPTION_5',
    label: 'This is the fifth option',
  },
];

const ID = 'ID';
const FIELD = 'FIELD';

describe('Simple Checkbox List', () => {
  const createSimpleCheckboxList = (
    defaultValue: string[],
    setValue?: UseFormSetValue<FieldValues>,
    errors?: DeepMap<FieldValues, FieldError>
  ) => {
    return render(
      <SimpleCheckboxList
        id={ID}
        field={FIELD}
        label="Simple Checkbox List:"
        errors={errors}
        value={defaultValue}
        setValue={setValue}
        options={CHECBOX_OPTIONS}
      />
    );
  };

  it('renders default element', () => {
    const defaultValue = [CHECBOX_OPTIONS[0].value, CHECBOX_OPTIONS[3].value];
    const { baseElement } = createSimpleCheckboxList(defaultValue);
    expect(baseElement).toMatchSnapshot();
  });

  it('change selection works', async () => {
    const setValue = jest.fn();
    const errors: DeepMap<FieldValues, FieldError> = {};

    const defaultValue = [CHECBOX_OPTIONS[0].value, CHECBOX_OPTIONS[3].value];
    const { baseElement } = createSimpleCheckboxList(defaultValue, setValue, errors);
    await act(async () => {
      userEvent.click(screen.getByText('This is the second option'));
    });

    expect(baseElement).toMatchSnapshot();
    expect(setValue.mock.calls).toEqual([
      [FIELD, defaultValue],
      [FIELD, [CHECBOX_OPTIONS[0].value, CHECBOX_OPTIONS[3].value, CHECBOX_OPTIONS[1].value]],
    ]);
  });
});
