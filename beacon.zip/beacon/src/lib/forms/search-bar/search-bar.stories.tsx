import { Meta, Story } from '@storybook/react';
import React, { ChangeEvent, useState } from 'react';
import { Card } from '../../cards/card';
import { Documentation, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { Label } from '../label/label';
import { SearchBar, SearchResultSize } from './search-bar';

export default {
  component: SearchBar,
  title: 'Core Components/Form Controls/Search Bar',
  parameters: {
    a11y: a11yConfig,
    badges: [StoryBadge.BETA],
  },
} as Meta;

const fruits = ['apple', 'pear', 'banana', 'orange', 'kiwi', 'blueberry'];

interface Fruit {
  name: string;
  description: string;
  color: string;
}

const fruitsDetailed: Fruit[] = [
  {
    name: 'apple',
    description: 'An apple is an edible fruit produced by an apple tree (Malus domestica)...',
    color: 'red',
  },
  {
    name: 'pear',
    description:
      'Pears are fruits produced and consumed around the world, growing on a tree and harvested in late Summer into October...',
    color: 'lightgreen',
  },
  {
    name: 'banana',
    description:
      'A banana is an elongated, edible fruit – botanically a berry – produced by several kinds of large herbaceous flowering plants in the genus Musa...',
    color: 'yellow',
  },
  {
    name: 'orange',
    description:
      'The orange is the fruit of various citrus species in the family Rutaceae (see list of plants known as orange)...',
    color: 'orange',
  },
  {
    name: 'kiwi',
    description:
      'Kiwifruit (often shortened to kiwi in America) or Chinese gooseberry is the edible berry of several species of woody vines in the genus Actinidia...',
    color: 'green',
  },
  {
    name: 'blueberry',
    description: 'Blueberries are perennial flowering plants with blue or purple berries...',
    color: 'blue',
  },
];

export const Example: Story = () => {
  const [results, setResults] = useState<string[]>([]);
  // const fruits = ["apple", "pear", "banana", "orange", "kiwi", "blueberry"];

  const onChange = (e: ChangeEvent<HTMLInputElement>, query: string) => {
    const newResults = fruits.filter((fruit) => fruit.toLowerCase().includes(query.toLowerCase()));
    setResults(newResults);
  };

  return (
    <div className="w-50">
      <SearchBar id="search-bar" results={results} onChange={onChange} />
    </div>
  );
};

const whenToUse = (
  <p>
    <strong>Search Bars</strong> should be used to search for specific content if the user know what search terms to use
    or can't find desired content in the main navigation.
  </p>
);
Example.storyName = 'Search Bar';
Example.decorators = [
  (Story: Story) => (
    <Documentation
      name="Example"
      description={<p>A search box is a element used for searching for results based on a user input/query.</p>}
      whenToUse={whenToUse}
    >
      <Story />
    </Documentation>
  ),
];
export const Labeled: Story = () => {
  const [results, setResults] = useState<string[]>([]);

  const onChange = (e: ChangeEvent<HTMLInputElement>, query: string) => {
    const newResults = fruits.filter((fruit) => fruit.toLowerCase().includes(query.toLowerCase()));
    setResults(newResults);
  };

  return (
    <div>
      <label htmlFor="labelled-search-bar-input">Search for Fruits</label>
      <SearchBar id="labelled-search-bar" results={results} onChange={onChange} />
    </div>
  );
};
Labeled.storyName = 'Labeled Search Bar';
Labeled.decorators = [
  (LabeledStory: Story) => (
    <Documentation
      name="Labeled"
      description={
        <p>
          Similar to normal HTML input elements, search bars can be associated with labels by appending{' '}
          <code>-input</code> to its <code>id</code> property.
        </p>
      }
      whenToUse={whenToUse}
    >
      <LabeledStory />
    </Documentation>
  ),
];
export const Clearable: Story = () => {
  const [results, setResults] = useState<string[]>([]);

  const onChange = (e: ChangeEvent<HTMLInputElement>, query: string) => {
    const newResults = fruits.filter((fruit) => fruit.toLowerCase().includes(query.toLowerCase()));
    setResults(newResults);
  };

  return (
    <div>
      <SearchBar id="labelled-search-bar" results={results} onChange={onChange} clearable />
    </div>
  );
};
Clearable.storyName = 'Clearable Search Bar';
Clearable.decorators = [
  (ClearableStory: Story) => (
    <Documentation
      name="Clearable"
      description={
        <p>A clear button can be added in the search bar before the search button to clear the current input.</p>
      }
      whenToUse={whenToUse}
    >
      <ClearableStory />
    </Documentation>
  ),
];
export const ExternalResults: Story = () => {
  const [results, setResults] = useState(fruitsDetailed);

  const onChange = async (e: ChangeEvent<HTMLInputElement>, query: string) => {
    if (query.length === 0) {
      setResults(fruitsDetailed);
    }

    const containsQuery = (str: string) => str.toUpperCase().includes(query.toUpperCase());

    const filteredResults = fruitsDetailed.filter((item) => {
      return containsQuery(item.color) || containsQuery(item.description) || containsQuery(item.name);
    });

    setResults(filteredResults);
  };

  const ColorBlock = ({ color }: { color: string }) => {
    return (
      <span
        style={{
          float: 'right',
          backgroundColor: color,
          width: '10px',
          height: '10px',
          border: '1px solid black',
        }}
        role="presentation"
      />
    );
  };

  return (
    <div>
      <Label htmlFor="hide-results-search-bar">Search:</Label>
      <SearchBar id="hide-results-search-bar" onChange={onChange} hideResults allowEmpty />
      <div className="d-flex flex-wrap">
        {results.map((result) => (
          <div className="w-25 m-1" key={result.name}>
            <Card
              id={`${result.name}-card`}
              title={
                <span>
                  {result.name}
                  <ColorBlock color={result.color} />
                </span>
              }
            >
              {result.description}
            </Card>
          </div>
        ))}
      </div>
    </div>
  );
};
ExternalResults.storyName = ' Search Bar Displaying External Results';
ExternalResults.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="External Results"
      whenToUse={whenToUse}
      description={
        <p>
          The search bar can be used without the built-in results by providing the <code>hideResults</code> property.
          This can be useful when the search bar is used to filter data in an external target (e.g. table or list).
        </p>
      }
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const Sizes: Story = () => {
  const [results, setResults] = useState<string[]>([]);
  // const fruits = ["apple", "pear", "banana", "orange", "kiwi", "blueberry"];

  const onChange = (e: ChangeEvent<HTMLInputElement>, query: string) => {
    const newResults = fruits.filter((fruit) => fruit.toLowerCase().includes(query.toLowerCase()));
    setResults(newResults);
  };

  return (
    <div>
      <div className="mb-1">
        <h3>Small</h3>
        <SearchBar id="search-bar-small" size={SearchResultSize.small} results={results} onChange={onChange} />
      </div>
      <div className="mb-1">
        <h3>Medium</h3>
        <SearchBar id="search-bar-medium" size={SearchResultSize.medium} results={results} onChange={onChange} />
      </div>
      <div className="mb-1">
        <h3>Large</h3>
        <SearchBar id="search-bar-large" size={SearchResultSize.large} results={results} onChange={onChange} />
      </div>
    </div>
  );
};
Sizes.storyName = 'Search Bar Sizing';
Sizes.decorators = [
  (Story: Story) => (
    <Documentation
      name="Sizes"
      description={
        <p>
          The width of the search results can be controlled with <code>size</code> property.
        </p>
      }
      whenToUse={whenToUse}
    >
      <Story />
    </Documentation>
  ),
];
export const Validation: Story = () => {
  const [results, setResults] = useState<string[]>([]);
  // const fruits = ["apple", "pear", "banana", "orange", "kiwi", "blueberry"];

  const onChange = (e: ChangeEvent<HTMLInputElement>, query: string) => {
    const newResults = fruits.filter((fruit) => fruit.toLowerCase().includes(query.toLowerCase()));
    setResults(newResults);
  };

  const validate = (query: string) => {
    const lettersRegex = /^[A-Za-z]+$/;
    return lettersRegex.test(query);
  };

  return (
    <div className="beacon">
      <SearchBar id="validated-search-bar" results={results} validate={validate} onChange={onChange} />
    </div>
  );
};
Validation.storyName = 'Search Bar Validation';
Validation.decorators = [
  (Story: Story) => (
    <Documentation
      name="Validation"
      description={
        <p>
          Validation can be added to search bars using <code>validate</code> function property. All changes to input
          will run against the validation function. If it passes, then events will executed normally.
        </p>
      }
      whenToUse={whenToUse}
    >
      <Story />
    </Documentation>
  ),
];
const fetchData = async (query: string) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(fruits.filter((fruit) => fruit.toLowerCase().includes(query.toLowerCase())));
    }, 500);
  }) as Promise<string[]>;
};

const fetchDetailedData = async (query: string) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(fruitsDetailed.filter((fruit) => fruit.name.toLowerCase().includes(query.toLowerCase())));
    }, 500);
  }) as Promise<Fruit[]>;
};

export const CustomContent: Story = () => {
  const [results, setResults] = useState<Fruit[]>();
  const [loading, setLoading] = useState(false);

  const validate = (query: string) => {
    const lettersRegex = /^[A-Za-z]+$/;
    return lettersRegex.test(query);
  };

  const onChange = async (e: ChangeEvent<HTMLInputElement>, query: string) => {
    setLoading(true);
    const newResults = await fetchDetailedData(query);
    setResults(newResults);
    setLoading(false);
  };

  const ResultsComponent = (results: unknown[], onSelect: (result: unknown) => void) => {
    return (results as Fruit[]).map((result) => (
      <div className="btn-outline-secondary p-2" tabIndex={0} onClick={() => onSelect(result)}>
        <div
          style={{
            float: 'right',
            backgroundColor: result.color,
            width: '10px',
            height: '10px',
            border: '1px solid black',
          }}
        />
        <div>
          <strong>{result.name}</strong>
        </div>
        <div>{result.description}</div>
      </div>
    ));
  };

  const NoResultsComponent = (query: string) => {
    return (
      <div className="p-2">
        Unable to find any results for <strong>{query}</strong>
      </div>
    );
  };

  const LoadingComponent = <div className="p-2 text-center">Searching for results...</div>;

  const InvalidQueryComponent = (query: string) => (
    <div className="p-2">
      Invalid input. Your input (<strong>{query}</strong>) should only contain letters.
    </div>
  );

  return (
    <div className="beacon">
      <SearchBar
        id="custom-search-bar"
        results={results}
        onChange={onChange}
        validate={validate}
        loading={loading}
        resultsComponent={ResultsComponent}
        noResultsComponent={NoResultsComponent}
        loadingComponent={LoadingComponent}
        invalidQueryComponent={InvalidQueryComponent}
      />
    </div>
  );
};
CustomContent.storyName = 'Search Bar Validation Content Components';
CustomContent.decorators = [
  (Story: Story) => (
    <Documentation
      name="Custom Content"
      description={
        <div>
          <p>The components used in the search bar can be customized through various properties:</p>
          <ul>
            <li>
              <code>resultsComponent</code> - displayed as the results of the search bar
            </li>
            <li>
              <code>noResultsComponent</code> - displayed when they are not any results
            </li>
            <li>
              <code>loadingComponent</code> - displayed when the search bar is loading
            </li>
            <li>
              <code>invalidQueryComponent</code> - displayed when the input/text is invalid (i.e. fails the validation
              function)
            </li>
          </ul>
        </div>
      }
      whenToUse={whenToUse}
    >
      <Story />
    </Documentation>
  ),
];
export const ServerSideResults: Story = () => {
  const [results, setResults] = useState<string[]>();
  const [loading, setLoading] = useState(false);

  const onChange = async (e: ChangeEvent<HTMLInputElement>, query: string) => {
    setLoading(true);
    const newResults = await fetchData(query);
    setResults(newResults);
    setLoading(false);
  };

  return (
    <div className="beacon">
      <SearchBar id="server-search-bar" results={results} onChange={onChange} loading={loading} debounce={500} />
    </div>
  );
};
ServerSideResults.storyName = 'Search Bar Validation Server Side Results';
ServerSideResults.decorators = [
  (Story: Story) => (
    <Documentation
      name="Server Side Results"
      description={
        <p>
          Search bars can be used with server-side or asynchronous results using <code>loading</code> property. When
          enabled, the search bar will show a loading message in place of any results. This property should be enabled
          before any asynchronous request and disabled after the request has finished.
        </p>
      }
      whenToUse={whenToUse}
    >
      <Story />
    </Documentation>
  ),
];
export const Entering: Story = () => {
  const [results, setResults] = useState<string[]>([]);

  const onChange = (e: ChangeEvent<HTMLInputElement>, query: string) => {
    const newResults = fruits.filter((fruit) => fruit.toLowerCase().includes(query.toLowerCase()));
    setResults(newResults);
  };

  const onPressEnter = (query: string) => {
    alert(`You have tried to enter "${query}"`);
  };

  return <SearchBar id="enter-search-bar" results={results} onChange={onChange} onPressEnter={onPressEnter} />;
};
Entering.storyName = 'Using Enter/Return in Search Bar';
Entering.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Entering"
      description={
        <p>
          When clicking ENTER/RETURN⏎ (with some input), the search bar will trigger the <code>onPressEnter</code>{' '}
          callback.
        </p>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
