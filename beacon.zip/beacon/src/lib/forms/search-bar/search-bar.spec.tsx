import { findByText, fireEvent, render, screen, waitFor } from '@testing-library/react';
import userEvent, { specialChars } from '@testing-library/user-event';
import React from 'react';
import { SearchBar, SearchResultSize } from './search-bar';
import { enumKeys } from '../../stories/documentation';
import { Button } from '../../button/button';
import { noop } from '../../utils';

describe('SearchBar', () => {
  enumKeys(SearchResultSize).forEach((resultSize) => {
    it(`renders ${resultSize} results`, async () => {
      const onChange = jest.fn();
      const { baseElement } = render(
        <SearchBar id="search-bar" onChange={onChange} size={SearchResultSize[resultSize]} />
      );

      userEvent.type(baseElement.querySelector('#search-bar-input'), 'berry');
      await waitFor(() => expect(onChange).toHaveBeenCalled());

      expect(baseElement).toMatchSnapshot();
    });
  });

  it('renders search results and triggers callback when input is typed', async () => {
    const onChange = jest.fn();
    const { container } = render(
      <SearchBar id="search-bar" results={['blueberry', 'strawberry']} onChange={onChange} />
    );

    userEvent.type(container.querySelector('#search-bar-input'), 'berry');
    await waitFor(() => expect(onChange).toHaveBeenCalled());

    expect(container).toMatchSnapshot();
  });

  it('triggers callback when a search result is selected', async () => {
    const onChange = jest.fn();
    const onSelect = jest.fn();
    const { baseElement } = render(
      <SearchBar id="search-bar" results={['blueberry', 'strawberry']} onChange={onChange} onSelect={onSelect} />
    );

    userEvent.type(baseElement.querySelector('#search-bar-input'), 'berry');
    await waitFor(() => {
      expect(onChange).toHaveBeenCalled();
    });
    fireEvent.click(await findByText(baseElement as HTMLElement, 'strawberry'));

    expect(onSelect).toHaveBeenCalledWith('strawberry');
  });

  it('closes results when clicking outside of the search bar', async () => {
    const onChange = jest.fn();
    const { baseElement } = render(
      <div>
        <SearchBar id="search-bar" onChange={onChange} />
        <div id="not-in-search-bar-block" />
      </div>
    );

    userEvent.type(baseElement.querySelector('#search-bar-input'), 'berry');
    await waitFor(() => expect(onChange).toHaveBeenCalled());
    fireEvent.mouseDown(baseElement.querySelector('#not-in-search-bar-block'));

    expect(baseElement).toMatchSnapshot();
  });

  it('triggers callback when clicking enter while having input', async () => {
    const onPressEnter = jest.fn();
    const onChange = jest.fn();
    const { baseElement } = render(
      <SearchBar id="search-bar" results={[]} onPressEnter={onPressEnter} onChange={onChange} />
    );

    userEvent.type(baseElement.querySelector('#search-bar-input'), 'berry');
    await waitFor(() => expect(onChange).toHaveBeenCalled());

    userEvent.type(baseElement.querySelector('#search-bar-input'), specialChars.enter);

    expect(onPressEnter).toHaveBeenCalledWith('berry');
  });

  it('does not triggers callback when clicking enter while not having input', async () => {
    const onPressEnter = jest.fn();
    const { container } = render(<SearchBar id="search-bar" onPressEnter={onPressEnter} />);

    userEvent.type(container.querySelector('#search-bar-input'), specialChars.enter);
    await findByText(container, 'Your input is not valid.');

    expect(onPressEnter).not.toHaveBeenCalled();
  });

  it('does trigger callback when clicking enter while not having input if allowEmpty true', async () => {
    const onPressEnter = jest.fn();
    const { container } = render(<SearchBar id="search-bar" allowEmpty onPressEnter={onPressEnter} />);

    userEvent.type(container.querySelector('#search-bar-input'), specialChars.enter);
    await waitFor(() => expect(onPressEnter).toHaveBeenCalled());

    expect(onPressEnter).toHaveBeenCalled();
  });

  it('triggers callback when clicking the icon while having input', async () => {
    const onPressEnter = jest.fn();
    const onChange = jest.fn();
    const { baseElement } = render(
      <SearchBar id="search-bar" results={[]} onPressEnter={onPressEnter} onChange={onChange} />
    );

    userEvent.type(baseElement.querySelector('#search-bar-input'), 'berry');
    await waitFor(() => expect(onChange).toHaveBeenCalled());

    userEvent.click(baseElement.querySelector('#beacon-icon-clickable'));
    expect(onPressEnter).toHaveBeenCalledWith('berry');
  });

  it('does not trigger callback when clicking the icon while not having input if allowEmpty false', async () => {
    const onPressEnter = jest.fn();
    const { baseElement } = render(<SearchBar id="search-bar" onPressEnter={onPressEnter} />);

    userEvent.click(baseElement.querySelector('#beacon-icon-clickable'));
    await waitFor(() => expect(onPressEnter).not.toHaveBeenCalled());

    expect(onPressEnter).not.toHaveBeenCalled();
  });

  it('does trigger callback when clicking the icon while not having input if allowEmpty true', async () => {
    const onPressEnter = jest.fn();
    const { baseElement } = render(<SearchBar id="search-bar" allowEmpty onPressEnter={onPressEnter} />);

    userEvent.click(baseElement.querySelector('#beacon-icon-clickable'));
    await waitFor(() => expect(onPressEnter).toHaveBeenCalled());

    expect(onPressEnter).toHaveBeenCalled();
  });

  it('does trigger callback when clicking the icon while having input if allowEmpty true', async () => {
    const onPressEnter = jest.fn();
    const onChange = jest.fn();
    const { baseElement } = render(
      <SearchBar id="search-bar" allowEmpty onPressEnter={onPressEnter} onChange={onChange} />
    );

    userEvent.type(baseElement.querySelector('#search-bar-input'), 'berry');
    await waitFor(() => expect(onChange).toHaveBeenCalled());

    userEvent.click(baseElement.querySelector('#beacon-icon-clickable'));
    await waitFor(() => expect(onPressEnter).toHaveBeenCalled());

    expect(onPressEnter).toHaveBeenCalled();
    expect(onPressEnter).toHaveBeenCalledWith('berry');
  });

  it('validates, renders invalid results and does not trigger callback', async () => {
    const validate = () => false;
    const onChange = jest.fn();
    const { container } = render(<SearchBar id="search-bar" validate={validate} onChange={onChange} />);

    userEvent.type(container.querySelector('#search-bar-input'), 'berry');
    await findByText(container, 'Your input is not valid.');

    expect(onChange).not.toHaveBeenCalled();
    expect(container).toMatchSnapshot();
  });

  it('validates, renders valid results and triggers callback', async () => {
    const validate = () => true;
    const onChange = jest.fn();
    const { baseElement } = render(
      <SearchBar id="search-bar" results={['blueberry', 'strawberry']} onChange={onChange} validate={validate} />
    );

    userEvent.type(baseElement.querySelector('#search-bar-input'), 'berry');
    await waitFor(() => expect(onChange).toHaveBeenCalled());

    expect(baseElement).toMatchSnapshot();
  });

  it('displays no results', async () => {
    const onChange = jest.fn();
    const { baseElement } = render(<SearchBar id="search-bar" onChange={onChange} results={[]} />);

    userEvent.type(baseElement.querySelector('#search-bar-input'), 'berry');
    await waitFor(() => expect(onChange).toHaveBeenCalled());

    expect(baseElement).toMatchSnapshot();
  });

  it('displays loading', async () => {
    const onChange = jest.fn();
    const { baseElement } = render(<SearchBar id="search-bar" onChange={onChange} loading />);

    userEvent.type(baseElement.querySelector('#search-bar-input'), 'berry');
    await waitFor(() => expect(onChange).toHaveBeenCalled());

    expect(baseElement).toMatchSnapshot();
  });

  it('hides the search bar results when it loses focus', async () => {
    const onChange = jest.fn();
    const { baseElement } = render(
      <div>
        <SearchBar id="search-bar" results={['blueberry', 'strawberry']} onChange={onChange} />
        <Button id="focusable-btn" onClick={noop}>
          focusable
        </Button>
      </div>
    );

    userEvent.type(baseElement.querySelector('#search-bar-input'), 'berry');
    await waitFor(() => expect(onChange).toHaveBeenCalled());
    const externalButton = baseElement.querySelector<HTMLButtonElement>('#focusable-btn');
    externalButton.focus();

    await waitFor(() => expect(baseElement.querySelector('#search-bar-results')).toBe(null));
  });

  it('does not hides the search bar when it gains focus', async () => {
    const onChange = jest.fn();
    const { baseElement, findByText } = render(
      <SearchBar id="search-bar" results={['blueberry', 'strawberry']} onChange={onChange} />
    );

    userEvent.type(baseElement.querySelector('#search-bar-input'), 'berry');
    const focusableOption = await findByText('blueberry');
    focusableOption.focus();

    expect(baseElement).toMatchSnapshot();
  });

  it('triggers callback on empty results when allowed', async () => {
    const onChange = jest.fn();
    const { baseElement } = render(
      <SearchBar id="search-bar" results={['blueberry', 'strawberry']} onChange={onChange} allowEmpty />
    );

    const input = baseElement.querySelector('#search-bar-input');
    userEvent.type(input, 'berry');
    await waitFor(() => {
      expect(onChange).toHaveBeenCalled();
    });
    userEvent.clear(input);

    await waitFor(() => {
      expect(onChange.mock.calls[1][1]).toEqual('');
    });
  });

  it('can hide results', async () => {
    const onChange = jest.fn();
    const { baseElement, queryByText } = render(
      <SearchBar id="search-bar" results={['blueberry', 'strawberry']} onChange={onChange} hideResults />
    );

    userEvent.type(baseElement.querySelector('#search-bar-input'), 'berry');
    await waitFor(() => {
      expect(onChange).toHaveBeenCalled();
    });

    expect(queryByText('blueberry')).toBeNull();
  });

  it('shows clear button if clearable', () => {
    const { baseElement } = render(<SearchBar id="search-bar" onChange={noop} clearable />);
    expect(baseElement).toMatchSnapshot();
  });

  it('clears input when clear button is clicked', async () => {
    const onChange = jest.fn();
    const { baseElement } = render(
      <SearchBar id="search-bar" results={['blueberry', 'strawberry']} onChange={onChange} clearable />
    );

    userEvent.type(baseElement.querySelector('#search-bar-input'), 'strawberry');
    await waitFor(() => expect(screen.getByText('strawberry')).toBeTruthy());
    userEvent.click(baseElement.querySelector('#clear-btn'));

    await waitFor(() => expect(screen.queryByText('strawberry')).not.toBeTruthy());
    expect(onChange).toHaveBeenCalledWith({ target: { value: '' } }, '');
  });
});
