import React, { FocusEventHandler, forwardRef, KeyboardEventHandler } from 'react';
import { noop } from '../../utils';
import { WithId } from '../../with-id';
import { WithInput } from '../../with-input';

interface ITextInputProps extends WithId, WithInput {
  /**
   * The type of input to render
   */
  type?: TextInputType;
  /**
   * The placeholder for the text input
   */
  placeholder?: string;
  /**
   * The popup title of the text input
   */
  title?: string;
  /**
   * The default value of the text input
   */
  defaultValue?: string;
  /**
   * The value of a controlled text input
   */
  value?: string;
  /**
   * The minimum value of the number input
   */
  min?: number;
  /**
   * The maximum value of the number input
   */
  max?: number;
  /**
   * The maximum text length for the text input
   */
  maxLength?: number;
  /**
   * Whether the text input is read-only (i.e. focusable and sent to form but cannot be modified)
   */
  readOnly?: boolean;
  /**
   * Whether the text input is focused when displayed
   */
  autoFocus?: boolean;
  /**
   * The ID(s) of the element(s) that describe the text input
   */
  ariaDescribedBy?: string;
  /**
   * The event handler for when after a key is pressed
   */
  onKeyPress?: KeyboardEventHandler<HTMLInputElement>;
  /**
   The event handler for when a key is released
   */
  onKeyUp?: KeyboardEventHandler<HTMLInputElement>;
  /**
   The event handler for when a key is being pressed
   */
  onKeyDown?: KeyboardEventHandler<HTMLInputElement>;
  /**
   The event handler for the text input is focused
   */
  onFocus?: FocusEventHandler<HTMLInputElement>;
}

export enum TextInputType {
  text = 'text',
  email = 'email',
  number = 'number',
  password = 'password',
  tel = 'tel',
  time = 'time',
  url = 'url',
  search = 'search',
}

export const TextInput = forwardRef<HTMLInputElement, ITextInputProps>(
  (
    {
      onChange = noop,
      onBlur = noop,
      onKeyPress = noop,
      onKeyUp = noop,
      onKeyDown = noop,
      onFocus = noop,
      type = TextInputType.text,
      ...props
    },
    ref
  ) => {
    return (
      <input
        id={props.id}
        className="form-control"
        type={type}
        ref={ref}
        value={props.value}
        defaultValue={props.defaultValue}
        name={props.name}
        placeholder={props.placeholder}
        title={props.title}
        aria-label={props['aria-label']}
        aria-describedby={props.ariaDescribedBy}
        disabled={props.disabled}
        readOnly={props.readOnly}
        autoComplete="off"
        autoFocus={props.autoFocus}
        required={props.required}
        min={props.min}
        max={props.max}
        maxLength={props.maxLength}
        onChange={(event) => onChange(event, event.target.value)}
        onKeyPress={onKeyPress}
        onKeyUp={onKeyUp}
        onKeyDown={onKeyDown}
        onFocus={onFocus}
        onBlur={onBlur}
      />
    );
  }
);

TextInput.displayName = 'TextInput';
