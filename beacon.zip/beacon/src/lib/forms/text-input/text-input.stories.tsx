import React, { ChangeEvent, useState } from 'react';
import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { TextInput, TextInputType } from './text-input';
import { Label } from '../label/label';

export default {
  component: TextInput,
  title: 'Core Components/Form Controls/Text Input',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const whenToUse = (
  <>
    <p>Text input boxes can span just one line or multiple lines depending on the amount of text to be entered.</p>
    <p>
      Text inputs should usually include a maximum number of characters, with some exceptions (such as a name field).{' '}
    </p>
    <ul>
      <li>
        <strong className="beacon-icon-success">Do</strong> include in-line validation in long forms in addition to any
        error messages that appear at the top of the form.
      </li>
      <li>
        <strong className="beacon-icon-success">Do</strong> include instructions or restrictions on what can be entered
        in a field. For example, if a password replacement field requires special characters and numbers, make that
        clear in the instructions.
      </li>
    </ul>
    <hr />
    <ul>
      <li>
        <strong className="beacon-icon-danger">Don't</strong> put any essential text inside the text field, such as
        instructions or labels, because the text disappears as soon as users click in the field. Any text you do use
        inside the text field should be helpful but not essential -- such as an example rather than instructions.
      </li>
      <li>
        <strong className="beacon-icon-danger">Don't</strong> break numbers with distinct sections into separate input
        fields (for example, phone numbers, Social Security Numbers, or credit card numbers). Use one input for a phone
        number, not three. This is because each field needs to be labeled for a screen reader, and the labels for fields
        broken into segments are often not meaningful to users.
      </li>
      <li>
        <strong className="beacon-icon-danger">Don't </strong>require users to write paragraphs of text in a single-line
        input box. Use a text area instead.
      </li>
    </ul>
  </>
);

const accessibilityConsiderations = (
  <ul>
    <li>
      Developer's Checklist
      <ul>
        <li>
          Display form controls in the same order in HTML as they appear on screen. Do not use CSS to rearrange the form
          controls. Screen readers narrate content in the order it appears in the HTML.
        </li>
        <li>
          Group each set of thematically related controls in a fieldset element. Use the legend element to offer a label
          within each one. The fieldset and legend elements make it easier for screen reader users to navigate the form.
        </li>
        <li>
          Use a single legend for a fieldset (this is required). One example of a common use of fieldset and legend is a
          question with radio button options for answers. The question text and radio buttons are wrapped in a fieldset,
          with the question itself being inside the legend tag.
        </li>
        <li>
          Only show error validation messages or validation stylings after a user has interacted with a particular
          field.
        </li>
        <li>
          Do not use placeholder text as a replacement for labels. Assistive technologies, such as screen readers, do
          not treat placeholder text as labels.
        </li>
      </ul>
    </li>
    <li>
      Designer's Checklist
      <ul>
        <li>
          Visually align validation messages with the input fields, so people using screen magnifiers can read them
          quickly.
        </li>
      </ul>
    </li>
  </ul>
);

const componentDescription =
  'A text input enables users to enter text, numerals, or special characters into a form (unless the field restricts input).';

export const BasicTextInput: Story = () => {
  return (
    <>
      <label htmlFor="input-id">Label</label>
      <TextInput id="input-id" name="input-name" type={TextInputType.text} />
    </>
  );
};
export const Controlled: Story = () => {
  const [value, setValue] = useState<string>('potato');

  const onChangeCallback = (e: ChangeEvent<HTMLInputElement>, value: string) => {
    setValue(value);
  };

  return (
    <div>
      <Label htmlFor="input-id">Enter value:</Label>
      <TextInput id="input-id" type={TextInputType.text} value={value} onChange={onChangeCallback} />
      <span>
        <strong>value: </strong>
        {value}
      </span>
    </div>
  );
};
export const Disabled: Story = () => {
  return (
    <>
      <label htmlFor="input-id">Label</label>
      <TextInput id="input-id" name="input-name" type={TextInputType.text} disabled defaultValue="Hello" />
    </>
  );
};

export const ReadOnly: Story = () => {
  return (
    <>
      <label htmlFor="input-id">Label</label>
      <TextInput id="input-id" name="input-name" type={TextInputType.text} readOnly defaultValue="Hello" />
    </>
  );
};

export const UsingNativeInputProperties: Story = () => {
  return (
    <>
      <label htmlFor="input-id">Enter Password</label>
      <TextInput id="input-id" name="input-name" type={TextInputType.password} placeholder="Enter password" />
    </>
  );
};

export const InputTime: Story = () => {
  return (
    <>
      <label htmlFor="input-id">Enter Time</label>
      <TextInput id="input-id" name="input-name" type={TextInputType.time} />
    </>
  );
};

export const WithDescription: Story = () => {
  return (
    <>
      <label htmlFor="input-id">Enter Alien Number:</label>
      <TextInput id="input-id" name="input-name" type={TextInputType.text} ariaDescribedBy="instructions-id" />
      <span id="instructions-id">Must have 9 numbers, the "A" is optional.</span>
    </>
  );
}

BasicTextInput.storyName = 'Text Input';
Controlled.storyName = 'Controlled Text Input';
Disabled.storyName = 'Disabled Text Input';
ReadOnly.storyName = 'Read-only Text Input';
UsingNativeInputProperties.storyName = 'Text Input Using Native Input Properties ';
InputTime.storyName = 'Time Input';

BasicTextInput.decorators = [
  (Story: Story) => (
    <Documentation
      name="Basic Text Input"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description={componentDescription}
    >
      <Story />
    </Documentation>
  ),
];

UsingNativeInputProperties.decorators = [
  (Story: Story) => (
    <Documentation
      name="Using native <input /> attributes like 'placeholder'"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description={componentDescription}
    >
      <Story />
    </Documentation>
  ),
];

Disabled.decorators = [
  (Story: Story) => (
    <Documentation
      name="Disabled control"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description={componentDescription}
    >
      <Story />
    </Documentation>
  ),
];

ReadOnly.decorators = [
  (Story: Story) => (
    <Documentation
      name="ReadOnly control"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description={componentDescription}
    >
      <Story />
    </Documentation>
  ),
];

Controlled.decorators = [
  (Story: Story) => (
    <Documentation
      name="Controlled Text Inputs"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description={
        <p>
          The value of a text input can be fully controlled (instead of them managing their state) with the{' '}
          <code>value</code> property. This property will always reflect the current value of the text input. If the
          text input is changed, this value (or the state variable that it is tied to) <strong>must be updated</strong>.
        </p>
      }
    >
      <Story />
    </Documentation>
  ),
];

InputTime.decorators = [
  (InputStory: Story) => (
    <Documentation
      name="Time Input"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description={
        <p>
          The text input can be used to input time in the format of <code>HH:mm aa</code>.
        </p>
      }
    >
      <InputStory />
    </Documentation>
  ),
];

WithDescription.decorators = [
  (InputStory: Story) => (
    <Documentation
      name="With Description"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description={
        <p>
          The text input can be associated with a description through the ariaDescribedBy prop.
        </p>
      }
    >
      <InputStory />
    </Documentation>
  ),
];
