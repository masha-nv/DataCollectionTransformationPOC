import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import { TextInput, TextInputType } from './text-input';
import userEvent from '@testing-library/user-event';

describe('TextInput', () => {
  it('renders TextInput for all types correctly', () => {
    const textInputArray = [];
    let key = 0;
    for (const type in TextInputType) {
      textInputArray.push(<TextInput key={`input_${++key}`} id="input-id" type={type as TextInputType} />);
    }

    const { baseElement } = render(<div>{textInputArray}</div>);
    expect(baseElement).toMatchSnapshot();
  });

  it('only uses the default value initially', () => {
    const { baseElement } = render(<TextInput id="input-id" defaultValue="new york" />);

    const input = baseElement.querySelector<HTMLInputElement>('#input-id');
    const initialValue = input.value;

    userEvent.type(input, ' bagel');

    expect(initialValue).toEqual('new york');
    expect(input.value).toEqual('new york bagel');
  });

  it('always uses it controlled value', () => {
    const { baseElement } = render(<TextInput id="input-id" value="new york" />);

    const input = baseElement.querySelector<HTMLInputElement>('#input-id');
    const initialValue = input.value;

    userEvent.type(input, 'bagel');

    expect(initialValue).toEqual('new york');
    expect(input.value).toEqual('new york');
  });

  it('calls key press handler', () => {
    const onKeyPressCallback = jest.fn();
    const { baseElement } = render(<TextInput id="input-id" onKeyPress={onKeyPressCallback} />);
    const input = baseElement.querySelector<HTMLInputElement>('#input-id');

    fireEvent.keyPress(input, { key: 'Enter', code: 13, charCode: 13 });

    expect(onKeyPressCallback).toHaveBeenCalled();
  });

  it('calls key up handler', () => {
    const onKeyUpCallback = jest.fn();
    const { baseElement } = render(<TextInput id="input-id" onKeyUp={onKeyUpCallback} />);
    const input = baseElement.querySelector<HTMLInputElement>('#input-id');

    fireEvent.keyUp(input, { key: 'Enter', code: 13, charCode: 13 });

    expect(onKeyUpCallback).toHaveBeenCalled();
  });

  it('calls key down handler', () => {
    const onKeyDownCallback = jest.fn();
    const { baseElement } = render(<TextInput id="input-id" onKeyDown={onKeyDownCallback} />);
    const input = baseElement.querySelector<HTMLInputElement>('#input-id');

    fireEvent.keyDown(input, { key: 'Enter', code: 13, charCode: 13 });

    expect(onKeyDownCallback).toHaveBeenCalled();
  });

  it('calls change handler when modified', () => {
    const onChangeCallback = jest.fn();
    const { baseElement } = render(<TextInput id="input-id" onChange={onChangeCallback} />);
    const input = baseElement.querySelector<HTMLInputElement>('#input-id');

    userEvent.type(input, 'cheese');

    expect(onChangeCallback).toHaveBeenCalled();
  });

  it('calls focus handler when focus', () => {
    const onFocusCallback = jest.fn();
    const { baseElement } = render(<TextInput id="input-id" onFocus={onFocusCallback} />);
    const input = baseElement.querySelector<HTMLInputElement>('#input-id');

    input.focus();

    expect(onFocusCallback).toHaveBeenCalled();
  });

  it('read-only', () => {
    const { container } = render(<TextInput id="input-id" readOnly />);
    const input = container.querySelector('#input-id');
    expect(input.attributes).toHaveProperty('readOnly');
  });

  it('autofocus', () => {
    const { container } = render(<TextInput id="input-id" autoFocus />);
    const input = container.querySelector('#input-id');
    expect(document.activeElement).toBe(input);
  });

  it('max length', () => {
    const { container } = render(<TextInput id="input-id" maxLength={4} />);
    const input = container.querySelector<HTMLInputElement>('#input-id');
    userEvent.type(input, 'abcd');
    expect(input.value).toEqual('abcd');
  });

  it('ariaDescribedBy', () => {
    const { container } = render(<TextInput id="input-id" ariaDescribedBy="description-id" />);
    const input = container.querySelector<HTMLInputElement>('#input-id');
    expect(input.getAttribute('aria-describedby')).toEqual('description-id');
  });
});
