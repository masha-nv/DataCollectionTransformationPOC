import { ReactElement } from 'react';
import { Trackable } from '../../analytics';
import { WithId } from '../../with-id';
import { WithInput } from '../../with-input';

export type SelectOptionValue = string | number | null;

export enum SelectType {
  primary = 'primary',
  secondary = 'secondary',
}

export enum SelectSize {
  small = 'small',
  medium = 'medium',
  large = 'large',
  fill = 'fill',
}

export interface ISelectOption {
  value: SelectOptionValue;
  label: ReactElement | string;
  title?: string;
}

export interface ISelectProps extends WithId, Trackable, WithInput<HTMLSelectElement, ISelectOption> {
  /**
   * Text that labels the select component
   */
  label?: string;
  /**
   * Must be a list of SelectOption elements
   */
  children: React.ReactElement<ISelectOptionProps>[];
  /**
   * Can either be primary or secondary
   */
  type?: SelectType;
  /**
   * Changes the min-width of the component. Can be either small, medium, or large
   */
  size?: SelectSize;
  /**
   * When true, allows null value to be selected from list of options
   */
  nullable?: boolean;
  /**
   * The value of a controlled select input
   */
  value?: SelectOptionValue;
  /**
   * Use this to specify text shown when null value is selected
   */
  unselectedText?: string;
  /**
   * Set this to true to allow filtering on the list of options. Queries are done on the label text.
   */
  filterable?: boolean;
  /**
   * Changes the max-height of the dropdown.
   */
  maxHeight?: string;
  /**
   * Removes tooltip
   */
  noTooltip?: boolean;
}

export interface ISelectOptionProps {
  /**
   * Value that will be recorded when the option is clicked
   */
  value: SelectOptionValue;
  /**
   *
   */
  defaultSelected?: boolean;
  /**
   * Set this to true to disable this option from being picked
   */
  disabled?: boolean;
  /**
   * This can be used to customize the title text when this list item is focused.
   * If option item is selected, this title is displayed on the main Select component.
   */
  title?: string;
  /**
   * Id for the option
   */
  id?: string;
  /**
   * Callback that is triggered when option is selected. This will be overwritten by the parent Select component.
   */
  onClick?: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;

  /**
   * Callback that is triggered when a key is pressed. This will be overwritten by the parent Select component.
   */
  onKeyDown?: (event: React.KeyboardEvent<HTMLButtonElement>) => void;

  /**
   * "frieldly text" that will appear on the select option
   */
  children: ReactElement | string;

  /**
   * Set this to true to add divider between SelectOptions. Useful for multi line custom elements.
   */
  showDivider?: boolean;
}
