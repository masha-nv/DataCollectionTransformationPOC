import React, { ChangeEvent, JSXElementConstructor, ReactElement } from 'react';
import { render, fireEvent, act, waitFor, screen } from '@testing-library/react';
import { Select, SelectOption } from './select';
import { ISelectOption, SelectSize, SelectType } from './select.types';
import userEvent from '@testing-library/user-event';
import { noop } from '../../utils';
import { Icon, IconType } from '../../icon/icon';

jest.mock('../analytics/matomo', () => {
  const module = jest.requireActual('../analytics/matomo');
  return {
    ...module,
    track: jest.fn(),
  };
});

const popperSelector = '.select-popper-container';
const inputHeaderSelector = '.select-filter-header';
const clearInputSelector = '.icon-clear';

describe('Select Component', () => {
  it('renders default select', () => {
    const { baseElement } = render(basicSelectWithType());
    expect(baseElement).toMatchSnapshot();
  });

  it('renders secondary select', () => {
    const { baseElement } = render(basicSelectWithType(SelectType.secondary));
    expect(baseElement).toMatchSnapshot();
  });

  it('renders disabled select', () => {
    const { baseElement } = render(disabledSelect);
    expect(baseElement).toMatchSnapshot();
  });

  test('renders disabled select without clear icon', async () => {
    render(disabledSelectDefaultSelected);
    await screen.findByDisplayValue(2);
    await waitFor(() => expect(screen.queryByTitle('Clear Input')).toBeFalsy());
  });

  it('renders one option disabled select', async () => {
    const { baseElement } = render(disabledOneOptionSelect);
    const selectElement = baseElement.querySelector(inputHeaderSelector);
    act(() => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());
    expect(baseElement).toMatchSnapshot();
  });

  it('renders nonNullable select', async () => {
    const { baseElement } = render(nonNullable);
    const selectElement = baseElement.querySelector(inputHeaderSelector);

    act(() => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());

    const selectedOption = baseElement.querySelector('#basic-select');
    expect(selectedOption.getAttribute('value')).toEqual('1');
    expect(baseElement).toMatchSnapshot();
  });

  it('renders required select', () => {
    const { baseElement } = render(required);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with custom titles', async () => {
    const { baseElement } = render(withCustomTitles);
    const selectElement = baseElement.querySelector(inputHeaderSelector);
    act(() => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());
    expect(baseElement).toMatchSnapshot();
  });

  it('renders filterable select', async () => {
    const { baseElement } = render(filterable);
    const selectElement = baseElement.querySelector(inputHeaderSelector);
    act(() => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());
    expect(baseElement).toMatchSnapshot();
  });

  it('renders large select', () => {
    const { baseElement } = render(selectWithSize(SelectSize.large));
    expect(baseElement).toMatchSnapshot();
  });

  it('renders small select', () => {
    const { baseElement } = render(selectWithSize(SelectSize.small));
    expect(baseElement).toMatchSnapshot();
  });

  it('renders a fill select', () => {
    const { baseElement } = render(selectWithSize(SelectSize.fill));
    expect(baseElement).toMatchSnapshot();
  });

  it('renders select without tooltip', () => {
    const { baseElement } = render(basicSelectWithoutTooltip());
    expect(baseElement).toMatchSnapshot();
  });

  it('filters options based on input in filter box', async () => {
    const { baseElement } = render(filterable);

    const selectElement = baseElement.querySelector(inputHeaderSelector);
    act(() => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());

    const filterInput = baseElement.querySelector('#basic-select');
    await act(async () => {
      userEvent.type(filterInput, '1');
    });

    expect(filterInput.getAttribute('value')).toEqual('1');
    expect(baseElement).toMatchSnapshot();
  });

  it('closes dropdown when escape is pressed', async () => {
    const { baseElement } = render(basicSelectWithType());

    const selectElement = baseElement.querySelector(inputHeaderSelector);
    act(() => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());

    const nullOption = baseElement.querySelector('#basic-select');

    await act(async () => {
      fireEvent.focus(nullOption);
      fireEvent.keyDown(nullOption, {
        key: 'Escape',
      });
    });

    expect(baseElement).toMatchSnapshot();
  });

  it('selects null value and sets null as value', async () => {
    const { baseElement } = render(basicSelectWithType());

    const selectElement = baseElement.querySelector(inputHeaderSelector);
    await act(async () => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());

    const nullOption = baseElement.querySelector('#basic-select');
    await act(async () => {
      fireEvent.click(nullOption);
    });

    expect(selectElement.getAttribute('value')).toBe(null);
  });

  it('selects option with value', async () => {
    const { baseElement } = render(basicSelectWithType());

    const selectElement = baseElement.querySelector(inputHeaderSelector);
    await act(async () => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());

    const secondOption = baseElement.querySelector('#basic-select-option-1');
    await act(async () => {
      fireEvent.click(secondOption);
    });

    const selectedOption = baseElement.querySelector('#basic-select');
    expect(selectedOption.getAttribute('value')).toEqual('2');
  });

  it('renders react element and selects option with value', async () => {
    const onChangeMock = jest.fn();
    const { baseElement } = render(elementSelectWithOnChange(onChangeMock, false));

    const selectElement = baseElement.querySelector(inputHeaderSelector);
    act(() => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());

    const secondOption = baseElement.querySelector('#react-element-select-option-1');
    await act(async () => {
      fireEvent.click(secondOption);
    });

    expect(onChangeMock).toBeCalledWith(
      { target: { name: undefined, value: '2' } },
      { label: <Icon type={IconType.folder} variant="blue" />, title: '2', value: 2 }
    );
  });

  it('renders react element and is disabled', async () => {
    const onChangeMock = jest.fn();
    const { baseElement } = render(elementSelectWithOnChange(onChangeMock, true));

    const selectElement = baseElement.querySelector(inputHeaderSelector);
    act(() => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).toBeNull());
  });

  it('closes dropdown on blur', async () => {
    const { baseElement } = render(basicSelectWithType());

    const selectElement = baseElement.querySelector(inputHeaderSelector);
    act(() => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());

    fireEvent.blur(baseElement.querySelector('.dropdown-menu'));

    await waitFor(() => expect(baseElement.querySelector(popperSelector)).toBeNull());
  });

  it('renders with correct defaultSelected value', () => {
    const { baseElement } = render(withDefaultSelected(2));
    const selectedOption = baseElement.querySelector('#basic-select');
    expect(selectedOption.getAttribute('value')).toEqual('2');
  });

  it('renders with null if defaultSelected is not an option', () => {
    const { baseElement } = render(withDefaultSelected(3));
    const selectedOption = baseElement.querySelector('#basic-select');
    expect(selectedOption.getAttribute('value')).toEqual('');
  });

  it('renders with onChange', async () => {
    let onChangeReturn = {};
    const onChange = (event: ChangeEvent<HTMLSelectElement>, value: ISelectOption) => {
      onChangeReturn = value;
    };
    const { baseElement } = render(withOnChange(onChange));
    const selectElement = baseElement.querySelector(inputHeaderSelector);
    act(() => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());

    const secondOption = baseElement.querySelector('#basic-select-option-1');
    fireEvent.click(secondOption);

    expect(onChangeReturn).toEqual({
      value: 2,
      label: '2',
      title: '2',
    });
  });

  it('opens dropdown when arrow key is pressed', async () => {
    const { baseElement } = render(basicSelectWithType());
    const selectElement = baseElement.querySelector(inputHeaderSelector);

    act(() => {
      fireEvent.keyDown(selectElement, {
        key: 'ArrowDown',
      });
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());
  });

  it('opens dropdown when enter is pressed', async () => {
    const { baseElement } = render(basicSelectWithType());
    const selectElement = baseElement.querySelector(inputHeaderSelector);

    act(() => {
      fireEvent.keyDown(selectElement, {
        key: 'Enter',
      });
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());
  });

  it('opens dropdown when arrow up key is pressed and closes dropdown when pressed again', async () => {
    const { baseElement } = render(basicSelectWithType());
    const selectElement = baseElement.querySelector(inputHeaderSelector);

    dropDownArrowUpKeyEvent(selectElement);
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());

    dropDownArrowUpKeyEvent(selectElement);
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).toBeNull());
  });

  it('traverses down dropdown using down arrow key', async () => {
    const { baseElement } = render(basicSelectWithType());
    const selectElement = baseElement.querySelector(inputHeaderSelector);
    act(() => {
      userEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());

    const firstOption = baseElement.querySelector('#basic-select-option-0');
    fireEvent.keyDown(selectElement, {
      key: 'ArrowDown',
    });
    fireEvent.keyDown(firstOption, {
      key: 'ArrowDown',
    });
    expect(document.activeElement.getAttribute('id')).toEqual('basic-select-option-1');
  });

  it('closes the popper when tabing out of the component', async () => {
    const { baseElement } = render(basicSelectWithType());

    const selectElement = baseElement.querySelector(inputHeaderSelector);

    act(() => {
      userEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());

    // tab into component (3 options)
    userEvent.tab();
    userEvent.tab();
    userEvent.tab();
    userEvent.tab();
    // tab out
    userEvent.tab();
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).toBeNull());
  });

  it('throws a warning if onclick is declared within child', async () => {
    const consoleSpy = jest.spyOn(console, 'warn').mockImplementation();

    const { baseElement } = render(withDeclaredOnClickInChild);
    const selectElement = baseElement.querySelector(inputHeaderSelector);

    act(() => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());

    expect(consoleSpy).toBeCalled();
  });

  it('closes popper on outside click', async () => {
    const { baseElement } = render(disabledOneOptionSelect);
    const selectElement = baseElement.querySelector(inputHeaderSelector);
    act(() => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());

    await act(async () => {
      fireEvent.mouseDown(baseElement.firstChild);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).toBeNull());
  });

  it('closes popper on self click', async () => {
    const { baseElement } = render(disabledOneOptionSelect);
    const selectElement = baseElement.querySelector(inputHeaderSelector);
    act(() => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());

    act(() => {
      userEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).toBeNull());
  });

  it('resets value and calls onChange with undefined value when clear icon clicked', async () => {
    let onChangeReturn = null;
    const onChange = (event: ChangeEvent<HTMLSelectElement>, value: ISelectOption) => {
      onChangeReturn = value;
    };

    const { baseElement } = render(filterableWithOnChange(onChange));
    const selectElement = baseElement.querySelector(inputHeaderSelector);
    act(() => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());

    const filterInput = baseElement.querySelector('#basic-select');
    userEvent.type(filterInput, 'ABC');
    await waitFor(() => expect(baseElement.querySelector('.icon-clear')).not.toBeNull());
    expect(filterInput.getAttribute('value')).toEqual('ABC');
    const clearIconElement = baseElement.querySelector('.fa-times');
    act(() => {
      userEvent.click(clearIconElement);
    });
    expect(onChangeReturn).toEqual({});
    expect(filterInput.getAttribute('value')).toBeFalsy();
    expect(baseElement).toMatchSnapshot();
  });

  it('focuses on first focusable child when ArrowDown', async () => {
    const { baseElement, getByText } = render(nullValue);
    const selectElement = baseElement.querySelector(inputHeaderSelector);
    act(() => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());
    act(() => {
      fireEvent.keyDown(selectElement, { key: 'ArrowDown' });
    });
    expect(document.activeElement).toEqual(getByText('1'));

    act(() => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).toBeNull());
    act(() => {
      fireEvent.keyDown(selectElement, { key: 'Tab' });
    });

    await waitFor(() =>
      expect(document.activeElement).not.toEqual(baseElement.querySelector('#basic-select-option-0'))
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('traverses down then up dropdown using down arrow key', async () => {
    const { baseElement } = render(basicSelectWithType());

    const selectElement = baseElement.querySelector(inputHeaderSelector);

    act(() => {
      userEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());

    const firstOption = baseElement.querySelector('#basic-select-option-0');
    const secondOption = baseElement.querySelector('#basic-select-option-1');
    fireEvent.keyDown(selectElement, {
      key: 'ArrowDown',
    });
    fireEvent.keyDown(firstOption, {
      key: 'ArrowDown',
    });
    fireEvent.keyDown(secondOption, {
      key: 'ArrowUp',
    });
    expect(document.activeElement.getAttribute('id')).toEqual('basic-select-option-0');
  });

  it('resets value when clear icon accessed by pressing enter or space', async () => {
    const { baseElement } = render(filterable);
    const selectElement = baseElement.querySelector(inputHeaderSelector);
    act(() => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());
    const filterInput = baseElement.querySelector('#basic-select');

    userEvent.type(filterInput, 'ABC');
    await waitFor(() => expect(baseElement.querySelector('.icon-clear')).not.toBeNull());
    expect(filterInput.getAttribute('value')).toEqual('ABC');
    let clearIconElement = baseElement.querySelector('.icon-clear');
    userEvent.type(clearIconElement, ' ');
    expect(filterInput.getAttribute('value')).toBeFalsy();

    userEvent.type(filterInput, 'DCF');
    await waitFor(() => expect(baseElement.querySelector('.icon-clear')).not.toBeNull());
    expect(filterInput.getAttribute('value')).toEqual('DCF');
    // Original element disappears after a "clear" action, so must be re-queried
    clearIconElement = baseElement.querySelector('.icon-clear');
    userEvent.type(clearIconElement, '{enter}');
    expect(filterInput.getAttribute('value')).toBeFalsy();

    userEvent.type(filterInput, 'HIJ');
    await waitFor(() => expect(baseElement.querySelector('.icon-clear')).not.toBeNull());
    expect(filterInput.getAttribute('value')).toEqual('HIJ');
    // Original element disappears after a "clear" action, so must be re-queried
    clearIconElement = baseElement.querySelector('.icon-clear');
    userEvent.type(clearIconElement, 'A');
    expect(filterInput.getAttribute('value')).not.toBeFalsy();
    expect(baseElement).toMatchSnapshot();
  });

  it('hides sequential nav for clear input when no filter value present', async () => {
    const { baseElement } = render(filterable);
    const clearIcon = baseElement.querySelector(clearInputSelector);

    expect(clearIcon).toBeNull();
  });

  it('enables sequential nav for clear input when filter value present', async () => {
    const { baseElement } = render(filterable);
    const selectElement = () => baseElement.querySelector(inputHeaderSelector);
    const filterInput = () => baseElement.querySelector('#basic-select');
    const clearIcon = () => baseElement.querySelector(clearInputSelector);

    act(() => {
      fireEvent.click(selectElement());
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());
    await act(async () => {
      userEvent.type(filterInput(), 'ABC');
    });

    expect(clearIcon()).toHaveProperty('tabIndex', 0);
  });

  it('renders showDivider select', async () => {
    const { baseElement } = render(showDividerSelect);
    const selectElement = baseElement.querySelector(inputHeaderSelector);

    act(() => {
      fireEvent.click(selectElement);
    });
    await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());

    const dropDownItems = baseElement.querySelectorAll('.border-bottom');
    expect(dropDownItems.length).toEqual(2);
  });

  it('filters options based on value if friendly text has been left undefined', async () => {
    await filterElementAndCheckResult(nullChildren, '1', '1');
  });

  it('filters options based on display ("friendly") text, based on input in filter box', async () => {
    await filterElementAndCheckResult(filterableWithFriendlyText, 'e', '1');
  });
});

const basicSelectWithType = (type?: SelectType) => (
  <Select id="basic-select" label="Basic Select" type={type}>
    <SelectOption value={1}>1</SelectOption>
    <SelectOption value={2}>2</SelectOption>
  </Select>
);

const disabledSelect = (
  <Select id="basic-select" label="Basic Select" disabled>
    <SelectOption value={1}>1</SelectOption>
    <SelectOption value={2}>2</SelectOption>
  </Select>
);

const disabledSelectDefaultSelected = (
  <Select id="basic-select" label="Basic Select" disabled value={2}>
    <SelectOption value={1}>1</SelectOption>
    <SelectOption value={2}>2</SelectOption>
  </Select>
);

const disabledOneOptionSelect = (
  <Select id="basic-select" label="Basic Select">
    <SelectOption value={1} disabled>
      1
    </SelectOption>
    <SelectOption value={2}>2</SelectOption>
  </Select>
);

const nonNullable = (
  <Select id="basic-select" label="Basic Select" nullable={false}>
    <SelectOption value={1}>1</SelectOption>
    <SelectOption value={2}>2</SelectOption>
  </Select>
);

const showDividerSelect = (
  <Select id="basic-select" label="Basic Select">
    <SelectOption value={1} showDivider>
      1
    </SelectOption>
    <SelectOption value={2} showDivider>
      2
    </SelectOption>
  </Select>
);

const basicSelectWithoutTooltip = () => (
  <Select id="basic-select" label="Basic Select" noTooltip>
    <SelectOption value={1}>1</SelectOption>
    <SelectOption value={2}>2</SelectOption>
  </Select>
);

const elementSelectWithOnChange = (
  onChange: (event: ChangeEvent<HTMLSelectElement>, val: ISelectOption) => void,
  disabled: boolean
) => (
  <Select id="react-element-select" label="React Element" onChange={onChange} disabled={disabled}>
    <SelectOption title={'1'} value={1}>
      <Icon type={IconType.folder} variant="green" />
    </SelectOption>
    <SelectOption title={'2'} value={2}>
      <Icon type={IconType.folder} variant="blue" />
    </SelectOption>
  </Select>
);

const required = (
  <Select id="basic-select" label="Basic Select" required>
    <SelectOption value={1}>1</SelectOption>
    <SelectOption value={2}>2</SelectOption>
  </Select>
);

const filterable = (
  <Select id="basic-select" label="Basic Select" maxHeight={'213px'} filterable>
    <SelectOption value={1}>1</SelectOption>
    <SelectOption value={2}>2</SelectOption>
  </Select>
);

const filterableWithFriendlyText = (
  <Select id="basic-select" label="Basic Select" maxHeight={'213px'} filterable>
    <SelectOption value={1}>One</SelectOption>
    <SelectOption value={2}>Two</SelectOption>
  </Select>
);

const filterableWithOnChange = (onChange: (event: ChangeEvent<HTMLSelectElement>, val: ISelectOption) => void) => (
  <Select id="basic-select" label="Basic Select" onChange={onChange} maxHeight={'213px'} filterable nullable>
    <SelectOption value={1}>1</SelectOption>
    <SelectOption value={2}>2</SelectOption>
  </Select>
);

const selectWithSize = (size?: SelectSize) => (
  <Select id="basic-select" label="Basic Select" size={size}>
    <SelectOption value={1}>1</SelectOption>
    <SelectOption value={2}>2</SelectOption>
  </Select>
);

// const withInputRef = (inputRef: React.Ref<HTMLSelectElement>) => (
//   <Select id="basic-select" label="Basic Select" inputRef={inputRef}>
//     <SelectOption value={1}>1</SelectOption>
//     <SelectOption value={2}>2</SelectOption>
//   </Select>
// );

const filterElementAndCheckResult = async (
  filterableSelectElement: ReactElement<unknown, string | JSXElementConstructor<unknown>>,
  filterValue: string,
  expectedValue: string
) => {
  const { baseElement } = render(filterableSelectElement);
  const selectElement = baseElement.querySelector(inputHeaderSelector);

  await act(async () => {
    fireEvent.click(selectElement);
  });

  await waitFor(() => expect(baseElement.querySelector(popperSelector)).not.toBeNull());

  const filterInput = await Promise.resolve(baseElement.querySelector('#basic-select'));

  await act(async () => {
    userEvent.type(filterInput, filterValue);
  });

  expect(filterInput.getAttribute('value')).toEqual(filterValue);
  const dropDownItems = baseElement.querySelectorAll('.dropdown-item');
  expect((dropDownItems[0] as HTMLSelectElement).value).toEqual(expectedValue);
  expect(dropDownItems.length).toEqual(1);
  expect(baseElement).toMatchSnapshot();
};

const withOnChange = (onChange: (event: ChangeEvent<HTMLSelectElement>, val: ISelectOption) => void) => (
  <Select id="basic-select" label="Basic Select" onChange={onChange}>
    <SelectOption value={1}>1</SelectOption>
    <SelectOption value={2}>2</SelectOption>
  </Select>
);

const withDeclaredOnClickInChild = (
  <Select id="basic-select" label="Basic Select" required>
    <SelectOption value={1} onClick={noop}>
      1
    </SelectOption>
    <SelectOption value={2}>2</SelectOption>
  </Select>
);

const withDefaultSelected = (value: number) => (
  <Select id="basic-select" label="Basic Select" value={value}>
    <SelectOption value={1}>1</SelectOption>
    <SelectOption value={2}>2</SelectOption>
  </Select>
);

const withCustomTitles = (
  <Select id="basic-select" label="Basic Select" value={2}>
    <SelectOption value={1} title="fancy title for 1">
      1
    </SelectOption>
    <SelectOption value={2} title="fancy title for 2">
      2
    </SelectOption>
  </Select>
);
const nullValue = (
  <Select id="null-option-select" label="Null Option Select">
    <SelectOption value={null}>1</SelectOption>
    <SelectOption value={2}>2</SelectOption>
  </Select>
);
const nullChildren = (
  <Select id="basic-select" label="Basic Select" maxHeight={'213px'} filterable>
    <SelectOption value={1}>{null}</SelectOption>
    <SelectOption value={2}>{null}</SelectOption>
  </Select>
);

const dropDownArrowUpKeyEvent = (selectElement: Element): void => {
  act(() => {
    fireEvent.keyDown(selectElement, {
      key: 'ArrowUp',
    });
  });
};
