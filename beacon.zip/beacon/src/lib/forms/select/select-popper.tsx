import React, { ReactElement, SyntheticEvent, useRef } from 'react';
import { defaultTracking, Trackable, TrackableEvent, trackableEvent } from '../../analytics';
import './select.scss';
import { ISelectOption, ISelectOptionProps } from './select.types';
import useOnClickOutside from 'use-onclickoutside';
import { WithId } from '../../with-id';
import classNames from 'classnames';

type SelectPopperKeyboardEvent = React.KeyboardEvent<HTMLInputElement> | React.KeyboardEvent<HTMLButtonElement>;

export interface ISelectPopperProps extends WithId, Trackable {
  /**
   * Reference to the parent Select element
   */
  parentRef: HTMLElement | null;
  /**
   * Must be a list of SelectOption elements
   */
  children: React.ReactElement<ISelectOptionProps>[];
  /**
   * When true, allows null value to be selected from list of options
   */
  nullable?: boolean;
  /**
   * When true, disabled the null option
   */
  isNullOptionDisabled?: boolean;
  /**
   * When true, blur when changing focus to the parentRef
   */
  shouldBlurOnParentFocus?: boolean;
  /**
   * Callback function that is triggered when the selected value changes
   */
  OnSelection: (selectedValue: ISelectOption) => void;
  /**
   * Callback function that is called when Add All button is clicked
   */
  OnSelectAll?: () => void;
  /**
   * Request Close Event handler
   */
  onRequestClose: () => void;
  /**
   * Changes the max-height of the component.
   */
  maxHeight?: string;
  /**
   * Include Add All button in dropdown
   */
  allowAddAll?: boolean;
  /**
   * Custom display value for Add All button
   */
  addAllText?: string;
}

const getTrackableChange = (
  tracking: TrackableEvent | undefined,
  id: string,
  onChange: (e: SyntheticEvent) => void
) => {
  const trackingInfo = defaultTracking(tracking, {
    grouping: 'Ungrouped',
    action: 'Selection Changed',
    trackingKey: `Select-${id}`,
  });
  return trackableEvent(trackingInfo, onChange);
};

export const getOptionInfo = (option: ReactElement<ISelectOptionProps>): ISelectOption => {
  const childValue = typeof option.props.children === 'string' ? option.props.children : option.props.value?.toString();
  return {
    value: option.props.value,
    label: option.props.children,
    title: option.props.title ? option.props.title : childValue,
  };
};

const handleDropdownUpDownKeys = (event: SelectPopperKeyboardEvent, onRequestClose: (() => void) | null) => {
  const nextElement = document.activeElement?.nextSibling as HTMLElement;
  const previousSibling = document.activeElement?.previousSibling as HTMLElement;

  if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
    event.preventDefault();
  }

  if (event.key === 'ArrowDown' && nextElement) {
    nextElement.focus();
  }

  if (event.key === 'ArrowUp' && previousSibling) {
    previousSibling.focus();
  }

  // Close if tabbed on the last element
  if (event.key === 'Tab' && !nextElement && !event.shiftKey && onRequestClose) {
    onRequestClose();
  }
};

export const SelectPopper = ({
  id,
  parentRef,
  OnSelection,
  OnSelectAll,
  onRequestClose,
  shouldBlurOnParentFocus = true,
  tracking,
  children,
  maxHeight,
  allowAddAll,
  addAllText = 'Add All Options',
}: ISelectPopperProps) => {
  const ref = useRef<HTMLDivElement>(null);
  useOnClickOutside(ref, (event) => {
    if (parentRef && parentRef.contains(event.target as Node)) {
      // do nothing since clicking on the parent select element will take care of everything
      return;
    }
    onRequestClose();
  });
  const closeOnBlur = (event: React.FocusEvent) => {
    const shouldBlurToParent =
      shouldBlurOnParentFocus || (parentRef && !parentRef.contains(event.relatedTarget as Node));
    if (!event.currentTarget.contains(event.relatedTarget as Node) && shouldBlurToParent) {
      onRequestClose();
    }
  };

  return (
    <div
      className="dropdown-menu"
      aria-labelledby={`${id}`}
      ref={ref}
      onBlur={closeOnBlur}
      style={{ maxHeight: maxHeight }}
    >
      {allowAddAll && OnSelectAll && children.length > 0 && (
        <SelectOption
          id={`${id}-option-add-all`}
          key={`${id}-option-add-all`}
          value="add-all"
          onClick={getTrackableChange(tracking, id, (event) => {
            event.preventDefault();
            OnSelectAll();
          })}
        >
          {addAllText}
        </SelectOption>
      )}
      {children.map((child, index) => {
        const optionProps = child.props;

        const optionValue: ISelectOption = getOptionInfo(child);
        if (optionProps.onClick != null) {
          console.warn(
            'When using an Select, define the onChange callback at the group level instead of defining the onClick method on the individual options.'
          );
        }

        return (
          <SelectOption
            {...optionProps}
            id={`${id}-option-${index}`}
            key={`${id}-option-key-${index}`}
            onClick={getTrackableChange(tracking, id, (event) => {
              event.preventDefault();
              OnSelection(optionValue);
            })}
            onKeyDown={(e) => handleDropdownUpDownKeys(e, onRequestClose)}
          >
            {optionProps.children}
          </SelectOption>
        );
      })}
    </div>
  );
};

export const SelectOption = ({ children, title, ...props }: ISelectOptionProps) => {
  const classes = classNames('dropdown-item', {
    instruction: props.value === null,
    'add-all': props.value === 'add-all',
    'border-bottom': props.showDivider,
  });

  if (!title && typeof children === 'string') {
    title = children;
  }

  return (
    <button
      disabled={props.disabled}
      id={props.id}
      className={classes}
      onClick={props.onClick}
      onKeyDown={props.onKeyDown}
      value={props.value ? props.value : undefined}
      title={title}
    >
      {children}
    </button>
  );
};
