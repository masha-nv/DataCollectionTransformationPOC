import React, {
  Children,
  CSSProperties,
  forwardRef,
  JSXElementConstructor,
  ReactElement,
  SyntheticEvent,
  useCallback,
  useEffect,
  useRef,
  useState,
} from 'react';
import { focusOnFirstFocusableChild, noop } from '../../utils';
import './select.scss';
import { Icon, IconType } from '../../icon/icon';
import { Label } from '../label/label';
import classNames from 'classnames';
import {
  ISelectOption,
  ISelectOptionProps,
  ISelectProps,
  SelectOptionValue,
  SelectSize,
  SelectType,
} from './select.types';
import { SelectPopper } from './select-popper';
import { usePopper } from 'react-popper';
import { matchWidth } from '../../utils/popper-modifiers/match-width';
import { Tooltip } from '../../modals/tooltip/tooltip';

const getOptionInfo = (option: ReactElement<ISelectOptionProps> | undefined): ISelectOption | undefined => {
  if (option) {
    const childValue =
      typeof option.props.children === 'string' ? option.props.children : option.props.value?.toString();
    return {
      value: option.props.value,
      label: option.props.children,
      title: option.props.title ? option.props.title : childValue,
    };
  }
  return undefined;
};

const getSelectOptionFromValue = (
  optionList: ReactElement<ISelectOptionProps>[],
  nullable: boolean | undefined,
  value?: SelectOptionValue
): ISelectOption | undefined => {
  if (value) {
    const selectedOption = optionList.find((option) => option.props.value === value);
    return getOptionInfo(selectedOption);
  }
  return nullable ? undefined : getOptionInfo(optionList[0]);
};

const getOptionDomId = (selectId: string, value?: SelectOptionValue) =>
  `${selectId}-option-${value === undefined || value === null ? 'empty' : String(value)}`;

const escapeKeyHandler = (
  { key }: React.KeyboardEvent<HTMLElement>,
  referenceElement: HTMLElement | null,
  setDropdownOpen: React.Dispatch<React.SetStateAction<boolean>>
) => {
  if (key === 'Escape') {
    setDropdownOpen(false);
    focusOnFirstFocusableChild(referenceElement);
  }
};

const handleSelectKeyEvents = (
  event: React.KeyboardEvent<HTMLElement>,
  dropdownOpen: boolean,
  popperElement: HTMLElement | null,
  setDropdownOpen: React.Dispatch<React.SetStateAction<boolean>>
) => {
  if (event.key === 'ArrowDown') {
    event.preventDefault();
    setDropdownOpen(true);
    focusOnFirstFocusableChild(popperElement);
  }

  if (event.key === 'Enter' || event.key === 'ArrowUp') {
    event.preventDefault();
    setDropdownOpen((prev) => !prev);
  }
};

const toggleDropdownOpen = (
  event: SyntheticEvent,
  setDropdownOpen: React.Dispatch<React.SetStateAction<boolean>>,
  setIsFiltering: React.Dispatch<React.SetStateAction<boolean>>
) => {
  event.preventDefault();
  setIsFiltering(() => false);
  setDropdownOpen((prev) => !prev);
};

const cursor = (disabledProp: boolean, filtereableProp: boolean, forInput: boolean) => {
  if (disabledProp) {
    return { cursor: 'not-allowed' };
  } else if (!filtereableProp && forInput) {
    return { cursor: 'pointer' };
  }
  return {};
};

const filterValueFromLabel = (propLabel: string | undefined) => {
  return propLabel ? propLabel : '';
};

const caretIcon = (dropdownOpen: boolean, label?: string) => {
  const name = label ? label + ' ' : '';
  if (dropdownOpen) {
    return <Icon description={'Collapse ' + name + 'Dropdown'} type={IconType.caretUp} />;
  }
  return <Icon description={'Expand ' + name + 'Dropdown'} type={IconType.caretDown} />;
};

const isSpaceOrEnterKey = (e: React.KeyboardEvent<HTMLSpanElement>) => {
  return e.key === ' ' || e.key === 'Enter';
};

const filterChildren = (
  isFiltering: boolean,
  filterValue: string | ReactElement,
  filterable: boolean | undefined,
  propChildren: ReactElement<ISelectOptionProps, string | JSXElementConstructor<unknown>>[]
) => {
  return isFiltering && filterValue && filterable
    ? propChildren.filter((child) => {
        const filterVal = child.props.children || child.props.value;
        return (
          filterVal?.toString().toLocaleLowerCase().includes(filterValue.toString().toLowerCase()) ||
          filterVal === filterValue.toString().toLowerCase()
        );
      })
    : propChildren;
};

interface IClearFilterIconProps {
  onClearClick: () => void;
}

const ClearFilterIcon = ({ onClearClick }: IClearFilterIconProps) => (
  <Icon description="Clear Input" type={IconType.times} onClick={onClearClick} />
);

interface IClearInputProps extends IClearFilterIconProps {
  filterValue: string | ReactElement;
  nullable?: boolean;
  filterable?: boolean;
  onKeyDown: () => void;
}

const ClearInput = ({ filterValue, nullable, filterable, onKeyDown, onClearClick }: IClearInputProps) => {
  if (nullable !== true || !filterValue) {
    return null;
  }

  return (
    <span
      aria-label="Clear Input"
      className="icon-clear"
      style={cursor(false, !!filterable, false)}
      tabIndex={0}
      onKeyDown={(e) => {
        if (isSpaceOrEnterKey(e)) {
          onKeyDown();
        }
      }}
    >
      <ClearFilterIcon onClearClick={onClearClick} />
    </span>
  );
};

export const Select = forwardRef<HTMLSelectElement, ISelectProps>(
  (
    {
      onChange = noop,
      type = SelectType.primary,
      size = SelectSize.medium,
      disabled = false,
      nullable = true,
      filterable = false,
      required = false,
      unselectedText = 'Select one...',
      ...props
    },
    ref
  ) => {
    const optionList = Children.toArray(props.children) as ReactElement<ISelectOptionProps>[];
    const labelId = `${props.id}-dropdown-label`;
    const listboxId = `${props.id}-listbox`;

    const getSelectOptionFromValueCallBack = useCallback(
      (value?: SelectOptionValue): ISelectOption | undefined => {
        return getSelectOptionFromValue(optionList, nullable, value);
      },
      [optionList, nullable]
    );

    const [selected, setSelected] = useState(getSelectOptionFromValueCallBack(props.value));
    const [dropdownOpen, setDropdownOpen] = useState(false);
    const [isFiltering, setIsFiltering] = useState(false);
    const [referenceElement, setReferenceElement] = useState<HTMLSpanElement | null>(null);
    const [filterValue, setFilterValue] = useState<string | ReactElement>('');
    const [activeDescendantId, setActiveDescendantId] = useState<string | undefined>(undefined);

    const dropdownButtonRef = useRef<HTMLDivElement>(null);
    const [popperElement, setPopperElement] = useState<HTMLDivElement | null>(null);

    const { styles, attributes } = usePopper(dropdownButtonRef.current, popperElement, {
      placement: 'bottom-start',
      modifiers: [matchWidth],
    });

    const popperStyles: CSSProperties = {
      ...styles.popper,
      zIndex: 9999,
    };

    const visibleChildren = filterChildren(
      isFiltering,
      filterValue,
      filterable,
      optionList
    ) as ReactElement<ISelectOptionProps>[];

    const onFilterValueChange = ({ target }: React.ChangeEvent<HTMLInputElement>) => {
      const nextFilterValue = target.value;
      const nextVisibleChildren = filterChildren(true, nextFilterValue, filterable, optionList) as ReactElement<
        ISelectOptionProps
      >[];
      const firstVisibleOption = getOptionInfo(nextVisibleChildren[0]);

      setFilterValue(nextFilterValue);
      setDropdownOpen(true);
      setIsFiltering(true);
      setActiveDescendantId(
        firstVisibleOption ? getOptionDomId(props.id, firstVisibleOption.value) : undefined
      );
    };

    useEffect(() => {
      const nextSelected = getSelectOptionFromValueCallBack(props.value);
      const propLabel = nextSelected?.label as string | undefined;

      setSelected(nextSelected);
      setFilterValue(filterValueFromLabel(propLabel));
      setActiveDescendantId(nextSelected ? getOptionDomId(props.id, nextSelected.value) : undefined);
    }, [getSelectOptionFromValueCallBack, props.value, props.id]);

    useEffect(() => {
      if (!dropdownOpen) {
        setActiveDescendantId(undefined);
        return;
      }

      const selectedVisibleChild = visibleChildren.find((child) => child.props.value === selected?.value);
      const activeOption = getOptionInfo(selectedVisibleChild || visibleChildren[0]);

      setActiveDescendantId(activeOption ? getOptionDomId(props.id, activeOption.value) : undefined);
    }, [dropdownOpen, visibleChildren, selected, props.id]);

    const selectValue = (selection: ISelectOption) => {
      setSelected(selection);
      setFilterValue(selection.label);
      setDropdownOpen(false);
      setIsFiltering(false);
      setActiveDescendantId(getOptionDomId(props.id, selection.value));

      onChange(
        {
          target: {
            name: props.name,
            value: selection.value?.toString(),
          },
        } as React.ChangeEvent<HTMLSelectElement>,
        selection
      );
    };

    const containerClasses = classNames('dropdown select-container', {
      'dropdown-primary': type === SelectType.primary,
      'dropdown-secondary': type === SelectType.secondary,
      'select-container-fill': size === SelectSize.fill,
    });

    const filterHeaderClasses = classNames('beacon dropdown select-filter-header', {
      disabled: disabled,
      'dropdown-primary': type === SelectType.primary,
      'dropdown-secondary': type === SelectType.secondary,
      'dropdown-small': size === SelectSize.small,
      'dropdown-medium': size === SelectSize.medium,
      'dropdown-large': size === SelectSize.large,
      'dropdown-fill': size === SelectSize.fill,
    });

    const selectElementClasses = classNames('form-control select-filterable', {
      'dropdown-primary': type === SelectType.primary,
      'dropdown-secondary': type === SelectType.secondary,
      instruction: !selected,
    });

    let inputArea;

    if (typeof filterValue === 'string' && (!filterable || disabled)) {
      inputArea = (
        <input
          id={`${props.id}`}
          role="combobox"
          aria-labelledby={props.label ? labelId : undefined}
          aria-expanded={dropdownOpen}
          aria-controls={listboxId}
          aria-haspopup="listbox"
          aria-activedescendant={activeDescendantId}
          type="text"
          value={filterValue}
          disabled={disabled}
          readOnly
          onKeyDown={(e) => handleSelectKeyEvents(e, dropdownOpen, popperElement, setDropdownOpen)}
          style={cursor(disabled as boolean, filterable as boolean, true)}
          autoComplete="off"
          placeholder={unselectedText}
          className="select-nonfilterable"
        />
      );
    } else if (typeof filterValue === 'string') {
      inputArea = (
        <input
          id={`${props.id}`}
          role="combobox"
          aria-labelledby={props.label ? labelId : undefined}
          aria-expanded={dropdownOpen}
          aria-controls={listboxId}
          aria-haspopup="listbox"
          aria-autocomplete="list"
          aria-activedescendant={activeDescendantId}
          type="text"
          onChange={onFilterValueChange}
          onKeyDown={(e) => handleSelectKeyEvents(e, dropdownOpen, popperElement, setDropdownOpen)}
          value={filterValue}
          disabled={!filterable || disabled}
          style={cursor(disabled as boolean, filterable as boolean, true)}
          autoComplete="off"
          placeholder={unselectedText}
          className={selectElementClasses}
          tabIndex={0}
        />
      );
    } else {
      inputArea = (
        <button
          aria-labelledby={props.label ? labelId : undefined}
          aria-expanded={dropdownOpen}
          aria-controls={listboxId}
          aria-haspopup="listbox"
          id={`${props.id}`}
          disabled={disabled}
          style={cursor(disabled as boolean, filterable as boolean, true)}
          tabIndex={0}
          className="dropdown-menu-btn"
          key={`${props.id}`}
          onKeyDown={(e) => handleSelectKeyEvents(e, dropdownOpen, popperElement, setDropdownOpen)}
        >
          {filterValue}
        </button>
      );
    }

    const mainContent = (
      <div
        className={filterHeaderClasses}
        onClick={(e) => !disabled && toggleDropdownOpen(e, setDropdownOpen, setIsFiltering)}
        style={disabled ? { cursor: 'not-allowed' } : {}}
        ref={dropdownButtonRef}
        aria-label={props.label}
      >
        {inputArea}

        {!disabled && (
          <ClearInput
            filterValue={filterValue}
            nullable={nullable}
            filterable={filterable}
            onKeyDown={() => {
              setFilterValue('');
              setActiveDescendantId(undefined);
              onChange(
                {
                  target: {
                    name: props.name,
                    value: '',
                  },
                } as React.ChangeEvent<HTMLSelectElement>,
                {} as ISelectOption
              );
            }}
            onClearClick={() => {
              setSelected(undefined);
              setDropdownOpen(false);
              setFilterValue('');
              setActiveDescendantId(undefined);
              onChange(
                {
                  target: {
                    name: props.name,
                    value: '',
                  },
                } as React.ChangeEvent<HTMLSelectElement>,
                {} as ISelectOption
              );
            }}
          />
        )}

        <span
          className="icon-caret"
          data-testid="dropdown-caret-icon"
          style={cursor(disabled as boolean, filterable as boolean, false)}
          aria-label={caretIcon(dropdownOpen, props.label).props.description}
          aria-controls={listboxId}
        >
          {caretIcon(dropdownOpen)}
        </span>
      </div>
    );

    return (
      <span
        onKeyDown={(e) => escapeKeyHandler(e, referenceElement, setDropdownOpen)}
        className={containerClasses}
        ref={setReferenceElement}
      >
        {props.label && (
          <Label id={labelId} required={required} htmlFor={`${props.id}`} className="label-margin">
            {props.label}
          </Label>
        )}

        {props.noTooltip ? (
          mainContent
        ) : (
          <Tooltip content={caretIcon(dropdownOpen, props.label).props.description}>{mainContent}</Tooltip>
        )}

        {dropdownOpen && (
          <div className="select-popper-container" ref={setPopperElement} style={popperStyles} {...attributes.popper}>
            <div id={listboxId} role="listbox" aria-labelledby={props.label ? labelId : undefined}>
              <SelectPopper
                parentRef={referenceElement}
                id={props.id}
                children={visibleChildren}
                nullable={nullable}
                tracking={props.tracking}
                OnSelection={(optionValue) => selectValue(optionValue)}
                onRequestClose={() => {
                  setDropdownOpen(false);
                  focusOnFirstFocusableChild(referenceElement);
                }}
                maxHeight={props.maxHeight}
              />
            </div>
          </div>
        )}
      </span>
    );
  }
);

Select.displayName = 'Select';

export { SelectOption } from './select-popper';
