import React, { useState } from 'react';
import { Meta, Story } from '@storybook/react';
import { Documentation, dropdownFromEnum, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import * as yup from 'yup';
import { hookFormUtils } from '../utils/hookform-utils';
import { yupResolver } from '@hookform/resolvers/yup';
import { Controller, useForm } from 'react-hook-form';
import { SubmitButton } from '../../button/submit-button';
import { FormGroup } from '../form-group/form-group';
import { action } from '@storybook/addon-actions';
import { Select, SelectOption } from './select';
import { SelectType, SelectSize, ISelectProps, ISelectOption } from './select.types';
import { Form } from '../form/form';
import { Label } from '../label/label';
import { Button } from '../../button/button';
import { Icon, IconType } from '../../icon/icon';

export default {
  component: Select,
  subcomponents: { SelectOption },
  title: 'Core Components/Form Controls/Dropdowns (Single-select)',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const whenToUse = (
  <>
    <p>Use single-selects for lists of predictable options (such as a list of months or increments of numbers).</p>
    <ul>
      <li>
        <b className="beacon-icon-danger">Don't</b> use selects for shorter lists of options and situations where it's
        better for users to see all options. In these cases, radio buttons are often a better choice.
      </li>
    </ul>
  </>
);

export const SelectBasic: Story<ISelectProps> = ({
  type,
  size,
  disabled,
  nullable,
  unselectedText,
  filterable,
  required,
  noTooltip,
}: ISelectProps) => {
  return (
    <div style={{ marginBottom: 100 }}>
      <Select
        id="basic-select"
        name="basicSelect"
        label="Basic Select"
        type={type}
        size={size}
        nullable={nullable}
        disabled={disabled}
        unselectedText={unselectedText}
        filterable={filterable}
        required={required}
        noTooltip={noTooltip}
      >
        <SelectOption value={1}>First option</SelectOption>
        <SelectOption value={2}>Second option</SelectOption>
      </Select>
    </div>
  );
};

SelectBasic.storyName = 'Primary Dropdown Single-select';

SelectBasic.decorators = [
  (Story: Story) => (
    <Documentation
      name="Basic Select"
      description="A Select element enables users to enter select a value from a list of simple or complex objects."
      whenToUse={whenToUse}
    >
      <Story />
    </Documentation>
  ),
];

SelectBasic.args = {
  type: SelectType.primary,
};

SelectBasic.argTypes = {
  type: {
    control: dropdownFromEnum(SelectType),
    defaultValue: SelectType.primary,
  },
  size: {
    control: dropdownFromEnum(SelectSize),
    defaultValue: SelectSize.medium,
  },
  label: {
    control: null,
  },
  defaultSelected: {
    control: null,
  },
  name: {
    control: null,
  },
  id: {
    control: null,
  },
  tracking: {
    control: null,
  },

  children: {
    control: null,
  },
  noTooltip: {
    control: 'boolean',
  },
};
export const SecondaryBasic: Story<ISelectProps> = ({
  type,
  size,
  disabled,
  nullable,
  unselectedText,
  filterable,
  required,
  noTooltip,
}: ISelectProps) => {
  return (
    <div style={{ marginBottom: 100 }}>
      <Select
        id="basic-select-secondary"
        name="basicSelectSecondary"
        label="Basic Select Secondary:"
        type={type}
        size={size}
        nullable={nullable}
        disabled={disabled}
        unselectedText={unselectedText}
        filterable={filterable}
        required={required}
        noTooltip={noTooltip}
      >
        <SelectOption value={1}>First option</SelectOption>
        <SelectOption value={2}>Second option</SelectOption>
      </Select>
    </div>
  );
};
SecondaryBasic.storyName = 'Secondary Dropdown Single-select';

SecondaryBasic.decorators = [
  (Story: Story) => (
    <Documentation
      name="Basic Select Secondary"
      description="A Select element enables users to enter select a value from a list of simple or complex objects."
      whenToUse={whenToUse}
    >
      <Story />
    </Documentation>
  ),
];

SecondaryBasic.args = {
  type: SelectType.primary,
};

SecondaryBasic.argTypes = {
  type: {
    control: dropdownFromEnum(SelectType),
    defaultValue: SelectType.primary,
  },
  size: {
    control: dropdownFromEnum(SelectSize),
    defaultValue: SelectSize.medium,
  },
  label: {
    control: null,
  },
  defaultSelected: {
    control: null,
  },
  name: {
    control: null,
  },
  id: {
    control: null,
  },
  tracking: {
    control: null,
  },

  children: {
    control: null,
  },
  noTooltip: {
    control: 'boolean',
  },
};
export const FilterableSelect: Story = () => {
  const longList = [
    'Lorem ipsum',
    'Dolor sit',
    'Consectetuer',
    'Adipiscing elit',
    'Diam',
    'Nonummy nibh',
    'Tincidunt',
    'Ut laoreet',
    'Magna',
    'Aliquam erat',
    'Ut',
    'Wisi enim',
    'Minim',
    'Veniam quis',
    'Exerci',
    'Tation ullamcorper',
    'Lobortis',
    'Nisl ut',
    'Ex',
    'Ea commodo',
  ];

  return (
    <div style={{ marginBottom: 100 }}>
      <Select id="filterable-select" name="filterableSelect" label="Filterable Select" filterable>
        {longList.map((entry, index) => {
          return (
            <SelectOption value={entry} key={`filterable-select-option-key-${index}`}>
              {entry}
            </SelectOption>
          );
        })}
      </Select>
    </div>
  );
};

FilterableSelect.storyName = 'Filterable Dropdown Single-select';

FilterableSelect.decorators = [
  (Story: Story) => (
    <Documentation
      name="Filterable Select"
      description="Options inside of a Select element can be filtered using the Filter input"
      whenToUse={whenToUse}
    >
      <Story />
    </Documentation>
  ),
];
export const DisabledSelect: Story = () => {
  return (
    <div style={{ marginBottom: 100 }}>
      <Select id="disabled-select" name="disabledSelect" label="Disabled Select:" disabled>
        <SelectOption value={1}>First option</SelectOption>
        <SelectOption value={2}>Second option</SelectOption>
      </Select>
      <div className="mt-3">
        <Select id="one-disabled-select" name="disabledSelect" label="Disabled Select:">
          <SelectOption value={1} disabled>
            First option
          </SelectOption>
          <SelectOption value={2}>Second option</SelectOption>
        </Select>
      </div>
    </div>
  );
};

DisabledSelect.storyName = 'Disabled Dropdown Single-select';

DisabledSelect.decorators = [
  (Story: Story) => (
    <Documentation
      name="Disabled Select"
      description="Either individual selections, or the entire element, can be disabled"
      whenToUse={whenToUse}
    >
      <Story />
    </Documentation>
  ),
];

export const CustomTitles: Story = () => {
  const shortList = ['Lorem ipsum', 'Dolor sit', 'Consectetuer'];
  return (
    <div style={{ marginBottom: 100 }}>
      <Select id="custom-titles-select" name="customTitlesSelect" label="Custom Titles Select" nullable={false}>
        {shortList.map((entry, index) => {
          return (
            <SelectOption
              value={entry}
              title={`This entry is ${0} on the list. It's value is "${entry}"`}
              key={`custom-titles-select-option-key-${index}`}
            >
              {entry}
            </SelectOption>
          );
        })}
      </Select>
    </div>
  );
};
CustomTitles.storyName = 'Dropdown Single-select Custom Titles';
CustomTitles.decorators = [
  (Story: Story) => (
    <Documentation
      name="Custom Titles"
      description="Custom titles will be displayed on each individual select option, as well as on the main select element when an option is chosen"
      whenToUse={whenToUse}
    >
      <Story />
    </Documentation>
  ),
];

export const Sizes: Story = () => {
  return (
    <div>
      <div className="mb-2">
        <Select id="small-select" label="Small Select" size={SelectSize.small} nullable>
          <SelectOption value={1}>1</SelectOption>
          <SelectOption value={2}>2</SelectOption>
        </Select>
      </div>
      <div className="mb-2">
        <Select id="medium-select" label="Medium Select" size={SelectSize.medium} nullable>
          <SelectOption value={1}>1</SelectOption>
          <SelectOption value={2}>2</SelectOption>
        </Select>
      </div>
      <div className="mb-2">
        <Select id="large-select" label="Large Select" size={SelectSize.large} nullable>
          <SelectOption value={1}>1</SelectOption>
          <SelectOption value={2}>2</SelectOption>
        </Select>
      </div>
      <div className="mb-2">
        <Select id="fill-select" label="Filling Select" size={SelectSize.fill} nullable>
          <SelectOption value={1}>1</SelectOption>
          <SelectOption value={2}>2</SelectOption>
        </Select>
      </div>
    </div>
  );
};
Sizes.storyName = 'Dropdown Single-select Sizes';
Sizes.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Sizes"
      description="The select can be customized with multiple different sizes: small, medium, large, and fill."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const DefaultSelected: Story = () => {
  return (
    <div style={{ marginBottom: 100 }}>
      <Select id="default-select" name="defaultSelect" label="Default Select:" nullable value={2}>
        <SelectOption value={1}>1</SelectOption>
        <SelectOption value={2}>2</SelectOption>
      </Select>
    </div>
  );
};

DefaultSelected.storyName = 'Dropdown Single-select with Default Selected';

DefaultSelected.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Default Value"
      description="A default value can be passed into select to have a selection made upon render."
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const ElementSelected: Story = () => {
  return (
    <div style={{ marginBottom: 100 }}>
      <Select
        id="react-element-select"
        name="reactElement"
        size={SelectSize.small}
        label="React Element:"
        nullable={false}
        value={2}
      >
        <SelectOption key={1} title={'1'} value={1}>
          <div>
            <Icon type={IconType.folder} variant="green" /> Folder 1
          </div>
        </SelectOption>
        <SelectOption key={2} title={'2'} value={2}>
          <div>
            <Icon type={IconType.folder} variant="blue" /> Folder 2
          </div>
        </SelectOption>
      </Select>
    </div>
  );
};

ElementSelected.storyName = 'Dropdown Single-select with React Element Selected';

ElementSelected.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="React Element Value"
      description="A React Element value can be passed into select to have a selection made upon render."
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const SelectChangeEvent: Story = () => {
  const shortList = ['Lorem ipsum', 'Dolor sit', 'Consectetuer'];
  const [currentSelection, setCurrentSelection] = useState('');
  const onChange = (e: unknown, selection: ISelectOption) => {
    setCurrentSelection(selection.value ? selection.value.toString() : '');
  };
  return (
    <div style={{ marginBottom: 100 }}>
      <Select id="non-nullable-select" name="nonNullableableSelect" label="Non-Nullable Select" onChange={onChange}>
        {shortList.map((entry, index) => {
          return (
            <SelectOption value={entry} key={`test-select-option-key-${index}`}>
              {entry}
            </SelectOption>
          );
        })}
      </Select>
      <hr />
      <Label htmlFor="Current Selection:">Entered value:</Label>
      <span>{currentSelection}</span>
    </div>
  );
};
SelectChangeEvent.storyName = 'Dropdown Single-select Change Event';
SelectChangeEvent.decorators = [
  (Story: Story) => (
    <Documentation
      name="Select Change event"
      description="A Select element enables users to enter select a value from a list of simple or complex objects."
      whenToUse={whenToUse}
    >
      <Story />
    </Documentation>
  ),
];

export const SelectForm: Story = () => {
  const complexObject = [
    { value: 22, description: 'This responds to code: 22' },
    { value: 1, description: 'This responds to code: 1' },
    { value: 9, description: 'This responds to code: 9' },
    { value: 19, description: 'This responds to code: 19' },
  ];

  const requiredMessage = 'This field is required';
  const schema = yup.object().shape({
    selectValue: yup.number().required(requiredMessage).label('Select Value'),
  });

  const {
    setValue,
    handleSubmit,
    control,
    formState: { errors },
  } = useForm({
    mode: 'onTouched',
    resolver: yupResolver(schema) /* A valid yup schema*/,
  });
  const onSubmit = (data: { selectValue: string }) => {
    action('submit-action')(data);
  };

  const onError = (data: unknown) => action('error-action')(data);

  return (
    <>
      <div className="mb-2">
        <Button id="button-set-select" onClick={(e) => setValue('selectValue', 22, { shouldValidate: true })}>
          Set Value to 22
        </Button>
      </div>
      <Form onSubmit={handleSubmit(onSubmit, onError)} style={{ marginBottom: 150 }}>
        <FormGroup id="fg-select-value" errorMessages={hookFormUtils.getErrorMessages(errors, 'selectValue')}>
          <Controller
            name="selectValue"
            control={control}
            render={({ field: { onChange, onBlur, value } }) => (
              <Select
                type={SelectType.primary}
                onChange={onChange}
                onBlur={onBlur}
                id="test-select"
                label="Test Select"
                size={SelectSize.medium}
                filterable
                unselectedText="Nothing is selected..."
                value={parseInt(value)}
                required
              >
                {complexObject.map((option, index) => {
                  return (
                    <SelectOption
                      value={option.value}
                      title={`${option.description}-title`}
                      key={`fg-select-option-key-${index}`}
                    >
                      {option.description}
                    </SelectOption>
                  );
                })}
              </Select>
            )}
          />
        </FormGroup>
        <SubmitButton id="button-toggle">Submit Select</SubmitButton>
      </Form>
    </>
  );
};
SelectForm.storyName = 'Dropdown Single-select in Form';
SelectForm.decorators = [
  (Story: Story) => (
    <Documentation
      name="Form"
      description={`
          Select elements can be used within Forms and Yup validation to validate and show user-specified errors.
          <br />
          <strong>Note:</strong> Select should be nested inside a Controller component`}
      whenToUse={whenToUse}
    >
      <Story />
    </Documentation>
  ),
];

export const NonNullableSelect: Story = () => {
  const shortList = ['Lorem ipsum', 'Dolor sit', 'Consectetuer'];
  return (
    <div style={{ marginBottom: 100 }}>
      <Select id="non-nullable-select" name="nonNullableableSelect" label="Non-Nullable Select:" nullable={false}>
        {shortList.map((entry) => {
          return <SelectOption value={entry}>{entry}</SelectOption>;
        })}
      </Select>
    </div>
  );
};

NonNullableSelect.storyName = 'Non-nullable Dropdown Single-select';

NonNullableSelect.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Non-Nullable Select"
      description="Select is nullable by default. When set to NOT nullable, the select element will, by default, set the first option as selected"
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const ShowDividers: Story = () => {
  return (
    <div style={{ marginBottom: 100 }}>
      <Select id="show-dividers-select" name="showDividers" label="Show Dividers:" nullable={true}>
        <SelectOption key={1} title={'1'} value={1} showDivider>
          <>
            <div>
              <Icon type={IconType.folder} variant="green" /> Folder 1
            </div>
            <div>Date Created: 02/21/2020</div>
            <div>Date Modified: 02/21/2021</div>
          </>
        </SelectOption>
        <SelectOption key={2} title={'2'} value={2} showDivider>
          <>
            <div>
              <Icon type={IconType.folder} variant="blue" /> Folder 2
            </div>
            <div>Date Created: 02/21/2022</div>
            <div>Date Modified: 02/21/2023</div>
          </>
        </SelectOption>
        <SelectOption key={3} title={'3'} value={3} showDivider>
          <>
            <div>
              <Icon type={IconType.folder} variant="red" /> Folder 3
            </div>
            <div>Date Created: 02/21/2024</div>
            <div>Date Modified: 02/21/2025</div>
          </>
        </SelectOption>
      </Select>
    </div>
  );
};

ShowDividers.storyName = 'Dropdown Single-select with Dividers';

ShowDividers.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Show Dividers"
      description="When showDividers is set, a bottom border is added to the element. This is useful for custom elements 
        that span multiple lines. Note: This property is set on the SelectOptions not on the Select."
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
