import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../../../stories';
import { a11yConfig } from '../../../stories/story.config';
import { SimpleSelect } from './simple-select';
import { ISimpleSelectProps } from './simple-select.types';
import { SelectType } from '../select.types';

export default {
  component: SimpleSelect,
  title: 'Core Components/Form Controls/Dropdowns (Single-Select)',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const whenToUse = (
  <p>
    Use SimpleSelects when you have a pre-defined list of ISelectOption and don't want to manually create all of the
    SelectOptions.
  </p>
);

const simpleSelectOptions = [
  {
    value: 1234,
    label: 'Option 1',
  },
  {
    value: 6927,
    label: 'Option 2',
  },
  {
    value: 9082,
    label: 'Option 3',
  },
];

export const SimpleSelectStory: Story<ISimpleSelectProps> = () => {
  return (
    <div style={{ marginBottom: 100 }}>
      <SimpleSelect
        id="simple-select"
        field="simpleSelect"
        label="Simple Select:"
        type={SelectType.primary}
        value={1234}
        options={simpleSelectOptions}
      />
    </div>
  );
};

SimpleSelectStory.storyName = 'Simple Select (Auto-Populating Select)';

SimpleSelectStory.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Auto-populating Select"
      description="This select handles the population of the <SelectOption> tags for you."
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
