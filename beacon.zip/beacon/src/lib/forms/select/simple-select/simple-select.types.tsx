import { FieldValues, UseFormSetValue } from 'react-hook-form';
import { ISelectOption, SelectOptionValue, SelectType } from '../select.types';

export interface ISimpleSelectProps {
  /**
   * The id for the component
   */
  id: string;
  /**
   * either 'primary' or 'secondary', determines the type of the generated selector
   */
  type: SelectType;
  /**
   * Necessary for error messages if using errors, determiens the id of the form group
   */
  field: string;
  /**
   * The options that will populate the dropdown
   */
  options: ISelectOption[];
  /**
   * Sets the label for the field if provided
   */
  label?: string;
  /**
   * The current value of the selector
   */
  value: SelectOptionValue;
  /**
   * Method for setting the value of the selector when using ReactHookForm
   */
  setValue?: UseFormSetValue<FieldValues>;

  isReadOnly?: boolean;
}
