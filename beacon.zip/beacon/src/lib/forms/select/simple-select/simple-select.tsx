import { useState } from 'react';
import { Select, SelectOption } from '../select';
import { ISelectOption, SelectOptionValue, SelectType } from '../select.types';
import { ISimpleSelectProps } from './simple-select.types';

export const SimpleSelect = (props: ISimpleSelectProps) => {
  const [currentSelection, setCurrentSeletion] = useState<SelectOptionValue>(props.value);
  const onChange = (e: unknown, selection: ISelectOption) => {
    setCurrentSeletion(selection.value);
    if (props.setValue) {
      props.setValue(props.field, selection.value);
    }
  };
  const getSelectOption = (entry: ISelectOption, index: number) => {
    if (entry.value === currentSelection) {
      return (
        <SelectOption value={entry.value} key={`${entry.value}-${index}`} defaultSelected>
          {entry.label}
        </SelectOption>
      );
    }
    return (
      <SelectOption value={entry.value} key={`${entry.value}-${index}`}>
        {entry.label}
      </SelectOption>
    );
  };

  return (
    <Select
      id={`${props.id}-single-select`}
      type={SelectType.primary}
      value={currentSelection}
      onChange={onChange}
      label={props.label}
      disabled={props.isReadOnly}
      filterable
    >
      {props.options.map((entry: ISelectOption, index) => getSelectOption(entry, index))}
    </Select>
  );
};
