import React from 'react';
import { render } from '@testing-library/react';
import { DeepMap, FieldError, FieldValues } from 'react-hook-form';
import userEvent from '@testing-library/user-event';
import { SimpleSelect } from './simple-select';
import { SelectType } from '../select.types';

const TEST_OPTIONS = [
  {
    value: '1243',
    label: 'Field1',
  },
  {
    value: '56345',
    label: 'Field2',
  },
  {
    value: '7623',
    label: 'Field3',
  },
  {
    value: undefined,
    label: 'invalid',
  },
];

const TEST_OPTIONS_NUMBERS = [
  {
    value: 1243,
    label: 'Field1',
  },
  {
    value: 56345,
    label: 'Field2',
  },
  {
    value: 7623,
    label: 'Field3',
  },
  {
    value: undefined,
    label: 'invalid',
  },
];

const simpleSelectNoDefaultSelected = () => (
  <SimpleSelect
    id="basic-select"
    value={null}
    label="Basic Select"
    type={SelectType.primary}
    field="testField"
    options={TEST_OPTIONS}
  />
);

const simpleSelectDefaultSelected = () => (
  <SimpleSelect
    id="basic-select"
    label="Basic Select"
    type={SelectType.primary}
    field="testField"
    options={TEST_OPTIONS}
    value="7623"
  />
);

const simpleSelectWithSetValue = (setValue: () => null) => (
  <SimpleSelect
    id="basic-select"
    label="Basic Select"
    type={SelectType.primary}
    field="testField"
    options={TEST_OPTIONS}
    value="7623"
    setValue={setValue}
  />
);

const simpleSelectWithSetValueNumber = (setValue: () => null) => (
  <SimpleSelect
    id="basic-select"
    label="Basic Select"
    type={SelectType.primary}
    field="testField"
    options={TEST_OPTIONS_NUMBERS}
    value={7623}
    setValue={setValue}
  />
);

describe('DataView RevisionHistory Single Select', () => {
  it('renders select with no default selection', () => {
    const { baseElement } = render(<>{simpleSelectNoDefaultSelected()}</>);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders select with default selection', () => {
    const { baseElement } = render(<>{simpleSelectDefaultSelected()}</>);
    expect(baseElement).toMatchSnapshot();
  });

  it('changing selected option populated the setValue method', async () => {
    const errors: DeepMap<FieldValues, FieldError> = {};
    const setValue = jest.fn();
    const { baseElement, getByText, findByText } = render(<>{simpleSelectWithSetValue(setValue)}</>);
    const input = baseElement.getElementsByClassName('select-filterable')[0] as HTMLSelectElement;
    userEvent.click(input);
    await findByText('Field2');
    userEvent.click(getByText('Field2'));
    userEvent.click(input);
    await findByText('Field3');
    userEvent.click(getByText('Field3'));
    userEvent.click(input);
    await findByText('invalid');
    userEvent.click(getByText('invalid'));
    expect(setValue.mock.calls).toEqual([
      ['testField', '56345'],
      ['testField', '7623'],
      ['testField', undefined],
    ]);
  });

  it('changing selected option populated the setValue method, with numbers not strings', async () => {
    const errors: DeepMap<FieldValues, FieldError> = {};
    const setValue = jest.fn();
    const { baseElement, getByText, findByText } = render(<>{simpleSelectWithSetValueNumber(setValue)}</>);
    const input = baseElement.getElementsByClassName('select-filterable')[0] as HTMLSelectElement;
    userEvent.click(input);
    await findByText('Field2');
    userEvent.click(getByText('Field2'));
    userEvent.click(input);
    await findByText('Field3');
    userEvent.click(getByText('Field3'));
    userEvent.click(input);
    await findByText('invalid');
    userEvent.click(getByText('invalid'));
    expect(setValue.mock.calls).toEqual([
      ['testField', 56345],
      ['testField', 7623],
      ['testField', undefined],
    ]);
  });
});
