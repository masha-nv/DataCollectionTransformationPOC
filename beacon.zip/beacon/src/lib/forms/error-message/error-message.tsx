import React from 'react';
import { WithId } from '../../with-id';

export interface IErrorMessagesProps extends WithId {
  /**
   * Error messages to display
   */
  messages: string[];
}

/**
 * Error Component
 */
export const ErrorMessages = ({ id, messages }: IErrorMessagesProps) => {
  const errorMessageList = messages.map((message, index) => (
    <div key={index} className="form-error-message">
      {message}
    </div>
  ));
  return (
    <div id={id} role="alert">
      {messages && messages.length > 0 && errorMessageList}
    </div>
  );
};
