import React from 'react';
import { render } from '@testing-library/react';
import { ErrorMessages } from './error-message';

describe('ErrorMessages', () => {
  it('renders correctly', () => {
    const { baseElement } = render(<ErrorMessages id="error-id" messages={['Some error']} />);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders empty region if there are not any messages', () => {
    const { baseElement } = render(<ErrorMessages id="error-id" messages={[]} />);
    expect(baseElement).toMatchSnapshot();
  });
});
