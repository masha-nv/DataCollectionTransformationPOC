import React, { forwardRef } from 'react';

interface CustomLabelProps {
  /**
   * Label is for a required field
   */
  required?: boolean;
}

export type ILabelProps = CustomLabelProps & JSX.IntrinsicElements['label'];

export const Label = forwardRef<HTMLLabelElement, ILabelProps>(
  ({ required, className, children, ...labelProps }, ref) => {
    if (required) {
      className = `${className ? className : ''} form-label-required`;
    }

    return (
      <label ref={ref} className={className} {...labelProps}>
        {children}
      </label>
    );
  }
);

Label.displayName = 'Label';
