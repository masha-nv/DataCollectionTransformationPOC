import { Story } from '@storybook/react';
import React from 'react';
import { Documentation, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { TextInput, TextInputType } from '../text-input/text-input';
import { Label } from './label';

export default {
  component: Label,
  title: 'Core Components/Form Controls/Label',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
};

export const BasicLabel: Story = () => {
  return (
    <>
      <Label htmlFor="firstName">First Name</Label>
      <TextInput id="firstName" name="firstName" type={TextInputType.text} />
    </>
  );
};

BasicLabel.decorators = [
  (Story: Story) => (
    <Documentation name="Label" description="Labels are components used to label their corresponding input controls.">
      <Story />
    </Documentation>
  ),
];

export const RequiredLabel: Story = () => {
  return (
    <>
      <Label htmlFor="firstName" required>
        First Name
      </Label>
      <TextInput id="firstName" name="firstName" type={TextInputType.text} required />
    </>
  );
};

RequiredLabel.decorators = [
  (Story: Story) => (
    <Documentation
      name="Required Label"
      description={
        <p>
          Labels will display a required indicator (red asterisk <span className="text-danger">*</span>) when they have
          the <code>required</code> property.
        </p>
      }
      accessibilityConsiderations={
        <p>
          Forms with required labels and fields must use also use <code>RequiredFieldLegend</code> at the top of the
          form.
        </p>
      }
    >
      <Story />
    </Documentation>
  ),
];
BasicLabel.storyName = 'Label';
