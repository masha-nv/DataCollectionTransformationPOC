import React from 'react';
import { render } from '@testing-library/react';
import { Label } from './label';

describe('Label', () => {
  it('renders correctly', async () => {
    const { baseElement } = render(<Label>Label</Label>);

    expect(baseElement).toMatchSnapshot();
  });

  it('renders required correctly', async () => {
    const { baseElement } = render(<Label required>Label</Label>);

    expect(baseElement).toMatchSnapshot();
  });

  it('renders required with custom class correctly', async () => {
    const { baseElement } = render(
      <Label className="custom" required>
        Label
      </Label>
    );

    expect(baseElement).toMatchSnapshot();
  });
});
