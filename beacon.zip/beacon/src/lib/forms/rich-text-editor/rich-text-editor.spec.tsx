import React from 'react';
import { screen, fireEvent, render, createEvent } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { RichTextEditor } from './rich-text-editor';
import { BasicRichTextEditor } from './rich-text-editor.stories';
import { noop } from '../../utils';

describe('RichTextEditor', () => {
  it('only uses the default value initially', () => {
    const { baseElement } = render(<RichTextEditor id="rte-id" defaultValue="<strong>potato</strong>" />);

    const editorElement = baseElement.querySelector<HTMLDivElement>('#rte-id .public-DraftEditor-content');
    const initialValue = editorElement.textContent;

    const event = createEvent.paste(editorElement, {
      clipboardData: {
        types: ['text/plain'],
        getData: () => 'baked',
      },
    });
    fireEvent(editorElement, event);

    expect(initialValue).toEqual('potato');
    expect(editorElement.textContent).toEqual('bakedpotato');
  });

  it('calls change handler when modified', () => {
    const onChangeCallback = jest.fn();
    const { baseElement } = render(
      <RichTextEditor id="rte-id" onChange={onChangeCallback} defaultValue="<strong>potato</strong>" />
    );

    const editorElement = baseElement.querySelector<HTMLDivElement>('#rte-id .public-DraftEditor-content');
    const event = createEvent.paste(editorElement, {
      clipboardData: {
        types: ['text/plain'],
        getData: () => 'tuber',
      },
    });
    fireEvent(editorElement, event);

    expect(onChangeCallback).toHaveBeenCalled();
  });

  it('does not paste if the content will exceed the max character count', () => {
    const { baseElement } = render(<RichTextEditor id="rte-id" defaultValue="" maxCharCount={10} />);

    const editorElement = baseElement.querySelector<HTMLDivElement>('#rte-id .public-DraftEditor-content');
    const event = createEvent.paste(editorElement, {
      clipboardData: {
        types: ['text/plain'],
        getData: () => '0123456789ABCDEFG',
      },
    });
    fireEvent(editorElement, event);

    expect(screen.getByRole('textbox').textContent).toEqual('');
  });

  it('pastes additional content if max length is not breached', () => {
    const { baseElement } = render(<RichTextEditor id="rte-id" defaultValue="world" maxCharCount={20} />);

    const editorElement = baseElement.querySelector<HTMLDivElement>('#rte-id .public-DraftEditor-content');
    const event = createEvent.paste(editorElement, {
      clipboardData: {
        types: ['text/plain'],
        getData: () => 'hello ',
      },
    });
    fireEvent(editorElement, event);

    // the editor "cursor" is at the start of the textbox, therefore the paste occurs at the beginningq
    expect(screen.getByRole('textbox').textContent).toEqual('hello world');
  });

  it('does not paste if not pasting anything', () => {
    const { baseElement } = render(<RichTextEditor id="rte-id" defaultValue="hello" maxCharCount={10} />);

    const editorElement = baseElement.querySelector<HTMLDivElement>('#rte-id .public-DraftEditor-content');
    const event = createEvent.paste(editorElement, {
      clipboardData: {
        types: ['text/plain'],
        getData: noop,
      },
    });
    fireEvent(editorElement, event);

    expect(screen.getByRole('textbox').textContent).toEqual('hello');
  });

  it('can clear the editor', () => {
    const { baseElement, getByText } = render(<BasicRichTextEditor />);

    userEvent.click(getByText('Clear it'));

    expect(screen.getByRole('textbox').textContent).toEqual('');
  });

  it('can set the text of the editor', () => {
    const { baseElement, getByText } = render(<BasicRichTextEditor />);

    userEvent.click(getByText('Sample Text'));

    // even though we do html, the "text content" just looks like normal text
    expect(screen.getByRole('textbox').textContent).toEqual('Lorem impsum dolor sit amet');
  });

  it('can be displayed as read-only', () => {
    const { baseElement } = render(<RichTextEditor id="rte-id" defaultValue="foo <em>bar</em>" readOnly />);
    //If not read only, the "text content" will pick up the BlockType options
    expect(baseElement.textContent).toEqual('foo bar');
  });

  it('can display the available character count', () => {
    const { baseElement } = render(
      <RichTextEditor id="rte-id" defaultValue="<strong>potato</strong>" maxCharCount={20} />
    );

    const charRemainingElement = baseElement.querySelector<HTMLDivElement>('#rte-id .char-remaining-display');

    expect(charRemainingElement.textContent).toEqual('14 remaining');
  });

  it('shows the correct warning threshold', () => {
    const { baseElement } = render(<RichTextEditor id="rte-id" defaultValue="0123456789012345678" maxCharCount={20} />);

    const charRemainingElement = baseElement.querySelector<HTMLDivElement>('#rte-id .char-remaining-display');

    expect(charRemainingElement.textContent).toEqual('1 remaining');
  });

  it('shows the max characters reached message', () => {
    const { baseElement } = render(
      <RichTextEditor id="rte-id" defaultValue="01234567890123456789" maxCharCount={20} />
    );

    expect(screen.getByRole('status').textContent).toEqual('Character limit:0 remainingCharacter limit of 20 reached.');
  });
});
