import React, { useEffect, useState } from 'react';
import ReactRichTextEditor from 'react-rte';
import { noop } from '../../utils';
import { RICH_TEXT_FORMAT, TOOLBAR_CONFIG } from './constants';

import './rich-text-editor.scss';
import { IRichTextEditorProps, ReactRichTextEditorInternal } from './rich-text-editor.types';

const revLimiter = (
  maxLength: number | undefined,
  editorStateInternal: Draft.EditorState,
  newText?: string
): Draft.DraftHandleValue => {
  if (!maxLength) {
    return 'not-handled';
  }
  const currentContent = editorStateInternal.getCurrentContent();
  let currentContentLength = currentContent.getPlainText('').length;
  if (newText) {
    currentContentLength += newText.length;
  }
  if (currentContentLength > maxLength - 1) {
    return 'handled';
  }
  return 'not-handled';
};

const CharactersRemaining = (props: { currentCount: number; maxCount: number }) => {
  const bgDefaultColor = '#E6F1F8';
  const bgWarningColor = '#FFF1D2';
  const warningThreshold = 0.9;
  const bgColor = props.currentCount / props.maxCount > warningThreshold ? bgWarningColor : bgDefaultColor;
  const bgPercentage = (100.0 * props.currentCount) / props.maxCount;
  const bgStyle = `linear-gradient(90deg, ${bgColor}, ${bgColor} ${bgPercentage}%, white ${bgPercentage}%, white)`;
  return (
    <div className="mt-1" role="status">
      Character limit:
      <div className="char-remaining-display" style={{ background: bgStyle }}>
        {props.maxCount - props.currentCount} remaining
      </div>
      {props.maxCount === props.currentCount && <em className="ml-2">Character limit of {props.maxCount} reached.</em>}
    </div>
  );
};

export const RichTextEditor = ({
  onChange = noop,
  onFocus = noop,
  onBlur = noop,
  readOnly = false,
  ...props
}: IRichTextEditorProps) => {
  const [value, setValue] = useState(
    props.defaultValue
      ? ReactRichTextEditor.createValueFromString(props.defaultValue, RICH_TEXT_FORMAT)
      : ReactRichTextEditor.createEmptyValue()
  );
  // the reason for this is so that when the defaultValue property changes, we can also
  // update the value here
  useEffect(() => {
    setValue(
      props.defaultValue
        ? ReactRichTextEditor.createValueFromString(props.defaultValue, RICH_TEXT_FORMAT)
        : ReactRichTextEditor.createEmptyValue()
    );
  }, [props.defaultValue]);

  const [currentLength, setCurrentLength] = useState(
    value.getEditorState().getCurrentContent().getPlainText('').length
  );
  return (
    <div id={props.id} className="rich-text-editor">
      <ReactRichTextEditorInternal
        value={value}
        className={`rich-text-editor-font${readOnly ? '-readonly' : ''}`}
        toolbarConfig={TOOLBAR_CONFIG}
        handleBeforeInput={() => revLimiter(props.maxCharCount, value.getEditorState())}
        handleReturn={() => revLimiter(props.maxCharCount, value.getEditorState()) === 'handled'}
        handlePastedText={(text: string) => revLimiter(props.maxCharCount, value.getEditorState(), text)}
        handleDrop={() => 'handled'}
        onChange={(value) => {
          setValue(value);
          setCurrentLength(value.getEditorState().getCurrentContent().getPlainText('').length);
          onChange(value.toString(RICH_TEXT_FORMAT));
        }}
        onFocus={() => onFocus()}
        onBlur={() => onBlur(value.toString(RICH_TEXT_FORMAT))}
        readOnly={readOnly}
      />
      {props.maxCharCount && (
        <CharactersRemaining currentCount={currentLength as number} maxCount={props.maxCharCount as number} />
      )}
    </div>
  );
};

RichTextEditor.displayName = 'RichTextEditor';
