import { GroupName } from './rich-text-editor.types';

export const RICH_TEXT_FORMAT = 'html';

export const TOOLBAR_CONFIG = {
  display: ['INLINE_STYLE_BUTTONS', 'BLOCK_TYPE_BUTTONS', 'BLOCK_TYPE_DROPDOWN', 'HISTORY_BUTTONS'] as GroupName,
  INLINE_STYLE_BUTTONS: [
    { label: 'Bold', style: 'BOLD' },
    { label: 'Italic', style: 'ITALIC' },
  ],
  BLOCK_TYPE_BUTTONS: [
    { label: 'Unordered List', style: 'unordered-list-item' },
    { label: 'Numbered List', style: 'ordered-list-item' },
  ],
  BLOCK_TYPE_DROPDOWN: [
    { label: 'Body', style: 'unstyled' },
    { label: 'Heading', style: 'header-three' },
  ],
};
