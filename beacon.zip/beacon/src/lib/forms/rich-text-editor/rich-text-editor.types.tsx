import React, { SyntheticEvent } from 'react';
import ReactRichTextEditor from 'react-rte';
import { WithId } from '../../with-id';

/**
 * ReactRichTextEditor does not expose a lot of Draftjs's internal props so they need to be extracted
 */
export type ReactRichTextEditorInternalProps = Omit<typeof ReactRichTextEditor.prototype.props, 'handleReturn'> & {
  handleReturn?: (e: React.KeyboardEvent<unknown>, editorState: Draft.EditorState) => boolean;
  handleBeforeInput?: (chars: string, editorState: Draft.EditorState, eventTimeStamp: number) => Draft.DraftHandleValue;
  handlePastedText?: (text: string, html: string | undefined, editorState: Draft.EditorState) => Draft.DraftHandleValue;
  handleDrop?: (
    selection: Draft.SelectionState,
    dataTransfer: unknown,
    isInternal: Draft.DraftDragType
  ) => Draft.DraftHandleValue;
  onFocus?: (e: SyntheticEvent) => void;
  onBlur?: (e: SyntheticEvent) => void;
};

export const ReactRichTextEditorInternal: (props: ReactRichTextEditorInternalProps) => JSX.Element =
  ReactRichTextEditor as unknown as (props: ReactRichTextEditorInternalProps) => JSX.Element;

export type GroupName = NonNullable<typeof ReactRichTextEditor.prototype.props.toolbarConfig>['display'];

export interface IRichTextEditorProps extends WithId {
  /** An initial value for this rich text editor */
  defaultValue?: string;
  /** Whether the rich text editor is read-only (i.e. rendered based on the markdown without editor controls) */
  readOnly?: boolean;
  /** The maximum number of displayed characters (i.e. markdown formatting characters are not counted) to allow in this editor field */
  maxCharCount?: number;
  /** The event handler for when the editor text content is changed (value is formatted using markdown) */
  onChange?: (value: string) => void;
  /** The event handler for when the editor text component receives focus */
  onFocus?: () => void;
  /** The event handler for when the editor text component loses focus (current value is formatted using markdown) */
  onBlur?: (value: string) => void;
}
