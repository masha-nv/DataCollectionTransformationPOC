import React, { useState } from 'react';
import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { RichTextEditor } from './rich-text-editor';
import { Button } from '../../button/button';
import { ButtonGroup, ButtonGroupDirection } from '../../button/button-group';

export default {
  component: RichTextEditor,
  title: 'Core Components/Form Controls/Rich Text Editor',
  parameters: {
    badges: [StoryBadge.BETA],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const componentDescription = 'A rich text editor enables users to enter formatted text which is stored as HTML.';

export const BasicRichTextEditor: Story = () => {
  const [value, setValue] = useState('<strong>Hello</strong> World');
  return (
    <div>
      <ButtonGroup direction={ButtonGroupDirection.LEFT}>
        <Button
          id="rte-clear"
          onClick={() => {
            setValue('');
          }}
          title="Clears the editor"
        >
          Clear it
        </Button>
        <Button
          id="rte-sample"
          title="Adds sample markdown to the editor and binds it with the current value"
          onClick={() => {
            setValue('Lorem <strong>impsum</strong> <em>dolor</em> sit amet');
          }}
        >
          Sample Text
        </Button>
      </ButtonGroup>
      <label htmlFor="rte-id">Rich Text Field</label>
      <RichTextEditor id="rte-id" defaultValue={value} onBlur={setValue} />
      <pre>Current value: {value}</pre>
    </div>
  );
};
BasicRichTextEditor.storyName = 'Rich Text Editor';

BasicRichTextEditor.decorators = [
  (ComponentStory: Story) => (
    <Documentation name="Basic Rich Text Editor" description={componentDescription}>
      <ComponentStory />
    </Documentation>
  ),
];
export const ReadOnly: Story = () => {
  return (
    <>
      <label htmlFor="input-id">Rich Text Field</label>
      <RichTextEditor id="input-id" defaultValue="Hello, <strong>potato</strong>!" readOnly />
    </>
  );
};
ReadOnly.storyName = 'Read-only Rich Text Editor';
ReadOnly.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="ReadOnly control"
      description={
        <p>
          Rich text editor can be made readonly using <code>readOnly</code> property. Like other input components, when
          readonly, the text or contents of the component cannot be modified but can be copied.
        </p>
      }
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const TrackingEvents: Story = () => {
  const [logs, setLogs] = useState<string[]>([]);
  return (
    <>
      <div className="w-50 d-inline-block">
        <label htmlFor="rte-id">Rich Text Field</label>
        <RichTextEditor
          id="rte-id"
          onChange={(value: string) => {
            logs.push(`Change to: ${value}`);
            setLogs([...logs]);
          }}
          onFocus={() => {
            logs.push(`Received focus`);
            setLogs([...logs]);
          }}
          onBlur={(value: string) => {
            logs.push(`Lost focus with value: ${value}`);
            setLogs([...logs]);
          }}
        />
      </div>
      <div className="w-50 d-inline-block align-top pl-4">
        <label>Events:</label>
        <ul id="rte-events">
          {logs.map((log) => (
            <li>{log}</li>
          ))}
        </ul>
      </div>
    </>
  );
};

TrackingEvents.storyName = 'Rich Text Editor With Event Tracking';
TrackingEvents.decorators = [
  (ComponentStory: Story) => (
    <Documentation name="Editor with Event Tracking" description={componentDescription}>
      <ComponentStory />
    </Documentation>
  ),
];
export const EditorWithCharacterLimit: Story = () => {
  return (
    <>
      <label htmlFor="rte-id">Rich Text Field</label>
      <RichTextEditor id="rte-id" defaultValue="Hello, <strong>potato</strong>!" maxCharCount={40} />
    </>
  );
};
EditorWithCharacterLimit.storyName = 'Rich Text Editor with Character Limit';
EditorWithCharacterLimit.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Editor with Character Limit"
      description={
        <p>
          A character limit can be enforced for a rich text editor using the <code>maxCharCount</code> property. When
          this property is used, some help text will appear below the component that shows how many character can still
          be added.
        </p>
      }
    >
      <ComponentStory />
    </Documentation>
  ),
];
