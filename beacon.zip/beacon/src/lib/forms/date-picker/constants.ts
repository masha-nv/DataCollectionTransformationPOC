export const DATE_FORMAT = 'MM/DD/YYYY';

export const MONTH_STRINGS = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

export const MONTH_ABBR_STRING = MONTH_STRINGS.map(function (str) {
  return str.substring(0, 3);
});

export const MIN_POSSIBLE_DATE = new Date(-8640000000000000);
export const MAX_POSSIBLE_DATE = new Date(8640000000000000);

export interface ICalendarPage {
  month: number;
  year: number;
}
