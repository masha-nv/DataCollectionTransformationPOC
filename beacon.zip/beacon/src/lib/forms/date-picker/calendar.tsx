import React, { useEffect, useRef, useState } from 'react';
import { Icon, IconType } from '../../icon/icon';
import { Direction } from '../../modals/modal-types';
import { Tooltip } from '../../modals/tooltip/tooltip';
import { WithId } from '../../with-id';
import { CalendarDayBody } from './calendar-day-body';
import { CalendarMonthBody } from './calendar-month-body';
import { ICalendarPage, MAX_POSSIBLE_DATE, MIN_POSSIBLE_DATE, MONTH_STRINGS } from './constants';

import './date-picker.scss';
import { noop } from '../../utils';

export interface ICalendarProps extends WithId {
  /**
   * Currently selected date
   */
  selectedDate: Date | null;
  /**
   * Minimum date
   */
  minDate?: Date;
  /**
   * Maximum date
   */
  maxDate?: Date;
  /**
   * Date selection event
   */
  onDateSelection: (date: Date) => void;
  /**
   * Close calendar event
   */
  onClose?: () => void;
}

const getMonthString = (month: number) => {
  return MONTH_STRINGS[month];
};

const getTitleButton = (
  id: string,
  showMonthSelector: boolean,
  calendarPage: ICalendarPage,
  setShowMonthSelector: React.Dispatch<React.SetStateAction<boolean>>
) => {
  const button = showMonthSelector ? (
    <button
      className="btn header-btn date-picker-month"
      onClick={() => setShowMonthSelector(!showMonthSelector)}
      id={`${id}-toggle-off`}
      tabIndex={0}
    >
      {calendarPage.year}
    </button>
  ) : (
    <button
      className="btn header-btn date-picker-month"
      onClick={() => setShowMonthSelector(!showMonthSelector)}
      id={`${id}-toggle-on`}
      tabIndex={0}
    >
      {`${getMonthString(calendarPage.month)} ${calendarPage.year}`}
    </button>
  );

  return (
    <Tooltip id={`${id}-toggleview-tooltip`} content={`Toggle Calendar View ${showMonthSelector ? 'Off' : 'On'}`}>
      {button}
    </Tooltip>
  );
};

const changeMonthYear = (
  increment: number,
  calendarPage: ICalendarPage,
  setCalendarPage: (calendarPage: ICalendarPage) => void,
  showMonthSelector: boolean
) => {
  if (!showMonthSelector) {
    calendarPage.month += increment;
  } else {
    calendarPage.year += increment;
  }
  if (calendarPage.month < 0) {
    calendarPage.month = 11;
    calendarPage.year--;
  } else if (calendarPage.month > 11) {
    calendarPage.month = 0;
    calendarPage.year++;
  }
  setCalendarPage({ ...calendarPage });
};

export const Calendar = ({
  id,
  selectedDate,
  minDate = MIN_POSSIBLE_DATE,
  maxDate = MAX_POSSIBLE_DATE,
  onDateSelection,
  onClose = noop,
}: ICalendarProps) => {
  const [showMonthSelector, setShowMonthSelector] = useState(false);
  const nextBtnRef = useRef<HTMLButtonElement>(null);

  const effectiveDate = selectedDate || new Date();

  const [calendarPage, setCalendarPage] = useState<ICalendarPage>({
    year: effectiveDate.getFullYear(),
    month: effectiveDate.getMonth(),
  });

  useEffect(() => {
    // page down and up goes to next month/year and previous mont/year respectively
    const nextPrevHandler = (event: KeyboardEvent) => {
      if (event.key === 'PageDown') {
        changeMonthYear(-1, calendarPage, setCalendarPage, showMonthSelector);
        event.preventDefault();
      }
      if (event.key === 'PageUp') {
        changeMonthYear(1, calendarPage, setCalendarPage, showMonthSelector);
        event.preventDefault();
      }
      if (event.key === 'Escape') {
        onClose();
        event.stopPropagation();
      }
    };

    document.addEventListener('keydown', nextPrevHandler, true);
    return () => {
      // event cleanup on destroy
      document.removeEventListener('keydown', nextPrevHandler, true);
    };
  }, [calendarPage, showMonthSelector, onClose]);

  return (
    <div className="date-picker-popover" aria-labelledby="calendar-toggle" id={`${id}`} tabIndex={0}>
      <div className="date-picker-popover-body">
        <div className="date-picker-calendar">
          <div className="calendar-header">
            <span>
              <Tooltip id={`${id}-prev-tooltip`} content="Previous Month/Year" direction={Direction.left}>
                <button
                  id={`${id}-btn-prev`}
                  className="btn header-btn"
                  onClick={() => changeMonthYear(-1, calendarPage, setCalendarPage, showMonthSelector)}
                  ref={nextBtnRef}
                >
                  <Icon type={IconType.chevronLeft} />
                </button>
              </Tooltip>
              {getTitleButton(id, showMonthSelector, calendarPage, setShowMonthSelector)}

              <Tooltip id={`${id}-next-tooltip`} content="Next Month/Year" direction={Direction.right}>
                <button
                  id={`${id}-btn-next`}
                  className="btn header-btn"
                  onClick={() => changeMonthYear(1, calendarPage, setCalendarPage, showMonthSelector)}
                >
                  <Icon type={IconType.chevronRight} />
                </button>
              </Tooltip>
            </span>
            {!showMonthSelector ? (
              <div className="calendar-weekdays">
                <div>Su</div>
                <div>Mo</div>
                <div>Tu</div>
                <div>We</div>
                <div>Th</div>
                <div>Fr</div>
                <div>Sa</div>
              </div>
            ) : null}
          </div>
          {showMonthSelector ? (
            <CalendarMonthBody
              id={id}
              selectedDate={selectedDate}
              currentYear={calendarPage.year}
              onMonthSelection={(month) => {
                setCalendarPage({
                  year: calendarPage.year,
                  month,
                });
                setShowMonthSelector(false);
              }}
              nextBtnRef={nextBtnRef}
            />
          ) : (
            <CalendarDayBody
              id={id}
              calendarPage={calendarPage}
              minDate={minDate}
              maxDate={maxDate}
              selectedDate={selectedDate}
              onDateSelection={(date) => onDateSelection(date)}
              nextBtnRef={nextBtnRef}
            />
          )}
        </div>
      </div>
    </div>
  );
};
