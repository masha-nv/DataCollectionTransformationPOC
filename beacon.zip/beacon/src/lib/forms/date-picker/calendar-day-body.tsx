import React, { useRef } from 'react';
import { WithId } from '../../with-id';
import { ICalendarPage } from './constants';
import { handleCalendarKeys } from '../utils/keyboard-nav-utils';

export interface ICalendarDayBody extends WithId {
  /**
   * Currently selected date
   */
  selectedDate: Date | null;
  /**
   * Minimum date
   */
  minDate: Date;
  /**
   * Maximum date
   */
  maxDate: Date;
  /**
   * Current Month/Year to render
   */
  calendarPage: ICalendarPage;

  /**
   * Date selection event
   */
  onDateSelection: (date: Date) => void;
  /**
   * Next button
   */
  nextBtnRef: React.RefObject<HTMLButtonElement>;
}

/**
 * Get upper and lower limits for the current visible calendar view
 */
const getBoundsOfVisibleCalendar = (displayMonth: number, displayYear: number): { startDate: Date; endDate: Date } => {
  // Find first Sunday of calendar
  const startDate = new Date(displayYear, displayMonth);
  if (startDate.getDay() !== 0) {
    startDate.setDate(startDate.getDate() - startDate.getDay());
  }
  const endDate = new Date(displayYear, displayMonth + 1);

  // Find last Saturday of calendar
  if (endDate.getDay() !== 0) {
    endDate.setDate(7 - endDate.getDay());
  } else {
    endDate.setDate(0);
  }

  return {
    startDate,
    endDate,
  };
};

/**
 * Compares two dates to see if they lie of the same day (time is not considered)
 */
const isSameDate = (d1: Date, d2: Date): boolean => {
  return d1.getMonth() === d2.getMonth() && d1.getDate() === d2.getDate() && d1.getFullYear() === d2.getFullYear();
};

/**
 * Generate days for the current calendar view
 * @param calendarPage
 */
const generateMonth = (calendarPage: ICalendarPage) => {
  const displayMonthDays: Date[] = [];

  const { startDate, endDate } = getBoundsOfVisibleCalendar(calendarPage.month, calendarPage.year);
  let dayCount = 0;
  let dayOfMonth: Date | null = null;
  do {
    dayOfMonth = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate() + dayCount);
    displayMonthDays.push(dayOfMonth);
    dayCount++;
  } while (!isSameDate(dayOfMonth, endDate));

  return displayMonthDays;
};

export const CalendarDayBody = ({
  id,
  calendarPage,
  selectedDate,
  minDate,
  maxDate,
  nextBtnRef,
  onDateSelection,
}: ICalendarDayBody) => {
  let isSelected = false;
  const dayRefs = useRef<HTMLButtonElement[]>([]);
  const dayButtons = generateMonth(calendarPage).map((day, index) => {
    const classes = ['calendar-cell'];
    if (day.getMonth() !== calendarPage.month) {
      classes.push('muted');
    }
    if (selectedDate && isSameDate(day, selectedDate)) {
      classes.push('selected');
      isSelected = true;
    }
    const isDisabled = day < minDate || day > maxDate;

    return (
      <button
        key={index}
        id={`${id}-${day.toJSON().slice(0, 10)}`}
        className={classes.join(' ')}
        onClick={(e) => {
          onDateSelection(day);
          e.preventDefault();
        }}
        tabIndex={isSelected ? 1 : 2}
        title={day.toDateString()}
        disabled={isDisabled}
        ref={(node) => (dayRefs.current[index] = node as HTMLButtonElement)}
        onKeyDown={(event) => handleCalendarKeys(event, index, 'day', dayRefs, nextBtnRef)}
      >
        {day.getDate()}
      </button>
    );
  });
  return <div className="calendar-body">{dayButtons}</div>;
};
