import React from 'react';
import { render, fireEvent, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Calendar } from './calendar';
import { MONTH_STRINGS } from './constants';
import { noop } from '../../utils';
import { Modal } from '../../modals/modal/modal';

describe('Calendar', () => {
  it('renders Day picker Calendar correctly', () => {
    const date = new Date(2000, 5, 1);
    const minDate = new Date(date);
    minDate.setDate(minDate.getDate() - 5);

    const maxDate = new Date(date);
    maxDate.setDate(maxDate.getDate() + 5);

    const { baseElement, container } = render(
      <Calendar
        id="date-picker-id-calendar"
        minDate={minDate}
        maxDate={maxDate}
        selectedDate={date}
        onDateSelection={noop}
      />
    );

    const firstCellVal = container.querySelector('.calendar-cell').innerHTML;

    expect(isNaN(parseInt(firstCellVal))).not.toBeTruthy();

    expect(baseElement).toMatchSnapshot();
  });

  it('renders Day picker Calendar with month starting with a Sunday correctly', () => {
    const date = new Date(2020, 10, 1);

    const { baseElement, container } = render(
      <Calendar id="date-picker-id-calendar" selectedDate={date} onDateSelection={noop} />
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders Day picker Calendar with month ending with a Saturday correctly', () => {
    const date = new Date(2020, 9, 1);

    const { baseElement, container } = render(
      <Calendar id="date-picker-id-calendar" selectedDate={date} onDateSelection={noop} />
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders Month picker Calendar correctly', () => {
    const date = new Date(2025, 5, 1);
    const id = 'date-picker-id-calendar';
    const { baseElement, container } = render(<Calendar selectedDate={date} id={id} onDateSelection={noop} />);

    const headerBtn = container.querySelector(`#${id}-toggle-on`);

    // switch to month view
    fireEvent.click(headerBtn);

    expect(container.querySelector('.calendar-cell').innerHTML).toBe('Jan');

    expect(baseElement).toMatchSnapshot();
  });

  it('Switches back to Day Picker view correctly', () => {
    const id = 'date-picker-id-calendar';
    const { baseElement, container } = render(<Calendar selectedDate={null} id={id} onDateSelection={noop} />);

    let headerBtn = container.querySelector(`#${id}-toggle-on`);

    // switch to month view
    fireEvent.click(headerBtn);

    // switch back to day view
    headerBtn = container.querySelector(`#${id}-toggle-off`);

    fireEvent.click(headerBtn);

    const firstCellVal = container.querySelector('.calendar-cell').innerHTML;

    expect(isNaN(parseInt(firstCellVal))).not.toBeTruthy();
  });

  it('switches to the next month for day view', () => {
    const id = 'date-picker-id-calendar';
    const date = new Date(2000, 5, 1);
    const { baseElement, container } = render(<Calendar id={id} selectedDate={date} onDateSelection={noop} />);

    const prevButton = container.querySelector(`#${id}-btn-prev`);
    const nextButton = container.querySelector(`#${id}-btn-next`);
    const headerBtn = container.querySelector(`#${id}-toggle-on`);

    expect(headerBtn.innerHTML).toBe(`${MONTH_STRINGS[date.getMonth()]} ${date.getFullYear()}`);

    // On prev click
    fireEvent.click(prevButton);
    expect(headerBtn.innerHTML).toBe(`${MONTH_STRINGS[date.getMonth() - 1]} ${date.getFullYear()}`);

    // On next click
    fireEvent.click(nextButton);
    expect(headerBtn.innerHTML).toBe(`${MONTH_STRINGS[date.getMonth()]} ${date.getFullYear()}`);
  });

  it('switches to the next year for month view', () => {
    const id = 'date-picker-id-calendar';
    const date = new Date(2000, 5, 1);
    const { baseElement, container } = render(<Calendar id={id} selectedDate={date} onDateSelection={noop} />);

    const prevButton = container.querySelector(`#${id}-btn-prev`);
    const nextButton = container.querySelector(`#${id}-btn-next`);
    const headerBtn = container.querySelector(`#${id}-toggle-on`);

    // Switch to month view
    fireEvent.click(headerBtn);

    expect(headerBtn.innerHTML).toBe(`${date.getFullYear()}`);

    fireEvent.click(prevButton);

    expect(headerBtn.innerHTML).toBe(`${date.getFullYear() - 1}`);

    fireEvent.click(nextButton);

    expect(headerBtn.innerHTML).toBe(`${date.getFullYear()}`);
  });

  it('raised onDateSelection for Day picker view', () => {
    const handler = jest.fn();
    const date = new Date(2021, 1, 5);
    const { baseElement, container } = render(
      <Calendar id="date-picker-id-calendar" selectedDate={date} onDateSelection={handler} />
    );

    const btnArr = Array.from(container.querySelectorAll('.calendar-cell'));

    const btn = btnArr.find((item) => item.innerHTML === '1');

    fireEvent.click(btn);

    expect(handler).toHaveBeenCalledWith(new Date(2021, 1, 1));
  });

  it('selected month from the Month picker view', () => {
    const id = 'date-picker-id-calendar';
    const date = new Date(2021, 1, 5);
    const { baseElement, container } = render(<Calendar id={id} selectedDate={date} onDateSelection={noop} />);

    let headerBtn = container.querySelector(`#${id}-toggle-on`);

    expect(headerBtn.innerHTML).toBe(`${MONTH_STRINGS[date.getMonth()]} ${date.getFullYear()}`);

    // Switch to month view
    fireEvent.click(headerBtn);

    const btnArr = Array.from(container.querySelectorAll('.calendar-cell'));

    const btn = btnArr.find((item) => item.innerHTML === 'Mar');

    fireEvent.click(btn);

    headerBtn = container.querySelector(`#${id}-toggle-on`);

    expect(headerBtn.innerHTML).toBe(`March ${date.getFullYear()}`);
  });

  it('switches to the next year for day view', () => {
    const id = 'date-picker-id-calendar';
    const date = new Date(2000, 11, 1);
    const { baseElement, container } = render(<Calendar id={id} selectedDate={date} onDateSelection={noop} />);

    const nextButton = container.querySelector(`#${id}-btn-next`);
    const headerBtn = container.querySelector(`#${id}-toggle-on`);

    expect(headerBtn.innerHTML).toBe(`${MONTH_STRINGS[date.getMonth()]} ${date.getFullYear()}`);

    // On next click
    fireEvent.click(nextButton);
    expect(headerBtn.innerHTML).toBe(`${MONTH_STRINGS[0]} ${date.getFullYear() + 1}`);
  });

  it('switches to the prev year for day view', () => {
    const id = 'date-picker-id-calendar';
    const date = new Date(2000, 0, 1);
    const { baseElement, container } = render(<Calendar id={id} selectedDate={date} onDateSelection={noop} />);

    const prevButton = container.querySelector(`#${id}-btn-prev`);
    const headerBtn = container.querySelector(`#${id}-toggle-on`);

    expect(headerBtn.innerHTML).toBe(`${MONTH_STRINGS[date.getMonth()]} ${date.getFullYear()}`);

    // On next click
    fireEvent.click(prevButton);
    expect(headerBtn.innerHTML).toBe(`${MONTH_STRINGS[11]} ${date.getFullYear() - 1}`);
  });

  describe('Keyboard Navigation ', () => {
    let onClose: jest.Mock;
    beforeEach(async () => {
      onClose = jest.fn();
      const date = new Date(2000, 3, 15);
      render(<Calendar id="test" selectedDate={date} onDateSelection={noop} onClose={onClose} />);
      expect(screen.getAllByText('27')[0]).toHaveProperty('focus');
    });

    it('focuses back to previous month/year', () => {
      userEvent.keyboard('{Tab}');
      const prevButton = screen.getAllByRole('button')[0];
      expect(prevButton).toHaveProperty('focus');
    });

    it('can use arrows to navigate days', () => {
      fireEvent.keyDown(screen.getAllByText('27')[0], { key: 'ArrowRight' });
      let selectedDay = screen.getAllByText('28')[0];
      expect(selectedDay).toHaveProperty('focus');

      fireEvent.keyDown(selectedDay, { key: 'ArrowDown' });
      selectedDay = screen.getAllByText('6')[0];
      expect(selectedDay).toHaveProperty('focus');

      fireEvent.keyDown(selectedDay, { key: 'ArrowLeft' });
      selectedDay = screen.getAllByText('5')[0];
      expect(selectedDay).toHaveProperty('focus');

      fireEvent.keyDown(selectedDay, { key: 'ArrowUp' });
      expect(screen.getAllByText('27')[0]).toHaveProperty('focus');
    });

    it('can use arrows to navigate months', () => {
      fireEvent.click(screen.getByText('April 2000'));
      userEvent.keyboard('{Tab}');
      userEvent.keyboard('{Tab}');
      let selectedMonth = screen.getByText('Jan');
      expect(selectedMonth).toHaveProperty('focus');

      fireEvent.keyDown(selectedMonth, { key: 'ArrowRight' });
      selectedMonth = screen.getByText('Feb');
      expect(selectedMonth).toHaveProperty('focus');

      fireEvent.keyDown(selectedMonth, { key: 'ArrowDown' });
      selectedMonth = screen.getByText('Jun');
      expect(selectedMonth).toHaveProperty('focus');

      fireEvent.keyDown(selectedMonth, { key: 'ArrowLeft' });
      selectedMonth = screen.getByText('May');
      expect(selectedMonth).toHaveProperty('focus');

      fireEvent.keyDown(selectedMonth, { key: 'ArrowUp' });
      expect(screen.getByText('Jan')).toHaveProperty('focus');
    });

    it('does not do anything if arrow navigation goes out of bounds', () => {
      const focusedDay = screen.getAllByText('27')[0];
      fireEvent.keyDown(focusedDay, { key: 'ArrowUp' });
      expect(focusedDay).toHaveProperty('focus');
    });

    it('can use pageUp and pageDown keys to go to next and previous month', () => {
      userEvent.keyboard('{PageUp}');
      expect(screen.getByText('May 2000')).toBeDefined();
      userEvent.keyboard('{PageDown}');
      expect(screen.getByText('April 2000')).toBeDefined();
    });

    it('can use pageUp and pageDown keys to go to next and previous year', () => {
      fireEvent.click(screen.getByText('April 2000'));
      userEvent.keyboard('{PageUp}');
      expect(screen.getByText('2001')).toBeDefined();
      userEvent.keyboard('{PageDown}');
      expect(screen.getByText('2000')).toBeDefined();
    });

    it('can use escape button to close', () => {
      userEvent.keyboard('{Escape}');
      expect(onClose).toHaveBeenCalled();
    });
  });

  it('calendar listener events stop other listeners for the same event', async () => {
    const onModalClose = jest.fn();
    const onCalendarClose = jest.fn();
    render(
      <div id="test">
        <Modal
          id="test"
          footer="Modal footer"
          title="Modal title"
          appElementSelector="body"
          onRequestClose={onModalClose}
        >
          <Calendar id="test" selectedDate={new Date(2000, 3, 15)} onDateSelection={noop} onClose={onCalendarClose} />
        </Modal>
      </div>
    );

    userEvent.keyboard('{Escape}');
    expect(onCalendarClose).toHaveBeenCalled();
    expect(onModalClose).not.toHaveBeenCalled();
  });
});
