import React, { useRef } from 'react';
import { WithId } from '../../with-id';
import { MONTH_ABBR_STRING } from './constants';
import { handleCalendarKeys } from '../utils/keyboard-nav-utils';

/**
 * Calendar
 */
export interface ICalendarMonthBody extends WithId {
  /**
   * Current date selection
   */
  selectedDate: Date | null;
  /**
   * Current Year to display
   */
  currentYear: number;
  /**
   * On Month Selection event
   */
  onMonthSelection: (month: number) => void;
  /**
   * Next button
   */
  nextBtnRef: React.RefObject<HTMLButtonElement>;
}

export const CalendarMonthBody = ({
  id,
  selectedDate,
  currentYear,
  onMonthSelection,
  nextBtnRef,
}: ICalendarMonthBody) => {
  const monthRefs = useRef<HTMLButtonElement[]>([]);
  const monthButtons = MONTH_ABBR_STRING.map((month, index) => {
    const classes = ['calendar-cell month-cell'];
    let isSelected = false;
    if (selectedDate && index === selectedDate.getMonth() && currentYear === selectedDate.getFullYear()) {
      classes.push('selected');
      isSelected = true;
    }
    return (
      <button
        key={index}
        id={`${id}-${month}`}
        className={classes.join(' ')}
        tabIndex={isSelected ? 1 : 2}
        title={`${month} ${currentYear}`}
        onClick={() => onMonthSelection(index)}
        ref={(node) => (monthRefs.current[index] = node as HTMLButtonElement)}
        onKeyDown={(event) => handleCalendarKeys(event, index, 'month', monthRefs, nextBtnRef)}
      >
        {month}
      </button>
    );
  });
  return <div className="calendar-body">{monthButtons}</div>;
};
