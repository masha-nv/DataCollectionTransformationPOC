import { Story } from '@storybook/react';
import moment from 'moment';
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Documentation, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { FormGroup } from '../form-group/form-group';
import { DATE_FORMAT } from './constants';
import { CalendarPopupDirection, DatePicker } from './date-picker';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { SubmitButton } from '../../button/submit-button';
import { action } from '@storybook/addon-actions';
import { hookFormUtils } from '../../forms/utils/hookform-utils';
import { yupUtils } from '../utils/yup-utils';
import { Label } from '../label/label';
import { Form } from '../form/form';
import { noop } from '../../utils';

export default {
  component: DatePicker,
  title: 'Core Components/Form Controls/Date Picker',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
};

const whenToUse = (
  <>
    <strong>Date Picker</strong> should be used to choose a date.
  </>
);
const description =
  'A date picker allows users to pick a date or a range of dates by either typing the date into a text field or choosing from pop-up calendars that let users click on the desired date or dates';

export const BasicDatePicker: Story = () => {
  const [date, setDate] = useState<string>();
  const minDate = new Date();
  minDate.setDate(minDate.getDate() - 45);

  const maxDate = new Date();
  maxDate.setDate(maxDate.getDate() + 45);

  return (
    <div>
      <Label htmlFor="date-picker-id">Label</Label>
      <DatePicker
        id="date-picker-id"
        name="date-picker-name"
        value={date}
        minDate={minDate}
        maxDate={maxDate}
        onChange={(e, value) => setDate(value)}
      />
    </div>
  );
};

BasicDatePicker.decorators = [
  (Story: Story) => (
    <Documentation name="DatePicker Component" description={description} whenToUse={whenToUse}>
      <Story />
    </Documentation>
  ),
];

export const Direction: Story = () => {
  const [date, setDate] = useState<string>();
  const minDate = new Date();
  minDate.setDate(minDate.getDate() - 15);

  const maxDate = new Date();
  maxDate.setDate(maxDate.getDate() + 15);

  return (
    <div style={{ marginLeft: '100px' }}>
      <Label htmlFor="date-picker-id">Label</Label>
      <DatePicker
        id="date-picker-id"
        name="date-picker-name"
        value={date}
        minDate={minDate}
        maxDate={maxDate}
        direction={CalendarPopupDirection.left}
        onChange={(e, value) => setDate(value)}
      />
    </div>
  );
};

Direction.decorators = [
  (Story: Story) => (
    <Documentation
      name="Direction of Datepicker"
      description={
        <p>
          By default, datepickers are right aligned of their input control. However, this can be changed (e.g. to be
          left aligned) using the <code>direction</code> property.
        </p>
      }
      whenToUse={whenToUse}
    >
      <Story />
    </Documentation>
  ),
];

export const Disabled: Story = () => {
  const [date, setDate] = useState<string>('11/11/2020');
  return (
    <div>
      <Label htmlFor="date-picker-id">Label</Label>
      <DatePicker id="date-picker-id" name="date-picker-name" value={date} disabled onChange={noop} />
    </div>
  );
};

Disabled.decorators = [
  (Story: Story) => (
    <Documentation
      name="Disabling the DatePicker"
      description={
        <p>
          Datepickers can be disabled using the <code>disabled</code> property
        </p>
      }
      whenToUse={whenToUse}
    >
      <Story />
    </Documentation>
  ),
];

export const FormDatePicker: Story = () => {
  const minDate = new Date();
  minDate.setDate(minDate.getDate() - 15);

  const maxDate = new Date();
  maxDate.setDate(maxDate.getDate() + 15);

  const schema = yup.object().shape({
    creationDate: yupUtils
      .yupDateWithFormat()
      .min(minDate, ({ min }) => `Date needs to be after ${moment(min).format(DATE_FORMAT)}`)
      .max(maxDate, ({ max }) => `Date needs to be on or before ${moment(max).format(DATE_FORMAT)}`)
      .required(),
  });
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema) /* A valid yup schema*/,
    defaultValues: { creationDate: '01/01/1999' },
  });
  const onSubmit = (data: { creationDate: Date }) => {
    action('submit-action')(data);
  };

  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      <FormGroup id="fg-firstName" errorMessages={hookFormUtils.getErrorMessages(errors, 'creationDate')}>
        <Label htmlFor="creationDate" required>
          Creation Date
        </Label>
        <DatePicker id="creationDate" minDate={minDate} maxDate={maxDate} {...register('creationDate')} required />
      </FormGroup>
      <SubmitButton id="submit">Submit</SubmitButton>
    </Form>
  );
};

FormDatePicker.decorators = [
  (Story: Story) => (
    <Documentation name="Datepickers in Forms" description={description} whenToUse={whenToUse}>
      <Story />
    </Documentation>
  ),
];
BasicDatePicker.storyName = 'Date Picker';
Direction.storyName = 'Date Picker Popup Alignment Direction';
Disabled.storyName = 'Disabled Date Picker';
