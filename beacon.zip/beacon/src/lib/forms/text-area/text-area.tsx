import React, { ChangeEvent, forwardRef, useState } from 'react';
import { noop } from '../../utils';
import { WithId } from '../../with-id';
import { WithInput } from '../../with-input';

export interface ITextAreaProps extends WithId, WithInput<HTMLTextAreaElement> {
  /**
   * The placeholder for the text input
   */
  placeholder?: string;
  /**
   * The default value of the text input
   */
  defaultValue?: string;
  /**
   * The value of a controlled text input
   */
  value?: string;
  /**
   * Whether the text input is read-only (i.e. focusable and sent to form but cannot be modified)
   */
  readOnly?: boolean;
  /**
   * The maximum amount of allowed characters
   */
  maxLength?: number;
  /**
   * The amount of the rows of text that the textarea will show
   */
  rows?: number;
}

export const TextArea = forwardRef<HTMLTextAreaElement, ITextAreaProps>(
  ({ onChange = noop, onBlur = noop, ...props }, ref) => {
    const [value, setValue] = useState(props.value || props.defaultValue);

    const onTextAreaChange = (event: ChangeEvent<HTMLTextAreaElement>) => {
      setValue(event.target.value);
      onChange(event, event.target.value);
    };

    const text = props.value ?? value;
    const textLength = text ? text.length : 0;

    return (
      <>
        <textarea
          id={props.id}
          className="form-control"
          ref={ref}
          value={props.value}
          defaultValue={props.defaultValue}
          name={props.name}
          placeholder={props.placeholder}
          disabled={props.disabled}
          readOnly={props.readOnly}
          onChange={onTextAreaChange}
          onBlur={onBlur}
          autoComplete="off"
          required={props.required}
          rows={props.rows}
          maxLength={props.maxLength}
        />
        {props.maxLength && (
          <span
            className="form-input-maxchar"
            id={`${props.id}-countmessage`}
            aria-describedby={props.id}
            aria-live="polite"
            tabIndex={0}
          >
            {`${props.maxLength - textLength} Characters Remaining`}
          </span>
        )}
      </>
    );
  }
);

TextArea.displayName = 'TextArea';
