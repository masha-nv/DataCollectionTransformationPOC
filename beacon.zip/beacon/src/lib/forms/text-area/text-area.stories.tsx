import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { TextArea } from './text-area';
import React, { ChangeEvent, useState } from 'react';
import { Label } from '../label/label';
import * as yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { Controller, useForm } from 'react-hook-form';
import { hookFormUtils } from '../utils/hookform-utils';
import { FormGroup } from '../form-group/form-group';
import { ButtonGroup } from '../../button/button-group';
import { Button, ButtonType } from '../../button/button';
import { SubmitButton } from '../../button/submit-button';
import { Form } from '../form/form';

export default {
  component: TextArea,
  title: 'Core Components/Form Controls/Text Area',
  parameters: {
    badges: [StoryBadge.BETA],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

export const Example: Story = () => {
  return (
    <>
      <Label htmlFor="example-text-area">Text Area</Label>
      <TextArea id="example-text-area" />
    </>
  );
};
Example.storyName = 'Text Area';
Example.decorators = [
  (Story: Story) => (
    <Documentation
      name="Simple Example"
      description="A text area enables users to enter multiple lines of inputs (text, numerals, special characters, etc)."
    >
      <Story />
    </Documentation>
  ),
];
export const TextAreaForm: Story = () => {
  const schema = yup.object().shape({
    text: yup.string().required().min(25).max(100),
  });

  const {
    handleSubmit,
    formState: { errors },
    control,
    setValue,
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: { text: 'Hello!' },
  });

  const onSubmit = (data: { text: string }) =>
    alert(`This form has been with submitted with data ${JSON.stringify(data)}`);

  return (
    <Form onSubmit={handleSubmit(onSubmit)} className="pl-2">
      <FormGroup id="form-group-text" errorMessages={hookFormUtils.getErrorMessages(errors, 'text')}>
        <Label htmlFor="textarea" required>
          The Next Great American Novel:
        </Label>
        <Controller
          control={control}
          name="text"
          render={({ field: { onChange, onBlur, value } }) => (
            <TextArea
              id="textarea"
              placeholder="Good luck buddy (:"
              required
              onBlur={onBlur}
              onChange={onChange}
              value={value}
              maxLength={100}
            />
          )}
        />
      </FormGroup>
      <ButtonGroup>
        <Button id="clear-btn" type={ButtonType.secondary} onClick={() => setValue('text', '')} behavior="button">
          Clear
        </Button>
        <SubmitButton id="save-btn">Submit</SubmitButton>
      </ButtonGroup>
    </Form>
  );
};
TextAreaForm.storyName = 'Text Area in Form';
TextAreaForm.decorators = [
  (Story: Story) => (
    <Documentation name="Text areas in forms">
      <Story />
    </Documentation>
  ),
];
export const Controlled: Story = () => {
  const [text, setText] = useState('');

  const onChangeCallback = (e: ChangeEvent<HTMLTextAreaElement>, value: string) => {
    setText(value);
  };

  return (
    <div>
      <Label htmlFor="controlled-text-area">Enter value:</Label>
      <TextArea id="controlled-text-area" value={text} onChange={onChangeCallback} rows={5} maxLength={1000} />
      <ButtonGroup>
        <Button id="clear-button" onClick={() => setText('')}>
          Clear
        </Button>
      </ButtonGroup>
      <hr />
      <Label htmlFor="entered-text-area">Entered value:</Label>
      <TextArea id="entered-text-area" readOnly value={text} rows={5} />
    </div>
  );
};
Controlled.storyName = 'Controlled Text Area';
Controlled.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Controlled Text Areas"
      description={
        <p>
          The value of a text area can be fully controlled (instead of them managing their state) with the{' '}
          <code>value</code> property. This property will always reflect the current value of the text input. If the
          text area is changed, this value (or the state variable that it is tied to) <strong>must be updated</strong>.
        </p>
      }
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const DisabledAndReadonly: Story = () => {
  return (
    <>
      <Label htmlFor="disabled-text-area">Disabled Text Area</Label>
      <TextArea id="disabled-text-area" disabled defaultValue="This textarea is disabled" />

      <Label htmlFor="readonly-text-area">Readonly Text Area</Label>
      <TextArea id="readonly-text-area" readOnly defaultValue="This textarea is readonly" />
    </>
  );
};
DisabledAndReadonly.storyName = 'Disabled and Read-only Text Area';
DisabledAndReadonly.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Disabled and Readonly Text Areas"
      description={
        <p>
          Text areas can be disabled or made read-only with the <code>disabled</code> or <code>readOnly</code>{' '}
          properties. In either case, users cannot enter input. However, users can still select text in read-only text
          areas.
        </p>
      }
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const NativeTextAreaProperties: Story = () => {
  return (
    <>
      <Label htmlFor="properties-text-area">Text Area</Label>
      <TextArea id="properties-text-area" rows={5} placeholder="Enter text here" maxLength={100} />
    </>
  );
};
NativeTextAreaProperties.storyName = 'Native Text Area Properties';
NativeTextAreaProperties.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Native TextArea Properties"
      description={
        <p>
          All of the common native text area properties can still used in react-beacon text areas. This includes
          properties like <code>placeholder</code>, <code>rows</code>, or <code>maxLength</code>.
        </p>
      }
    >
      <ComponentStory />
    </Documentation>
  ),
];
