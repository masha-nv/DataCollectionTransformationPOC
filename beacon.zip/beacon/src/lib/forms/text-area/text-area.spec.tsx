import React from 'react';
import { TextArea } from './text-area';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

describe('TextArea', () => {
  it('initially uses the default value', () => {
    const { baseElement } = render(<TextArea id="text-area" defaultValue="wisconsin" />);

    const textarea = baseElement.querySelector<HTMLTextAreaElement>('#text-area');
    const initialValue = textarea.value;

    userEvent.type(textarea, ' cheese');

    expect(initialValue).toEqual('wisconsin');
    expect(textarea.value).toEqual('wisconsin cheese');
  });

  it('always uses it controlled value', () => {
    const { baseElement } = render(<TextArea id="text-area" value="wisconsin" />);

    const textarea = baseElement.querySelector<HTMLTextAreaElement>('#text-area');
    const initialValue = textarea.value;

    userEvent.type(textarea, ' cheese');

    expect(initialValue).toEqual('wisconsin');
    expect(textarea.value).toEqual('wisconsin');
  });

  it('calls change handler when modified', () => {
    const onChangeCallback = jest.fn();
    const { baseElement } = render(<TextArea id="text-area" onChange={onChangeCallback} />);
    const textarea = baseElement.querySelector<HTMLTextAreaElement>('#text-area');

    userEvent.type(textarea, 'cheese');

    expect(onChangeCallback).toHaveBeenCalled();
  });

  it('readonly', () => {
    const { baseElement } = render(<TextArea id="text-area" readOnly />);

    expect(baseElement).toMatchSnapshot();
  });

  it('disabled', () => {
    const { baseElement } = render(<TextArea id="text-area" disabled />);

    expect(baseElement).toMatchSnapshot();
  });

  it('rows', () => {
    const { baseElement } = render(<TextArea id="text-area" rows={5} />);

    expect(baseElement).toMatchSnapshot();
  });

  it('placeholder', () => {
    const { baseElement } = render(<TextArea id="text-area" placeholder="Place Text Here" />);

    expect(baseElement).toMatchSnapshot();
  });

  it('maxLength', async () => {
    render(<TextArea id="text-area" maxLength={100} />);
    await screen.findByText('100 Characters Remaining');
    userEvent.type(await screen.findByRole('textbox'), 'Adding 20 Characters');
    expect(await screen.findByText('80 Characters Remaining')).toBeTruthy();
  });

  it('maxLength with text', () => {
    const { baseElement } = render(<TextArea id="text-area" defaultValue="hello world" maxLength={100} />);

    expect(baseElement).toMatchSnapshot();
  });
});
