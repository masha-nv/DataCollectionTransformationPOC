import React, { ReactElement, useMemo } from 'react';
import './filter-chip-list.scss';
import { calcLength } from './utils';
import { WithId } from '../../with-id';

interface IFilterChipListProps extends WithId {
  /**
   * Display label for the FilterChipList
   */
  label: string;

  children: ReactElement<IFilterChipListProps>[];
}

export const FilterChipList = ({ id, label, children }: IFilterChipListProps) => {
  const arrayedChildren = useMemo(() => calcLength(children), [children]);
  return (
    <>
      <label htmlFor={id} className="filter-chip-list-label">
        {label}
      </label>
      <div className="filter-chip-list-chips" id={`filter-chip-list-` + id}>
        {arrayedChildren.map((child) => child)}
      </div>
    </>
  );
};

FilterChipList.displayName = 'FilterChipList';
