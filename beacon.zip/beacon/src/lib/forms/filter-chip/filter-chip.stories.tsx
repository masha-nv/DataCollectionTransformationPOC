import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { FilterChip } from './filter-chip';
import { useState } from 'react';
import { FilterChipList } from './filter-chip-list';
import { Controller, FieldValues, useForm } from 'react-hook-form';
import { action } from '@storybook/addon-actions';
import { Form } from '../form/form';
import { FormGroup } from '../form-group/form-group';
import { hookFormUtils } from '../utils/hookform-utils';
import { SubmitButton } from '../../button/submit-button';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';

const whenToUse = (
  <p>
    <strong>FilterChip</strong> should be used for interactions that require user confirmation before applying changes.
    The filter should not take effect immediately. You cannot pass down more than four chips to a FilterChipList.
  </p>
);

export default {
  component: FilterChip,
  title: 'Core Components/Form Controls/FilterChip',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
  },
} as Meta;

export const FilterChips: Story = () => {
  const [chips, setChips] = useState<Record<number, boolean>>({ 0: true, 1: false, 2: false });

  const chipClick = (id: number) => {
    setChips({ ...chips, [id]: !chips[id] });
  };

  return (
    <FilterChipList id="default-list" label="Test Label">
      {Object.keys(chips).map((key) => {
        const keyAsNumber = parseInt(key);
        return (
          <FilterChip
            id={`mapped-chip-${key}`}
            label={key}
            checked={chips[keyAsNumber]}
            key={key}
            onChange={() => {
              chipClick(keyAsNumber);
            }}
          />
        );
      })}
    </FilterChipList>
  );
};

FilterChips.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Filter Chip"
      description="Filter Chips are checkboxes with an added icon and styling when selected."
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
FilterChips.storyName = 'FilterChip';

export const FilterChipListInAForm: Story = () => {
  const schema = yup.object({
    testFilterChipList: yup.object({ One: yup.boolean(), Two: yup.boolean(), Three: yup.boolean() }).test({
      message: 'At least one value must be selected',
      test: (obj) => Object.values(obj).some((value) => value === true),
    }),
  });

  const {
    control,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<FieldValues>({
    defaultValues: { testFilterChipList: { One: true, Two: false, Three: false } },
    resolver: yupResolver(schema),
  });
  const onSubmit = (data: unknown) => {
    action('submit-action')(data);
    alert('Checked Value: ' + JSON.stringify(data));
  };

  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      <FormGroup id="fg-checkboxList" errorMessages={hookFormUtils.getErrorMessages(errors, 'testFilterChipList')}>
        <FilterChipList id="form-list" label="Test Label">
          <Controller
            control={control}
            name="testFilterChipList.One"
            render={({ field }) => (
              <FilterChip
                id="form-chip-1"
                label="One"
                {...field}
                checked={field.value}
                onChange={() => setValue('testFilterChipList.One', !field.value)}
              />
            )}
          />
          <Controller
            control={control}
            name="testFilterChipList.Two"
            render={({ field }) => (
              <FilterChip
                id="form-chip-2"
                label="Two"
                {...field}
                checked={field.value}
                onChange={() => setValue('testFilterChipList.Two', !field.value)}
              />
            )}
          />
          <Controller
            control={control}
            name="testFilterChipList.Three"
            render={({ field }) => (
              <FilterChip
                id="form-chip-3"
                label="Three"
                {...field}
                checked={field.value}
                onChange={() => setValue('testFilterChipList.Three', !field.value)}
              />
            )}
          />
        </FilterChipList>
      </FormGroup>
      <SubmitButton id="button-toggle">Submit FilterChipList</SubmitButton>
    </Form>
  );
};

FilterChipListInAForm.storyName = 'FilterChipList in a Form';

FilterChipListInAForm.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Form Usage"
      whenToUse={whenToUse}
      description="FilterChipList can be used in forms, and works with yup validation."
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const MaxLength: Story = () => {
  const [chips, setChips] = useState<Record<number, boolean>>({
    0: true,
    1: false,
    2: false,
    3: false,
    4: false,
  });

  const chipClick = (id: number) => {
    setChips({ ...chips, [id]: !chips[id] });
  };

  return (
    <FilterChipList id="max-length-list" label="Test Label">
      <FilterChip id="max-length-chip-1" label="One" checked={chips[0]} onChange={() => chipClick(0)} />
      <FilterChip id="max-length-chip-2" label="Two" checked={chips[1]} onChange={() => chipClick(1)} />
      <FilterChip id="max-length-chip-3" label="Three" checked={chips[2]} onChange={() => chipClick(2)} />
      <FilterChip id="max-length-chip-4" label="Four" checked={chips[3]} onChange={() => chipClick(3)} />
      <FilterChip id="max-length-chip-5" label="Five" checked={chips[4]} onChange={() => chipClick(4)} />
    </FilterChipList>
  );
};

MaxLength.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Max Length"
      description="A warning will appear in the console if more than four chips are passed to a FilterChipList."
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
MaxLength.storyName = 'MaxLength';
