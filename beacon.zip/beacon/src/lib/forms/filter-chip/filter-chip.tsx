import classNames from 'classnames';
import React, { ChangeEvent, forwardRef, ReactElement, SyntheticEvent, useState } from 'react';
import { getTrackableClickHandler, Trackable } from '../../analytics';
import { WithId } from '../../with-id';
import { Icon, IconType } from '../../icon/icon';
import { Label } from '../label/label';
import './filter-chip.scss';

export interface ICustomFilterChipProps extends Trackable, WithId {
  /**
   * Label can be as simple as a string, or can be customized by inserting your own html.
   */
  label: string | number | ReactElement;
  onChange: (e: SyntheticEvent) => void;
  disabled?: boolean;
  checked: boolean;
}

export type IFilterChipProps = ICustomFilterChipProps &
  Omit<JSX.IntrinsicElements['input'], 'className' | 'ref' | 'type' | 'onChange' | 'onBlur'>;

export const FilterChip = forwardRef<HTMLInputElement, IFilterChipProps>(
  ({ label, onChange, disabled, checked, ...props }, ref) => {
    const { tracking, id } = props;
    const [focused, setFocused] = useState(false);

    const trackingDefaults = {
      grouping: 'Ungrouped',
      action: 'Clicked',
      trackingKey: `FilterChip-${props.id}`,
    };

    const onChangeEventHandler = (event: ChangeEvent<HTMLInputElement> | React.KeyboardEvent<HTMLDivElement>) => {
      onChange?.(event);
    };

    const labelClasses = classNames('filter-chip', {
      selected: checked === true,
      disabled: disabled === true,
      focused: focused,
    });

    return (
      <Label htmlFor={id} className={labelClasses} key={props.key}>
        <input
          {...props}
          disabled={disabled}
          type="checkbox"
          className="filter-chip-input"
          ref={ref}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          onChange={getTrackableClickHandler(tracking, trackingDefaults, onChangeEventHandler)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              const tracked = getTrackableClickHandler(tracking, trackingDefaults, onChangeEventHandler);
              tracked(e);
            }
          }}
        />
        {checked && <Icon type={IconType.check} />}
        {label}
      </Label>
    );
  }
);

FilterChip.displayName = 'FilterChip';
