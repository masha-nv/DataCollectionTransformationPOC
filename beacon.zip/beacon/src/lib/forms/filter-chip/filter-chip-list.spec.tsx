import { render, screen } from '@testing-library/react';
import { FilterChipList } from './filter-chip-list';
import { noop } from '../../utils';
import { FilterChip } from './filter-chip';
import { maxChipsError } from './utils';

jest.mock('../analytics/matomo', () => {
  const module = jest.requireActual('../analytics/matomo');
  return {
    ...module,
    track: jest.fn(),
  };
});

it('renders label', () => {
  render(
    <FilterChipList id="render-label-test-list" label={'Test'}>
      <FilterChip id="render-label-test-chip-1" label="chip1" checked={true} onChange={noop} />
      <FilterChip id="render-label-test-chip-2" label="chip2" checked={true} onChange={noop} />
    </FilterChipList>
  );

  expect(screen.getByText('Test')).toBeTruthy();
});

it('renders children', () => {
  render(
    <FilterChipList id="render-chip-test-list" label="test">
      <FilterChip id="render-chip-test-chip-1" label="chip1" checked={true} onChange={noop} />
      <FilterChip id="render-chip-test-chip-2" label="chip2" checked={true} onChange={noop} />
    </FilterChipList>
  );

  expect(screen.getByText('chip1')).toBeTruthy();
  expect(screen.getByText('chip2')).toBeTruthy();
});

it('renders error and trims children if length is greater than four', () => {
  const mock = jest.spyOn(console, 'warn');

  render(
    <FilterChipList id="max-length-test-list" label={'Test'}>
      <FilterChip id="max-length-test-chip-1" label="chip1" checked={true} onChange={noop} />
      <FilterChip id="max-length-test-chip-2" label="chip2" checked={false} onChange={noop} />
      <FilterChip id="max-length-test-chip-3" label="chip3" checked={false} onChange={noop} />
      <FilterChip id="max-length-test-chip-4" label="chip4" checked={false} onChange={noop} />
      <FilterChip id="max-length-test-chip-5" label="Should Not Render" checked={false} onChange={noop} />
    </FilterChipList>
  );

  expect(mock).toHaveBeenCalledWith(maxChipsError);
  expect(screen.queryByText('Should Not Render')).not.toBeTruthy();
});
