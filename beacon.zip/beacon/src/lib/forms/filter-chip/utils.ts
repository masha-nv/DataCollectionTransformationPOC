import { ReactNode, Children } from 'react';

export const maxChipsError = 'FilterChipList Usage Error: Too many chips passed to list. Max length is four';

export const calcLength = (children?: ReactNode) => {
  let arrayedChildren = Children.toArray(children);

  if (arrayedChildren && arrayedChildren.length > 4) {
    console.warn(maxChipsError);
    arrayedChildren = arrayedChildren.slice(0, 4);
  }

  return arrayedChildren;
};
