import { render, waitFor } from '@testing-library/react';
import { FilterChip } from './filter-chip';
import userEvent from '@testing-library/user-event';
import { noop } from '../../utils';

jest.mock('../analytics/matomo', () => {
  const module = jest.requireActual('../analytics/matomo');
  return {
    ...module,
    track: jest.fn(),
  };
});

describe('FilterChip', () => {
  it('renders icon on checked', () => {
    const base = render(<FilterChip checked={true} id={'icon-test'} onChange={noop} label="test" />);

    const label = base.getByText('test');

    //text does not count as a child of the label
    expect(label.children).toHaveLength(2);
  });

  it('accepts disabled prop', () => {
    const mock = jest.fn();
    const base = render(<FilterChip checked={false} id={'disabled-test'} onChange={mock} label="Test" disabled />);
    const chip = base.getByText('Test');

    userEvent.click(chip);

    expect(mock).not.toHaveBeenCalled();
  });

  it('runs onChange handler', () => {
    const mock = jest.fn();
    const base = render(<FilterChip checked={false} id={'on-change-test'} onChange={mock} label="Test" />);
    const chip = base.getByText('Test');

    userEvent.click(chip);

    expect(mock).toHaveBeenCalled();
  });

  it('runs onChange handler on key down event', () => {
    const mock = jest.fn();
    const base = render(<FilterChip checked={false} id={'on-change-test'} onChange={mock} label="Test" />);
    const chip = base.getByLabelText('Test');

    chip.focus();

    userEvent.keyboard('{enter}');

    expect(mock).toHaveBeenCalled();
  });

  it('does not run onChange handler on non enter-key down events', () => {
    const mock = jest.fn();
    const base = render(<FilterChip checked={false} id={'on-change-test'} onChange={mock} label="Test" />);
    const chip = base.getByLabelText('Test');

    chip.focus();

    userEvent.keyboard('a');

    expect(mock).not.toHaveBeenCalled();
  });

  it('can be focused and blurred', async () => {
    const mock = jest.fn();
    const base = render(<FilterChip checked={false} id={'on-change-test'} onChange={mock} label="Test" />);
    const chip = base.getByLabelText('Test');
    const labelWrapper = chip.parentElement;

    chip.focus();
    await waitFor(() => expect(labelWrapper.className.includes('focused')).toBeTruthy());
    chip.blur();
    await waitFor(() => expect(labelWrapper.className.includes('focused')).toBeFalsy());
  });

  it('does not run onChange handler on key down event if key is not enter', () => {
    const mock = jest.fn();
    const base = render(<FilterChip checked={false} id={'on-change-test'} onChange={mock} label="Test" />);
    const chip = base.getByText('Test').parentElement;

    chip.focus();

    userEvent.keyboard('{shift}');

    expect(mock).not.toHaveBeenCalled();
  });
});
