/**
 * Compares two dates in string format. It returns:
 * 1. Greater than 0 if dateStringA > dateStringB
 * 2. Less than 0 if dateStringA < dateStringB
 * 3. returns 0 if dateStringA = dateStringB
 */

const compareDateString = (dateStringA: string | null | undefined, dateStringB: string | null | undefined): number => {
  if (!dateStringB) {
    return 1;
  }

  if (!dateStringA) {
    return -1;
  }

  const timeA = new Date(dateStringA).getTime();
  const timeB = new Date(dateStringB).getTime();

  if (isNaN(timeB)) {
    return 1;
  }

  if (isNaN(timeA)) {
    return -1;
  }

  return timeA - timeB;
};

export const dateUtils = {
  compareDateString,
};
