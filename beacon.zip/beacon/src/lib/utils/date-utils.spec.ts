import { dateUtils } from './date-utils';

describe('Date Utils', () => {
  describe('compareDateString', () => {
    const { compareDateString } = dateUtils;
    it('is greater than 0 when first date is larger ', () => {
      expect(compareDateString('1/1/2020', '12/1/2010')).toBeGreaterThan(0);
    });
    it('is less than 0 when first date is smaller ', () => {
      expect(compareDateString('12/1/2010', '1/1/2020')).toBeLessThan(0);
    });

    it('is greater than 0 when second date is undefined ', () => {
      expect(compareDateString('1/1/2020', undefined)).toBeGreaterThan(0);
    });
    it('is less than 0 when first date is undefined', () => {
      expect(compareDateString(undefined, '1/1/2020')).toBeLessThan(0);
    });

    it('is greater than 0 when second date is invalid', () => {
      expect(compareDateString('1/1/2020', 'NOT_A_DATE')).toBeGreaterThan(0);
    });

    it('is less than 0 when first date is invalid ', () => {
      expect(compareDateString('NOT_A_DATE', '1/1/2020')).toBeLessThan(0);
    });

    it('is greater than 0 when both dates are invalid', () => {
      expect(compareDateString('NOT_A_DATE', 'NOT_A_DATE')).toBeGreaterThan(0);
    });
  });
});
