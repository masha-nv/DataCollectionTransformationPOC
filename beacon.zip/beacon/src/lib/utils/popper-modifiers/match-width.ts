import { Modifier, Options } from '@popperjs/core';

type MatchWidthModifier = Modifier<'matchWidth', Options>;

/**
 * Popper modifier that sets the width of the popper to the width of the reference element
 */
export const matchWidth: MatchWidthModifier = {
  name: 'matchWidth',
  enabled: true,
  fn: ({ state }) => {
    state.styles.popper.width = `${state.rects.reference.width}px`;
  },
  phase: 'beforeWrite',
  requires: ['computeStyles'],
};
