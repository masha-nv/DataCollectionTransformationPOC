import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { track } from '../../analytics/matomo';
import { TrackableEvent } from '../../analytics';
import { Action } from './action';
import { noop } from '../../utils';

jest.mock('../analytics/matomo', () => {
  const module = jest.requireActual('../analytics/matomo');
  return {
    ...module,
    track: jest.fn(),
  };
});

describe('Action Component', () => {
  it('renders default Action', () => {
    const { baseElement } = render(
      <Action id="action" onClick={noop}>
        action
      </Action>
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('tracks event when clicked', () => {
    render(
      <Action id="action" onClick={noop}>
        action
      </Action>
    );
    const actionElement = screen.getByText('action');
    fireEvent.click(actionElement);
    expect(track).toHaveBeenCalledWith({
      grouping: 'Ungrouped',
      action: 'Clicked',
      trackingKey: 'ActionMenuAction-action',
    } as TrackableEvent);
  });
});
