import React, { forwardRef } from 'react';
import { WithId } from '../../with-id';

export const ActionSeparator = forwardRef<HTMLDivElement, WithId>((props, ref) => {
  return <div id={props.id} className="dropdown-divider" ref={ref} />;
});
