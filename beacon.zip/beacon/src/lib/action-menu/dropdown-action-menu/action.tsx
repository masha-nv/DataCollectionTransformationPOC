import React, { forwardRef, ReactNode, SyntheticEvent } from 'react';
import { WithId } from '../../with-id';
import { Trackable, getTrackableClickHandler } from '../../analytics';

export interface IActionProps extends Trackable, WithId {
  /**
   * The display text for the Action button
   */
  children: ReactNode;
  /**
   * The click event handler
   */
  onClick: (param: SyntheticEvent) => void;
  /**
   * Disables action from being used
   */
  disabled?: boolean;
}

export const Action = forwardRef<HTMLButtonElement, IActionProps>((props, ref) => {
  const buttonOnClick = (event: SyntheticEvent): void => {
    props.onClick(event);
  };

  const trackingDefaults = {
    grouping: 'Ungrouped',
    action: 'Clicked',
    trackingKey: `ActionMenuAction-${props.id}`,
  };

  return (
    <button
      id={props.id}
      onClick={getTrackableClickHandler(props.tracking, trackingDefaults, buttonOnClick)}
      className="dropdown-item"
      ref={ref}
      disabled={props.disabled}
    >
      {props.children}
    </button>
  );
});

Action.displayName = 'Action';
