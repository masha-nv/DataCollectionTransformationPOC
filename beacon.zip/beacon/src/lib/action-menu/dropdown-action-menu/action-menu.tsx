import { forwardRef, ReactNode, useState, CSSProperties } from 'react';
import { WithId } from '../../with-id';
import { Trackable, defaultTracking } from '../../analytics';
import { Button } from '../../button/button';
import { Icon, IconType } from '../../icon/icon';
import './action-menu.scss';
import classNames from 'classnames';
import ReactDOM from 'react-dom';
import { usePopper } from 'react-popper';
import { Direction } from '../../modals/modal-types';
import { cloneActionItems, setActionButtonHandlers, setActionElementHandlers } from './action-menu-utils';
import { ActionMenuContext } from './action-menu-context';
import { SubMenuRef } from './action-sub-menu';

const getMenuLabel = (label: string, isActive: boolean, id: string, iconLabelType?: IconType) => {
  if (iconLabelType) {
    return <Icon type={iconLabelType} />;
  }
  return (
    <>
      {label}
      <span className="ml-1">
        <Icon type={isActive ? IconType.caretUp : IconType.caretDown} />
      </span>
    </>
  );
};

export enum ActionMenuSize {
  small = 'small',
  medium = 'medium',
  large = 'large',
}

export interface IActionMenuProps extends Trackable, WithId {
  /**
   * The Action items for the menu
   */
  children: ReactNode;
  /**
   * The display text for the Menu Button
   */
  label: string;
  /**
   * The type of styling for the menu
   */
  type?: ActionMenuType;
  /**
   * The size of the menu
   */
  size?: ActionMenuSize;
  /**
   * IconType to use as the ActionMenu label
   */
  iconLabelType?: IconType;
  /**
   * Toogle to shift the action menu left
   */
  isShiftedLeft?: boolean;
  /**
   * Tooltip text for the ActionMenu button
   */
  menuButtonTitle?: string;
  /**
   * Disables action menu from being used
   */
  disabled?: boolean;
}

export enum ActionMenuType {
  primary = 'primary',
  secondary = 'secondary',
  // menu Ellipsis used with DataViews .data-list-view
  menuEllipsis = 'menu-ellipsis',
}

export const ActionMenu = forwardRef<HTMLDivElement, IActionMenuProps>(
  ({ type = ActionMenuType.primary, ...props }, ref) => {
    const actionElementList: HTMLElement[] = [];
    const [isActive, setIsActive] = useState(false);
    const [referenceElement, setReferenceElement] = useState<HTMLButtonElement | null>(null);
    const [popperElement, setPopperElement] = useState<HTMLDivElement | null>(null);

    const isShiftedLeftInternal = props.isShiftedLeft ? true : false;
    const placement = isShiftedLeftInternal ? Direction.bottomEnd : Direction.bottomStart;

    const { styles, attributes, update } = usePopper(referenceElement, popperElement, {
      placement,
    });

    const popperStyles: CSSProperties = {
      ...styles.popper,
      zIndex: 9999,
    };

    const trackingInfo = defaultTracking(props.tracking, {
      grouping: 'Ungrouped',
      action: 'Clicked',
      trackingKey: `ActionMenu-${props.id}`,
    });

    if (referenceElement) {
      setActionButtonHandlers(referenceElement, actionElementList, isActive, setIsActive, popperElement, update);
    }

    const actionElementCallback = (element: HTMLElement): void => {
      if (element) {
        if ('button' in element) {
          const subMenuElement = element as unknown as SubMenuRef;
          setActionElementHandlers(
            subMenuElement.button,
            actionElementList,
            setIsActive,
            referenceElement,
            popperElement,
            subMenuElement
          );
        } else {
          setActionElementHandlers(element, actionElementList, setIsActive, referenceElement, popperElement);
        }
      }
    };

    const menuClassNames = classNames('beacon dropdown-menu action-menu-node', {
      'action-menu-small': props.size === ActionMenuSize.small,
      'action-menu-medium': props.size === ActionMenuSize.medium,
      'action-menu-large': props.size === ActionMenuSize.large,
      show: isActive,
    });

    const actionMenuNode = (
      <div className="beacon beacon-dropdown-node-container">
        <div
          id={`${props.id}-menu`}
          className={menuClassNames}
          ref={setPopperElement}
          style={popperStyles}
          {...attributes.popper}
        >
          {cloneActionItems(props.children, actionElementCallback)}
        </div>
      </div>
    );

    const wrapperClasses = classNames('dropdown', {
      'menu-ellipsis': type === ActionMenuType.menuEllipsis,
      'dropdown-primary': type === ActionMenuType.primary,
      'dropdown-secondary': type === ActionMenuType.secondary,
    });

    return (
      <ActionMenuContext.Provider value={{ setIsActive, actionMenuButton: referenceElement }}>
        <div className={wrapperClasses} ref={ref}>
          <Button
            id={props.id}
            onClick={async () => {
              setIsActive(!isActive);
              update && (await update());
            }}
            ref={setReferenceElement}
            tracking={trackingInfo}
            title={props.menuButtonTitle ?? (isActive ? 'Hide Menu' : 'Show Menu')}
            disabled={props.disabled}
            behavior={'button'}
            showInReadOnlyView={true}
            disableInReadOnlyView={false}
          >
            {getMenuLabel(props.label, isActive, props.id, props.iconLabelType)}
          </Button>

          {ReactDOM.createPortal(actionMenuNode, document.body)}
        </div>
      </ActionMenuContext.Provider>
    );
  }
);

ActionMenu.displayName = 'ActionMenu';
