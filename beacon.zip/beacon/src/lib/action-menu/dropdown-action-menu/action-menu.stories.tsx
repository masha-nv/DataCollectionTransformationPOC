import React, { useState } from 'react';
import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { ActionMenu, ActionMenuSize, ActionMenuType } from './action-menu';
import { Action } from './action';
import { ActionSeparator } from './action-separator';
import { noop } from '../../utils';
import { Button, ButtonType } from '../../button/button';
import { ActionSubMenu } from './action-sub-menu';
import { IconType } from '../../icon/constants';
import { Icon } from '../../icon/icon';

export default {
  component: ActionMenu,
  subcomponents: { Action, ActionSeparator },
  title: 'Core Components/Action Menus',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
  },
} as Meta;

const whenToUse = (
  <p>
    Use dropdown action menus to enable users to select an action where space is limited -- for example, in a table row.
  </p>
);

/**
 * Action Menu
 */
export const BasicExample: Story = () => {
  const [label, setLabel] = useState('load');
  return (
    <>
      <label>
        Click an action to change the label: <em>{label}</em>
      </label>
      <ActionMenu id="actionmenu-default" label="Actions">
        <Action id="action-open" onClick={() => setLabel('open')}>
          Open
        </Action>
        <Action id="action-save" onClick={() => setLabel('save')}>
          Save
        </Action>
        <ActionSeparator id="action-separator" />
        <Action id="action-quit" onClick={() => setLabel('quit')}>
          Quit
        </Action>
      </ActionMenu>
      <div style={{ marginTop: '10px' }}>
        <Button id="primary-button-sample" type={ButtonType.primary} onClick={noop}>
          Sample 1
        </Button>
      </div>
    </>
  );
};

BasicExample.storyName = 'Primary Action Menu';

BasicExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Basic Action Menu"
      description="Action Menus can be used when a user needs to pick an action from a list. Although they look similar, these are not form elements. The link or action occurs as soon as the user chooses the action from the list."
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const TypeExample: Story = () => {
  return (
    <>
      <ActionMenu id="actionmenu-primary" label="Primary Type" type={ActionMenuType.primary}>
        <Action id="action-primary-open" onClick={noop}>
          Open
        </Action>
        <Action id="action-primary-save" onClick={noop}>
          Save
        </Action>
        <ActionSeparator id="action-primary-separator" />
        <Action id="action-primary-quit" onClick={noop}>
          Quit
        </Action>
      </ActionMenu>
      <span className="m-3">
        <ActionMenu id="actionmenu-secondary" label="Secondary Type" type={ActionMenuType.secondary}>
          <Action id="action-secondary-one" onClick={noop}>
            One
          </Action>
          <Action id="action-secondary-two" onClick={noop}>
            Two
          </Action>
          <ActionSeparator id="action-secondary-separator" />
          <Action id="action-secondary-three" onClick={noop}>
            Four
          </Action>
        </ActionMenu>
      </span>
    </>
  );
};

TypeExample.storyName = 'Secondary Action Menu';

TypeExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Action Menu Type"
      description={
        <>
          <p>
            <strong>Primary:</strong> A primary action menu dropdown is used to denote primary actions available on a
            current screen, for example a table may include these to show actions that are applicable to a record.
          </p>
          <p>
            <strong>Secondary:</strong> A secondary dropdown is used to denote secondary actions that can take place in
            a menu form
          </p>
        </>
      }
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const SeparatorExample: Story = () => {
  return (
    <ActionMenu id="actionmenu-separator" label="Actions">
      <Action id="action-separator-open" onClick={noop}>
        Open
      </Action>
      <Action id="action-separator-save" onClick={noop}>
        Save
      </Action>
      <ActionSeparator id="action-separator-middle" />
      <Action id="action-separator-quit" onClick={noop}>
        Quit
      </Action>
    </ActionMenu>
  );
};

SeparatorExample.storyName = 'Action Menu Item Seperator';

SeparatorExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Action Menu Separator"
      description="Action Menu Separator is used to insert a separator between the Actions in the menu."
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
export const Sizes = () => {
  return (
    <div>
      <div className="mb-2">
        <ActionMenu id="actionmenu-small" label="Small Actions" size={ActionMenuSize.small}>
          <Action id="action-small" onClick={noop}>
            Action
          </Action>
        </ActionMenu>
      </div>
      <div className="mb-2">
        <ActionMenu id="actionmenu-medium" label="Medium Actions" size={ActionMenuSize.medium}>
          <Action id="action-medium" onClick={noop}>
            Action
          </Action>
        </ActionMenu>
      </div>
      <div className="mb-2">
        <ActionMenu id="actionmenu-large" label="Large Actions" size={ActionMenuSize.large}>
          <Action id="action-medium" onClick={noop}>
            Action
          </Action>
        </ActionMenu>
      </div>
    </div>
  );
};

Sizes.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Action Menu Sizes"
      description="Actions menus can be three different sizes: small (default), medium, or large"
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
Sizes.storyName = 'Action Menu Sizes';
export const DisabledExample: Story = () => {
  return (
    <div className="d-flex">
      <span className="mr-3">
        <ActionMenu id="actionmenu-disabled" label="Disabled Actions" disabled>
          <Action id="action-disabled-help" onClick={noop}>
            Shouldn't be able to open the menu
          </Action>
        </ActionMenu>
      </span>
      <ActionMenu id="actionmenu-basic" label="Actions">
        <Action id="action-basic-open" onClick={noop}>
          Open
        </Action>
        <Action id="action-basic-save" onClick={noop} disabled>
          Save
        </Action>
        <ActionSeparator id="action-basic-middle" />
        <Action id="action-basic-quit" onClick={noop}>
          Quit
        </Action>
      </ActionMenu>
    </div>
  );
};

DisabledExample.storyName = 'Disabled Action Menu';

DisabledExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Disable Action Menu"
      description="Action Menu can be disabled from opening. Individual actions can also be disabled from being activated."
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const SubMenuExample: Story = () => {
  return (
    <div className="d-flex">
      <span className="mr-3">
        <ActionMenu id="actionmenu-disabled" label="Disabled Actions">
          <Action id="action-basic-open" onClick={noop}>
            Open
          </Action>
          <ActionSubMenu id="action-basic-sub-menu-disabled" label="Sub Menu disabled" disabled>
            <Action id="action-basic-submenu-open-disabled" onClick={noop}>
              Sub Menu Open
            </Action>
          </ActionSubMenu>
          <ActionSubMenu id="action-basic-sub-menu-disabled-inner" label="Sub Menu">
            <Action id="action-basic-submenu-disabled" onClick={noop} disabled>
              Sub Menu Action Disabled
            </Action>
            <Action id="action-basic-submenu-open-disabled" onClick={noop}>
              Sub Menu Open
            </Action>
            <Action id="action-basic-submenu-save-disabled" onClick={noop}>
              Sub Menu Save
            </Action>
          </ActionSubMenu>
        </ActionMenu>
      </span>
      <ActionMenu id="actionmenu-main" label="Actions">
        <Action id="action-basic-open" onClick={noop}>
          Open
        </Action>
        <Action id="action-basic-save" onClick={noop}>
          Save
        </Action>
        <ActionSeparator id="action-basic-middle" />
        <ActionSubMenu
          id="action-basic-submenu-prefix"
          labelPrefix={<Icon type={IconType.plusCircle} />}
          label="Sub Menu Icon"
        >
          <Action id="action-basic-submenu-prefix-open" onClick={noop}>
            Sub Menu Open
          </Action>
        </ActionSubMenu>
        <ActionSubMenu id="action-basic-sub-menu" label="Sub Menu">
          <Action id="action-basic-submenu-save" onClick={noop}>
            Sub Menu Save
          </Action>
          <Action id="action-basic-submenu-open" onClick={noop}>
            Sub Menu Open
          </Action>
          <Action id="action-basic-submenu-quit" onClick={noop}>
            Sub Menu Quit
          </Action>
        </ActionSubMenu>
        <Action id="action-basic-quit" onClick={noop}>
          Quit
        </Action>
      </ActionMenu>
    </div>
  );
};

SubMenuExample.storyName = 'Action Sub Menu';

SubMenuExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Action Sub Menu"
      description="Action Menu can also have a sub menu option. The sub menu uses action and action seperator."
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];
