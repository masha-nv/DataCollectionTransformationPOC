import React, { createRef } from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ActionMenu, ActionMenuSize, ActionMenuType } from './action-menu';
import { ActionSeparator } from './action-separator';
import { Action } from './action';
import { noop } from '../../utils';
import { Icon, IconType } from '../../icon/icon';
import { enumKeys } from '../../stories';
import { act } from 'react-dom/test-utils';
import { ActionSubMenu, SubMenuRef } from './action-sub-menu';

const action = (
  <Action id="action-open" onClick={noop}>
    Open
  </Action>
);

const defaultActionMenu = (
  <ActionMenu id="actionmenu-default" label="Actions">
    {action}
  </ActionMenu>
);

describe('Action Menu Component', () => {
  it('renders default ActionMenu', async () => {
    let baseElement;
    await act(async () => {
      baseElement = render(
        <ActionMenu id="actionmenu-default" label="Actions">
          <ActionSeparator id="action-separator" />
        </ActionMenu>
      ).baseElement;
    });
    expect(baseElement).toMatchSnapshot();
  });

  it('renders secondary ActionMenu', async () => {
    let baseElement;
    await act(async () => {
      baseElement = render(
        <ActionMenu id="actionmenu-default" type={ActionMenuType.secondary} label="Actions">
          <ActionSeparator id="action-separator" />
        </ActionMenu>
      ).baseElement;
    });
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with Icon label', async () => {
    let baseElement;
    await act(async () => {
      baseElement = render(
        <ActionMenu
          id="actionmenu-default"
          type={ActionMenuType.secondary}
          label="IconLabel"
          iconLabelType={IconType.ellipsis}
        >
          <ActionSeparator id="action-separator" />
        </ActionMenu>
      ).baseElement;
    });
    expect(baseElement).toMatchSnapshot();
  });

  it('renders plaintext child', async () => {
    const consoleSpy = jest.spyOn(console, 'warn').mockImplementation();
    let baseElement;
    await act(async () => {
      baseElement = render(
        <ActionMenu id="actionmenu-default" label="Actions">
          Dont Render Me
        </ActionMenu>
      ).baseElement;
    });
    expect(baseElement).toMatchSnapshot();
    expect(consoleSpy).toBeCalled();
  });

  it('click ActionMenuButton', async () => {
    const { baseElement } = render(defaultActionMenu);
    const actionElement = screen.getByText('Actions');
    await act(async () => {
      userEvent.click(actionElement);
    });
    expect(document.activeElement).toEqual(actionElement);
    expect(baseElement).toMatchSnapshot();
  });

  it('keypress ArrowUp on ActionMenuButton', async () => {
    const { baseElement } = render(defaultActionMenu);
    const actionElement = screen.getByText('Actions');
    await act(async () => {
      fireEvent.keyDown(actionElement, { key: 'ArrowUp', code: 'ArrowUp' });
    });
    await act(async () => {
      fireEvent.keyDown(actionElement, { key: 'ArrowUp', code: 'ArrowUp' });
    });
    expect(document.activeElement).toEqual(screen.getByText('Open'));
    expect(baseElement).toMatchSnapshot();
  });

  it('keypress arrownDown on ActionMenuButton', async () => {
    const { baseElement } = render(defaultActionMenu);
    const actionElement = screen.getByText('Actions');
    await act(async () => {
      fireEvent.keyDown(actionElement, { key: 'ArrowDown', code: 'ArrowDown' });
    });
    await act(async () => {
      fireEvent.keyDown(actionElement, { key: 'ArrowDown', code: 'ArrowDown' });
    });
    expect(document.activeElement).toEqual(screen.getByText('Open'));
    expect(baseElement).toMatchSnapshot();
  });

  it('keypress arrownRight on ActionMenuButton', async () => {
    const { baseElement } = render(defaultActionMenu);
    const actionElement = screen.getByText('Actions');
    await act(async () => {
      fireEvent.keyDown(actionElement, { key: 'ArrowRight', code: 'ArrowRight' });
    });
    expect(baseElement).toMatchSnapshot();
  });

  it('keypress Tab on ActionButton when Active', async () => {
    render(defaultActionMenu);
    const actionElement = screen.getByText('Actions');
    await act(async () => {
      userEvent.click(actionElement);
    });
    await act(async () => {
      userEvent.tab();
    });

    expect(document.activeElement).toEqual(screen.getByText('Open'));
  });

  it('keypress arrowUp on Action', async () => {
    render(defaultActionMenu);
    const actionElement = screen.getByText('Open');
    actionElement.focus();
    await act(async () => {
      fireEvent.keyDown(actionElement, { key: 'ArrowUp', code: 'ArrowUp' });
    });
    expect(document.activeElement).toEqual(actionElement);
  });

  it('keypress arrowUDown on Action', async () => {
    render(defaultActionMenu);
    const actionElement = screen.getByText('Open');
    actionElement.focus();
    await act(async () => {
      fireEvent.keyDown(actionElement, { key: 'ArrowDown', code: 'ArrowDown' });
    });
    expect(document.activeElement).toEqual(actionElement);
  });

  it('keypress Escape on Action', async () => {
    render(defaultActionMenu);
    const actionElement = screen.getByText('Open');
    actionElement.focus();
    await act(async () => {
      fireEvent.keyDown(actionElement, { key: 'Escape', code: 'Escape' });
    });
    expect(document.activeElement).toEqual(screen.getByText('Actions'));
  });

  it('keypress Tab on Action to close Menu', async () => {
    render(defaultActionMenu);
    const actionElement = screen.getByText('Open');
    actionElement.focus();
    await act(async () => userEvent.tab());
    expect(document.activeElement).toEqual(screen.getByText('Actions'));
  });

  it('keypress Shift Tab on Action to close Menu', async () => {
    render(defaultActionMenu);
    const actionElement = screen.getByText('Open');
    actionElement.focus();
    await act(async () => userEvent.tab({ shift: true }));
    expect(document.activeElement).toEqual(screen.getByText('Actions'));
  });

  it('keypress ArrowRight on Action', async () => {
    render(defaultActionMenu);
    const actionElement = screen.getByText('Open');
    actionElement.focus();
    await act(async () => {
      fireEvent.keyDown(actionElement, { key: 'ArrowRight', code: 'ArrowRight' });
    });
    expect(document.activeElement).toEqual(actionElement);
  });

  it('blur Action on ActionMenu', async () => {
    const { baseElement } = render(defaultActionMenu);
    const actionElement = screen.getByText('Open');
    await act(async () => {
      fireEvent.blur(actionElement);
    });
    expect(baseElement).toMatchSnapshot();
  });

  it('blur Action to ActionButton', async () => {
    const { baseElement } = render(defaultActionMenu);
    const actionElement = screen.getByText('Open');
    const actionButtonElement = screen.getByText('Actions');
    await act(async () => {
      fireEvent.blur(actionElement, { relatedTarget: actionButtonElement });
    });
    expect(baseElement).toMatchSnapshot();
  });

  it('blur ActionButon to ActionButton', async () => {
    const { baseElement } = render(defaultActionMenu);
    const actionElement = screen.getByText('Actions');
    await act(async () => {
      fireEvent.blur(actionElement, { relatedTarget: actionElement });
    });
    expect(baseElement).toMatchSnapshot();
  });

  it('blur ActionButon on ActionMenu', async () => {
    const { baseElement } = render(defaultActionMenu);
    const actionElement = screen.getByText('Actions');
    await act(async () => {
      fireEvent.blur(actionElement);
    });
    expect(baseElement).toMatchSnapshot();
  });

  it('render menu shifted left', async () => {
    const { baseElement } = render(
      <ActionMenu id="actionmenu-default" label="Actions" isShiftedLeft={true}>
        {action}
      </ActionMenu>
    );
    await act(async () => userEvent.click(screen.getByText('Actions')));
    expect(baseElement).toMatchSnapshot();
  });

  it('disables action button from being able to open menu', async () => {
    const { baseElement } = render(
      <ActionMenu id="actionmenu-default" label="Actions" disabled>
        {action}
      </ActionMenu>
    );
    await act(async () => userEvent.click(screen.getByText('Actions')));
    expect(baseElement).toMatchSnapshot();
  });

  it('disables action item from being clicked', async () => {
    const onClick = jest.fn();

    const { baseElement } = render(
      <ActionMenu id="actionmenu-default" label="Actions">
        <Action id="action-open" onClick={onClick} disabled>
          Open
        </Action>
      </ActionMenu>
    );
    await act(async () => {
      userEvent.click(screen.getByText('Actions'));
      userEvent.click(screen.getByText('Open'));
    });

    expect(baseElement).toMatchSnapshot();
    expect(onClick).not.toHaveBeenCalled();
  });

  it('does not remove child refs', async () => {
    const onClick = jest.fn();
    const ref = createRef<HTMLButtonElement>();
    await act(async () => {
      render(
        <ActionMenu id="actionmenu-default" label="Actions">
          <Action id="action-open" onClick={onClick} ref={ref}>
            Open
          </Action>
        </ActionMenu>
      );
    });
    expect(ref.current).not.toBe(null);
  });

  it('close menu handlers applied when actions are passed in as children param', async () => {
    const onClick = jest.fn();

    const children = (
      <Action id="action-open" onClick={onClick}>
        Open
      </Action>
    );
    render(<ActionMenu id="actionmenu-default" label="Actions" children={children} />);

    await act(async () => {
      userEvent.click(screen.getByText('Actions'));
      userEvent.click(screen.getByText('Open'));
    });

    await waitFor(() => {
      expect(onClick).toHaveBeenCalled();
      expect('Show Menu' === screen.queryByText('Actions').title);
    });
  });

  describe('Sub Menu', () => {
    const defaultActionMenuWithSubMenu = (
      <ActionMenu id="actionmenu-default" label="Actions">
        <ActionSubMenu id="action-basic-sub-menu" label="Sub Menu">
          <Action id="action-open" onClick={noop}>
            Open
          </Action>
          <Action id="action-save" onClick={noop}>
            Save
          </Action>
        </ActionSubMenu>
      </ActionMenu>
    );

    const openSubMenu = async (actionElement: HTMLElement) => {
      userEvent.click(screen.getByText('Actions'));
      userEvent.click(actionElement);
    };

    it('click Action SubMenu Button', async () => {
      const { baseElement } = render(defaultActionMenuWithSubMenu);
      const actionElement = screen.getByText('Sub Menu');
      await act(async () => {
        openSubMenu(actionElement);
      });
      expect(document.activeElement).toEqual(actionElement);
      expect(baseElement).toMatchSnapshot();
    });

    it('Action SubMenu renders with label prefix', async () => {
      const { baseElement } = render(
        <ActionMenu id="actionmenu-default" label="Actions">
          <ActionSubMenu id="action-basic-sub-menu" label="Sub Menu" labelPrefix={<Icon type={IconType.plusCircle} />}>
            <Action id="action-open" onClick={noop}>
              Open
            </Action>
          </ActionSubMenu>
        </ActionMenu>
      );
      await screen.findByText('Sub Menu');
      expect(baseElement).toMatchSnapshot();
    });

    it('pressing enter on Action SubMenu Button keeps focus on button', async () => {
      render(defaultActionMenuWithSubMenu);
      const actionElement = screen.getByText('Sub Menu');
      await act(async () => {
        userEvent.click(screen.getByText('Actions'));
        actionElement.focus();
        userEvent.keyboard('{enter}');
      });
      expect(document.activeElement).toEqual(actionElement);
    });

    it('clicking on sub menu option should return focus to actions menu button', async () => {
      render(defaultActionMenuWithSubMenu);
      const actionElement = screen.getByText('Sub Menu');
      await act(async () => {
        openSubMenu(actionElement);
        userEvent.click(screen.getByText('Open'));
      });
      expect(document.activeElement).toEqual(screen.getByText('Actions'));
    });

    it('hover Action SubMenu Button opens sub menu', async () => {
      render(defaultActionMenuWithSubMenu);
      const actionElement = screen.getByText('Sub Menu');
      await act(async () => {
        userEvent.click(screen.getByText('Actions'));
        userEvent.hover(actionElement, 1);
      });
      expect(screen.getByTestId('submenu').getAttribute('class')).toContain('block');
      await act(async () => {
        userEvent.unhover(actionElement, 1);
      });
      await waitFor(() => {
        expect(screen.getByTestId('submenu').getAttribute('class')).toContain('hidden');
      });
    });

    it('hover Action in submenu keeps sub menu open', async () => {
      render(defaultActionMenuWithSubMenu);
      const actionElement = screen.getByText('Sub Menu');
      await act(async () => {
        userEvent.click(screen.getByText('Actions'));
        userEvent.hover(actionElement, 1);
        userEvent.hover(screen.getByText('Open'), 1);
      });
      expect(screen.getByTestId('submenu').getAttribute('class')).toContain('block');
      await act(async () => {
        userEvent.unhover(screen.getByText('Open'), 1);
      });
      await waitFor(() => {
        expect(screen.getByTestId('submenu').getAttribute('class')).toContain('hidden');
      });
    });

    it('keypress ArrowRight on Sub Menu button opens sub menu', async () => {
      const { baseElement } = render(defaultActionMenuWithSubMenu);
      const actionElement = screen.getByText('Sub Menu');
      await act(async () => {
        openSubMenu(actionElement);
        fireEvent.keyDown(actionElement, { key: 'ArrowRight', code: 'ArrowRight' });
      });
      expect(screen.getByTestId('submenu').getAttribute('class')).toContain('block');
      expect(baseElement).toMatchSnapshot();
    });

    it('keypress ArrowDown and ArrowUp on Sub Menu button', async () => {
      const { baseElement } = render(defaultActionMenuWithSubMenu);
      const actionElement = screen.getByText('Sub Menu');
      await act(async () => {
        openSubMenu(actionElement);
        fireEvent.keyDown(actionElement, { key: 'ArrowRight', code: 'ArrowRight' });
      });
      expect(document.activeElement).toEqual(screen.getByText('Open'));
      await act(async () => {
        fireEvent.keyDown(screen.getByText('Open'), { key: 'ArrowDown', code: 'ArrowDown' });
      });
      expect(document.activeElement).toEqual(screen.getByText('Save'));
      await act(async () => {
        fireEvent.keyDown(screen.getByText('Save'), { key: 'ArrowUp', code: 'ArrowUp' });
      });
      expect(document.activeElement).toEqual(screen.getByText('Open'));
      expect(baseElement).toMatchSnapshot();
    });

    it('keypress Tab on ActionButton when Active', async () => {
      render(defaultActionMenuWithSubMenu);
      const actionElement = screen.getByText('Sub Menu');
      await act(async () => {
        openSubMenu(actionElement);
        fireEvent.keyDown(actionElement, { key: 'ArrowRight', code: 'ArrowRight' });
      });
      expect(document.activeElement).toEqual(screen.getByText('Open'));
      await act(async () => {
        userEvent.tab();
      });
      expect(document.activeElement).toEqual(screen.getByText('Save'));
    });

    it('keypress ArrowLeft in Sub Menu button closes sub menu', async () => {
      const { baseElement } = render(defaultActionMenuWithSubMenu);
      const actionElement = screen.getByText('Sub Menu');
      await act(async () => {
        openSubMenu(actionElement);
        fireEvent.keyDown(actionElement, { key: 'ArrowRight', code: 'ArrowRight' });
      });
      expect(document.activeElement).toEqual(screen.getByText('Open'));
      await act(async () => {
        fireEvent.keyDown(screen.getByText('Open'), { key: 'ArrowLeft', code: 'ArrowLeft' });
      });
      expect(document.activeElement).toEqual(actionElement);
      expect(baseElement).toMatchSnapshot();
    });

    it('keypress Escape in sub menu closes entire menu', async () => {
      const { baseElement } = render(defaultActionMenuWithSubMenu);
      const actionElement = screen.getByText('Sub Menu');
      await act(async () => {
        openSubMenu(actionElement);
        fireEvent.keyDown(actionElement, { key: 'ArrowRight', code: 'ArrowRight' });
      });
      expect(document.activeElement).toEqual(screen.getByText('Open'));
      await act(async () => {
        fireEvent.keyDown(screen.getByText('Open'), { key: 'Escape', code: 'Escape' });
      });
      expect(document.activeElement).toEqual(screen.getByText('Actions'));
      expect(baseElement).toMatchSnapshot();
    });

    it('keypress Tab on Action to close sub menu', async () => {
      const { baseElement } = render(defaultActionMenuWithSubMenu);
      const actionElement = screen.getByText('Sub Menu');
      await act(async () => {
        openSubMenu(actionElement);
        fireEvent.keyDown(actionElement, { key: 'ArrowRight', code: 'ArrowRight' });
      });
      expect(document.activeElement).toEqual(screen.getByText('Open'));
      await act(async () => userEvent.tab());
      await act(async () => userEvent.tab());
      expect(document.activeElement).toEqual(actionElement);
      expect(baseElement).toMatchSnapshot();
    });

    it('keypress Shift Tab on Action to close sub menu', async () => {
      const { baseElement } = render(defaultActionMenuWithSubMenu);
      const actionElement = screen.getByText('Sub Menu');
      await act(async () => {
        openSubMenu(actionElement);
        fireEvent.keyDown(actionElement, { key: 'ArrowRight', code: 'ArrowRight' });
      });
      expect(document.activeElement).toEqual(screen.getByText('Open'));
      await act(async () => userEvent.tab({ shift: true }));
      expect(document.activeElement).toEqual(actionElement);
      expect(baseElement).toMatchSnapshot();
    });

    it('does not remove child refs', async () => {
      const onClick = jest.fn();
      const ref = createRef<SubMenuRef>();
      await act(async () => {
        render(
          <ActionMenu id="actionmenu-default" label="Actions">
            <ActionSubMenu id="action-open" ref={ref} label={'Sub Menu'}>
              <Action id="action-open" onClick={onClick}>
                Open
              </Action>
            </ActionSubMenu>
          </ActionMenu>
        );
      });
      expect(ref.current).not.toBe(null);
    });

    it('disables sub menu button from being able to open menu', async () => {
      const { baseElement } = render(
        <ActionMenu id="actionmenu-default" label="Actions">
          <ActionSubMenu id="action-basic-sub-menu" label="Sub Menu" disabled>
            <Action id="action-basic-submenu-open" onClick={noop}>
              Sub Menu Open
            </Action>
          </ActionSubMenu>
        </ActionMenu>
      );
      await act(async () => {
        userEvent.click(screen.getByText('Actions'));
        userEvent.click(screen.getByText('Sub Menu'));
      });

      expect(baseElement).toMatchSnapshot();
    });

    it('disables action item from being clicked', async () => {
      const onClick = jest.fn();

      const { baseElement } = render(
        <ActionMenu id="actionmenu-default" label="Actions">
          <Action id="action-open" onClick={onClick}>
            Open
          </Action>
          <ActionSubMenu id="action-basic-sub-menu-disabled" label="Sub Menu">
            <Action id="action-basic-submenu-open-disabled" onClick={onClick} disabled>
              Sub Menu Open
            </Action>
          </ActionSubMenu>
        </ActionMenu>
      );
      await act(async () => {
        userEvent.click(screen.getByText('Actions'));
        userEvent.click(screen.getByText('Sub Menu'));
        userEvent.click(screen.getByText('Sub Menu Open'));
      });

      expect(baseElement).toMatchSnapshot();
      expect(onClick).not.toHaveBeenCalled();
    });

    describe('Menu Direction', () => {
      const mockClientRect = ({ left = 0, right = 0 }) => {
        return {
          top: 0,
          bottom: 0,
          left,
          right,
          width: right - left,
          height: 0,
          x: left,
          y: 0,
          toJSON: () => '',
        };
      };
      beforeEach(() => {
        Object.defineProperty(window, 'innerWidth', {
          writable: true,
          configurable: true,
          value: 1024,
        });
      });

      it('render sub menu shifted left', async () => {
        const { baseElement } = render(
          <ActionMenu id="actionmenu-default" label="Actions">
            <ActionSubMenu id="action-basic-sub-menu" label="Sub Menu" isShiftedLeft={true}>
              <Action id="action-basic-submenu-open" onClick={noop}>
                Sub Menu Open
              </Action>
            </ActionSubMenu>
          </ActionMenu>
        );
        await act(async () => {
          userEvent.click(screen.getByText('Actions'));
          userEvent.click(screen.getByText('Sub Menu'));
        });

        expect(screen.getByTestId('submenu').getAttribute('class')).toContain('left');
        expect(baseElement).toMatchSnapshot();
      });

      it('render sub menu should shift to right if shifted left but screen size is too small', async () => {
        render(
          <ActionMenu id="actionmenu-default" label="Actions">
            <ActionSubMenu id="action-basic-sub-menu" label="Sub Menu" isShiftedLeft={true}>
              <Action id="action-basic-submenu-open" onClick={noop}>
                Sub Menu Open
              </Action>
            </ActionSubMenu>
          </ActionMenu>
        );

        const submenu = screen.getByTestId('submenu');
        if (submenu) {
          submenu.getBoundingClientRect = () => mockClientRect({ left: -100, right: 200 });
        }

        await act(async () => {
          userEvent.click(screen.getByText('Actions'));
          userEvent.click(screen.getByText('Sub Menu'));
        });

        await waitFor(async () => {
          expect(screen.getByTestId('submenu').getAttribute('class')).toContain('right');
        });
      });

      it('render sub menu should shift to left if screen size is too small', async () => {
        render(
          <ActionMenu id="actionmenu-default" label="Actions">
            <ActionSubMenu id="action-basic-sub-menu" label="Sub Menu">
              <Action id="action-basic-submenu-open" onClick={noop}>
                Sub Menu Open
              </Action>
            </ActionSubMenu>
          </ActionMenu>
        );

        const submenu = screen.getByTestId('submenu');
        if (submenu) {
          submenu.getBoundingClientRect = () => mockClientRect({ left: 900, right: 1100 });
        }
        await act(async () => {
          userEvent.click(screen.getByText('Actions'));
          userEvent.click(screen.getByText('Sub Menu'));
        });

        await waitFor(async () => {
          expect(screen.getByTestId('submenu').getAttribute('class')).toContain('left');
        });
      });
    });
  });

  enumKeys(ActionMenuSize).forEach((size) => {
    it(`renders ${size} size`, async () => {
      let baseElement;
      await act(async () => {
        baseElement = render(
          <ActionMenu id="actionmenu-default" label="Actions" size={ActionMenuSize[size]}>
            <Action id="action-open" onClick={noop}>
              Action
            </Action>
          </ActionMenu>
        ).baseElement;
      });
      expect(baseElement).toMatchSnapshot();
    });
  });
});
