import { State } from '@popperjs/core';
import React, { ReactNode, ReactElement, RefAttributes, MutableRefObject, RefCallback } from 'react';
import { mergeRefs } from 'use-callback-ref';
import { ActionSeparator } from './action-separator';
import { SubMenuRef } from './action-sub-menu';

const focusArrayElement = (elementArray: HTMLElement[], index: number): void => {
  if (elementArray.length && typeof elementArray[index] !== 'undefined') {
    elementArray[index].focus();
  }
};

const focusSiblingAction = (elementArray: HTMLElement[], index: number, isNextSibling: boolean): void => {
  let newIndex = index;
  const step = isNextSibling ? 1 : -1;
  newIndex += step;

  while (newIndex >= 0 && newIndex < elementArray.length) {
    if (
      typeof elementArray[newIndex] !== 'undefined' &&
      elementArray[newIndex] instanceof HTMLButtonElement &&
      !(elementArray[newIndex] as HTMLButtonElement)?.disabled
    ) {
      elementArray[newIndex].focus();
      return;
    }
    newIndex += step;
  }
};

const setKeyDownAction = (
  event: KeyboardEvent,
  element: HTMLElement,
  elementList: HTMLElement[],
  setActive: React.Dispatch<React.SetStateAction<boolean>>,
  setParentActive: React.Dispatch<React.SetStateAction<boolean>>,
  buttonElement: HTMLElement | null,
  parentButtonElement: HTMLElement | null
) => {
  const index = elementList.indexOf(document.activeElement as HTMLElement);
  if (event.key === 'ArrowDown') {
    event.preventDefault();
    focusSiblingAction(elementList, index, true);
  } else if (event.key === 'ArrowUp') {
    event.preventDefault();
    focusSiblingAction(elementList, index, false);
  } else if (event.key === 'Escape') {
    setParentActive(false);
    parentButtonElement?.focus();
  } else if (
    (event.shiftKey && event.key === 'Tab' && elementList[0] === element) ||
    (!event.shiftKey && event.key === 'Tab' && elementList[elementList.length - 1] === element)
  ) {
    event.preventDefault();
    setActive(false);
    buttonElement?.focus();
  }
};

const setOnBlurAction = (
  element: HTMLElement,
  setActive: React.Dispatch<React.SetStateAction<boolean>>,
  menuElement: HTMLElement | null
) => {
  element.onblur = (event: FocusEvent) => {
    if (!menuElement?.contains(event.relatedTarget as Node) && element !== event.relatedTarget) {
      setActive(false);
    }
  };
};

export const setActionSubMenuElementHandlers = (
  element: HTMLElement,
  elementList: HTMLElement[],
  setActive: React.Dispatch<React.SetStateAction<boolean>>,
  setParentActive: React.Dispatch<React.SetStateAction<boolean>>,
  buttonElement: HTMLElement | null,
  menuElement: HTMLElement | null,
  parentButtonElement: HTMLElement | null
) => {
  element.onkeydown = (event: KeyboardEvent) => {
    setKeyDownAction(event, element, elementList, setActive, setParentActive, buttonElement, parentButtonElement);
    if (event.key === 'ArrowLeft') {
      setActive(false);
      buttonElement?.focus();
    }
  };
  element.onclick = (event: MouseEvent) => {
    setParentActive(false);
    parentButtonElement?.focus();
  };
  setOnBlurAction(element, setActive, menuElement);

  if (!elementList.includes(element)) {
    elementList.push(element);
  }
};

export const setActionElementHandlers = (
  element: HTMLElement | null,
  elementList: HTMLElement[],
  setActive: React.Dispatch<React.SetStateAction<boolean>>,
  buttonElement: HTMLElement | null,
  menuElement: HTMLElement | null,
  subMenuElement?: SubMenuRef
) => {
  if (element) {
    element.onkeydown = (event: KeyboardEvent) => {
      setKeyDownAction(event, element, elementList, setActive, setActive, buttonElement, buttonElement);
      if (subMenuElement && event.key === 'Enter') {
        event.preventDefault();
      } else if (subMenuElement && event.key === 'ArrowRight') {
        subMenuElement.setOpen(true);
        if (subMenuElement.menu) {
          const elementArray = Array.from(subMenuElement.menu?.children) as HTMLElement[];
          focusSiblingAction(elementArray, -1, true);
        }
      }
    };

    if (!subMenuElement) {
      element.onclick = (event: MouseEvent) => {
        setActive(false);
        buttonElement?.focus();
      };
    }
    setOnBlurAction(element, setActive, menuElement);

    if (!elementList.includes(element)) {
      elementList.push(element);
    }
  }
};

export const setActionButtonHandlers = (
  element: HTMLElement,
  elementList: HTMLElement[],
  isActive: boolean,
  setActive: React.Dispatch<React.SetStateAction<boolean>>,
  menuElement: HTMLElement | null,
  update: (() => Promise<Partial<State>>) | null
) => {
  element.onkeydown = async (event: KeyboardEvent) => {
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault();
      if (isActive) {
        focusArrayElement(elementList, 0);
      } else {
        setActive(true);
      }
      update && (await update());
    } else if (event.key === 'Tab' && !event.shiftKey && isActive) {
      event.preventDefault();
      focusArrayElement(elementList, 0);
    }
  };
  setOnBlurAction(element, setActive, menuElement);
  return element;
};

export const cloneActionItems = (children: ReactNode, childrenCallback: (element: HTMLElement) => void) => {
  if (React.isValidElement(children) && children.type === React.Fragment) {
    children = (children as ReactElement).props.children;
  }
  return React.Children.map(children, (child) => {
    if (React.isValidElement(child)) {
      const childRef = (child as RefAttributes<HTMLElement>).ref;
      let ref: MutableRefObject<HTMLElement | null> | RefCallback<HTMLElement> | null = null;
      if (child.type !== ActionSeparator) {
        if (childRef) {
          ref = mergeRefs([childRef, childrenCallback as RefCallback<HTMLElement>]);
        } else {
          ref = childrenCallback as RefCallback<HTMLElement>;
        }
      }
      return React.cloneElement(child, {
        ref,
      });
    } else {
      console.warn('Do not use ActionMenu on plain text, use Action or ActionSeparator');
      return null;
    }
  });
};
