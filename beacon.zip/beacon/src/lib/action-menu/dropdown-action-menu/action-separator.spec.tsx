import React from 'react';
import { render } from '@testing-library/react';
import { ActionSeparator } from './action-separator';

describe('Action Separator Component', () => {
  it('renders default Action Separator', () => {
    const { baseElement } = render(<ActionSeparator id="action-separator" />);
    expect(baseElement).toMatchSnapshot();
  });
});
