import { render } from '@testing-library/react';
import { useActionMenu } from './action-menu-context';

describe('useActionMenu', () => {
  it('throws error if used outside of ActionMenuContext.Provider', () => {
    const TestComponent = () => {
      useActionMenu();
      return <div />;
    };
    const spy = jest.spyOn(console, 'error').mockImplementation(() => {
      return '';
    });
    expect(() => render(<TestComponent />)).toThrow('useActionMenu must be used within an ActionMenuContext.Provider');
    spy.mockRestore();
  });
});
