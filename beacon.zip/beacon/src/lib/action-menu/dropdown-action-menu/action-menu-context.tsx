import { createContext, useContext } from 'react';

type ActionMenuContextType = {
  actionMenuButton: HTMLButtonElement | null;
  setIsActive: React.Dispatch<React.SetStateAction<boolean>>;
};

export const ActionMenuContext = createContext<ActionMenuContextType | null>(null);

export const useActionMenu = () => {
  const context = useContext(ActionMenuContext);
  if (!context) {
    throw new Error('useActionMenu must be used within an ActionMenuContext.Provider');
  }
  return context;
};
