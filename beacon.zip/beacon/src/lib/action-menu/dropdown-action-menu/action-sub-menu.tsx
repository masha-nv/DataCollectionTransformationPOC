import { forwardRef, ReactNode, useEffect, useImperativeHandle, useState } from 'react';
import { getTrackableClickHandler, Trackable } from '../../analytics';
import { WithId } from '../../with-id';
import { noop } from '../../utils';
import { IconType } from '../../icon/constants';
import { Icon } from '../../icon/icon';
import { cloneActionItems, setActionSubMenuElementHandlers } from './action-menu-utils';
import { useActionMenu } from './action-menu-context';

export interface IActionSubMenuProps extends Trackable, WithId {
  /**
   * The Action items for the sub menu
   */
  children: ReactNode;
  /**
   * Optional ReactNode to come before the label
   */
  labelPrefix?: ReactNode;
  /**
   * The display text for the Sub Menu Button
   */
  label: string;
  /**
   * Toogle to shift the action menu left
   */
  isShiftedLeft?: boolean;
  /**
   * Disables action submenu from being used
   */
  disabled?: boolean;
}

export interface SubMenuRef {
  button: HTMLElement | null;
  menu: HTMLElement | null;
  setOpen: React.Dispatch<React.SetStateAction<boolean>>;
}

const adjustMenuDirection = (
  menuElement: HTMLDivElement,
  setActualDropdownDirection: React.Dispatch<React.SetStateAction<string>>,
  isShiftedLeft: boolean | undefined
) => {
  const rect = menuElement.getBoundingClientRect();
  const overflowRight = rect.right > window.innerWidth;
  const overflowLeft = rect.left < 0;
  if (!isShiftedLeft && overflowRight) {
    setActualDropdownDirection('left');
  } else if (isShiftedLeft && overflowLeft) {
    setActualDropdownDirection('right');
  } else {
    setActualDropdownDirection(isShiftedLeft ? 'left' : 'right');
  }
};

export const ActionSubMenu = forwardRef<SubMenuRef, IActionSubMenuProps>((props, ref) => {
  const [open, setOpen] = useState(false);
  const actionElementList: HTMLElement[] = [];
  const [referenceElement, setReferenceElement] = useState<HTMLButtonElement | null>(null);
  const [popperElement, setPopperElement] = useState<HTMLDivElement | null>(null);
  const { setIsActive, actionMenuButton } = useActionMenu();
  const [actionDropdownDirection, setActualDropdownDirection] = useState(props.isShiftedLeft ? 'left' : 'right');

  const trackingDefaults = {
    grouping: 'Ungrouped',
    action: 'Clicked',
    trackingKey: `ActionSubMenuAction-${props.id}`,
  };

  useEffect(() => {
    if (popperElement) {
      adjustMenuDirection(popperElement, setActualDropdownDirection, props.isShiftedLeft);
    }
  }, [popperElement, props.children, props.isShiftedLeft, open]);

  useImperativeHandle(ref, () => ({
    button: referenceElement,
    menu: popperElement,
    setOpen: setOpen,
  }));

  const actionElementCallback = (element: HTMLElement): void => {
    if (element) {
      setActionSubMenuElementHandlers(
        element,
        actionElementList,
        setOpen,
        setIsActive,
        referenceElement,
        popperElement,
        actionMenuButton
      );
    }
  };

  return (
    <div className="dropdown-submenu-node">
      <button
        id={`${props.id}-submenu`}
        aria-haspopup="menu"
        aria-expanded={open}
        onMouseEnter={() => setOpen(true)}
        onMouseLeave={() => setOpen(false)}
        onClick={getTrackableClickHandler(props.tracking, trackingDefaults, noop)}
        className="dropdown-item dropdown-submenu-btn"
        ref={setReferenceElement}
        disabled={props.disabled}
      >
        {props.labelPrefix ? (
          <span>
            {props.labelPrefix}&nbsp;{props.label}
          </span>
        ) : (
          props.label
        )}{' '}
        <Icon type={IconType.caretRight} />
      </button>
      <div
        ref={setPopperElement}
        data-testid="submenu"
        aria-label={props.label}
        className={`dropdown-menu dropdown-submenu ${actionDropdownDirection} ${open ? 'block' : 'hidden'}`}
        onMouseEnter={() => setOpen(true)}
        onMouseLeave={() => setOpen(false)}
      >
        {cloneActionItems(props.children, actionElementCallback)}
      </div>
    </div>
  );
});
