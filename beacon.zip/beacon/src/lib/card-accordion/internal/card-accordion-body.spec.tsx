import React from 'react';
import { render } from '@testing-library/react';
import { CardAccordionBody } from './card-accordion-body';

describe('CardAccordionBody', () => {
  it('renders card-accordion-body successfully', () => {
    const { baseElement } = render(
      <CardAccordionBody>
        <p>Test</p>
      </CardAccordionBody>
    );
    expect(baseElement).toMatchSnapshot();
  });
});
