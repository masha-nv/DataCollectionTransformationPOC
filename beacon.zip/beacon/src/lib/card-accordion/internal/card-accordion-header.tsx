import React, { ReactElement, SyntheticEvent } from 'react';
import { defaultTracking, Trackable, trackableEvent } from '../../analytics';
import { WithId } from '../../with-id';

export interface ICardAccordionHeaderProps extends Trackable, WithId {
  /**
   * A string or `ReactElement` that is either an `AccordionCustomHeader` or both `AccordionLeftHeader`
   * and `AccordionRightHeader`. These help render a customizable header for all accordions.
   */
  header: ReactElement | string;
  /**
   * (optional) Default state for disable/enabled when the component loads
   */
  disabled?: boolean;
  /**
   * Whether or not the pinnel panel for title is collapsed or not
   */
  collapsed?: boolean;
  /**
   * (optional) function to be executed when the panel title is clicked
   */
  onToggled?: (param: SyntheticEvent) => void;
}

// eslint-disable-next-line @typescript-eslint/no-empty-function
const defaultOnToggled = () => {};

export const CardAccordionHeader = ({
  id,
  header,
  disabled,
  collapsed,
  onToggled = defaultOnToggled,
  tracking,
}: ICardAccordionHeaderProps) => {
  const buttonCollapsedStyle = collapsed ? 'collapsed' : '';
  const togglePanelIcon = (trackableClick: SyntheticEvent) => {
    onToggled(trackableClick);
  };
  enum TrackingActionType {
    expanded = 'Expanded',
    collapsed = 'Collapsed',
  }
  const trackingInfo = defaultTracking(tracking, {
    grouping: 'Ungrouped',
    trackingKey: 'CardAccordion-' + id,
  });
  trackingInfo.action = collapsed ? TrackingActionType.expanded : TrackingActionType.collapsed;
  const trackableClick = trackableEvent(trackingInfo, togglePanelIcon);

  let titleClass = 'card-accordion-title flex-grow-1';
  let tabIndex = 0;
  if (disabled) {
    titleClass += ' card-accordion-disabled';
    tabIndex = -1;
  }
  let headerElement = <div className={titleClass}>{header}</div>;
  if (typeof header === 'string') {
    headerElement = (
      <div className={titleClass} tabIndex={tabIndex}>
        <span className="flex-grow-1 p-2">{header}</span>
      </div>
    );
  }

  return (
    <div
      id={`${id}-header`}
      className={`text-left flex-grow-1 card-accordion-header ${buttonCollapsedStyle} ${
        disabled ? 'card-accordion-disabled' : ''
      }`}
    >
      <div className="summary d-flex">
        {headerElement}
        <button
          id={`${id}-button`}
          disabled={disabled}
          onClick={trackableClick}
          className="card-accordion-button"
          tabIndex={tabIndex}
        >
          {collapsed ? (
            <i className="toggle-icon fas fa-angle-down">
              <span className="sr-only">Expand</span>
            </i>
          ) : (
            <i className="toggle-icon fas fa-angle-up">
              <span className="sr-only">Collapse</span>
            </i>
          )}
        </button>
      </div>
    </div>
  );
};
