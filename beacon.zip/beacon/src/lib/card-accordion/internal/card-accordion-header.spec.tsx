import React from 'react';
import { render } from '@testing-library/react';
import { CardAccordionHeader } from './card-accordion-header';
import { track } from '../../analytics/matomo';
import { TrackableEvent } from '../../analytics';

jest.mock('../analytics/matomo', () => {
  const module = jest.requireActual('../analytics/matomo');
  return {
    ...module,
    track: jest.fn(),
  };
});

describe('CardAccordionHeader', () => {
  const clickAction = jest.fn();
  it('renders successfully as collapsed', () => {
    const { baseElement } = render(<CardAccordionHeader id="title1" header="TEST" collapsed />);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders successfully as expanded', () => {
    const { baseElement } = render(<CardAccordionHeader id="title1" header="TEST" />);
    expect(baseElement).toMatchSnapshot();
  });

  it('clicking button calls the buttonClickAction', () => {
    const { baseElement } = render(<CardAccordionHeader id="title1" header="TEST" onToggled={clickAction} />);

    baseElement.querySelector<HTMLElement>('.card-accordion-button').click();

    expect(clickAction).toHaveBeenCalled();
  });

  it('logs analytics information when expanded', () => {
    const { baseElement } = render(<CardAccordionHeader id="title1" header="TEST" collapsed />);

    baseElement.querySelector<HTMLElement>('.card-accordion-button').click();

    expect(track).toHaveBeenCalledWith({
      grouping: 'Ungrouped',
      action: 'Expanded',
      trackingKey: 'CardAccordion-title1',
    } as TrackableEvent);
  });

  it('logs analytics information when collapsed', () => {
    const { baseElement } = render(<CardAccordionHeader id="title1" header="TEST" />);

    baseElement.querySelector<HTMLElement>('.card-accordion-button').click();

    expect(track).toHaveBeenCalledWith({
      grouping: 'Ungrouped',
      action: 'Collapsed',
      trackingKey: 'CardAccordion-title1',
    } as TrackableEvent);
  });

  it('allows overriding analytics grouping', () => {
    const { baseElement } = render(
      <CardAccordionHeader id="title1" header="TEST" tracking={{ grouping: 'jest test' }} collapsed />
    );

    baseElement.querySelector<HTMLElement>('.card-accordion-button').click();

    expect(track).toHaveBeenCalledWith({
      grouping: 'jest test',
      action: 'Expanded',
      trackingKey: 'CardAccordion-title1',
    } as TrackableEvent);
  });

  it('allows overriding analytics tracking key', () => {
    const { baseElement } = render(
      <CardAccordionHeader id="title1" header="TEST" tracking={{ trackingKey: 'jest test' }} collapsed />
    );

    baseElement.querySelector<HTMLElement>('.card-accordion-button').click();

    expect(track).toHaveBeenCalledWith({
      grouping: 'Ungrouped',
      action: 'Expanded',
      trackingKey: 'jest test',
    } as TrackableEvent);
  });

  it('does not allow overriding analytics action', () => {
    const { baseElement } = render(
      <CardAccordionHeader id="title1" header="TEST" tracking={{ action: 'jest test' }} collapsed />
    );

    baseElement.querySelector<HTMLElement>('.card-accordion-button').click();

    expect(track).toHaveBeenCalledWith({
      grouping: 'Ungrouped',
      action: 'Expanded',
      trackingKey: 'CardAccordion-title1',
    } as TrackableEvent);
  });

  it('renders with disabled true successfully', () => {
    const { baseElement } = render(<CardAccordionHeader id="title1" header="TEST" collapsed disabled />);
    expect(baseElement.querySelector('button')?.hasAttribute('disabled')).toBeTruthy();
  });
});
