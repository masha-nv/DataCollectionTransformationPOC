import React, { ReactNode } from 'react';

export interface ICardAccordionBodyProps {
  /**
   * The actual contents of this particular pinned panel
   */
  children: ReactNode;
}

export const CardAccordionBody = ({ children }: ICardAccordionBodyProps) => {
  return (
    <div tabIndex={0} className="accordion-tab card-accordion-body">
      {children}
    </div>
  );
};
