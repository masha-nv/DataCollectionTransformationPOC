import React from 'react';
import { render } from '@testing-library/react';
import { CardAccordionGroup } from './card-accordion-group';
import { CardAccordion } from './card-accordion';

describe('Card Accordion Group Component', () => {
  it('renders successfully', () => {
    const { baseElement } = render(
      <CardAccordionGroup id="card-accordion-group">
        <CardAccordion id="panel1" header="hello">
          Hello world
        </CardAccordion>
      </CardAccordionGroup>
    );

    expect(baseElement).toMatchSnapshot();
  });

  describe('errors', () => {
    let originalError: typeof console.error;
    beforeEach(() => {
      originalError = console.error;
      console.error = jest.fn();
    });

    it('does not allow non CardAccordion child components', () => {
      const renderAction = () => {
        render(
          <CardAccordionGroup id="card-accordion-group-with-errors">
            <div>Second</div>
          </CardAccordionGroup>
        );
      };

      expect(renderAction).toThrowError('CardAccordionGroup component only allows children of type CardAccordion');
    });

    afterEach(() => {
      console.error = originalError;
    });
  });
});
