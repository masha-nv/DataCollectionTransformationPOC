import React from 'react';
import { render, fireEvent, screen, within } from '@testing-library/react';
import { DisabledCardAccordion, CardAccordionPrimary, ControlledCardAccordion } from './card-accordion.stories';
import { track } from '../analytics/matomo';
import { TrackableEvent } from '../analytics';
import { CardAccordion } from './card-accordion';
import userEvent from '@testing-library/user-event';

jest.mock('../analytics/matomo', () => {
  const module = jest.requireActual('../analytics/matomo');
  return {
    ...module,
    track: jest.fn(),
  };
});

describe('Card Accordion Component', () => {
  it('renders successfully', () => {
    const { baseElement } = render(<CardAccordionPrimary />);

    expect(baseElement).toMatchSnapshot();
  });

  it('renders can expand an accordion', () => {
    const { baseElement } = render(<CardAccordionPrimary />);

    const element = baseElement.querySelector<HTMLElement>('#accordion-0');
    element.click();

    expectAccordionIsExpanded(baseElement, 'accordion-0');
    expect(baseElement).toMatchSnapshot();
  });

  it('can be expanded by default', () => {
    const { baseElement } = render(
      <CardAccordion id="accordion-0" header="test" defaultExpanded>
        <p>Test</p>
      </CardAccordion>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders disabled accordion successfully', () => {
    const { baseElement } = render(<DisabledCardAccordion />);

    baseElement.querySelector<HTMLElement>('#disabled-card-accordion-header').click();

    expectAccordionIsCollapsed(baseElement, 'disabled-card-accordion-header');
    expect(baseElement).toMatchSnapshot();
  });

  it('syncs with expanded prop changes (controlled scenario) while still allowing user toggles', () => {
    const { baseElement } = render(<ControlledCardAccordion />);
    const accordionHeaders = Array.from(baseElement.querySelectorAll('.card-accordion-header')) as HTMLElement[];

    // initially collapsed (expanded=false)
    accordionHeaders.forEach((ah) => {
      expect(ah.className.includes('collapsed')).toBe(true);
    });

    // parent intent: expand
    const expandBtn = screen.getByRole('button', { name: /Expand All/i });
    userEvent.click(expandBtn);
    accordionHeaders.forEach((ah) => {
      expect(ah.className.includes('collapsed')).toBe(false);
    });

    // parent intent: collapse
    const collapseBtn = screen.getByRole('button', { name: /Collapse All/i });
    userEvent.click(collapseBtn);
    accordionHeaders.forEach((ah) => {
      expect(ah.className.includes('collapsed')).toBe(true);
    });

    // user can still toggle locally by clicking an individual accordion header button
    const secondAccordionBtn = within(accordionHeaders[1]).getByRole('button');
    userEvent.click(secondAccordionBtn);
    accordionHeaders.forEach((ah, i) => {
      if (i === 1) {
        // second accordion
        expect(ah.className.includes('collapsed')).toBe(false);
      } else {
        expect(ah.className.includes('collapsed')).toBe(true);
      }
    });
  });

  const expectAccordionIsExpanded = (baseElement: Element, accordionId: string) => {
    expect(baseElement.querySelector(`#${accordionId}`).className.includes('collapsed')).toBeFalsy();
  };

  const expectAccordionIsCollapsed = (baseElement: Element, accordionId: string) => {
    console.log('[expectAccordionIsCollapsed]', accordionId);
    expect(baseElement.querySelector(`#${accordionId}`).className.includes('collapsed')).toBeTruthy();
  };

  const fireToggleAndExpectTrackedEventToBe = (detailsElement: Element, expectedTrackedAction: string) => {
    fireEvent(detailsElement, new Event('toggle'));
    expect(track).toHaveBeenLastCalledWith({
      grouping: 'Ungrouped',
      action: expectedTrackedAction,
      trackingKey: 'CardAccordion-accordion-0',
    } as TrackableEvent);
  };
});
