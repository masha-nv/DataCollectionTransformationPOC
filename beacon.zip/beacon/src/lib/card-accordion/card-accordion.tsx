import React, { ReactElement, ReactNode, useEffect, useState } from 'react';
import { Trackable } from '../analytics';
import { WithId } from '../with-id';
import { CardAccordionBody } from './internal/card-accordion-body';
import { CardAccordionHeader } from './internal/card-accordion-header';
import './card-accordion.scss';

export interface ICardAccordionProps extends Trackable, WithId {
  /**
   * A string or `ReactElement` that is either an `AccordionCustomHeader` or both `AccordionLeftHeader`
   * and `AccordionRightHeader`. These help render a customizable header for all accordions.
   */
  header: ReactElement | string;
  /**
   * (optional) Default state for disable/enabled when the component loads
   */
  disabled?: boolean;
  /**
   * (optional) Whether or not this pinned panel is expanded by default
   */
  defaultExpanded?: boolean;
  /**
   * (optional) Used to use control the expand/collapse state
   */
  expanded?: boolean;
  /**
   * Child elements
   */
  children: ReactNode;
}

export const CardAccordion = ({
  id,
  header,
  disabled,
  defaultExpanded = false,
  expanded,
  children,
  tracking,
}: ICardAccordionProps) => {
  const [collapsed, setCollapsed] = useState(!defaultExpanded);

  // Sync internal state when parent issues a new intent for collapse/expand
  useEffect(() => {
    if (expanded === undefined) return;
    setCollapsed(!expanded);
  }, [expanded]);

  const togglePanel = () => {
    setCollapsed((c) => !c);
  };

  return (
    <div id={id} className={`accordion-tab card-accordion-container ${disabled ? 'card-accordion-disabled' : ''}`}>
      <CardAccordionHeader
        tracking={tracking}
        id={id}
        header={header}
        disabled={disabled}
        onToggled={togglePanel}
        collapsed={collapsed}
      />
      {!collapsed && !disabled && <CardAccordionBody children={children}></CardAccordionBody>}
    </div>
  );
};
