import { Badge, BadgeVariant } from '../notifications/badge/badge';
import { Icon } from '../icon/icon';
import { Story, Meta } from '@storybook/react';
import React, { useState } from 'react';
import { Documentation, StoryBadge } from '../stories';
import { CardAccordion } from './card-accordion';
import { CardAccordionGroup } from './card-accordion-group';
import { AccordionCustomHeader, AccordionLeftHeader, AccordionRightHeader } from '../accordion/accordion';
import { IconType, IconVariant } from '../icon/constants';
import { a11yConfig } from '../stories/story.config';
import { ButtonGroup } from '../button/button-group';
import { Button, ButtonType } from '../button/button';

export default {
  component: CardAccordion,
  title: 'Core Components/Accordions/Card Accordion',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
  },
} as Meta;

const description = (
  <>
    Accordions are components that expand or collapse to reveal or hide additional content. Accordions are commonly used
    to reduce the need to scroll when presenting multiple sections of content on a single page.
  </>
);

const whenToUse = (
  <>
    <p>
      Accordions are useful for progressive disclosure: when accordions are collapsed, users can scan the headings to
      get a sense of all the content available. Collapsed accordions take up less vertical space on the screen, but can
      reveal more detail with a click.
    </p>
    <ul>
      <li>
        <strong className="beacon-icon-danger">Don't</strong> over-use accordions. There are times when simply listing
        the content is sufficient instead of putting it in an accordion
      </li>
      <li>
        <strong className="beacon-icon-danger">Don't</strong> use nested accordions (accordions within accordions).
      </li>
    </ul>
  </>
);

const accessibilityConsiderations = (
  <>
    <p>Accordions should be keyboard accessible or able to be controlled with the keyboard.</p>
    <p>Exposed content should be focusable.</p>
  </>
);

export const CardAccordionPrimary: Story = () => {
  const queries = [
    {
      fullName: 'SAMPLES, JAMES',
      dob: '01/11/1933',
      queryDate: '02/26/2020',
      queryExpired: false,
      hasFlags: true,
      counts: {
        pending: 3,
        total: 3,
      },
      records: 5,
    },
    {
      fullName: 'MCSAMPLES, JAMES',
      dob: '01/11/1933',
      queryDate: '12/30/2019',
      queryExpired: true,
      hasFlags: false,
      counts: {
        pending: 0,
        total: 0,
      },
      records: 0,
    },
    {
      fullName: 'SAMPLES, JACK',
      dob: '01/11/1933',
      queryDate: '02/26/2020',
      queryExpired: false,
      hasFlags: false,
      counts: {
        pending: 0,
        total: 0,
      },
      records: 0,
    },
  ];

  return (
    <div className="w-50">
      <CardAccordionGroup id="sample-card-accordion">
        {queries.map((query, index) => {
          return (
            <CardAccordion
              id={`accordion-${index}`}
              key={`accordion-${index}`}
              header={
                <>
                  <AccordionLeftHeader>
                    <div className="p-2">
                      <div style={{ width: '20px', float: 'left' }}>
                        {query.hasFlags === true && (
                          <Icon type={IconType.exclamationTriangle} variant={IconVariant.warning}></Icon>
                        )}
                      </div>
                      <div className="d-inline-block font-weight-normal">
                        <div className="header">{query.fullName}</div>
                        <div className="header">{query.dob}</div>
                        <div className="small text-secondary">
                          {query.queryExpired && (
                            <Badge id="expired-badge" variant={BadgeVariant.warning}>
                              Expired
                            </Badge>
                          )}
                          <i>Queried: {query.queryDate}</i>
                        </div>
                      </div>
                    </div>
                  </AccordionLeftHeader>
                  <AccordionRightHeader>
                    <div className="small pt-2">
                      {query.counts && (
                        <span>
                          {query.counts.pending > 0 && (
                            <span>
                              <Badge id="pending-badge" variant={BadgeVariant.warning} showIcon={false}>
                                Pending Disposition
                              </Badge>
                            </span>
                          )}
                          {query.counts.total === 0 && (
                            <span>
                              <Badge id={`no-match-badge-${index}`} variant={BadgeVariant.default} showIcon={false}>
                                No Match
                              </Badge>
                            </span>
                          )}
                        </span>
                      )}
                    </div>
                  </AccordionRightHeader>
                </>
              }
            >
              <p className="small">
                <i>
                  {query.records > 0
                    ? `This query resulted in ${query.records} TECS/NCIC matches.`
                    : 'This query resulted in no TECS/NCIC match.'}
                </i>
              </p>
            </CardAccordion>
          );
        })}
      </CardAccordionGroup>
    </div>
  );
};

CardAccordionPrimary.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Card Accordion"
      description={description}
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
CardAccordionPrimary.storyName = 'Card Accordion';

export const CustomCardAccordion: Story = () => {
  const details = [
    { key: 'Sex', value: 'M' },
    { key: 'DOB', value: '01/11/1933' },
    { key: 'SSN', value: '555-555-5555' },
    { key: 'A-Number', value: 'A987654321' },
    { key: 'COB', value: 'Democratic Republic of Congo' },
  ];

  return (
    <div className="beacon react-beacon">
      <CardAccordion
        id="custom-card-secondary"
        header={
          <AccordionCustomHeader>
            <div className="d-flex justify-content-between">
              {details.map((detail, index) => {
                return (
                  <div className="p-4" key={index}>
                    {detail.key}: <strong>{detail.value}</strong>
                  </div>
                );
              })}
            </div>
          </AccordionCustomHeader>
        }
      >
        Some details...
      </CardAccordion>
    </div>
  );
};
CustomCardAccordion.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Custom Card Accordion"
      description={description}
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const DisabledCardAccordion: Story = () => {
  return (
    <div className="beacon react-beacon">
      <CardAccordion id="disabled-card-accordion" header="This accordion cannot be expanded" disabled>
        There is nothing to see here
      </CardAccordion>
    </div>
  );
};
DisabledCardAccordion.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Disabled Card Accordion"
      description={description}
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const ControlledCardAccordion: Story = () => {
  const queries = [
    {
      fullName: 'SAMPLES, JAMES',
      dob: '01/11/1933',
      queryDate: '02/26/2020',
      queryExpired: false,
      hasFlags: true,
      counts: {
        pending: 3,
        total: 3,
      },
      records: 5,
    },
    {
      fullName: 'MCSAMPLES, JAMES',
      dob: '01/11/1933',
      queryDate: '12/30/2019',
      queryExpired: true,
      hasFlags: false,
      counts: {
        pending: 0,
        total: 0,
      },
      records: 0,
    },
    {
      fullName: 'SAMPLES, JACK',
      dob: '01/11/1933',
      queryDate: '02/26/2020',
      queryExpired: false,
      hasFlags: false,
      counts: {
        pending: 0,
        total: 0,
      },
      records: 0,
    },
  ];

  const [expandAll, setExpandAll] = useState<boolean>(false);

  const handleExpandCollapse = (expandAllRequested: boolean) => {
    setExpandAll(expandAllRequested);
  };

  return (
    <div className="w-50">
      <ButtonGroup>
        <Button id="expand-all-btn" type={ButtonType.tertiary} onClick={() => handleExpandCollapse(true)}>
          Expand All
        </Button>
        <Button id="collapse-all-btn" type={ButtonType.tertiary} onClick={() => handleExpandCollapse(false)}>
          Collapse All
        </Button>
      </ButtonGroup>
      <CardAccordionGroup id="sample-card-accordion">
        {queries.map((query, index) => {
          return (
            <CardAccordion
              id={`accordion-${index}`}
              key={`accordion-${index}`}
              header={
                <>
                  <AccordionLeftHeader>
                    <div className="p-2">
                      <div style={{ width: '20px', float: 'left' }}>
                        {query.hasFlags === true && (
                          <Icon type={IconType.exclamationTriangle} variant={IconVariant.warning}></Icon>
                        )}
                      </div>
                      <div className="d-inline-block font-weight-normal">
                        <div className="header">{query.fullName}</div>
                        <div className="header">{query.dob}</div>
                        <div className="small text-secondary">
                          {query.queryExpired && (
                            <Badge id="expired-badge" variant={BadgeVariant.warning}>
                              Expired
                            </Badge>
                          )}
                          <i>Queried: {query.queryDate}</i>
                        </div>
                      </div>
                    </div>
                  </AccordionLeftHeader>
                  <AccordionRightHeader>
                    <div className="small pt-2">
                      {query.counts && (
                        <span>
                          {query.counts.pending > 0 && (
                            <span>
                              <Badge id="pending-badge" variant={BadgeVariant.warning} showIcon={false}>
                                Pending Disposition
                              </Badge>
                            </span>
                          )}
                          {query.counts.total === 0 && (
                            <span>
                              <Badge id={`no-match-badge-${index}`} variant={BadgeVariant.default} showIcon={false}>
                                No Match
                              </Badge>
                            </span>
                          )}
                        </span>
                      )}
                    </div>
                  </AccordionRightHeader>
                </>
              }
              expanded={expandAll}
            >
              <p className="small">
                <i>
                  {query.records > 0
                    ? `This query resulted in ${query.records} TECS/NCIC matches.`
                    : 'This query resulted in no TECS/NCIC match.'}
                </i>
              </p>
            </CardAccordion>
          );
        })}
      </CardAccordionGroup>
    </div>
  );
};

ControlledCardAccordion.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Card Accordion (Controlled)"
      description={description}
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
