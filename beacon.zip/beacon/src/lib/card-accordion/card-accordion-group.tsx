import React, { ReactElement } from 'react';
import { WithId } from '../with-id';
import { CardAccordion } from './card-accordion';

export interface ICardAccordionGroupProps extends WithId {
  /**
   * The nodes inside this group
   */
  children: ReactElement<typeof CardAccordion> | ReactElement<typeof CardAccordion>[];
}

/**
 * Comment what the new component is for
 */
export const CardAccordionGroup = (props: ICardAccordionGroupProps) => {
  // Restrict children to a specific type
  React.Children.forEach(props.children, (child) => {
    if (child.type !== CardAccordion) {
      throw new Error(
        `${CardAccordionGroup.name} component only allows children of type ${CardAccordion.name}. Not ${child.type}`
      );
    }
  });

  return <div id={props.id}>{props.children}</div>;
};
