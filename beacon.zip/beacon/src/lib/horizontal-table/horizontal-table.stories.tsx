import { Button, ButtonType } from '../button/button';
import { Badge, BadgeVariant } from '../notifications/badge/badge';
import { HorizontalTable } from './horizontal-table';
import { IHorizontalTableField, HighlightColorVariant } from './horizontal-table-types';
import { Meta, Story } from '@storybook/react';
import { Documentation, StoryBadge } from '../stories';
import { a11yConfig } from '../stories/story.config';
import { TextInput } from '../forms/text-input/text-input';
import { IconType, IconVariant } from '../icon/constants';
import { SelectOption } from '../forms/select/select-popper';
import { Select } from '../forms/select/select';

export default {
  component: HorizontalTable,
  title: 'Core Components/Tables/Horizontal Table',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const accessibilityConsiderations = (
  <ul>
    <li>
      The <code>title</code> will serve as a caption for the table and should be unique, if you need additional space,
      then use the <code>summary</code> attribute to provide more context about the information on the table
    </li>
  </ul>
);

interface Person {
  name: string;
  alienNumber: string;
  dateOfBirth?: string;
  address: string;
  gender: string;
  receiptNum: string;
  contacts?: {
    phone?: string;
    email?: string;
  };
}

const DATA: Person[] = [
  {
    name: 'John Wilson',
    alienNumber: 'A0123456789',
    dateOfBirth: '04/15/1973',
    address: '17326 MAIN ST KANSAS CITY, MO 22445 UNITED STATES',
    gender: 'MALE',
    receiptNum: 'IOE0987654321',
  },
  {
    name: 'James Wilson',
    alienNumber: 'A0123456787',
    dateOfBirth: '04/15/1974',
    address: '17326 MAIN ST KANSAS CITY, MO 22445 UNITED STATES',
    gender: 'MALE',
    receiptNum: 'IOE09876543212',
  },
  {
    name: 'Roger Wilson',
    alienNumber: 'A0123456788',
    dateOfBirth: '04/15/1975',
    address: '17326 MAIN ST KANSAS CITY, MO 22445 UNITED STATES',
    gender: 'MALE',
    receiptNum: 'IOE09876543213',
  },
];

const FIELDS: IHorizontalTableField<Person>[] = [
  {
    label: 'USCIS Receipt Number',
    field: 'receiptNum',
    showEdit: false,
    decorator: (records: Person[]) => (
      <Badge variant={BadgeVariant.info} id="test-badge">
        Sample Badge
      </Badge>
    ),
    cellDecorator: (record: Person, index: number) =>
      index === 0
        ? {
            icon: IconType.flag,
            variant: IconVariant.danger,
          }
        : {},
  },
  {
    label: 'Name',
    field: 'name',
    showEdit: false,
    edit: (record: Person, index: number) => (
      <TextInput
        id="test-input-field"
        defaultValue={record && record.name !== undefined ? (record.name as string) : ''}
        onChange={(event) => (record.name = event.target.value)}
      />
    ),
    cellDecorator: (record: Person, index: number) =>
      index === 1
        ? {
            icon: IconType.check,
            variant: IconVariant.success,
          }
        : {},
  },
  {
    label: 'Date of Birth',
    field: 'dateOfBirth',
    showEdit: false,
    cellDecorator: (record: Person, index: number) =>
      index === 2
        ? {
            icon: IconType.star,
            variant: IconVariant.info,
          }
        : {},
  },
  {
    label: 'Address',
    field: 'address',
    showEdit: false,
    highlight: (records: Person[]) => HighlightColorVariant.warning,
    icon: (records: Person[]) => ({
      icon: IconType.exclamationTriangle,
      variant: IconVariant.warning,
    }),
  },
  {
    label: 'Gender',
    field: 'gender',
    showEdit: false,
  },
  {
    label: 'A-Number',
    field: 'alienNumber',
    showEdit: false,
    edit: (record: Person, index: number) => (
      <TextInput
        id="test-input-field"
        defaultValue={record && record.alienNumber !== undefined ? (record.alienNumber as string) : ''}
        onChange={(event) => (record.alienNumber = event.target.value)}
      />
    ),
  },
];

/**
 * Horizontal Table
 */
export const Default: Story = (storyProps) => {
  const saveData = async (updatedData: Promise<Person[]>) => {
    const newData: Person[] = await updatedData;
    if (newData) {
      console.log('Data Saved ' + newData.map((a) => `(${Object.values(a).join(', ')})`).join(', '));
    } else {
      console.log('Error');
    }
  };

  const testClick = () => {
    console.log('clicked');
  };

  return (
    <div>
      <HorizontalTable
        id="horizontal-table"
        title="Sample Horizontal Table Title"
        fields={FIELDS}
        data={DATA}
        pagination={false}
        columnLabel={(record: Person, columnIndex: number) => `Case ${columnIndex + 1} Data`}
        columnActions={(record: Person, columnIndex: number) =>
          columnIndex === 0 && (
            <Button onClick={() => testClick()} id="sample-column-button" type={ButtonType.tertiary}>
              Sample Column Action
            </Button>
          )
        }
        headerActions={
          <Button onClick={() => testClick()} id="sample-header-button" type={ButtonType.tertiary}>
            {' '}
            Sample Header Action
          </Button>
        }
        footerActions={
          <Button onClick={() => testClick()} id="sample-footer-button">
            Sample Footer Action
          </Button>
        }
        enableEditing={true}
        saveData={saveData}
      />
    </div>
  );
};

Default.storyName = 'Horizontal Table';
Default.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Horizontal Tables"
      description="These tables are used to display multiple columns of data side by side.  
      In addition custom highlighting, decoration, cell level form controls, and column and table actions can be added."
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];

/**
 * Horizontal Table  - With Pagination
 */
export const Pagination: Story = (storyProps) => {
  const data: Person[] = [
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      address: '17326 MAIN ST KANSAS CITY, MO 22445 UNITED STATES',
      gender: 'MALE',
      receiptNum: 'IOE0987654321',
    },
    {
      name: 'James Wilson',
      alienNumber: 'A0123456787',
      dateOfBirth: '04/15/1974',
      address: '17326 MAIN ST KANSAS CITY, MO 22445 UNITED STATES',
      gender: 'MALE',
      receiptNum: 'IOE09876543212',
    },
    {
      name: 'Roger Wilson',
      alienNumber: 'A0123456788',
      dateOfBirth: '04/15/1975',
      address: '17326 MAIN ST KANSAS CITY, MO 22445 UNITED STATES',
      gender: 'MALE',
      receiptNum: 'IOE09876543213',
    },
    {
      name: 'Billy Zane',
      alienNumber: 'A0123456543',
      dateOfBirth: '07/15/1985',
      address: '44 ROUTE 66, MO 22445 UNITED STATES',
      gender: 'MALE',
      receiptNum: 'IOE09876543217',
    },
    {
      name: 'Willy Zane',
      alienNumber: 'A1123456543',
      dateOfBirth: '08/15/1985',
      address: '45 ROUTE 66, MO 22445 UNITED STATES',
      gender: 'MALE',
      receiptNum: 'IOE39876543217',
    },
    {
      name: 'Silly Zane',
      alienNumber: 'A2123456543',
      dateOfBirth: '079/15/1985',
      address: '46 ROUTE 66, MO 22445 UNITED STATES',
      gender: 'FEMALE',
      receiptNum: 'IOE19876543217',
    },
    {
      name: 'Silly Zane',
      alienNumber: 'A2123456543',
      dateOfBirth: '079/15/1985',
      address: '46 ROUTE 66, MO 22445 UNITED STATES',
      gender: 'FEMALE',
      receiptNum: 'IOE19876543217',
    },
  ];

  const fields: IHorizontalTableField<Person>[] = [
    {
      label: 'USCIS Receipt Number',
      field: 'receiptNum',
      showEdit: false,
    },
    {
      label: 'Name',
      field: 'name',
      showEdit: false,
    },
    {
      label: 'Date of Birth',
      field: 'dateOfBirth',
      showEdit: false,
    },
    {
      label: 'Address',
      field: 'address',
      showEdit: false,
      highlight: (records: Person[]) => HighlightColorVariant.warning,
      icon: (records: Person[]) => ({
        icon: IconType.exclamationTriangle,
        variant: IconVariant.warning,
      }),
    },
    {
      label: 'Gender',
      field: 'gender',
      showEdit: false,
      icon: (records: Person[]) => ({
        icon: IconType.minus,
      }),
    },
    {
      label: 'A-Number',
      field: 'alienNumber',
      showEdit: false,
    },
  ];

  const saveDataPag = async (updatedData: Promise<Person[]>) => {
    const newDataPag: Person[] = await updatedData;
    if (newDataPag) {
      console.log('Data Saved ' + newDataPag.map((a) => `(${Object.values(a).join(', ')})`).join(', '));
    }
  };

  const testClickPag = () => {
    console.log('clicked');
  };

  return (
    <div>
      <HorizontalTable
        id="horizontal-table"
        title="Sample Horizontal Table Title w/ Pagination"
        fields={fields}
        data={data}
        pagination={true}
        columnLabel={(record: Person, columnIndex: number) => `Case ${columnIndex + 1} Data`}
        columnActions={(record: Person, columnIndex: number) =>
          columnIndex === 0 && (
            <Button onClick={() => testClickPag()} id="sample-column-button" type={ButtonType.tertiary}>
              Sample Column Action
            </Button>
          )
        }
        headerActions={
          <Button onClick={() => testClickPag()} id="sample-header-button-pag" type={ButtonType.tertiary}>
            {' '}
            Sample Header Action
          </Button>
        }
        footerActions={
          <Button onClick={() => testClickPag()} id="sample-footer-button-pag">
            Sample Footer Action
          </Button>
        }
        enableEditing={true}
        saveData={saveDataPag}
      />
    </div>
  );
};

Pagination.storyName = 'Horizontal Table - With Pagination';
Pagination.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Horizontal Tables - With Pagination"
      description="These tables are used to display multiple columns of data side by side.  
      In addition custom highlighting, decoration, cell level form controls, and column and table actions can be added."
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];

export const CustomCell: Story = (storyProps) => {
  const data: Person[] = [
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      address: '17326 MAIN ST KANSAS CITY, MO 22445 UNITED STATES',
      gender: 'MALE',
      receiptNum: 'IOE0987654321',
      contacts: {
        email: 'jwilson@mail.gov',
      },
    },
    {
      name: 'James Wilson',
      alienNumber: 'A0123456787',
      dateOfBirth: '04/15/1974',
      address: '17326 MAIN ST KANSAS CITY, MO 22445 UNITED STATES',
      gender: 'MALE',
      receiptNum: 'IOE09876543212',
      contacts: {
        phone: '1234567890',
      },
    },
    {
      name: 'Roger Wilson',
      alienNumber: 'A0123456788',
      dateOfBirth: '04/15/1975',
      address: '17326 MAIN ST KANSAS CITY, MO 22445 UNITED STATES',
      gender: 'MALE',
      receiptNum: 'IOE09876543213',
    },
  ];

  const fields: IHorizontalTableField<Person>[] = [
    {
      label: 'USCIS Receipt Number',
      field: 'receiptNum',
      showEdit: false,
      cellDecorator: (record: Person, index: number) => onIndexDisplayIcon(index, 0, IconType.flag, IconVariant.danger),
    },
    {
      label: 'Name',
      field: 'name',
      showEdit: false,
      cell: (record: Person) => <strong>{record.name}</strong>,
      edit: (record: Person, index: number) => (
        <TextInput
          id="test-input-field-name"
          defaultValue={record.name}
          onChange={(event) => (record.name = event.target.value)}
        />
      ),
      cellDecorator: (record: Person, index: number) =>
        onIndexDisplayIcon(index, 1, IconType.check, IconVariant.success),
    },
    {
      label: 'Date of Birth',
      field: 'dateOfBirth',
      showEdit: false,
      cellDecorator: (record: Person, index: number) => onIndexDisplayIcon(index, 2, IconType.star, IconVariant.info),
    },
    {
      label: 'Address',
      field: 'address',
      showEdit: false,
    },
    {
      label: 'Gender',
      field: 'gender',
      showEdit: false,
    },
    {
      label: 'A-Number',
      field: 'alienNumber',
      showEdit: false,
      cell: (record: Person) => <a href="/">{record.alienNumber}</a>,
      highlight: (records: Person[]) => HighlightColorVariant.warning,
      icon: (records: Person[]) => ({
        icon: IconType.exclamationTriangle,
        variant: IconVariant.warning,
      }),
      edit: (record: Person, index: number) => (
        <TextInput
          id="test-input-field-alien-number"
          defaultValue={record.alienNumber}
          onChange={(event) => (record.alienNumber = event.target.value)}
        />
      ),
    },
    {
      label: 'Email',
      field: 'contacts',
      showEdit: false,
      cell: (record: Person) => record.contacts?.email || 'N/A',
      edit: (record: Person, index: number) => (
        <TextInput
          id="test-input-field-email"
          defaultValue={record.contacts?.email}
          onChange={(event) => (record.contacts = { email: event.target.value, phone: record.contacts?.phone })}
        />
      ),
    },
  ];
  return (
    <div>
      <HorizontalTable
        id="horizontal-table"
        title="Sample Horizontal Table Title w/ Custom Cell"
        fields={fields}
        data={data}
        pagination={false}
        columnLabel={(record: Person, columnIndex: number) => `Case ${columnIndex + 1} Data`}
        enableEditing={true}
      />
    </div>
  );
};
CustomCell.storyName = 'Horizontal Table - With Custom Cell Content';
CustomCell.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Horizontal Tables - With Custom Cell Content"
      description="These tables are used to display multiple columns of data side by side.  
      In addition custom highlighting, decoration, cell level form controls, and column and table actions can be added."
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];

const onIndexDisplayIcon = (index: number, displayIndex: number, icon: IconType, variant: IconVariant) =>
  index === displayIndex
    ? {
        icon: icon,
        variant: variant,
      }
    : {};

export const Subheader: Story = (storyProps) => {
  const testClickSubheader = () => {
    console.log('clicked');
  };

  return (
    <div>
      <HorizontalTable
        id="horizontal-table"
        title="Sample Horizontal Table Title"
        fields={FIELDS}
        data={DATA}
        pagination={false}
        subHeaderComponent={
          <div className="d-flex justify-content-between align-items-end">
            <Select id="subheader-select" label="Filter Data">
              <SelectOption value={'1'}>Option 1</SelectOption>
              <SelectOption value={'2'}>Option 2</SelectOption>
            </Select>
            <div className="form-inline">
              <Button id={'subheader-button-1'} onClick={testClickSubheader}>
                Button 1
              </Button>
            </div>
          </div>
        }
        headerActions={
          <Button onClick={testClickSubheader} id="sample-header-button" type={ButtonType.tertiary}>
            Sample Header Action
          </Button>
        }
        enableEditing={true}
        saveData={() => null}
      />
    </div>
  );
};

Subheader.storyName = 'Horizontal Table - With Subheader';
Subheader.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Horizontal Tables"
      description="These tables are used to display multiple columns of data side by side.  
          In addition custom highlighting, decoration, cell level form controls, and column and table actions can be added."
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
