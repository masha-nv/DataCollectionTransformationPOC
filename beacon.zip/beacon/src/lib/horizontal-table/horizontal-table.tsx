import { useState, useMemo } from 'react';
import { Heading } from '../heading/heading';
import HorizontalTableBody from './horizontal-table-body';
import { IHorizontalTableProps } from './horizontal-table-types';
import { ButtonGroup } from '../button/button-group';
import { Button, ButtonType } from '../button/button';

const COLUMNS_PER_PAGE = 3;

interface ITableHeaderProps<T> extends IHorizontalTableProps<T> {
  currentPage: number;
}
/**
 * Horizontal Table Header component
 */
const HorizontalTableHeader = <T,>({
  columnLabel,
  columnActions,
  data,
  pagination,
  currentPage,
}: ITableHeaderProps<T>) => {
  const headers = data.map((column: T, columnIndex: number) => {
    return (
      <th className="header" key={columnIndex} scope="col">
        {!pagination && columnLabel && columnLabel(column, columnIndex)}
        {pagination && columnLabel && columnLabel(column, columnIndex + COLUMNS_PER_PAGE * currentPage)}
        <div
          key={`column-actions-div-${columnIndex}`}
          id={`column-actions-div-${columnIndex}`}
          className="horizontal-column-actions mb-1 mb-auto"
        >
          {!pagination && columnActions && columnActions(column, columnIndex)}
          {pagination && columnActions && columnActions(column, columnIndex + COLUMNS_PER_PAGE * currentPage)}
        </div>
      </th>
    );
  });

  return (
    <thead>
      <tr className="header-row">
        <th className="header-field" scope="col">
          Field
        </th>
        {headers}
      </tr>
    </thead>
  );
};

interface PaginationProps {
  setCurrentPage: (currentPage: number) => void;
  currentTablePage: number;
  totalPages: number;
}

/**
 * Pagination Controls component
 */
const PaginationControls = ({ currentTablePage, totalPages, setCurrentPage }: PaginationProps) => (
  <ButtonGroup>
    <Button
      disabled={totalPages === 0 || currentTablePage === 0}
      title="First Page"
      id={`horizontal-pagination-first-page`}
      aria-label="First Page"
      onClick={() => setCurrentPage(0)}
    >
      <i className="fa fa-step-backward pag-controls"></i>
    </Button>
    <Button
      title="Previous Page"
      id={`horizontal-pagination-previous-page`}
      aria-label="Previous Page"
      disabled={totalPages === 0 || currentTablePage === 0}
      onClick={() => setCurrentPage(--currentTablePage)}
    >
      <i className="fa fa-caret-left pag-controls"></i>
    </Button>
    <Button
      disabled={totalPages === 0 || currentTablePage === totalPages}
      title="Next Page"
      id={`horizontal-pagination-next-page`}
      aria-label="Next Page"
      onClick={() => setCurrentPage(++currentTablePage)}
    >
      <i className="fa fa-caret-right pag-controls"></i>
    </Button>
    <Button
      disabled={totalPages === 0 || currentTablePage === totalPages}
      title="Last Page"
      id={`horizontal-pagination-last-page`}
      aria-label="Last Page"
      onClick={() => setCurrentPage(totalPages)}
    >
      <i className="fa fa-step-forward pag-controls"></i>
    </Button>
  </ButtonGroup>
);

interface RangeProps {
  start: number;
  end: number;
  count: number;
}

const RangeLabel = ({ start, end, count }: RangeProps) => {
  return (
    <span title="Page Range" id="range-span">
      {'Viewing '}
      <strong>{`${start} `}</strong>
      {'to '}
      <strong>{`${end} `}</strong>
      <span>{`out of `}</span>
      <strong>{`${count} `}</strong>
      columns
    </span>
  );
};

const calculateIndices = (currentTablePage: number, numOfColumns: number) => {
  const startIndex =
    COLUMNS_PER_PAGE * currentTablePage < numOfColumns - 1 ? COLUMNS_PER_PAGE * currentTablePage : numOfColumns - 1;
  const endIndex = startIndex + COLUMNS_PER_PAGE < numOfColumns ? startIndex + COLUMNS_PER_PAGE : numOfColumns;
  const totalPages = Math.ceil(numOfColumns / COLUMNS_PER_PAGE) - 1;
  return { startIndex, endIndex, totalPages };
};

export const HorizontalTable = <T,>({
  id,
  title,
  data,
  columnLabel,
  pagination,
  footerActions,
  headerActions,
  columnActions,
  fields,
  enableEditing,
  saveData,
  progressPending,
  subHeaderComponent,
}: IHorizontalTableProps<T>) => {
  const [isEditing, setEditing] = useState(false);
  const [currentTablePage, setCurrentTablePage] = useState<number>(0);
  const [startingPageIndex, setStartingPageIndex] = useState<number>(0);
  const [endingPageIndex, setEndingPageIndex] = useState<number>(0);
  const [totalPages, setTotalPages] = useState<number>(0);

  const processedData = useMemo(() => {
    if (!data) {
      return [];
    }

    // Get the data for the selected page
    if (pagination) {
      const indices = calculateIndices(currentTablePage, data.length);
      setStartingPageIndex(indices.startIndex);
      setEndingPageIndex(indices.endIndex);
      setTotalPages(indices.totalPages);
      if (data.length > COLUMNS_PER_PAGE) {
        return data.slice(indices.startIndex, indices.endIndex);
      }
    }
    return data;
  }, [data, pagination, currentTablePage, setStartingPageIndex, setEndingPageIndex, setTotalPages]);

  const saveChanges = () => {
    if (saveData) {
      const promise = new Promise<T[]>(function (resolve, reject) {
        setTimeout(() => {
          resolve(data);
        }, 500);
      });
      saveData(promise);
    }
    setEditing(false);
  };

  return (
    <div className="horizontal-table">
      <div className="d-flex">
        <Heading headingType={'h3'}>{title}</Heading>
        {(headerActions || enableEditing) && (
          <span className="ml-auto custom-checkbox pr-3">
            {headerActions}
            {enableEditing && !pagination && (
              <span className="pl-2">
                <Button
                  id="edit-data-button"
                  disabled={isEditing || processedData.length <= 0}
                  onClick={() => setEditing(true)}
                  type={ButtonType.tertiary}
                  title="Edit"
                >
                  <i className="fas fa-pencil-alt pr-1"></i>Edit
                </Button>
              </span>
            )}
          </span>
        )}
      </div>
      {subHeaderComponent && <div className="pb-2">{subHeaderComponent}</div>}
      {progressPending && (
        <div role="table" className="no-data-wrapper d-flex justify-content-center">
          <div className="loading-message">Loading...</div>
        </div>
      )}
      {!progressPending && (
        <>
          {processedData.length <= 0 && (
            <div role="table" className="no-data-wrapper d-flex justify-content-center">
              <div className="no-data">There are no records to display</div>
            </div>
          )}
          {processedData.length > 0 && pagination && (
            <div className="pagination-main table-quickview-save card">
              <div className="pagination-count">
                <RangeLabel start={startingPageIndex + 1} end={endingPageIndex} count={data.length} />
                <div className="pagination-button">
                  <PaginationControls
                    setCurrentPage={setCurrentTablePage}
                    currentTablePage={currentTablePage}
                    totalPages={totalPages}
                  />
                </div>
              </div>
            </div>
          )}
          {processedData.length > 0 && (
            <table id={id}>
              <HorizontalTableHeader
                title={title}
                id={id}
                fields={fields}
                columnLabel={columnLabel}
                columnActions={columnActions}
                data={processedData}
                pagination={pagination}
                currentPage={currentTablePage}
              />
              <HorizontalTableBody fields={fields} data={processedData} editMode={isEditing} />
            </table>
          )}
          {(footerActions || isEditing) && (
            <div className="table-quickview-save card">
              <ButtonGroup>
                {footerActions}
                {isEditing && (
                  <>
                    <Button
                      title="Cancel"
                      id="horizontal-table-cancel-button"
                      type={ButtonType.secondary}
                      onClick={() => setEditing(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      title="Save Changes"
                      id="horizontal-table-save-changes-button"
                      type={ButtonType.primary}
                      onClick={saveChanges}
                    >
                      Save Changes
                    </Button>
                  </>
                )}
              </ButtonGroup>
            </div>
          )}
        </>
      )}
    </div>
  );
};
