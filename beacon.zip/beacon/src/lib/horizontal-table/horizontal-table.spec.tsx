import { render } from '@testing-library/react';
import { HorizontalTable } from './horizontal-table';
import { CustomCell, Default, Pagination } from './horizontal-table.stories';
import { Button, ButtonType } from '../button/button';
import { IHorizontalTableField, HighlightColorVariant } from './horizontal-table-types';
import { TextInput } from '../forms/text-input/text-input';
import { Badge, BadgeVariant } from '../notifications/badge/badge';
import { screen, fireEvent } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { IconVariant, IconType } from '../icon/constants';

interface Person {
  name: string;
  alienNumber: string;
  dateOfBirth?: string;
  address: string;
  gender: string;
  receiptNum: string;
}

describe('Horizontal Table Component', () => {
  const data: Person[] = [
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      address: '17326 MAIN ST KANSAS CITY, MO 22445 UNITED STATES',
      gender: 'MALE',
      receiptNum: 'IOE0987654321',
    },
    {
      name: 'James Wilson',
      alienNumber: 'A0123456787',
      dateOfBirth: '04/15/1974',
      address: '17326 MAIN ST KANSAS CITY, MO 22445 UNITED STATES',
      gender: 'MALE',
      receiptNum: 'IOE09876543212',
    },
    {
      name: 'Roger Wilson',
      alienNumber: 'A0123456788',
      dateOfBirth: '04/15/1975',
      address: '17326 MAIN ST KANSAS CITY, MO 22445 UNITED STATES',
      gender: 'MALE',
      receiptNum: 'IOE09876543213',
    },
  ];

  const fields: IHorizontalTableField<Person>[] = [
    {
      label: 'USCIS Receipt Number',
      field: 'receiptNum',
      showEdit: false,
      decorator: (records: Person[]) => (
        <Badge variant={BadgeVariant.info} id="test-badge">
          Sample Badge
        </Badge>
      ),
    },
    {
      label: 'Name',
      field: 'name',
      showEdit: true,
      edit: (record: Person, index: number) => (
        <TextInput
          id={`test-name-field-${index}`}
          key={`name-input-${index}`}
          title="name-input"
          defaultValue={record && record.name !== undefined ? (record.name as string) : ''}
          onChange={(event) => (record.name = event.target.value)}
        />
      ),
    },
    {
      label: 'Date of Birth',
      field: 'dateOfBirth',
      showEdit: false,
    },
    {
      label: 'Address',
      field: 'address',
      showEdit: false,
      highlight: (records: Person[]) => HighlightColorVariant.warning,
      icon: (records: Person[]) => ({
        icon: IconType.exclamationTriangle,
        variant: IconVariant.warning,
        description: 'this is a warning icon',
      }),
    },
    {
      label: 'Gender',
      field: 'gender',
      showEdit: false,
    },
    {
      label: 'A-Number',
      field: 'alienNumber',
      showEdit: false,
      edit: (record: Person, index: number) => (
        <TextInput
          id="test-a-number-field"
          defaultValue={record && record.alienNumber !== undefined ? (record.alienNumber as string) : ''}
          onChange={(event) => (record.alienNumber = event.target.value)}
        />
      ),
    },
  ];

  it('renders footer actions correctly', () => {
    const stub = jest.fn();
    const { baseElement } = render(
      <HorizontalTable
        id="horizontal-table-footer"
        title="Default Horizontal Table"
        data={data}
        fields={fields}
        columnLabel={(record: Person, columnIndex: number) => `Case ${columnIndex + 1} Data`}
        enableEditing={false}
        footerActions={
          <Button onClick={() => stub()} id="sample-footer-button">
            Sample Footer Action
          </Button>
        }
      />
    );
    expect(baseElement).toMatchSnapshot();
    const button = screen.findAllByTitle('Sample Footer Action');
    expect(button).not.toBeNull();
    userEvent.click(screen.getByText('Sample Footer Action'));
    expect(stub).toHaveBeenCalled();
  });

  it('renders header actions correctly', () => {
    const stub = jest.fn();
    const { baseElement } = render(
      <HorizontalTable
        id="horizontal-table-header"
        title="Default Horizontal Table"
        data={data}
        fields={fields}
        columnLabel={(record: Person, columnIndex: number) => `Case ${columnIndex + 1} Data`}
        enableEditing={false}
        headerActions={
          <Button onClick={() => stub()} id="sample-header-button">
            Sample Header Action
          </Button>
        }
      />
    );
    expect(baseElement).toMatchSnapshot();
    const button = screen.findAllByTitle('Sample Header Action');
    expect(button).not.toBeNull();
    userEvent.click(screen.getByText('Sample Header Action'));
    expect(stub).toHaveBeenCalled();
  });

  it('renders column actions correctly', () => {
    const { baseElement } = render(
      <HorizontalTable
        id="horizontal-table-header"
        title="Default Horizontal Table"
        data={data}
        fields={fields}
        columnLabel={(record: Person, columnIndex: number) => `Case ${columnIndex + 1} Data`}
        columnActions={(record: Person, columnIndex: number) =>
          columnIndex === 0 && (
            <Button onClick={() => null} id="sample-column-button" type={ButtonType.tertiary}>
              Sample Column Action
            </Button>
          )
        }
      />
    );
    expect(baseElement).toMatchSnapshot();
    const button = screen.getByText('Sample Column Action');
    expect(button).not.toBeNull();
    userEvent.click(button);
  });

  it('renders edit mode correctly main', () => {
    const { baseElement } = render(
      <HorizontalTable
        id="horizontal-table-header"
        title="Default Horizontal Table"
        data={data}
        fields={fields}
        enableEditing={true}
      />
    );
    expect(baseElement).toMatchSnapshot();
    const button = screen.getAllByTitle('Edit');
    expect(button).not.toBeNull();
  });

  it('edit mode and cancel main', () => {
    const { baseElement } = render(
      <HorizontalTable
        id="horizontal-table-header"
        title="Default Horizontal Table"
        data={data}
        fields={fields}
        enableEditing={true}
      />
    );
    expect(baseElement).toMatchSnapshot();
    const button = screen.getByTitle('Edit');
    expect(button).not.toBeNull();
    fireEvent.click(button);
    const cancelButton = screen.getAllByTitle('Cancel');
    expect(cancelButton).not.toBeNull();
    fireEvent.click(cancelButton[0]);
  });

  const saveData = async (updatedData: Promise<Person[]>) => {
    const newData: Person[] = await updatedData;
    if (newData) {
      console.log('Data Saved ' + newData.map((a) => `(${Object.values(a).join(', ')})`).join(', '));
    } else {
      console.log('Error');
    }
  };

  it('edit mode and save data main', () => {
    const { baseElement } = render(
      <HorizontalTable
        id="horizontal-table-header"
        title="Default Horizontal Table"
        data={data}
        fields={fields}
        enableEditing={true}
        saveData={saveData}
      />
    );
    expect(baseElement).toMatchSnapshot();
    const button = screen.getByTitle('Edit');
    expect(button).not.toBeNull();
    fireEvent.click(button);
    const saveButton = screen.getAllByTitle('Save Changes');
    expect(saveButton).not.toBeNull();
    fireEvent.click(saveButton[0]);
  });

  it('edit mode and dont save data main', () => {
    const { baseElement } = render(
      <HorizontalTable
        id="horizontal-table-header"
        title="Default Horizontal Table"
        data={data}
        fields={fields}
        enableEditing={true}
      />
    );
    expect(baseElement).toMatchSnapshot();
    const button = screen.getByTitle('Edit');
    expect(button).not.toBeNull();
    fireEvent.click(button);
    const saveButton = screen.getAllByTitle('Save Changes');
    expect(saveButton).not.toBeNull();
    fireEvent.click(saveButton[0]);
  });

  it('renders field control', () => {
    const { baseElement } = render(
      <HorizontalTable
        id="horizontal-table-header"
        title="Default Horizontal Table"
        data={data}
        fields={fields}
        enableEditing={true}
      />
    );
    expect(baseElement).toMatchSnapshot();
    const inputs = screen.getAllByTitle('name-input');
    expect(inputs[0].id).toEqual('test-name-field-0');
  });

  it('edit field control', () => {
    const stub = jest.fn();

    const { baseElement } = render(
      <HorizontalTable
        id="horizontal-table-header"
        title="Default Horizontal Table"
        data={data}
        fields={fields}
        enableEditing={true}
      />
    );
    expect(baseElement).toMatchSnapshot();
    const inputs = screen.getAllByTitle('name-input');
    inputs[0].onchange = stub();
    fireEvent.change(inputs[0], { target: { value: 'newNam' } });
    expect(stub).toHaveBeenCalled();
    const inputsAfter = screen.getByDisplayValue('newNam');
    expect(inputsAfter).toBeDefined();
  });

  it('pagination - previous page', () => {
    const { baseElement } = render(<Pagination />);
    expect(baseElement).toMatchSnapshot();
    const button = screen.getByTitle('Next Page');
    expect(button).not.toBeNull();
    fireEvent.click(button);
    const range = screen.getByTitle('Page Range');
    expect(range.innerHTML).toEqual(
      'Viewing <strong>4 </strong>to <strong>6 </strong><span>out of </span><strong>7 </strong>columns'
    );
    const buttonAgain = screen.getByTitle('Previous Page');
    expect(buttonAgain).not.toBeNull();
    fireEvent.click(buttonAgain);
    const rangeAgain = screen.getByTitle('Page Range');
    expect(rangeAgain.innerHTML).toEqual(
      'Viewing <strong>1 </strong>to <strong>3 </strong><span>out of </span><strong>7 </strong>columns'
    );
  });

  it('pagination - next page', () => {
    const { baseElement } = render(<Pagination />);
    expect(baseElement).toMatchSnapshot();
    const button = screen.getByTitle('Next Page');
    expect(button).not.toBeNull();
    fireEvent.click(button);
    const range = screen.getByTitle('Page Range');
    expect(range.innerHTML).toEqual(
      'Viewing <strong>4 </strong>to <strong>6 </strong><span>out of </span><strong>7 </strong>columns'
    );
    fireEvent.click(button);
    const rangeAgain = screen.getByTitle('Page Range');
    expect(rangeAgain.innerHTML).toEqual(
      'Viewing <strong>7 </strong>to <strong>7 </strong><span>out of </span><strong>7 </strong>columns'
    );
    fireEvent.click(button);
    const rangeAgainAgain = screen.getByTitle('Page Range');
    expect(rangeAgainAgain.innerHTML).toEqual(
      'Viewing <strong>7 </strong>to <strong>7 </strong><span>out of </span><strong>7 </strong>columns'
    );
  });

  it('pagination - first page', () => {
    const { baseElement } = render(<Pagination />);
    expect(baseElement).toMatchSnapshot();
    userEvent.click(screen.getByRole('button', { name: 'Next Page' }));
    userEvent.click(screen.getByRole('button', { name: 'First Page' }));
    const range = screen.getByTitle('Page Range');
    expect(range.innerHTML).toEqual(
      'Viewing <strong>1 </strong>to <strong>3 </strong><span>out of </span><strong>7 </strong>columns'
    );
  });

  it('pagination - last page', () => {
    const { baseElement } = render(<Pagination />);
    expect(baseElement).toMatchSnapshot();
    const button = screen.getByTitle('Last Page');
    expect(button).not.toBeNull();
    fireEvent.click(button);
    const range = screen.getByTitle('Page Range');
    expect(range.innerHTML).toEqual(
      'Viewing <strong>7 </strong>to <strong>7 </strong><span>out of </span><strong>7 </strong>columns'
    );
  });

  it('renders with pagination', () => {
    const { baseElement } = render(<Pagination />);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with pagination - 3 columns', () => {
    const { baseElement } = render(
      <HorizontalTable
        id="horizontal-table"
        title=""
        data={data}
        fields={fields}
        pagination={true}
        columnLabel={(record: Person, columnIndex: number) => `Case ${columnIndex + 1} Data`}
      />
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with pagination - 2 columns', () => {
    const data2: Person[] = [
      {
        name: 'John Wilson',
        alienNumber: 'A0123456789',
        dateOfBirth: '04/15/1973',
        address: '17326 MAIN ST KANSAS CITY, MO 22445 UNITED STATES',
        gender: 'MALE',
        receiptNum: 'IOE0987654321',
      },
      {
        name: 'James Wilson',
        alienNumber: 'A0123456787',
        dateOfBirth: '04/15/1974',
        address: '17326 MAIN ST KANSAS CITY, MO 22445 UNITED STATES',
        gender: 'MALE',
        receiptNum: 'IOE09876543212',
      },
    ];

    const { baseElement } = render(
      <HorizontalTable
        id="horizontal-table"
        title=""
        data={data2}
        fields={fields}
        pagination={true}
        columnLabel={(record: Person, columnIndex: number) => `Case ${columnIndex + 1} Data`}
      />
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with pagination - 1 column', () => {
    const data1: Person[] = [
      {
        name: 'John Wilson',
        alienNumber: 'A0123456789',
        dateOfBirth: '04/15/1973',
        address: '17326 MAIN ST KANSAS CITY, MO 22445 UNITED STATES',
        gender: 'MALE',
        receiptNum: 'IOE0987654321',
      },
    ];

    const { baseElement } = render(
      <HorizontalTable id="horizontal-table" title="" data={data1} fields={fields} pagination={true} />
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with customized header', () => {
    const { baseElement } = render(
      <HorizontalTable
        id="horizontal-view-default"
        title="Default Horizontal Table"
        data={data}
        fields={fields}
        columnLabel={(record: Person, columnIndex: number) => `Case ${columnIndex + 1} Data`}
      />
    );
    expect(baseElement).toMatchSnapshot();
  });

  test('renders with no customized heading with empty title', () => {
    const { baseElement } = render(
      <HorizontalTable
        id="horizontal-table"
        title=""
        data={data}
        fields={fields}
        columnLabel={(record: Person, columnIndex: number) => `Case ${columnIndex + 1} Data`}
      />
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('renders the default storybook example with no customized render', () => {
    const { baseElement } = render(<Default />);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with custom cells', () => {
    const { baseElement } = render(<CustomCell />);
    expect(baseElement).toMatchSnapshot();
  });

  test('renders with empty data', () => {
    const { baseElement } = render(
      <HorizontalTable id="horizontal-table" title="Empty Data Example" data={[]} fields={fields} />
    );
    expect(baseElement).toMatchSnapshot();
  });

  test('renders with no data', () => {
    const { baseElement } = render(
      <HorizontalTable id="horizontal-table" title="No Data Example" data={undefined} fields={fields} />
    );
    expect(baseElement).toMatchSnapshot();
  });

  test('renders loading state', async () => {
    render(
      <HorizontalTable
        id="horizontal-table"
        title=""
        progressPending
        data={data}
        fields={fields}
        columnLabel={(record: Person, columnIndex: number) => `Case ${columnIndex + 1} Data`}
      />
    );
    expect(await screen.findByText('Loading...')).toBeTruthy();
  });

  test('renders with subheader', async () => {
    render(
      <HorizontalTable
        id="horizontal-table-footer"
        title="Default Horizontal Table"
        data={data}
        fields={fields}
        subHeaderComponent={<h4>Subheader Test</h4>}
      />
    );
    expect(await screen.findByText('Subheader Test')).toBeTruthy();
  });
});
