import { ReactNode } from 'react';
import { WithId } from '../with-id';
import { IconVariant, IconType } from '../icon/constants';

export enum HighlightColorVariant {
  success = '#e9f9e3',
  info = '#e6f1f8',
  warning = '#fff1d2',
  danger = '#ffefef',
}

export interface DecoratorSpecification {
  icon?: IconType;
  variant?: IconVariant;
  description?: string;
}

export interface IHorizontalTableProps<T> extends WithId {
  /*
   * Title of the horizontal table, this is required for accessibility
   */
  title: string;

  /*
   * The data source for the table, each array data item represents the values that will be displayed
   * in a column.
   */
  data: T[];

  /*
   * The various fields to display for each of the data sources.
   */
  fields: IHorizontalTableField<T>[];

  /*
   * Represents the label for the data column
   */
  columnLabel?: (record: T, columnIndex: number) => string;

  /*
   * Action to be performed for the data column
   */
  columnActions?: (record: T, columnIndex: number) => ReactNode;

  /*
   * Whether to enable pagination or not
   */
  pagination?: boolean;

  /*
   * Actions to be added to the table's header
   */
  headerActions?: ReactNode;

  /*
   * Actions to be added to the table's footer
   */
  footerActions?: ReactNode;

  /*
   * Whether to enable editing for this table or not
   */
  enableEditing?: boolean;

  /*
   * A function called whenever data is saved on the table
   */
  saveData?: (updatedData: Promise<T[]>) => void;

  /**
   * Disables the table and displays a plain text Loading Indicator
   */
  progressPending?: boolean;

  /**
   * A component you want to render for the subheader
   */
  subHeaderComponent?: React.ReactNode | React.ReactNode[];
}

export interface IHorizontalTableField<T> {
  /**
   * Label used to describe the table field
   */
  label: string;

  /*
   * A basic field reference to a field you want to display
   */
  field: keyof T;

  /**
   * jsx function to render custom cell content!
   * e.g `(record) => <h2>{record.title}</h2>.`
   */
  cell?: (record: T, index?: number) => ReactNode;

  /*
   * Field decorator
   */
  decorator?: (records: T[]) => ReactNode;

  /*
   * Color used to highlight the row associated with this field
   */
  highlight?: (records: T[]) => HighlightColorVariant | undefined;

  /*
   * Icon associated with this field to be displayed at the beginning of this row
   */
  icon?: (records: T[]) => DecoratorSpecification;

  /*
   * Boolean representing whether to display the field control or not
   */
  showEdit: boolean;

  /*
   * The function to display the edit view of the data
   */
  edit?: (record: T, index: number) => ReactNode;

  /*
   * The function used to add decorators to a specific table cell
   */
  cellDecorator?: (record: T, index: number) => DecoratorSpecification;
}
