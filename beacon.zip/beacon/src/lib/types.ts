export type SyntheticEventHandler = (event: React.SyntheticEvent) => void;

export enum Variant {
  default,
  info,
  warning,
  success,
  danger,
  suggestion,
}
