import React, { ReactNode, useState } from 'react';
import { Meta, Story } from '@storybook/react';
import { Documentation, dropdownFromEnum, StoryBadge } from '../stories';
import { a11yConfig } from '../stories/story.config';
import { Icon, IconSize, IconType, IconVariant, IIconProps, IconAnimation, IconStyle } from './icon';
import { iconDescription } from './story-utils';
import { SearchBar } from '../forms/search-bar/search-bar';
import { Card } from '../cards/card';

export default {
  component: Icon,
  title: 'Styling/Icons',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
  argTypes: {
    type: {
      control: null,
    },
    size: {
      control: null,
    },
    variant: {
      control: null,
    },
    description: {
      control: null,
    },
    id: {
      control: null,
    },
  },
} as Meta;

const whenToUse = (
  <>
    <ul>
      <li>
        <strong className="beacon-icon-success">Do</strong> use icons consistently, and for the function listed below
      </li>
    </ul>
    <hr />
    <ul>
      <li>
        <strong className="beacon-icon-danger">Don't</strong> use icons by themselves for navigation
      </li>
      <li>
        <strong className="beacon-icon-danger">Don't</strong> use icons to complete an action -- for example, don't use
        an icon instead of a Submit button. Starting an action with an icon is acceptable -- for example, using the edit
        icon to allow users to edit a table
      </li>
      <li>
        <strong className="beacon-icon-danger">Don't</strong> use icons alone where a button or link should be used
      </li>
    </ul>
  </>
);

const accessibilityConsiderations = (
  <ul>
    <li>
      Presentation only icons (like an Info icon on an Info badge) do not need a description (since the content/context
      is presented by the accompanying badge/element next to it).
    </li>
    <li>
      Icons that are presented by themselves should have a description provided via a "title" attribute, to address the
      "but keyboard users can't see it", a legend should be provided
    </li>
    <li>
      If a legend cannot be provided, then the icon should be wrapped in a "Tooltip" component to provide the
      description that way and make the icon focusable.
    </li>
  </ul>
);

const getIconDescription = (type: IconType): ReactNode => {
  const item = iconDescription.find((item) => item.name === type);
  if (item) return <span>{item.description}</span>;
  else return null;
};

export const IconCollection: Story<IIconProps> = ({ type }: IIconProps) => {
  const iconDescription = getIconDescription(type);
  return (
    <>
      <div>
        <Icon type={type} size={IconSize.large} variant={IconVariant.default} description="Icon desc" />
      </div>
      <div>{iconDescription}</div>
    </>
  );
};

IconCollection.args = {
  type: IconType.star,
};

IconCollection.argTypes = {
  type: {
    control: dropdownFromEnum(IconType),
  },
  size: {
    control: null,
  },
  variant: {
    control: null,
  },
  description: {
    control: null,
  },
  id: {
    control: null,
  },
};

IconCollection.decorators = [
  (Story: Story) => (
    <Documentation
      name="Icon Collection"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description="The Beacon Design System uses a subset of Font Awesome icons"
    >
      <Story />
    </Documentation>
  ),
];

export const FindAnIcon: Story = () => {
  const [query, setQuery] = useState('');
  console.log('change', query);
  return (
    <div>
      <div className="mb-2">
        <SearchBar id="icon-search-bar" hideResults allowEmpty onChange={(_event, value) => setQuery(value)} />
      </div>
      <div className="d-flex flex-wrap">
        {Object.values(IconType)
          .filter((type) => {
            const formattedQuery = query.toLocaleLowerCase().trim();
            return (
              type.toLocaleLowerCase().includes(formattedQuery) ||
              iconDescription
                .find((item) => item.name === type)
                ?.description.toLocaleLowerCase()
                .includes(formattedQuery)
            );
          })
          .map((type) => (
            <div className="mr-2 mb-2" key={type}>
              <Card id={type}>
                <div className="d-flex" style={{ width: '300px', height: '175px' }}>
                  <Icon type={type} size={IconSize.large} />
                  <div className="ml-3">
                    <strong>{type}</strong>
                    <p>{getIconDescription(type)}</p>
                    <div className="mb-1">CODE SNIPPET</div>
                    <code className="language-html">{`<Icon type={IconType.${type}} />`}</code>
                  </div>
                </div>
              </Card>
            </div>
          ))}
      </div>
    </div>
  );
};

FindAnIcon.decorators = [
  (ComponentStory: Story) => (
    <Documentation name="Find an Icon">
      <ComponentStory />
    </Documentation>
  ),
];

export const IconSizes: Story = () => {
  return (
    <>
      <Icon type={IconType.star} size={IconSize.small} variant={IconVariant.default} description="small icon" />
      <Icon type={IconType.star} size={IconSize.regular} variant={IconVariant.default} description="regular icon" />
      <Icon type={IconType.star} size={IconSize.large} variant={IconVariant.default} description="large icon" />
      <Icon type={IconType.star} size={IconSize.default} variant={IconVariant.default} description="inherit icon" />
    </>
  );
};

IconSizes.decorators = [
  (Story: Story) => (
    <Documentation
      name="Icon Sizes"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description="Multiple icon sizes (small, regular, large, & default) are available"
    >
      <Story />
    </Documentation>
  ),
];

export const IconVariants: Story = () => {
  return (
    <>
      <Icon type={IconType.flag} size={IconSize.large} variant={IconVariant.default} description="Icon desc" />
      <Icon type={IconType.flag} size={IconSize.large} variant={IconVariant.info} description="Icon desc" />
      <Icon type={IconType.flag} size={IconSize.large} variant={IconVariant.success} description="Icon desc" />
      <Icon type={IconType.flag} size={IconSize.large} variant={IconVariant.warning} description="Icon desc" />
      <Icon type={IconType.flag} size={IconSize.large} variant={IconVariant.danger} description="Icon desc" />
      <Icon type={IconType.flag} size={IconSize.large} variant={IconVariant.suggestion} description="Icon desc" />
      <Icon type={IconType.flag} size={IconSize.large} variant={'#f216dc'} description="Icon desc" />
    </>
  );
};

IconVariants.decorators = [
  (Story: Story) => (
    <Documentation
      name="Icon color variants"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description="Variant options are default, info, success, warning, danger, and suggestion. Other than that, a custom color can also be provided"
    >
      <Story />
    </Documentation>
  ),
];

export const IconAnimations: Story = () => {
  return (
    <>
      <Icon type={IconType.sync} size={IconSize.large} variant={IconVariant.default} description="No animation" />
      <Icon
        type={IconType.sync}
        size={IconSize.large}
        variant={IconVariant.default}
        animation={IconAnimation.spin}
        description="spin animation"
      />
    </>
  );
};

IconAnimations.decorators = [
  (AnimationStory: Story) => (
    <Documentation
      name="Icon Animations"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description="An optional option for fa animations."
    >
      <AnimationStory />
    </Documentation>
  ),
];

export const IconStyles: Story = () => {
  return (
    <>
      <Icon
        type={IconType.commentAlt}
        style={IconStyle.default}
        size={IconSize.large}
        variant={IconVariant.default}
        description="classic solid"
      />
      <Icon
        type={IconType.commentAlt}
        style={IconStyle.regular}
        size={IconSize.large}
        variant={IconVariant.default}
        description="classic regular"
      />
    </>
  );
};

IconStyles.decorators = [
  (AnimationStory: Story) => (
    <Documentation
      name="Icon Style"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
      description="An option to change the look of comments."
    >
      <AnimationStory />
    </Documentation>
  ),
];
