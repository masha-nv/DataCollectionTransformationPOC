import React, { ReactNode } from 'react';
import { act, fireEvent, render, screen } from '@testing-library/react';
import { Icon, IconAnimation, IconSize, IconType, IconVariant, IconStyle } from './icon';
import { enumKeys } from '../stories';

describe('Icon', () => {
  it('renders icons with default properties correctly', () => {
    const iconArray = [];
    let key = 0;
    for (const type in IconType) {
      iconArray.push(<Icon key={`icon_${++key}`} type={type as IconType} description="Icon desc" />);
    }

    const { baseElement } = render(<div>{iconArray}</div>);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders icons on all types correctly', () => {
    const iconArray = [];
    let key = 0;
    for (const type in IconType) {
      iconArray.push(
        <Icon
          key={`icon_${++key}`}
          type={type as IconType}
          size={IconSize.large}
          variant={IconVariant.default}
          description="Icon desc"
        />
      );
    }

    const { baseElement } = render(<div>{iconArray}</div>);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders icons sizes correctly', () => {
    const iconArray: ReactNode[] = [];
    enumKeys(IconSize).forEach((key, index) => {
      iconArray.push(
        <Icon
          key={`icon_${index}`}
          type={IconType.flag}
          size={IconSize[key]}
          variant={IconVariant.default}
          description="Icon desc"
        />
      );
    });

    const { baseElement } = render(<div>{iconArray}</div>);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders icons with aria-label and correct role', () => {
    const { baseElement } = render(
      <div>
        {
          <Icon
            key={`icon_with_aria_label`}
            type={IconType.flag}
            variant={IconVariant.default}
            description="Icon desc"
            ariaLabel="Icon aria-label"
          />
        }
      </div>
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('renders icons variants correctly', () => {
    const iconArray = [];
    let key = 0;
    for (const variant in IconVariant) {
      iconArray.push(
        <Icon
          key={`icon_${++key}`}
          type={IconType.flag}
          size={IconSize.large}
          variant={variant as IconVariant}
          description="Icon desc"
        />
      );
    }

    iconArray.push(
      <Icon
        key={`icon_${++key}`}
        type={IconType.flag}
        size={IconSize.large}
        variant={'#f216dc'}
        description="Icon desc"
      />
    );

    const { baseElement } = render(<div>{iconArray}</div>);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders concurrent icon variants correctly', () => {
    const iconArray = [];
    let key = 0;
    for (const variant in IconVariant) {
      iconArray.push(
        <Icon
          key={`icon_${++key}`}
          type={IconType.concurrent}
          size={IconSize.large}
          variant={variant as IconVariant}
          description="Icon desc"
        />
      );
    }

    iconArray.push(
      <Icon
        key={`icon_${++key}`}
        type={IconType.concurrent}
        size={IconSize.large}
        variant={'#f216dc'}
        description="Icon desc"
      />
    );

    const { baseElement } = render(<div>{iconArray}</div>);
    expect(baseElement).toMatchSnapshot();
  });

  it('calls the onClick callback when clicked', () => {
    const testOnClick = jest.fn();
    const { baseElement, getByTitle } = render(
      <div id="icon-element">
        <Icon
          key={'test-icon-onclick'}
          type={IconType.times}
          description="Icon desc"
          onClick={testOnClick}
          isClickable={true}
        />
      </div>
    );

    const iconElement = getByTitle('Icon desc');
    expect(iconElement).not.toBeNull();
    act(() => {
      fireEvent.click(iconElement);
    });
    expect(testOnClick).toHaveBeenCalled();
    expect(baseElement).toMatchSnapshot();
  });

  it('calls the onClick null callback when clicked', () => {
    const { baseElement, getByTitle } = render(
      <div id="icon-element">
        <Icon
          key={'test-icon-onclick'}
          type={IconType.times}
          description="Icon desc"
          onClick={null}
          isClickable={true}
        />
      </div>
    );
    const iconElement = getByTitle('Icon desc');
    expect(iconElement).not.toBeNull();
    act(() => {
      fireEvent.click(iconElement);
    });
    expect(baseElement).toMatchSnapshot();
  });

  test('renders animation correctly', () => {
    render(
      <div id="icon-element">
        <Icon key={'test-icon-onclick'} type={IconType.sync} description="Icon desc" animation={IconAnimation.spin} />
      </div>
    );
    const iconElement = screen.getByTitle('Icon desc');
    expect(iconElement.classList.contains('fa-spin')).toBeTruthy();
  });

  test('renders style correctly', () => {
    render(
      <div id="icon-element">
        <Icon key={'test-icon-onclick'} type={IconType.sync} description="Icon desc" style={IconStyle.regular} />
      </div>
    );
    const iconElement = screen.getByTitle('Icon desc');
    expect(iconElement.classList.contains('far')).toBeTruthy();
  });
});
