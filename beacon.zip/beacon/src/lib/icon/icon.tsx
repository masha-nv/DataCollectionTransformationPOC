import React, { CSSProperties, forwardRef } from 'react';
import { IconAnimation, IconSize, IconType, IconTypeCSS, IconVariant, IconVariantCSS, IconStyle } from './constants';
import './icon.scss';
export interface IIconProps {
  /**
   * Icon type
   */
  type: IconType;
  /**
   * Size of the icon
   */
  size?: IconSize;
  /**
   * Color variable. Either use available options or a custom color
   */
  variant?: IconVariant | string;
  /**
   * Icon style that will be used to differentiate the icon look
   */
  style?: string;
  /**
   * Animation of the icon
   */
  animation?: IconAnimation;
  /**
   * Icon description that will be used as the title
   */
  description?: string;
  /**
   * Aria label used descriptive icons.
   */
  ariaLabel?: string;
  /**
   * Icon can be clicked
   */
  isClickable?: boolean;
  /**
   * Callback that is triggered when icon is clicked.
   */
  onClick?: (event: React.SyntheticEvent) => void;
}

export const Icon = forwardRef<HTMLImageElement, IIconProps>((props, ref) => {
  if (props.type === IconType.concurrent) {
    return <ConcurrentIcon {...props} />;
  }

  const {
    type,
    size = IconSize.default,
    variant = IconVariant.default,
    description,
    ariaLabel,
    isClickable,
    animation,
    style = IconStyle.default,
  } = props;

  const classes = [style, IconTypeCSS[type], size];

  const customStyle: CSSProperties = {};
  if (variant) {
    const predefinedClass = IconVariantCSS[variant as IconVariant];
    if (predefinedClass) {
      classes.push(predefinedClass);
    } else {
      customStyle.color = variant;
    }
  }
  if (animation) {
    classes.push(animation);
  }

  return (
    <>
      {isClickable && (
        <i
          id="beacon-icon-clickable"
          ref={ref}
          className={classes.join(' ')}
          style={{ ...customStyle, cursor: 'pointer' }}
          title={description}
          aria-label={ariaLabel}
          role="button"
          tabIndex={0}
          onClick={(e) => {
            if (props.onClick) props.onClick(e);
          }}
        />
      )}
      {!isClickable && (
        <i
          ref={ref}
          className={classes.join(' ')}
          style={customStyle}
          title={description}
          aria-label={ariaLabel}
          role={ariaLabel ? 'img' : undefined}
          onClick={(e) => {
            if (props.onClick) props.onClick(e);
          }}
        />
      )}
    </>
  );
});

Icon.displayName = 'Icon';

const ConcurrentIcon = ({ type, size = IconSize.regular, variant = IconVariant.default, description }: IIconProps) => {
  const classes = ['fa-stack', size];

  const customStyle: CSSProperties = {};
  if (variant) {
    const predefinedClass = IconVariantCSS[variant as IconVariant];
    if (predefinedClass) {
      classes.push(predefinedClass);
    } else {
      customStyle.color = variant;
    }
  }

  return (
    <span className={classes.join(' ')} style={customStyle} title={description}>
      <span className="bi-concurrent-filing">
        <i className="far fa-folder fa-stack-1x bi-icon-1"></i>
        <i className="fas fa-folder fa-stack-1x"></i>
      </span>
    </span>
  );
};

export { IconSize, IconType, IconVariant, IconAnimation, IconStyle } from './constants';
