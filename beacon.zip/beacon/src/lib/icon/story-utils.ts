import { IconType } from './icon';

export const iconDescription = [
  {
    name: IconType.star,
    description:
      'Indicates an entry is a primary value for that field. Note: by default, this icon is assigned the primary color.',
  },
  {
    name: IconType.flag,
    description: 'Indicates a serious hard-stop on a case or issue.',
  },
  {
    name: IconType.trash,
    description: 'Delete an item.',
  },
  {
    name: IconType.pencilAlt,
    description:
      'Enables "edit mode" so data can be changed. Should always be used in combination with a link that says "Edit".',
  },
  {
    name: IconType.filter,
    description: 'Used to indicate you can filter data such as on a table or in search results.',
  },
  {
    name: IconType.envelope,
    description: 'Indicates an unread item.',
  },
  {
    name: IconType.envelopeOpen,
    description: 'Indicates a read item.',
  },
  {
    name: IconType.eraser,
    description: 'Indicates an action that clears form data',
  },
  {
    name: IconType.exclamationCircle,
    description:
      'Indicates an error that is the result of an action taken by users, which must be addressed before continuing. Used in butterbar alerts and elsewhere.',
  },
  {
    name: IconType.exclamationTriangle,
    description:
      'Indicates a warning to users of important information that does not necessarily need to be addressed before continuing. Used in butterbar alerts and elsewhere.',
  },
  {
    name: IconType.sort,
    description: 'Used in table headers to indicate the column can be sorted by clicking.',
  },
  {
    name: IconType.externalLinkAlt,
    description: 'Used in combination with a link to indicate the link opens in a new page outside of ELIS.',
  },
  {
    name: IconType.ellipsis,
    description: 'More information or choices are available.',
  },
  {
    name: IconType.calendar,
    description: 'Used to label a date value or datepicker input',
  },
  {
    name: IconType.timesCircle,
    description: 'Used to indicate something is removable, such as in filter tags.',
  },
  {
    name: IconType.times,
    description: 'Used to indicate something is closeable, such as modals and tabs.',
  },
  {
    name: IconType.checkCircle,
    description: 'Indicates success.',
  },
  {
    name: IconType.check,
    description:
      'Indicates success: use as standalone inside of a wizard with our own circles, or as the check in a check box. Can be used without a label in the side navigation when checking off tasks.',
  },
  {
    name: IconType.search,
    description: 'Used on Search field button to submit search. Can be used without a label.',
  },
  {
    name: IconType.tasks,
    description: '',
  },
  {
    name: IconType.print,
    description: 'Print the page.',
  },
  {
    name: IconType.infoCircle,
    description: 'Indicates information message.',
  },
  {
    name: IconType.caretUp,
    description:
      'Used in dropdowns, when the dropdown is open. Also used to indicate a table column is sorted in ascending order.',
  },
  {
    name: IconType.caretDown,
    description:
      'Used in dropdowns, when the dropdown is closed. Also used to indicate a table column is sorted in descending order.',
  },
  {
    name: IconType.caretRight,
    description: 'Used in pagination, to move one page forward.',
  },
  {
    name: IconType.caretLeft,
    description: 'Used in pagination, to move one page backwards.',
  },
  {
    name: IconType.chevronUp,
    description: 'Used in accordions, when the accordion is open.',
  },
  {
    name: IconType.chevronDown,
    description: 'Used in accordions, when the accordion is closed.',
  },
  {
    name: IconType.arrowDown,
    description: 'Directional icon used to indicate re-ordering items downward in a list',
  },
  {
    name: IconType.arrowUp,
    description: 'Directional icon used to indicate re-ordering items upward in a list',
  },
  {
    name: IconType.arrowLeft,
    description: 'Directional icon to indicate moving to a previous page, state, or step',
  },
  {
    name: IconType.arrowRight,
    description: 'Directional icon to indicate moving to the next page, state, or step',
  },
  {
    name: IconType.eye,
    description: 'Can be used without a label as a link to a quick view.',
  },
  {
    name: IconType.userFriends,
    description: 'Indicates this case is part of a family pack',
  },
  {
    name: IconType.userXmark,
    description: 'Indicates a user performed an invalid action',
  },
  {
    name: IconType.concurrent,
    description:
      'Use this icon for concurrent filing, it can be styled with the normal beacon icon classes at the top of this page',
  },
  {
    name: IconType.chevronLeft,
    description: 'Represents moving backwards or to a previous state',
  },
  {
    name: IconType.chevronRight,
    description: 'Represents moving forwards or to a next state',
  },
  {
    name: IconType.calendarAlt,
    description: 'Alternate icon used to label a date value or datepicker input',
  },
  {
    name: IconType.plusCircle,
    description: 'Represents adding an element to the UI',
  },
  {
    name: IconType.redo,
    description:
      'Use this icon for concurrent filing, it can be styled with the normal beacon icon classes at the top of this page',
  },
  {
    name: IconType.save,
    description:
      'Use this icon for concurrent filing, it can be styled with the normal beacon icon classes at the top of this page',
  },
  {
    name: IconType.windowRestore,
    description: 'Used to illustrate an "open this in new tab" action',
  },
  {
    name: IconType.arrowsAlt,
    description: 'Used to label a "zoom to fit available space" action',
  },
  {
    name: IconType.bookmark,
    description: 'Represents that this element is bookmarked to be quickly referenced later',
  },
  {
    name: IconType.tag,
    description:
      'Represents that this is a "tag" describing the category of an element, e.g. a document category for a piece of evidence',
  },
  {
    name: IconType.circle,
    description: 'Used to represent one of a series of pages of information, e.g. in a "carousel" component',
  },
  {
    name: IconType.file,
    description: 'Represents a digital document',
  },
  {
    name: IconType.fileCsv,
    description: 'Represents a digital CSV document',
  },
  {
    name: IconType.fileExcel,
    description: 'Represents a digital spreadsheet document, e.g. for an "Export as Excel file" action',
  },
  {
    name: IconType.fileImport,
    description: 'Indicates the importing of data into a record',
  },
  {
    name: IconType.folder,
    description: 'Represents a group of documents or other records',
  },
  {
    name: IconType.folderOpen,
    description: 'Alternate depiction of a folder, to suggest that this is an "active" folder',
  },
  {
    name: IconType.folderMinus,
    description: 'Used to indicate a "Remove Folder" action',
  },
  {
    name: IconType.folderPlus,
    description: 'Used to indicate an "Add Folder" action',
  },
  {
    name: IconType.image,
    description: 'Represents an image file which could be a piece of case evidence',
  },
  {
    name: IconType.minus,
    description: 'Represents a reduction in value or "zooming out" of a view',
  },
  {
    name: IconType.minusCircle,
    description: 'Represents a reversal to a prior state, say a chat window not being open.',
  },
  {
    name: IconType.plus,
    description: 'Represents an increase in value or "zooming in" of a view',
  },
  {
    name: IconType.questionCircle,
    description: 'Represents availability of additional help information',
  },
  {
    name: IconType.searchMinus,
    description: 'Represents a "zooming out" of a view',
  },
  {
    name: IconType.searchPlus,
    description: 'Represents a "zooming in" of a view',
  },
  {
    name: IconType.stickyNote,
    description: 'Represents a user or ELIS-generated note about an item',
  },
  {
    name: IconType.thLarge,
    description: 'Used to mark a drag handle on an element that can be moved on the screen with a mouse drag event',
  },
  {
    name: IconType.trashAlt,
    description: 'Alternate icon for deleting an item',
  },
  {
    name: IconType.undo,
    description: 'Revert the last user action',
  },
  {
    name: IconType.download,
    description: 'Represents the download of a file',
  },
  {
    name: IconType.sync,
    description: 'Represents syncing or refreshing',
  },
  {
    name: IconType.signOut,
    description: 'For ending a user session',
  },
  {
    name: IconType.commentDots,
    description: 'For opening a live discussion',
  },
  {
    name: IconType.house,
    description: 'Represents a default or home location',
  },
  {
    name: IconType.paperPlane,
    description: 'For sending or submitting a message, form, or a similar piece of information',
  },
  {
    name: IconType.newspaper,
    description: 'Represents reports or routinely updated textual information',
  },
  {
    name: IconType.cloudArrowUp,
    description: 'For uploading data',
  },
  {
    name: IconType.barcode,
    description: 'Represents a barcode',
  },
  {
    name: IconType.gear,
    description: 'Represents settings or configurations',
  },
  {
    name: IconType.gears,
    description: 'Represents settings, configurations, and/or logging information',
  },
  {
    name: IconType.grip,
    description: 'Represents grip handle for draggable components',
  },
  {
    name: IconType.bell,
    description: 'Represents a notification',
  },
  {
    name: IconType.bullhorn,
    description: 'Represents an announcement',
  },
  {
    name: IconType.clock,
    description: 'Represents time',
  },
  {
    name: IconType.spinner,
    description: 'Represents loading and/or time passing',
  },
  {
    name: IconType.skullAndCrossbones,
    description: 'Represents deceased',
  },
  {
    name: IconType.locationDot,
    description: 'Represents location or map marker',
  },
  {
    name: IconType.bookOpen,
    description: 'Represents QRGs and ELIS manuals',
  },
  {
    name: IconType.list,
    description: 'Represents list of options',
  },
  {
    name: IconType.chartLine,
    description: 'Represents dashboard or charts',
  },
  {
    name: IconType.chalkboardUser,
    description: 'Represents a user accessing a webpage',
  },
  {
    name: IconType.link,
    description: 'Represents external link',
  },
  {
    name: IconType.rocket,
    description: 'Represents a point within a user tour',
  },
  {
    name: IconType.wrench,
    description: 'Represents manually modifying',
  },
  {
    name: IconType.circleArrowRight,
    description: 'Represents a skip or bypass',
  },
  {
    name: IconType.circleDot,
    description: 'Represents remote room status.',
  },
  {
    name: IconType.tabletScreenButton,
    description: 'Represents tablet screen.',
  },
];
