import React from 'react';
import { render } from '@testing-library/react';
import { HighlightedText, HighlightVariant } from './highlighted-text';

describe('HighlightedText', () => {
  it('renders default highlighted text correctly', () => {
    const { baseElement } = render(<HighlightedText id="highlight-text">Text</HighlightedText>);

    expect(baseElement).toMatchSnapshot();
  });

  it('renders suggestion highlighted text correctly', () => {
    const { baseElement } = render(
      <HighlightedText id="highlight-text" variant={HighlightVariant.suggestion}>
        Text
      </HighlightedText>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders default highlighted text with tooltip correctly', () => {
    const { baseElement } = render(
      <HighlightedText id="highlight-text" contextualHelp="tooltip">
        Text
      </HighlightedText>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders suggestion highlighted text with tooltip correctly', () => {
    const { baseElement } = render(
      <HighlightedText id="highlight-text" variant={HighlightVariant.suggestion} contextualHelp="tooltip">
        Text
      </HighlightedText>
    );

    expect(baseElement).toMatchSnapshot();
  });
});
