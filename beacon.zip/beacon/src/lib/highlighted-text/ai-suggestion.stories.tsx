import { Meta, Story } from '@storybook/react';
import React from 'react';
import { Documentation, StoryBadge } from '../stories';
import { a11yConfig } from '../stories/story.config';
import { HighlightedText, HighlightVariant } from './highlighted-text';

export default {
  component: HighlightedText,
  title: 'Core Components/AI Suggestions',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
  },
} as Meta;

const whenToUse = (
  <>
    AI Suggestion Highlighted Text should be used anytime ELIS is using AI or machine learning to make suggestions to
    users. The highlighted text serves as a way to highlight content related to AI/ML suggestions within a larger text
    paragraph.
  </>
);

const languageGuidelines = (
  <div>
    <ul>
      <li>
        AI Suggestion Highlighted Text should only be used to highlight text content related to within AI/ML
        suggestions.
      </li>
      <li>An AI Suggestion Badge should be included somewhere in the same UI to give context to the text highlight.</li>
    </ul>
  </div>
);

export const AISuggestionHighlightedText: Story = () => {
  return (
    <HighlightedText id="highlight-1" variant={HighlightVariant.suggestion} contextualHelp="Name 1">
      JAY ALLEN SAMPLES
    </HighlightedText>
  );
};

AISuggestionHighlightedText.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="AI Suggestion Highlighted Text"
      description="Used to highlight content that has been AI suggested."
      whenToUse={whenToUse}
      languageGuidelines={languageGuidelines}
    >
      <ComponentStory />
    </Documentation>
  ),
];
