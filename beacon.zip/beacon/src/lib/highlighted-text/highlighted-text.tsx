import classNames from 'classnames';
import React from 'react';
import { Tooltip } from '../modals/tooltip/tooltip';
import { WithId } from '../with-id';
import './highlighted-text.scss';

export interface IHighlightedTextProps extends WithId {
  /**
   * Color variant of text to render
   */
  variant?: HighlightVariant;
  /**
   * Set a value to display text in a tooltip
   */
  contextualHelp?: string;
  /**
   * The text content to highlight
   */
  children: string;
}

export enum HighlightVariant {
  default = 'default',
  suggestion = 'suggestion',
}

/**
 * Highlighted Text component
 */
export const HighlightedText = ({
  id,
  variant = HighlightVariant.default,
  contextualHelp,
  children,
}: IHighlightedTextProps) => {
  const classes = classNames(
    'highlighted-text',
    { 'highlight-default': variant === HighlightVariant.default },
    { 'highlight-suggestion': variant === HighlightVariant.suggestion }
  );

  const textContent = (
    <mark tabIndex={0} id={id} className={classes}>
      {children}
    </mark>
  );

  if (contextualHelp) {
    let tooltipContent = undefined;
    if (variant === HighlightVariant.suggestion) {
      tooltipContent = (
        <>
          <div>
            <i className="fas fa-wand-magic-sparkles mr-2 mb-2" aria-hidden="true">
              <span className="sr-only">suggestion badge</span>
            </i>
            <strong>Suggested by ELIS</strong>
          </div>
          <div>{contextualHelp}</div>
        </>
      );
    }

    return (
      <Tooltip id={`${id}-tooltip`} content={variant === HighlightVariant.suggestion ? tooltipContent : contextualHelp}>
        {textContent}
      </Tooltip>
    );
  } else {
    return textContent;
  }
};
