import { render } from '@testing-library/react';
import { AccordionHeader } from './accordion-header';

describe('Accordion Header Component', () => {
  it('renders successfully', () => {
    const { baseElement } = render(<AccordionHeader id="header1" title={'Header 1'} />);
    expect(baseElement).toMatchSnapshot();
  });
});
