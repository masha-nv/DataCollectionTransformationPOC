import { ReactNode, useEffect, useRef } from 'react';
import { ErrorBoundary } from '../../boundary/error-boundary';

export interface IAccordionBodyProps {
  /**
   * Whether or not the body is expanded
   */
  expanded: boolean;
  /**
   * The actual contents of this particular accordion
   */
  children: ReactNode;
}

export const AccordionBody = ({ expanded, children }: IAccordionBodyProps) => {
  const bodyRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (expanded) {
      bodyRef.current?.focus();
    }
  }, [expanded]);
  return (
    <div tabIndex={0} className="accordion-tab accordion-body" ref={bodyRef}>
      <ErrorBoundary>{children}</ErrorBoundary>
    </div>
  );
};
