import classNames from 'classnames';
import React, { ReactElement, SyntheticEvent } from 'react';
import { defaultTracking, Trackable, trackableEvent } from '../../analytics';
import { Heading, HeadingType } from '../../heading/heading';
import { WithId } from '../../with-id';

export interface IAccordionHeaderProps extends Trackable, WithId {
  /**
   * A string title to display within the accordion header.
   */
  title: string;
  /**
   * A string or `ReactElement` that is either an `AccordionCustomHeader` or both `AccordionLeftHeader`
   * and `AccordionRightHeader`. These help render a customizable header for all accordions. Displays next to title.
   */
  details?: ReactElement | string;
  /**
   * (optional) Default state for disable/enabled when the component loads
   */
  disabled?: boolean;
  /**
   * Whether or not the panel for title is collapsed or not
   */
  collapsed?: boolean;
  /**
   * (optional) function to be executed when the panel title is clicked
   */
  onToggled?: (param: SyntheticEvent) => void;
  /**
   * The type of heading used for the title.
   */
  headingType?: HeadingType;
}

// eslint-disable-next-line @typescript-eslint/no-empty-function
const defaultOnToggled = () => {
  // Intentionally left empty
};

const doNotExpand = (event: SyntheticEvent) => {
  event.preventDefault();
  return false;
};

export const AccordionHeader = ({
  id,
  title,
  details,
  disabled,
  collapsed,
  onToggled = defaultOnToggled,
  tracking,
  headingType,
}: IAccordionHeaderProps) => {
  const togglePanelIcon = (clickEvent: SyntheticEvent) => {
    onToggled(clickEvent);
  };
  const trackingInfo = defaultTracking(tracking, {
    grouping: 'Ungrouped',
    trackingKey: 'Accordion-' + id,
  });
  trackingInfo.action = collapsed ? 'Expanded' : 'Collapsed';
  const trackableClick = trackableEvent(trackingInfo, togglePanelIcon);

  const preventExpand = disabled ? doNotExpand : undefined;

  const headerClasses = classNames('accordion-header', 'flex-grow-1', 'text-left', {
    'accordion-disabled': disabled,
    collapsed: collapsed,
  });

  const titleClasses = classNames('accordion-title', 'd-flex', 'flex-grow-1', {
    'accordion-disabled': disabled,
  });

  return (
    <div id={`${id}-header`} className={headerClasses} onClick={preventExpand}>
      <div className="summary d-flex" tabIndex={-1}>
        <div className={titleClasses}>
          <span className="d-flex flex-grow-1">
            <button
              id={`${id}-text-button`}
              disabled={disabled}
              onClick={trackableClick}
              className="accordion-text-button"
              tabIndex={disabled ? -1 : 0}
              type="button"
            >
              <Heading headingType={headingType ? headingType : 'h3'} headingStyle="m">
                {title}
              </Heading>
            </button>
            {details}
          </span>
        </div>
        <button
          id={`${id}-button`}
          disabled={disabled}
          onClick={trackableClick}
          className="accordion-button"
          tabIndex={disabled ? -1 : 0}
          type="button"
        >
          {collapsed ? (
            <i className="toggle-icon fas fa-angle-down">
              <span className="sr-only">Expand</span>
            </i>
          ) : (
            <i className="toggle-icon fas fa-angle-up">
              <span className="sr-only">Collapse</span>
            </i>
          )}
        </button>
      </div>
    </div>
  );
};
