import { render } from '@testing-library/react';
import { AccordionBody } from './accordion-body';

describe('Accordion Header Component', () => {
  it('renders successfully', () => {
    const { baseElement } = render(<AccordionBody expanded={false}>Body</AccordionBody>);
    expect(baseElement).toMatchSnapshot();
  });
});
