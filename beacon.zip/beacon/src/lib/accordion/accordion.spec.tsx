import { render } from '@testing-library/react';
import { Accordion } from './accordion';
import { DisableAnAccordion, AccordionPrimary } from './accordion.stories';
import { track } from '../analytics/matomo';
import { TrackableEvent } from '../analytics';

jest.mock('../analytics/matomo', () => {
  const module = jest.requireActual('../analytics/matomo');
  return {
    ...module,
    track: jest.fn(),
  };
});

describe('Accordion Component', () => {
  it('renders successfully', () => {
    const { baseElement } = render(<AccordionPrimary />);

    expect(baseElement).toMatchSnapshot();
  });

  it('renders can expand an accordion', () => {
    const { container } = render(<AccordionPrimary />);

    const button = container.querySelector<HTMLButtonElement>('.accordion-button');
    button.click();

    expectAccordionIsExpanded(container, 'first-accordion');
    expect(container).toMatchSnapshot();
  });

  it('focuses the body when the accordion is expanded', () => {
    const { baseElement } = render(<AccordionPrimary />);

    const button = baseElement.querySelector<HTMLButtonElement>('.accordion-button');
    button.click();

    expect(baseElement.querySelector('.accordion-body')).toBeTruthy();
    expect(baseElement).toMatchSnapshot();
  });

  it('invokes onToggle handler', () => {
    const fakeToggleHandler = jest.fn();
    const { baseElement } = render(
      <Accordion id="first-accordion" onToggle={fakeToggleHandler} title="test accordion">
        Hello
      </Accordion>
    );

    const button = baseElement.querySelector<HTMLButtonElement>('.accordion-button');
    button.click();

    expect(fakeToggleHandler).toHaveBeenCalledWith(true, expect.anything());
  });

  it('tracks toggle events', () => {
    const { baseElement } = render(<AccordionPrimary />);

    // triggers both expand and collapse events
    const button = baseElement.querySelector<HTMLButtonElement>('.accordion-button');

    fireToggleAndExpectTrackedEventToBe(button, 'Expanded');
    fireToggleAndExpectTrackedEventToBe(button, 'Collapsed');
  });

  it('renders disabled accordion successfully', () => {
    const { container } = render(<DisableAnAccordion />);

    const summary = container.querySelector<HTMLElement>('#disabled-accordion .summary');
    summary.click();

    expectAccordionIsCollapsed(container, 'disabled-accordion');
    expect(container).toMatchSnapshot();
  });

  const expectAccordionIsExpanded = (baseElement: HTMLElement, accordionId: string) => {
    expect(baseElement.querySelector(`#${accordionId}-header collapsed`)).toBeNull();
  };

  const expectAccordionIsCollapsed = (baseElement: HTMLElement, accordionId: string) => {
    expect(baseElement.querySelector(`#${accordionId}-header`)).toBeTruthy();
  };

  const fireToggleAndExpectTrackedEventToBe = (button: HTMLElement, expectedTrackedAction: string) => {
    button.click();
    expect(track).toHaveBeenLastCalledWith({
      grouping: 'Ungrouped',
      action: expectedTrackedAction,
      trackingKey: 'Accordion-first-accordion',
    } as TrackableEvent);
  };

  it('renders an accordion with customized heading', () => {
    const { baseElement } = render(
      <Accordion id="accordion1" title="title" headingType="h1">
        Body
      </Accordion>
    );

    expect(baseElement).toMatchSnapshot();
  });
});
