import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import { AccordionGroup } from './accordion-group';

import { Accordion } from './accordion';

describe('AccordionGroup Component', () => {
  it('still renders even if onToggle is provided on child accordion', () => {
    const fakeOnToggle = jest.fn();
    const { baseElement } = render(
      <AccordionGroup id="accordionGroup">
        <Accordion id="first-accordion" title="first">
          Hello
        </Accordion>
        <Accordion id="second-accordion" title="second" onToggle={fakeOnToggle}>
          Hello
        </Accordion>
      </AccordionGroup>
    );

    const secondAccordion = baseElement.querySelector('#second-accordion');
    fireEvent(secondAccordion, new Event('toggle'));

    expect(fakeOnToggle).not.toHaveBeenCalled();
  });

  it('does not fire onexpand when collapsing an accordion', () => {
    const fakeOnExpand = jest.fn();
    const { baseElement } = render(
      <AccordionGroup id="accordionGroup" onExpand={fakeOnExpand}>
        <Accordion id="first-accordion" title="first">
          Hello
        </Accordion>
        <Accordion id="second-accordion" title="second">
          Hello
        </Accordion>
        <Accordion id="third-accordion" title="third">
          Hello
        </Accordion>
      </AccordionGroup>
    );

    const thirdAccordion = baseElement.querySelector<HTMLElement>('#third-accordion .accordion-button');
    // expand and collapse it
    thirdAccordion.click();
    thirdAccordion.click();

    expect(fakeOnExpand).toHaveBeenCalledTimes(1);
  });
});
