import React, { SyntheticEvent, useEffect, useState } from 'react';
import { WithId } from '../with-id';
import { Accordion, IAccordionProps } from './accordion';

export type AccordionGroupToggleHandler = (newActiveAccordion: string, event: SyntheticEvent) => void;

export interface IAccordionGroupProps extends WithId {
  /**
   * The `id` of the accordion to expand by default
   */
  defaultExpanded?: string;
  /**
   * A callback that is invoked when a new accordion is expanded inside this group
   */
  onExpand?: AccordionGroupToggleHandler;
  /**
   * The accordions that make up the children of this group
   */
  children: React.ReactElement<IAccordionProps>[];
}

// eslint-disable-next-line @typescript-eslint/no-empty-function
const emptyOnExpandHandler: AccordionGroupToggleHandler = () => {};
/**
 * Represents a group of `Accordion` components that can only have **one accordion** open at a time.
 */
export const AccordionGroup = ({ onExpand = emptyOnExpandHandler, ...props }: IAccordionGroupProps) => {
  const [activeAccordion, setActiveAccordion] = useState<string>();

  useEffect(() => {
    setActiveAccordion(props.defaultExpanded);
  }, [props.defaultExpanded]);

  return (
    <div className="accordion-group">
      {props.children.map((accordion, index) => {
        const propsToPass = {
          ...accordion.props,
        };
        if (propsToPass && propsToPass.onToggle) {
          console.warn(
            'When using an AccordionGroup, define the onExpand at the group level, the individual one will be ignored'
          );
        }
        propsToPass.onToggle = (expanded, event) => {
          if (expanded) {
            onExpand(propsToPass.id, event);
          }
          if (expanded && propsToPass.id !== activeAccordion) {
            setActiveAccordion(propsToPass.id);
          }
        };
        propsToPass.expanded = activeAccordion === propsToPass.id;
        return <Accordion key={`${props.id}-accordion-${index}`} {...propsToPass} />;
      })}
    </div>
  );
};
