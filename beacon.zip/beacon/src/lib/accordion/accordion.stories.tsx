import { Story, Meta } from '@storybook/react';
import React from 'react';
import { Button, ButtonType } from '../button/button';
import { Badge, BadgeVariant } from '../notifications/badge/badge';
import { Documentation, dropdownFromHeadingTypes, StoryBadge } from '../stories';
import { a11yConfig } from '../stories/story.config';
import { Accordion, AccordionCustomHeader, AccordionLeftHeader, AccordionRightHeader } from './accordion';
import { AccordionGroup } from './accordion-group';

export default {
  component: Accordion,
  title: 'Core Components/Accordions/Accordion',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const description = (
  <>
    Accordions are components that expand or collapse to reveal or hide additional content. Accordions are commonly used
    to reduce the need to scroll when presenting multiple sections of content on a single page.
    <br />
    <br />
    This example shows a set of accordions that are not linked to each other. They can be expanded and collapsed
    independently of one another. To view accordions that are linked, see the <code>AccordionGroup</code> stories.
    <br />
    <br />
    The second and third accordions show custom components being included in the header. Use the sample code to
    determine which components to use in the header to achieve a single custom header or a two column layout.
  </>
);

const whenToUse = (
  <>
    <p>
      Accordions are useful for progressive disclosure: when accordions are collapsed, users can scan the headings to
      get a sense of all the content available. Collapsed accordions take up less vertical space on the screen, but can
      reveal more detail with a click.
    </p>
    <div className="usageInfo">
      <strong className="beacon-icon-danger">Don't</strong> over-use accordions. There are times when simply listing the
      content is sufficient instead of putting it in an accordion
      <br />
      <strong className="beacon-icon-danger">Don't</strong> use nested accordions (accordions within accordions).
    </div>
  </>
);

const accessibilityConsiderations = (
  <>
    <p>Accordions should be keyboard accessible or able to be controlled with the keyboard.</p>
    <p>Exposed content should be focusable.</p>
  </>
);

const argTypes = {
  headingType: {
    control: dropdownFromHeadingTypes(),
    defaultValue: 'h3',
  },
};

export const AccordionPrimary: Story = (props) => {
  return (
    <div>
      <Accordion id="first-accordion" title="Simple text-only header" headingType={props.headingType}>
        This contains a simple body with some simple string elements
      </Accordion>
      <Accordion
        id="second-accordion"
        title="Header with TSX code including a"
        details={
          <AccordionCustomHeader>
            <Badge id="info-badge-1" variant={BadgeVariant.info}>
              Info badge
            </Badge>
          </AccordionCustomHeader>
        }
        headingType={props.headingType}
      >
        <p>This content is still very simple but show you can add anything inside of here</p>
      </Accordion>
      <Accordion
        id="third-accordion"
        title="Header on the left and action on the right"
        details={
          <>
            <AccordionLeftHeader> </AccordionLeftHeader>
            <AccordionRightHeader>
              <Button
                id="btn-id"
                type={ButtonType.tertiary}
                onClick={() => {
                  alert('Hello from an accordion');
                }}
              >
                Does nothing
              </Button>{' '}
            </AccordionRightHeader>
          </>
        }
        headingType={props.headingType}
      >
        <p>
          This is also another text only body accordion. Note that for the code on this one, the right hand needs some
          padding.
        </p>
      </Accordion>
    </div>
  );
};

AccordionPrimary.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Accordion"
      description={description}
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
AccordionPrimary.storyName = 'Accordion';
AccordionPrimary.argTypes = argTypes;

export const HandleAToggleEvent: Story = (props) => {
  return (
    <div className="beacon react-beacon">
      <Accordion
        id="toggle-event-accordion"
        title="Click me to see events in the console"
        onToggle={(expanded, event) => {
          console.info(
            `The accordion is now ${expanded ? 'expanded' : 'collapsed'}, the full event captured is:`,
            event
          );
        }}
        headingType={props.headingType}
      >
        Open the developer console to view the events
      </Accordion>
    </div>
  );
};
HandleAToggleEvent.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Accordion Toggle Event"
      description={description}
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
HandleAToggleEvent.storyName = 'Accordion Toggle Event';

export const DisableAnAccordion: Story = () => {
  return (
    <div className="beacon react-beacon">
      <p>
        <Badge id="dummy-badge-1">Just here to show focus</Badge>
      </p>
      <Accordion id="disabled-accordion" title="This accordion cannot be expanded" disabled>
        There is nothing to see here
      </Accordion>
      <p>
        <Badge id="dummy-badge-2">Just here to show focus</Badge>
      </p>
    </div>
  );
};
DisableAnAccordion.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Disabled Accordion"
      description={description}
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
DisableAnAccordion.storyName = 'Disabled Accordion';
DisableAnAccordion.argTypes = argTypes;

const descriptionGroup = (
  <>
    <p>
      Accordions are components that expand or collapse to reveal or hide additional content. Accordions are commonly
      used to reduce the need to scroll when presenting multiple sections of content on a single page.
    </p>

    <p>
      This example shows a set of accordions grouped together so that only one accordion is visible at a time. The
      accordions show the second accordion as defaulting to an <code>expanded</code> state.
    </p>
  </>
);

const whenToUseGroup = (
  <>
    <p>
      Accordions are useful for progressive disclosure: when accordions are collapsed, users can scan the headings to
      get a sense of all the content available. Collapsed accordions take up less vertical space on the screen, but can
      reveal more detail with a click.
    </p>
    <p>
      Accordions in an <code>AccordionGroup</code> can only have one accordion open at once.
    </p>
    <div className="usageInfo">
      <strong className="beacon-icon-danger">Don't </strong> over-use accordions. There are times when simply listing
      the content is sufficient instead of putting it in an accordion
      <br />
      <strong className="beacon-icon-danger">Don't </strong> use nested accordions (accordions within accordions).
    </div>
  </>
);

const accessibilityConsiderationsGroup = (
  <>
    <p>Accordions should be keyboard accessible or able to be controlled with the keyboard.</p>
    <p>Exposed content should be focusable.</p>
  </>
);

export const GroupOfAccordions: Story = (props) => {
  return (
    <AccordionGroup id="accordion-group-1" defaultExpanded="second-accordion">
      <Accordion id="first-accordion" title="Simple text-only header" headingType={props.headingType}>
        This contains a simple body with some simple string elements
      </Accordion>
      <Accordion
        id="second-accordion"
        title="Header with TSX code including a"
        details={
          <AccordionCustomHeader>
            <Badge id="info-badge-2" variant={BadgeVariant.info}>
              Info badge
            </Badge>
          </AccordionCustomHeader>
        }
        headingType={props.headingType}
      >
        <p>This content is still very simple but show you can add anything inside of here</p>
      </Accordion>
      <Accordion
        id="third-accordion"
        title="Header on the left and action on the right"
        details={
          <>
            <AccordionLeftHeader> </AccordionLeftHeader>
            <AccordionRightHeader>
              <Button
                id="btn-id"
                type={ButtonType.tertiary}
                onClick={() => {
                  alert('Hello from an accordion');
                }}
              >
                Does nothing
              </Button>{' '}
            </AccordionRightHeader>
          </>
        }
        headingType={props.headingType}
      >
        <p>
          This is also another text only body accordion. Note that for the code on this one, the right hand needs some
          padding.
        </p>
      </Accordion>
    </AccordionGroup>
  );
};

GroupOfAccordions.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Group of Accordions"
      description={descriptionGroup}
      whenToUse={whenToUseGroup}
      accessibilityConsiderations={accessibilityConsiderationsGroup}
    >
      <ComponentStory />
    </Documentation>
  ),
];
GroupOfAccordions.storyName = 'Group of Accordions';
GroupOfAccordions.argTypes = argTypes;

export const HandleAnExpandEvent: Story = (props) => {
  return (
    <div className="beacon react-beacon">
      <AccordionGroup
        id="expand-event-group"
        onExpand={(newActiveAccordion, event) => {
          console.info(`Expanding a new accordion [${newActiveAccordion}], full event captured is`, event);
        }}
      >
        <Accordion id="expandable-accordion-1" title="First expandable" headingType={props.headingType}>
          First expandable - open dev tools
        </Accordion>
        <Accordion id="expandable-accordion-2" title="Second expandable" headingType={props.headingType}>
          Second expandable - open dev tools
        </Accordion>
      </AccordionGroup>
    </div>
  );
};
HandleAnExpandEvent.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Handle an Accordion Expand Event"
      description={descriptionGroup}
      whenToUse={whenToUseGroup}
      accessibilityConsiderations={accessibilityConsiderationsGroup}
    >
      <ComponentStory />
    </Documentation>
  ),
];
HandleAnExpandEvent.storyName = 'Handle an Accordion Expand Event';
HandleAnExpandEvent.argTypes = argTypes;

const ProblemChild = () => {
  const badString: unknown = undefined;
  // forces this to throw an error while rendering so the error boundary takes over
  return <p>The string has a length of: {(badString as string).length}</p>;
};
export const ProblematicChildren: Story = (props) => {
  return (
    <div className="beacon react-beacon">
      <div className="w-50">
        <AccordionGroup id="accordion-group-with-problematic-children">
          <Accordion id="good-accordion" title="Good accordion">
            This accordion renders properly
          </Accordion>
          <Accordion id="accordion-with-problem-child" title="Accordion with errors">
            <ProblemChild />
          </Accordion>
        </AccordionGroup>
      </div>
    </div>
  );
};
