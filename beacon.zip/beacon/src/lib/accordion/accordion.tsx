import classNames from 'classnames';
import { ReactElement, ReactNode, SyntheticEvent, useEffect, useState } from 'react';
import { Trackable } from '../analytics';
import { HeadingType } from '../heading/heading';
import { WithId } from '../with-id';
import './accordion.scss';
import { AccordionBody } from './internal/accordion-body';
import { AccordionHeader } from './internal/accordion-header';

export type AccordionToggleHandler = (expanded: boolean, event: SyntheticEvent) => void;

// eslint-disable-next-line @typescript-eslint/no-empty-function
const emptyOnToggleHandler: AccordionToggleHandler = (expanded, event) => {};

/**
 * This is used when adding a single custom header which contains other `ReactElement`
 * objects.
 */
export const AccordionCustomHeader = ({ children }: { children: ReactNode }) => {
  return <div className="flex-grow-1">{children}</div>;
};

/**
 * Used in conjunction with `AccordionRightHeader` to render a split accordion header
 * with content on the left and right.
 */
export const AccordionLeftHeader = ({ children }: { children: ReactNode }) => {
  return <div className="flex-grow-1">{children}</div>;
};

/**
 * Used in conjunction with `AccordionLeftHeader` to render a split accordion header
 * with content on the left and right.
 */
export const AccordionRightHeader = ({ children }: { children: ReactNode }) => {
  return <div className="mr-2">{children}</div>;
};

export interface IAccordionProps extends Trackable, WithId {
  /**
   * A string title to display within the accordion header.
   */
  title: string;
  /**
   * A string or `ReactElement` that is either an `AccordionCustomHeader` or both `AccordionLeftHeader`
   * and `AccordionRightHeader`. These help render a customizable header for all accordions.
   */
  details?: ReactElement | string;
  /**
   * Set to `true` to make an `Accordion` be expanded by default.
   */
  expanded?: boolean;
  /**
   * The contents of the body of the accordion.
   */
  children: ReactNode;
  /**
   * Set to `true` to disable the ability to expand/collapse the accordion.
   * This _does not_ affect the `expanded` attribute.
   */
  disabled?: boolean;
  /**
   * Event handler to be invoked when toggling this accordion, when in an `AccordionGroup` use the
   * `onExpand` on the `AccordionGroup` component to determine which accordion has been expanded.
   */
  onToggle?: AccordionToggleHandler;
  /**
   * The type of heading used for the header titles.
   */
  headingType?: HeadingType;
}

/**
 * Represents a single accordion, this can be used for showing a single accordion or
 * a set of accordions that are allowed to be open simulteneously.
 */
export const Accordion = (props: IAccordionProps) => {
  const { expanded, onToggle } = props;
  const [isCurrentlyExpanded, setIsCurrentlyExpanded] = useState<boolean>();
  const onToggleResolved = onToggle ? onToggle : emptyOnToggleHandler;

  const toggleEvent = (event: SyntheticEvent) => {
    onToggleResolved(!isCurrentlyExpanded, event);
    setIsCurrentlyExpanded(!isCurrentlyExpanded);
  };

  useEffect(() => {
    setIsCurrentlyExpanded(expanded);
  }, [expanded]);

  const classes = classNames('accordion-tab', 'accordion-container', {
    'accordion-disabled': props.disabled,
  });

  return (
    <div id={props.id} className={classes}>
      <AccordionHeader
        tracking={props.tracking}
        id={props.id}
        title={props.title}
        details={props.details}
        disabled={props.disabled}
        onToggled={toggleEvent}
        collapsed={!isCurrentlyExpanded}
        headingType={props.headingType}
      />
      {isCurrentlyExpanded && !props.disabled && (
        <AccordionBody children={props.children} expanded={isCurrentlyExpanded}></AccordionBody>
      )}
    </div>
  );
};
