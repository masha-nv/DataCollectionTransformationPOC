export const noop: () => void = () => {
  return;
};

/**
 * Checks if element contains focusable child
 */
export const containsFocusableChildById = (elementId: string): boolean => {
  const element = document.getElementById(elementId);

  if (!element) return false;

  const focusable = element?.querySelector(
    'button:not(:disabled), [href]:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex]:not([tabindex="-1"])'
  ) as HTMLElement;

  return !!focusable;
};

/**
 * Focus on the first focusable child
 */
export const focusOnFirstFocusableChildById = (elementId: string): void => {
  const element = document.getElementById(elementId);
  if (!element) {
    return;
  }
  focusOnFirstFocusableChild(element);
};

/**
 * Focus on the first focusable child
 */
export const focusOnFirstFocusableChild = (element: HTMLElement | null): void => {
  const focusable = element?.querySelector(
    'button:not(:disabled), [href]:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex]:not([tabindex="-1"])'
  ) as HTMLElement;
  if (focusable) {
    focusable.focus();
  }
};

/**
 * Attempts to return the value of the property from an object given a path
 */
export const getPropertyValueFromPath = (
  /* eslint-disable @typescript-eslint/ban-types */
  obj: object | null,
  path: string
): string | object | null => {
  return path
    .replace(']', '')
    .split(/[.[]/)
    .reduce((prev, curr) => (prev ? (prev as Record<string, object>)[curr] : null), obj);
};
/* eslint-enable @typescript-eslint/ban-types */
