import { Meta, Story } from '@storybook/react';
import React from 'react';
import Beacon from '../beacon';
import { Card } from '../cards/card';
import { WithId } from '../with-id';
import banner from './react-beacon-banner.png';

export default {
  component: Beacon,
  title: 'Getting Started',
} as Meta;

/**
 * This styling is highly specific to this component and that is why it's not included in a CSS selector
 */
const positionBannerRotated = {
  width: '571px',
  height: '362px',
  position: 'relative',
  top: '-50px',
  transform: 'rotate(15deg) scale(1.25)',
} as React.CSSProperties;
const bannerImageContainer = {
  height: '195px',
  overflowY: 'hidden',
} as React.CSSProperties;

const latestVersion = process.env.SERVICE_VERSION || 'local-development';

const Banner = () => {
  return (
    <section className="row">
      <div className="col-md-5">
        <div className="m-4 align-middle d-inline-block">
          <h1>React Beacon</h1>
          <p>
            This storybook is intended to showcase and document the basic components that make up the Beacon Design
            System
          </p>
          <p>
            Latest version: <code>{latestVersion}</code>
          </p>
        </div>
      </div>
      <div className="col-md-7">
        <div style={bannerImageContainer}>
          <img src={banner as string} alt="React Beacon banner" title="React Beacon" style={positionBannerRotated} />
        </div>
      </div>
    </section>
  );
};

const BorderlessCard: React.FC = ({ children }) => {
  return (
    <div className="card mb-4">
      <div className="card-body p-0">{children}</div>
    </div>
  );
};

const Section: React.FC<WithId> = ({ id, children }) => {
  return (
    <section className="mt-2 mb-4">
      <Card id={id}>{children}</Card>
    </section>
  );
};

const Installation = () => {
  return (
    <Section id="react-beacon-installation">
      <h2>Installation</h2>
      <p>
        ELIS InternalApp already includes react-beacon, but it can be added to a new project by following these steps:
        <ol className="mt-3">
          <li>
            Install the react-beacon package:
            <code className="ml-2">npm install --save @gov.dhs.uscis.elis/react-beacon</code>
          </li>
          <li>
            Install the yup package:
            <code className="ml-2">npm install --save yup</code>
          </li>
          <li>
            Import the legacy Beacon styling, e.g.:
            <code className="ml-2">
              &lt;link rel=&quot;stylesheet&quot;
              href=&quot;https://elis-beacon-prod.k8s.elis.uscis.dhs.gov/beacon.css&quot; /&gt;
            </code>
          </li>
          <li>
            Import the bundled react-beacon styling, e.g.:
            <code className="ml-2">@import '~@gov.dhs.uscis.elis/react-beacon/beacon.esm.css';</code>
          </li>
          <li>
            Assign the <code>beacon</code> and <code>react-beacon</code> classes to a parent element, e.g.:
            <code className="ml-2">&lt;body class=&quot;beacon react-beacon&quot;&gt;</code>
          </li>
        </ol>
      </p>
    </Section>
  );
};

const SonarBadge = ({ metric }: { metric: string }) => {
  return (
    <a
      href="http://sonar-enterprise.uscis.dhs.gov:9000/dashboard?id=gov.dhs.uscis.react-beacon"
      target="_blank"
      rel="noreferrer"
    >
      <img
        alt={`React Beacon ${metric}`}
        src={`https://elis-apigw-pp.apps2.ocp-nonprod.uscis.dhs.gov/elis-sonar/measure?project=gov.dhs.uscis.react-beacon&metric=${metric}`}
      />
    </a>
  );
};

const ContributingNotes = () => {
  return (
    <Section id="contributing-to-react-beacon">
      <h2>Contributing to React Beacon</h2>
      <p>
        When adding a component to React Beacon make sure it aligns with the{' '}
        <a
          href="https://maestro.dhs.gov/confluence/display/ELIS2/Beacon+Design+System"
          rel="noreferrer"
          target="_blank"
        >
          Beacon Design System
        </a>
        . The goal of this library is to offer standardization of components to be used in the ELIS monolith and its
        microservices.
      </p>
      <p>
        There should be zero components added to this library that contain ELIS specific items (for example things like
        references to cases, form types, ref data, etc. Those belong in the ELIS monolith.
      </p>
    </Section>
  );
};

const CodeQuality = () => {
  return (
    <Section id="quality">
      <h2>Code quality</h2>
      <ul>
        <li>
          <a
            href="https://jenkins-elis-gss.uscis.dhs.gov/job/ELIS-Non-Prod/job/elis-user-interface/job/react-beacon-ci/"
            rel="noreferrer"
            target="_blank"
          >
            <img
              alt="React Beacon build status"
              src="https://jenkins-elis-gss.uscis.dhs.gov/buildStatus/icon?job=ELIS-Non-Prod%2Felis-user-interface%2Freact-beacon-ci"
            />
          </a>
        </li>
        <li>
          <SonarBadge metric="alert_status" />
        </li>
        <li>
          <SonarBadge metric="coverage" />
        </li>
        <li>
          <SonarBadge metric="code_smells" />
        </li>
      </ul>
    </Section>
  );
};

export const Introduction: Story = () => {
  return (
    <div
      className="beacon"
      style={{
        maxWidth: '1024px',
      }}
    >
      <BorderlessCard>
        <Banner />
      </BorderlessCard>
      <Installation />
      <div className="row">
        <div className="col-md-8">
          <ContributingNotes />
        </div>
        <div className="col-md-4">
          <CodeQuality />
        </div>
      </div>
    </div>
  );
};
export const CoreNamingConvention: Story = () => {
  return (
    <div
      className="beacon"
      style={{
        maxWidth: '1024px',
      }}
    >
      <h2>Core Component Naming Guidelines</h2>
      <ul>
        <li>All stories must include the component name</li>
        <li>
          List the standard component first (for example, Accordion); list additional versions alphabetically below
        </li>
        <li>
          For components with defined hierarchy (Primary, Secondary, Tertiary), list using the hierarchy instead of
          alphabetically
        </li>
        <li>Use title case for capitalization</li>
      </ul>
    </div>
  );
};
CoreNamingConvention.storyName = 'Core Component Naming Guidelines';
