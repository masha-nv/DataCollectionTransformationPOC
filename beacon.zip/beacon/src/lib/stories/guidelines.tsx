import React, { ReactNode } from 'react';
import './guidelines.scss';

export const Guidelines = ({ summary, children }: { summary: ReactNode; children: ReactNode }) => {
  let summaryElement = <summary className="summary d-flex">{summary}</summary>;
  if (typeof summary === 'string') {
    summaryElement = (
      <summary className="summary d-flex">
        <span className="flex-grow-1">
          <h4>{summary}</h4>
        </span>
      </summary>
    );
  }

  return (
    <div>
      {' '}
      {summaryElement}
      {children}
    </div>
  );
};
