import React, { ReactNode } from 'react';
import { Guidelines } from './guidelines';
import classNames from 'classnames';
import './documentation.scss';

// `no-explicit-any` exemption is used here to allow this function to work with enums of any type
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const enumKeys = <T,>(enumReference: T) => {
  // filter out react-docgen entries added to types so that we can use them as full keys
  return Object.keys(enumReference).filter((key) => key !== 'displayName' && key !== '__docgenInfo') as (keyof T)[];
};

// `no-explicit-any` exemption is used here to allow this function to work with enums of any type
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const dropdownFromEnum = (enumReference: any) => {
  // returns the dynamic configuration necessary to display a dropdown for a prop in storybook
  return {
    type: 'select',
    options: enumKeys(enumReference),
  };
};

export const dropdownFromHeadingTypes = () => {
  // returns the dynamic configuration necessary to display a dropdown for a prop in storybook
  return {
    type: 'select',
    options: ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'],
  };
};

export const dropdownFromHeadingStyles = () => {
  // returns the dynamic configuration necessary to display a dropdown for a prop in storybook
  return {
    type: 'select',
    options: ['xxl', 'xl', 'l', 'm', 's', 'xs'],
  };
};

export interface IDocumentation {
  /**
   * The name of the component
   */
  name: string;
  description?: ReactNode;
  whenToUse?: ReactNode;
  accessibilityConsiderations?: ReactNode;
  languageGuidelines?: ReactNode;
  children: ReactNode;
  darkMode?: boolean;
}
export function Documentation(props: IDocumentation) {
  const description = props.description || 'No additional description';
  const { whenToUse, accessibilityConsiderations, languageGuidelines } = props;

  return (
    <section className={classNames('beacon react-beacon', { dark: props.darkMode })}>
      <h2>{props.name}</h2>
      <p>{description}</p>
      <div className="story-body">{props.children}</div>
      {(whenToUse || accessibilityConsiderations || languageGuidelines) && (
        <section>
          <h3 id="guidelinesId">Usage Guidelines</h3>
          {whenToUse && <Guidelines summary="When to use">{whenToUse}</Guidelines>}
          {accessibilityConsiderations && (
            <Guidelines summary="Accessibility Considerations">{accessibilityConsiderations}</Guidelines>
          )}
          {languageGuidelines && <Guidelines summary="Language Guidelines">{languageGuidelines}</Guidelines>}
        </section>
      )}
    </section>
  );
}
