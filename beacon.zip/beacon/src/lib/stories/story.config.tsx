export const a11yConfig = {
  element: '.story-body', // ensures that only the story body is checked for accessibility
};
