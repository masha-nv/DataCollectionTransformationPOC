export enum StoryBadge {
  NEEDS_508 = 'needs508',
  READY = 'ready',
  BETA = 'beta',
  ESPRESSO_REVIEW = 'espresso',
}
