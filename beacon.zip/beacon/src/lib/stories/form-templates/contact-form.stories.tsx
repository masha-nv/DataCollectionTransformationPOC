import React from 'react';
import { Meta, Story } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { StoryBadge } from '../story-badge';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { TextInput, TextInputType } from '../../forms/text-input/text-input';
import { FormGroup } from '../../forms/form-group/form-group';
import { hookFormUtils } from '../../forms/utils/hookform-utils';
import { Documentation } from '..';
import { a11yConfig } from '../story.config';
import { SubmitButton } from '../../button/submit-button';
import { RequiredFieldLegend } from '../../forms/required-field-legend/required-field-legend';
import { Label } from '../../forms/label/label';

export default {
  title: 'Form Templates/Contact Form',
  parameters: {
    badges: [StoryBadge.BETA],
    a11y: a11yConfig,
  },
} as Meta;

interface ContactForm {
  firstName: string;
  lastName: string;
  email: string;
  address: {
    streetaddress: string;
    city: string;
    state: string;
    zipcode: string;
  };
}

export const ContactForm: Story = () => {
  /*
  // Required Imports
  import { useForm } from 'react-hook-form';
  import { yupResolver } from '@hookform/resolvers/yup';
  import * as yup from 'yup';
  import { FormGroup, TextInput, TextInputType, SubmitButton, hookFormUtils } from '@gov.dhs.uscis.elis/react-beacon';
  */
  // eslint-disable-next-line no-template-curly-in-string
  const requiredMessage = '${path} is required';

  /**
   * Object schema for the form
   */
  const schema = yup.object().shape({
    firstName: yup.string().required(requiredMessage).label('First Name'),
    lastName: yup.string().required(requiredMessage).label('Last Name'),
    email: yup.string().required(requiredMessage).email().label('Email'),
    address: yup.object().shape({
      streetaddress: yup.string().required(requiredMessage).label('Street Address'),
      city: yup.string().required(requiredMessage).label('City'),
      state: yup.string().required(requiredMessage).label('State'),
      zipcode: yup
        .string()
        .required(requiredMessage)
        .matches(/^\d{5}(?:[-\s]\d{4})?$/, 'Zip Code is not valid')
        .label('Zip Code'),
    }),
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    // mode: 'onTouched' ,
    resolver: yupResolver(schema) /* A valid yup schema*/,
    defaultValues: {
      firstName: 'John',
    } as ContactForm,
  });
  const onSubmit = (data: unknown) => action('submit-action')(data);
  const onError = (data: unknown) => action('error-action')(data);

  return (
    <div className="w-50">
      <form onSubmit={handleSubmit(onSubmit, onError)}>
        <RequiredFieldLegend />
        <FormGroup id="fg-firstName" errorMessages={hookFormUtils.getErrorMessages(errors, 'firstName')}>
          <Label htmlFor="firstName" required>
            First Name
          </Label>
          <TextInput id="firstName" {...register('firstName')} />
        </FormGroup>
        <FormGroup id="fg-lastName" errorMessages={hookFormUtils.getErrorMessages(errors, 'lastName')}>
          <Label htmlFor="lastName" required>
            Last Name
          </Label>
          <TextInput id="lastName" {...register('lastName')} />
        </FormGroup>
        <FormGroup id="fg-email" errorMessages={hookFormUtils.getErrorMessages(errors, 'email')}>
          <Label htmlFor="email" required>
            Email
          </Label>
          <TextInput type={TextInputType.email} id="email" {...register('email')} />
        </FormGroup>
        <div>
          <fieldset>
            <legend>Address</legend>
            <FormGroup
              id="fg-streetaddress"
              errorMessages={hookFormUtils.getErrorMessages(errors, 'address.streetaddress')}
            >
              <Label htmlFor="streetaddress" required>
                Street Address
              </Label>
              <TextInput id="streetaddress" {...register('address.streetaddress')} />
            </FormGroup>
            <FormGroup id="fg-city" errorMessages={hookFormUtils.getErrorMessages(errors, 'address.city')}>
              <Label htmlFor="city" required>
                City
              </Label>
              <TextInput id="city" {...register('address.city')} />
            </FormGroup>
            <FormGroup id="fg-state" errorMessages={hookFormUtils.getErrorMessages(errors, 'address.state')}>
              <Label htmlFor="state" required>
                State
              </Label>
              <TextInput id="state" {...register('address.state')} />
            </FormGroup>
            <FormGroup id="fg-zipcode" errorMessages={hookFormUtils.getErrorMessages(errors, 'address.zipcode')}>
              <Label htmlFor="zipcode" required>
                Zip code
              </Label>
              <TextInput id="zipcode" {...register('address.zipcode')} />
            </FormGroup>
          </fieldset>
        </div>
        <SubmitButton id="submit">Submit</SubmitButton>
      </form>
    </div>
  );
};

ContactForm.decorators = [
  (Story: Story) => (
    <Documentation
      name="Contact Form"
      description={'Contact Form built with react-beacon Form Components with validation'}
    >
      <Story />
    </Documentation>
  ),
];
