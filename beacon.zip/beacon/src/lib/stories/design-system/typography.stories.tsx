import React from 'react';
import { Meta, Story } from '@storybook/react';
import { Guidelines } from '../guidelines';

import './typography.scss';
import '../../root-variables.scss';
import { StoryBadge } from '../story-badge';
import { Documentation } from '../documentation';
import { Radio } from '../../forms/radio/radio';
import { RadioOption } from '../../forms/radio/radio-option';
import { Heading } from '../../heading/heading';
import { DataView } from '../../data-view/data-view';
import { IDataViewFieldProps } from '../../data-view/data-view-types';

export default {
  title: 'Styling/Typography',
  parameters: {
    badges: [StoryBadge.READY],
  },
} as Meta;

const greenDo = <span className="text-success">Do</span>;

/**
 * Documentation for your story goes here, this supports Markdown, so it means I can reference `Beacon` the component and _emphasize_ other items.
 */
export const Typography: Story = () => {
  return (
    <div className="beacon">
      <h1>Typography</h1>
      <p>
        The ELIS typeface is Source Sans Pro, an open-source sans serif typeface designed for legibility that provides
        clear headers and highly readable body text.
      </p>
    </div>
  );
};

export const Headings: Story = () => {
  return (
    <>
      <Heading headingType="h1">Heading level 1</Heading>
      <Heading headingType="h2">Heading level 2</Heading>
      <Heading headingType="h3">Heading level 3</Heading>
      <Heading headingType="h4">Heading level 4</Heading>
      <Heading headingType="h5">Heading level 5</Heading>
      <Heading headingType="h6">Heading level 6</Heading>

      <Heading headingType="h1">Header with lead</Heading>
      <p className="lead">Lead paragraph. This is a paragraph with larger font size default.</p>
      <p>Regular paragraph. This is every other paragraph.</p>
    </>
  );
};

Headings.storyName = 'Headings';

Headings.decorators = [
  (Story: Story) => (
    <Documentation
      name="Headings"
      description={
        <p>
          Headings describe what’s on a page or within a section of the page. For good UX as well as accessibility, use
          them to show the semantic hierarchy: H1 for titles or the most important heading, and H2, H3, H4, etc., for
          the next levels down.
        </p>
      }
      languageGuidelines={
        <>
          <p>Take into consideration the following guidelines when using headings:</p>
          <ul>
            <li>
              <strong>{greenDo} make the headings, including page titles, meaningful</strong> by using brief, clear,
              plain language and avoiding jargon
            </li>
            <li>
              <strong>
                {greenDo} use <em>title case</em> for headings
              </strong>
              , including page settings
            </li>
          </ul>
        </>
      }
    >
      <Story />
    </Documentation>
  ),
];

export const BodyText: Story = () => {
  return (
    <article className="beacon">
      <h1>Body Text</h1>
      <p>Main text used in paragraphs and other non-heading text on a page.</p>
      <Guidelines summary="Language guidelines">
        <>
          <strong>
            <span className="text-danger">Don't</span> overuse emphasizers
          </strong>{' '}
          such as bold, italic, and all caps when writing. Use one or maybe two of these emphasizers in a text grouping
        </>
      </Guidelines>
    </article>
  );
};

export const Lists: Story = () => {
  return (
    <>
      <div>
        <h3>Ordered List</h3>
        <ol>
          <li>Washington</li>
          <li>Adams</li>
          <li>Jefferson</li>
          <li>Madison</li>
        </ol>
      </div>
      <div>
        <h3>Unordered List</h3>
        <ul>
          <li>Gryffindor</li>
          <li>Hufflepuff</li>
          <li>Ravenclaw</li>
          <li>Slytherin</li>
        </ul>
      </div>
    </>
  );
};

Lists.storyName = 'Lists';

Lists.decorators = [
  (Story: Story) => (
    <Documentation
      name="Lists"
      description={
        <p>
          Lists organize written information for users, and are more easily scanned visually, which provides better
          usability.
        </p>
      }
      whenToUse={
        <>
          <p>
            <strong>Ordered Lists</strong> should be used to group a collection of items where order is important.
          </p>
          <p>
            <strong>Unordered Lists</strong> should be used to group a collection of items with no special order or
            sequence
          </p>
        </>
      }
      languageGuidelines={
        <ul>
          <li>
            <strong>{greenDo}</strong> use a numbered list <strong>only</strong> to convey order or steps required to
            complete a process. Otherwise, <strong>use a bulleted list</strong>
          </li>
          <li>
            <strong>{greenDo} begin each list item</strong> with a capital letter
          </li>
          <li>
            <strong>
              {greenDo} use <em>sentence case</em>
            </strong>{' '}
            for list items
          </li>
        </ul>
      }
    >
      <Story />
    </Documentation>
  ),
];

export const Links: Story = () => {
  return (
    <>
      <p>
        <a href="#links-and-support-text">Link</a>
      </p>

      <p>
        <b>
          <a href="#links-and-support-text">Bold Link</a>
        </b>
      </p>
    </>
  );
};

Links.storyName = 'Links';

Links.decorators = [
  (Story: Story) => (
    <Documentation
      name="Links"
      description={' '}
      whenToUse={
        <p>
          Links should be used to navigate to another page. Links are able to navigate to elements of the same page but
          the sidebar is the preferable approach for this action
        </p>
      }
    >
      <Story />
    </Documentation>
  ),
];
export const SupportText: Story = () => {
  return <p className="support-text">Support Text</p>;
};

SupportText.decorators = [
  (Story: Story) => (
    <Documentation
      name="Support Text"
      description={' '}
      whenToUse={
        <p>
          Support text should be used to display information about the surrounding content – for example, for the *
          “Required” notation for fields
        </p>
      }
    >
      <Story />
    </Documentation>
  ),
];
export const TitleCase: Story = () => {
  return (
    <>
      <p>
        <u>
          <strong>Heading/page titles</strong>
        </u>
        <br />
        Risk and Fraud
        <br />
        View Account Information
        <br />
        Family Pack and Associated Cases
      </p>
      <p>
        <u>
          <strong>Labels for buttons, table rows, or drop-downs </strong>
        </u>
        <br />
        Complete Task
        <br />
        Date of Birth
        <br />
        Sign Up
      </p>
    </>
  );
};

TitleCase.storyName = 'Title Case';

TitleCase.decorators = [
  (Story: Story) => (
    <Documentation
      name="Title Case"
      description={
        <>
          <p>
            <strong>Use Title Case for Titles, Labels, and Headers</strong>
          </p>
          <p>When using title case, capitalize most key words, and lowercase most smaller ones.</p>
        </>
      }
      whenToUse={
        <>
          <p>Use title case with these elements:</p>
          <ul>
            <li>Buttons</li>
            <li>Titles</li>
            <ul>
              <li>
                All page and sub-section headings (H1, H2,H3, etc.)– <strong>except H6</strong>, which is always
                all-caps
              </li>
              <li>
                Titles of all elements: accordions,tabs, cards, modals, side navigation, form controls, icons, and tags
              </li>
            </ul>
            <li>Labels</li>
            <li>Table row and column labels</li>
            <li>Form control labels</li>
            <li>Horizontal stepper step labels</li>
          </ul>
        </>
      }
      languageGuidelines={
        <>
          <strong>Capitalize All Words Except These</strong>
          <ul>
            <li>
              Capitalize <strong>all words</strong> in titles and labels <strong>except</strong>: a, an, the, at, by,
              for, in, of, on, to, up, and, as, but, or, nor
            </li>
            <li>
              <strong>But:</strong> Capitalize these words if they are the <strong>first or last</strong> word of a
              title or label. For example, a button with the title "Sign Up" or a column label "Uploaded On"
            </li>
          </ul>
        </>
      }
    >
      <Story />
    </Documentation>
  ),
];

export const SentenceCase: Story = () => {
  return (
    <>
      <p>
        <u>
          <strong>Instructions</strong>
        </u>
        <br />
        Please review the referred case information to clear the petitioner or determine if AWA relates or is possible.
      </p>
      <p>
        <u>
          <strong>Checkbox and radio button options</strong>
        </u>
        <br />
        <Radio id="sentence-photograph" name="photograph">
          <RadioOption id="sentence-approve" value={1} defaultChecked>
            Approve photograph for printing
          </RadioOption>
          <RadioOption id="sentence-disapprove" value={2}>
            Disapprove photograph for printing
          </RadioOption>
        </Radio>
      </p>
    </>
  );
};

SentenceCase.storyName = 'Sentence Case';

SentenceCase.decorators = [
  (Story: Story) => (
    <Documentation
      name="Sentence Case"
      description={
        <>
          <p>
            <strong>Use Sentence Case for Instructional and Descriptive Text</strong>
          </p>
          <p>
            With sentence case, capitalize only the <strong>first word</strong> of the phrase or sentence, along with
            any <strong>proper nouns</strong>.
          </p>
        </>
      }
      whenToUse={
        <>
          <p>Use sentence case for the text types below:</p>
          <ul>
            <li>Instructions</li>
            <li>Explanatory or descriptive text, including:</li>
            <ul>
              <li>Body text in modals, tooltips, and popovers</li>
              <li>Descriptive text in a horizontal stepper</li>
            </ul>
            <li>Numbered or bulleted lists</li>
            <li>Checkbox and radio button options</li>
            <li>Drop-down menus</li>
            <li>Asterisks -- for example, "Indicates required field"</li>
            <li>Error and informational messages(such as in butterbars or flyouts)</li>
          </ul>
        </>
      }
    >
      <Story />
    </Documentation>
  ),
];

const createField = (style: React.CSSProperties) => {
  return () => <div style={style}>Elis is a great website!</div>;
};

const createFieldSpacing = (style: React.CSSProperties, isPadding: boolean) => {
  return () => (
    <div style={{ display: 'flex', borderStyle: 'solid', borderWidth: 1, marginRight: isPadding === true ? 80 : 0 }}>
      <div style={style}>Elis</div>
      <div style={style}>is</div>
      <div style={style}>a</div>
      <div style={style}>great</div>
      <div style={style}>website!</div>
    </div>
  );
};

const fontWeightFields: IDataViewFieldProps<string>[] = [
  {
    label: '--beacon-font-weight-light',
    readonly: createField({ fontWeight: 'var(--beacon-font-weight-light)' as React.CSSProperties['fontWeight'] }),
  },
  {
    label: '--beacon-font-weight-regular',
    readonly: createField({ fontWeight: 'var(--beacon-font-weight-regular)' as React.CSSProperties['fontWeight'] }),
  },
  {
    label: '--beacon-font-weight-medium',
    readonly: createField({ fontWeight: 'var(--beacon-font-weight-medium)' as React.CSSProperties['fontWeight'] }),
  },
  {
    label: '--beacon-font-weight-semibold',
    readonly: createField({ fontWeight: 'var(--beacon-font-weight-semibold)' as React.CSSProperties['fontWeight'] }),
  },
  {
    label: '--beacon-font-weight-bold',
    readonly: createField({ fontWeight: 'var(--beacon-font-weight-bold)' as React.CSSProperties['fontWeight'] }),
  },
];

const fontSizeFields: IDataViewFieldProps<string>[] = [
  {
    label: '--beacon-font-size-2xs',
    readonly: createField({ fontSize: 'var(--beacon-font-size-2xs)' }),
  },
  {
    label: '--beacon-font-size-xs',
    readonly: createField({ fontSize: 'var(--beacon-font-size-xs)' }),
  },
  {
    label: '--beacon-font-size-s',
    readonly: createField({ fontSize: 'var(--beacon-font-size-s)' }),
  },
  {
    label: '--beacon-font-size-m',
    readonly: createField({ fontSize: 'var(--beacon-font-size-m)' }),
  },
  {
    label: '--beacon-font-size-l',
    readonly: createField({ fontSize: 'var(--beacon-font-size-l)' }),
  },
  {
    label: '--beacon-font-size-xl',
    readonly: createField({ fontSize: 'var(--beacon-font-size-xl)' }),
  },
  {
    label: '--beacon-font-size-2xl',
    readonly: createField({ fontSize: 'var(--beacon-font-size-2xl)' }),
  },
  {
    label: '--beacon-font-size-3xl',
    readonly: createField({ fontSize: 'var(--beacon-font-size-3xl)' }),
  },
];

const lineHeightFields: IDataViewFieldProps<string>[] = [
  {
    label: '--beacon-line-height-xs',
    readonly: createField({ lineHeight: 'var(--beacon-line-height-xs)' }),
  },
  {
    label: '--beacon-line-height-s',
    readonly: createField({ lineHeight: 'var(--beacon-line-height-s)' }),
  },
  {
    label: '--beacon-line-height-m',
    readonly: createField({ lineHeight: 'var(--beacon-line-height-m)' }),
  },
  {
    label: '--beacon-line-height-l',
    readonly: createField({ lineHeight: 'var(--beacon-line-height-l)' }),
  },
  {
    label: '--beacon-line-height-xl',
    readonly: createField({ lineHeight: 'var(--beacon-line-height-xl)' }),
  },
  {
    label: '--beacon-line-height-2xl',
    readonly: createField({ lineHeight: 'var(--beacon-line-height-2xl)' }),
  },
];

const paddedSpacingFields: IDataViewFieldProps<string>[] = [
  {
    label: '--beacon-spacing-none',
    readonly: createFieldSpacing({ padding: 'var(--beacon-spacing-none)', borderWidth: 1, borderStyle: 'solid' }, true),
  },
  {
    label: '--beacon-spacing-xs',
    readonly: createFieldSpacing({ padding: 'var(--beacon-spacing-xs)', borderWidth: 1, borderStyle: 'solid' }, true),
  },
  {
    label: '--beacon-spacing-s',
    readonly: createFieldSpacing({ padding: 'var(--beacon-spacing-s)', borderWidth: 1, borderStyle: 'solid' }, true),
  },
  {
    label: '--beacon-spacing-m',
    readonly: createFieldSpacing({ padding: 'var(--beacon-spacing-m)', borderWidth: 1, borderStyle: 'solid' }, true),
  },
  {
    label: '--beacon-spacing-l',
    readonly: createFieldSpacing({ padding: 'var(--beacon-spacing-l)', borderWidth: 1, borderStyle: 'solid' }, true),
  },
  {
    label: '--beacon-spacing-xl',
    readonly: createFieldSpacing({ padding: 'var(--beacon-spacing-xl)', borderWidth: 1, borderStyle: 'solid' }, true),
  },
];

const marginSpacingFields: IDataViewFieldProps<string>[] = [
  {
    label: '--beacon-spacing-none',
    readonly: createFieldSpacing(
      {
        margin: 'var(--beacon-spacing-none)',
        padding: 'var(--beacon-spacing-s)',
        borderWidth: 1,
        borderStyle: 'solid',
      },
      false
    ),
  },
  {
    label: '--beacon-spacing-xs',
    readonly: createFieldSpacing(
      { margin: 'var(--beacon-spacing-xs)', padding: 'var(--beacon-spacing-s)', borderWidth: 1, borderStyle: 'solid' },
      false
    ),
  },
  {
    label: '--beacon-spacing-s',
    readonly: createFieldSpacing(
      { margin: 'var(--beacon-spacing-s)', padding: 'var(--beacon-spacing-s)', borderWidth: 1, borderStyle: 'solid' },
      false
    ),
  },
  {
    label: '--beacon-spacing-m',
    readonly: createFieldSpacing(
      { margin: 'var(--beacon-spacing-m)', padding: 'var(--beacon-spacing-s)', borderWidth: 1, borderStyle: 'solid' },
      false
    ),
  },
  {
    label: '--beacon-spacing-l',
    readonly: createFieldSpacing(
      { margin: 'var(--beacon-spacing-l)', padding: 'var(--beacon-spacing-s)', borderWidth: 1, borderStyle: 'solid' },
      false
    ),
  },
  {
    label: '--beacon-spacing-xl',
    readonly: createFieldSpacing(
      { margin: 'var(--beacon-spacing-xl)', padding: 'var(--beacon-spacing-s)', borderWidth: 1, borderStyle: 'solid' },
      false
    ),
  },
];

export const FontVariables: Story = () => {
  return (
    <>
      <p>
        <u>
          <strong style={{ fontSize: 'var(--beacon-font-size-xl)' }}>Examples</strong>
        </u>
        <br />
        Here are examples of each variable being used:
      </p>
      <DataView id={'font-story-data-view'} title={'Font weight examples'} data={''} fields={fontWeightFields} />
      <DataView id={'font-story-data-view'} title={'Font size examples'} data={''} fields={fontSizeFields} />
      <DataView id={'font-story-data-view'} title={'Line height examples'} data={''} fields={lineHeightFields} />
      <DataView id={'font-story-data-view'} title={'Padded spacing examples'} data={''} fields={paddedSpacingFields} />
      <DataView id={'font-story-data-view'} title={'Margin spacing examples'} data={''} fields={marginSpacingFields} />
    </>
  );
};

FontVariables.storyName = 'Font Variables';

FontVariables.decorators = [
  (Story: Story) => (
    <Documentation
      name="Font Variables"
      description={
        <>
          <p>
            Font variables are global css variables that allow you to customize your fonts, they can be found in the
            root-variables.scss file inside react-beacon.
          </p>
          <p>Use them by replacing the css rule with the equivelent css variable.</p>
          <p>
            <strong>Example:</strong>
          </p>
          <p style={{ color: 'var(--beacon-color-red-5)' }}>fontSize = 34px;</p>
          <p style={{ color: 'var(--beacon-color-green-5)' }}>fontSize = var(--beacon-font-size-3xl);</p>
          <p style={{ color: 'var(--beacon-color-green-5)' }}>
            Inline: style=&#123;&#123;fontSize = &#39;var(--beacon-font-size-3xl)&#39;&#125;&#125;
          </p>
        </>
      }
    >
      <Story />
    </Documentation>
  ),
];
