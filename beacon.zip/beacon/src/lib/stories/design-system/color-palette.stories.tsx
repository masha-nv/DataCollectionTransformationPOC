import React from 'react';
import { Meta, Story } from '@storybook/react';
import { Guidelines } from '../guidelines';
import { StoryBadge } from '../story-badge';
import './color-palette.scss';

export default {
  title: 'Styling/Color Palette',
  parameters: {
    badges: [StoryBadge.READY],
  },
} as Meta;

enum ColorStoryElementType {
  square = 'color-square',
  blockLarge = 'color-block-large',
  blockSmall = 'color-block-small',
}

interface IColorStoryProps {
  name: string;
  colorHex: string;
  type?: ColorStoryElementType;
  description: string;
}

const ColorStoryElement: Story<IColorStoryProps> = ({
  name,
  colorHex,
  type = ColorStoryElementType.square,
  description,
}: IColorStoryProps) => {
  return (
    <div className={`${type}-spacing`}>
      <div className={`bg-${name} ${type}`}></div>
      <p className="mb-1">
        <strong>{colorHex}</strong>
      </p>
      <p className="mb-1">{name}</p>
      <p className="mb-1">
        <small>
          <em>{description}</em>
        </small>
      </p>
    </div>
  );
};

interface IVarColorStoryProps {
  name: string;
  colorHex: string;
  type?: ColorStoryElementType;
  description: string;
}

const VarColorStoryElement: Story<IVarColorStoryProps> = ({
  name,
  colorHex,
  type = ColorStoryElementType.square,
  description,
}: IColorStoryProps) => {
  return (
    <div className={`${type}-spacing`}>
      <div style={{ backgroundColor: `var(${name})` }} className={`${type}`}></div>
      <p className="mb-1">
        <strong>{colorHex}</strong>
      </p>
      <p className="mb-1">{name}</p>
      <p className="mb-1">
        <small>
          <em>{description}</em>
        </small>
      </p>
    </div>
  );
};

export const ColorContrastCompliance: Story = () => {
  return (
    <section className="beacon">
      <h2>Color Contrast Compliance</h2>
      <p>
        Make sure colors for text have sufficient contrast with the background (a ratio of 4.5:1) to be readable by all
        users (WCAG’s AA-level). Use a color contrast checker such as{' '}
        <a href="https://webaim.org/resources/contrastchecker/">WebAIM</a>.
      </p>
      <Guidelines summary="508 considerations">
        <>
          <p>Information that is being provided by color must also be represented textually on the screen.</p>

          <p>Meaningful images and text must have a background to foreground contrast ratio of 4.5:1.</p>
        </>
      </Guidelines>
    </section>
  );
};

export const PrimaryColors: Story = () => {
  return (
    <section className="beacon">
      <h2>Primary Colors</h2>
      <p>
        The ELIS palette's primary colors are blue, gray, and white. Blue is commonly associated with trust, confidence,
        and sincerity; it also used to represent calmness and responsibility.
      </p>
      <div className="story-body">
        <div className="color-details d-flex flex-wrap">
          <ColorStoryElement name="color-primary" colorHex="#0071bb" description="Used for: links, button" />
          <ColorStoryElement name="color-primary-darker" colorHex="#205493" description="Used for: hover effect" />
          <ColorStoryElement name="color-primary-darkest" colorHex="#122E51" description="Used for: links on-click" />
          <ColorStoryElement name="color-base" colorHex="#323A44" description="Used for: text" />
          <ColorStoryElement name="color-disabled" colorHex="#AEB0B5" description="Used for: disabled state" />
        </div>
      </div>
    </section>
  );
};

export const BackgroundColors: Story = () => {
  return (
    <section className="beacon">
      <h2>Background Colors</h2>
      <p>
        ELIS uses black, gray, and white largely for background blocks and large content areas. When alternating between
        color tones, be sure to use enough contrast between adjacent colors.
      </p>
      <div className="story-body">
        <div className="color-details d-flex flex-wrap">
          <ColorStoryElement name="color-gray-light" colorHex="#F4F4F4" description="Used for: table headers" />
          <ColorStoryElement
            name="color-gray-lightest"
            colorHex="#FAFAFA"
            description="Used for: Table subheaders, card bg"
          />
          <ColorStoryElement name="color-white" colorHex="#FFFFFF" description="Used for: Background" />
          <ColorStoryElement name="color-base" colorHex="#323A44" description="Used for: Tooltip background" />
        </div>
      </div>
    </section>
  );
};

export const ContentSpecificColors: Story = () => {
  return (
    <section className="beacon">
      <h2>Content-Specific Colors</h2>
      <p>
        Use these colors primarily for content-specific needs, such as alerts and illustrations. They should never
        overpower the primary colors.
      </p>
      <div className={`story-body`}>
        <div className="color-details d-flex flex-wrap">
          <div className="color-block-group d-flex flex-row">
            <ColorStoryElement
              name="color-info"
              colorHex="#4094CC"
              description="Used for: Info"
              type={ColorStoryElementType.blockLarge}
            />
            <ColorStoryElement
              name="color-info-lightest"
              colorHex="#E6F1F8"
              description="Used for: Info background"
              type={ColorStoryElementType.blockSmall}
            />
          </div>
          <div className="color-block-group d-flex flex-row">
            <ColorStoryElement
              name="color-warning"
              colorHex="#FDB81E"
              description="Used for: Warning"
              type={ColorStoryElementType.blockLarge}
            />
            <ColorStoryElement
              name="color-warning-lightest"
              colorHex="#FFF1D2"
              description="Used for: Warning background"
              type={ColorStoryElementType.blockSmall}
            />
          </div>
          <div className="color-block-group d-flex flex-row">
            <ColorStoryElement
              name="color-success"
              colorHex="#2C7E3E"
              description="Used for: Success"
              type={ColorStoryElementType.blockLarge}
            />
            <ColorStoryElement
              name="color-success-lightest"
              colorHex="#E9F9E3"
              description="Used for: Success background"
              type={ColorStoryElementType.blockSmall}
            />
          </div>
          <div className="color-block-group d-flex flex-row">
            <ColorStoryElement
              name="color-error"
              colorHex="#E21C3D"
              description="Used for: Error, flags"
              type={ColorStoryElementType.blockLarge}
            />
            <ColorStoryElement
              name="color-error-lightest"
              colorHex="#FFEFEF"
              description="Used for: Error background"
              type={ColorStoryElementType.blockSmall}
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export const Grayscale: Story = () => {
  return (
    <section className="beacon">
      <h2>Grayscale</h2>
      <p>Use this limited set of grays for text, background colors, outlines, and disabled states.</p>
      <div className={`story-body`}>
        <div className="color-details d-flex flex-wrap">
          <ColorStoryElement
            name="color-gray-darkest"
            colorHex="#323A44"
            description="Used for: text, tooltip backgrounds"
            type={ColorStoryElementType.blockLarge}
          />
          <ColorStoryElement
            name="color-gray-dark"
            colorHex="#686C76"
            description="Used for: Lighter text"
            type={ColorStoryElementType.blockSmall}
          />
          <ColorStoryElement
            name="color-disabled"
            colorHex="#AEB0B5"
            description="Used for: disabled state"
            type={ColorStoryElementType.blockSmall}
          />
          <ColorStoryElement
            name="color-gray-medium"
            colorHex="#D6D7D9"
            description="Used for: outlines"
            type={ColorStoryElementType.blockSmall}
          />
          <ColorStoryElement
            name="color-gray-light"
            colorHex="#F4F4F4"
            description="Used for: table headers"
            type={ColorStoryElementType.blockSmall}
          />
          <ColorStoryElement
            name="color-gray-lightest"
            colorHex="#FAFAFA"
            description="Used for: table subheaders"
            type={ColorStoryElementType.blockSmall}
          />
        </div>
      </div>
    </section>
  );
};

export const CSSColorVariables: Story = () => {
  return (
    <section className="beacon react-beacon">
      <h2>CSS Color Variables</h2>
      <p>
        These variables are globally defined on the :root level and should be accessable to anything that imports
        react-beacon CSS.
      </p>
      <p>Use them by referencing their variable names directly in place of color codes</p>
      <div className={`story-body`}>
        <h1>Grayscale</h1>
        <div className="color-details color-block-group d-flex flex-row">
          <VarColorStoryElement
            name="--beacon-color-white"
            colorHex="#FFFFFF"
            description=""
            type={ColorStoryElementType.blockSmall}
          />
          <VarColorStoryElement
            name="--beacon-color-black"
            colorHex="#000000"
            description=""
            type={ColorStoryElementType.blockSmall}
          />
        </div>
        <div className="color-details d-flex flex-wrap">
          <div className="color-block-group d-flex flex-row">
            <VarColorStoryElement
              name="--beacon-color-gray-0"
              colorHex="#FAFAFA"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-gray-1"
              colorHex="#F4F4F4"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-gray-2"
              colorHex="#E7E8E8"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-gray-3"
              colorHex="#D6D7D9"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
          </div>
          <div className="color-block-group d-flex flex-row">
            <VarColorStoryElement
              name="--beacon-color-gray-4"
              colorHex="#AEB0B5"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-gray-5"
              colorHex="#686C76"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-gray-6"
              colorHex="#323A44"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-gray-7"
              colorHex="#23282F"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
          </div>
        </div>
        <h1>Purples</h1>
        <div className="color-details d-flex flex-wrap">
          <div className="color-block-group d-flex flex-row">
            <VarColorStoryElement
              name="--beacon-color-purple-0"
              colorHex="#F5EFFA"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-purple-1"
              colorHex="#EEE2F6"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-purple-2"
              colorHex="#CEBBDF"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-purple-3"
              colorHex="#AD94C7"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
          </div>
          <div className="color-block-group d-flex flex-row">
            <VarColorStoryElement
              name="--beacon-color-purple-4"
              colorHex="#8C6CAE"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-purple-5"
              colorHex="#6C4597"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-purple-6"
              colorHex="#59377B"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-purple-7"
              colorHex="#462C60"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
          </div>
        </div>
        <h1>Greens</h1>
        <div className="color-details d-flex flex-wrap">
          <div className="color-block-group d-flex flex-row">
            <VarColorStoryElement
              name="--beacon-color-green-0"
              colorHex="#E9F9E3"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-green-1"
              colorHex="#CAE5C8"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-green-2"
              colorHex="#A1C69B"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-green-3"
              colorHex="#7DAE7A"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
          </div>
          <div className="color-block-group d-flex flex-row">
            <VarColorStoryElement
              name="--beacon-color-green-4"
              colorHex="#AEB0B5"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-green-5"
              colorHex="#2C7E3E"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-green-6"
              colorHex="#256A34"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-green-7"
              colorHex="#205A2C"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
          </div>
        </div>
        <h1>Reds</h1>
        <div className="color-details d-flex flex-wrap">
          <div className="color-block-group d-flex flex-row">
            <VarColorStoryElement
              name="--beacon-color-red-0"
              colorHex="#FFEFEF"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-red-1"
              colorHex="#FFCBCB"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-red-2"
              colorHex="#FEA7A7"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-red-3"
              colorHex="#F88183"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
          </div>
          <div className="color-block-group d-flex flex-row">
            <VarColorStoryElement
              name="--beacon-color-red-4"
              colorHex="#EE585F"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-red-5"
              colorHex="#E21C3D"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-red-6"
              colorHex="#C81735"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-red-7"
              colorHex="#AE132D"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
          </div>
        </div>
        <h1>Blues</h1>
        <div className="color-details d-flex flex-wrap">
          <div className="color-block-group d-flex flex-row">
            <VarColorStoryElement
              name="--beacon-color-blue-0"
              colorHex="#E6F1F8"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-blue-1"
              colorHex="#D2E2F2"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-blue-2"
              colorHex="#91BBDF"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-blue-3"
              colorHex="#4094CC"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
          </div>
          <div className="color-block-group d-flex flex-row">
            <VarColorStoryElement
              name="--beacon-color-blue-4"
              colorHex="#2683C5"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-blue-5"
              colorHex="#0071BB"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-blue-6"
              colorHex="#205493"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-blue-7"
              colorHex="#122E51"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
          </div>
        </div>
        <h1>Yellows</h1>
        <div className="color-details d-flex flex-wrap">
          <div className="color-block-group d-flex flex-row">
            <VarColorStoryElement
              name="--beacon-color-yellow-0"
              colorHex="#FFF1D2"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-yellow-1"
              colorHex="#FFE5B0"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-yellow-2"
              colorHex="#FFDA8F"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-yellow-3"
              colorHex="#FECE6E"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
          </div>
          <div className="color-block-group d-flex flex-row">
            <VarColorStoryElement
              name="--beacon-color-yellow-4"
              colorHex="#FEC44C"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-yellow-5"
              colorHex="#FDB81E"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-yellow-6"
              colorHex="#E9A818"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
            <VarColorStoryElement
              name="--beacon-color-yellow-7"
              colorHex="#BB8002"
              description=""
              type={ColorStoryElementType.blockSmall}
            />
          </div>
        </div>
      </div>
    </section>
  );
};
