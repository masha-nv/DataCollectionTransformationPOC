import React from 'react';
import { Heading } from '../heading/heading';
import ComparisonTableBody from './comparison-table-body';
import ComparisonTableHeader from './comparison-table-header';
import { IComparisonTableProps } from './comparison-table-types';

export const ComparisonTable = ({
  id,
  summary,
  title,
  columns,
  dataSources: data,
  fields,
  headingType,
  headingStyle,
}: IComparisonTableProps) => {
  return (
    <table id={id} className="comparison-table">
      <caption className="comparison-table-caption">
        <span className="comparison-table-title">
          <Heading
            headingType={headingType ? headingType : 'h3'}
            headingStyle={headingStyle ? headingStyle : undefined}
          >
            {title}
          </Heading>
        </span>
        <span className="comparison-table-summary support-text">{summary}</span>
      </caption>
      <ComparisonTableHeader columns={columns} />
      <ComparisonTableBody fields={fields} data={data} />
    </table>
  );
};
