import React from 'react';
import { ComparisonTable } from './comparison-table';
import { IComparisonTableColumn, IComparisonTableField } from './comparison-table-types';
import { Meta, Story } from '@storybook/react';
import { Documentation, dropdownFromHeadingStyles, dropdownFromHeadingTypes, StoryBadge } from '../stories';
import { a11yConfig } from '../stories/story.config';

export default {
  component: ComparisonTable,
  title: 'Core Components/Tables/Comparison Table',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const whenToUse = (
  <ul>
    <li>Generally, data comparison tables are used to display information about an applicant</li>
    <li>
      Tables that compare data and indicate which data does not match should highlight the rows that show non-matching
      data, and should include a warning notification above the table directing users to review the highlighted rows.
    </li>
    <li>
      Tables that compare data and indicate which data does match should indicate which column has the canonical data.
      In the tables that are compared, the data elements that match should be indicated with a fa-check-circle icon,
      with the circle in green.
    </li>
  </ul>
);

const accessibilityConsiderations = (
  <ul>
    <li>
      The <code>title</code> will serve as a caption for the table and should be unique, if you need additional space,
      then use the <code>summary</code> attribute to provide more context about the information on the table
    </li>
  </ul>
);

const argTypes = {
  headingType: {
    control: dropdownFromHeadingTypes(),
    defaultValue: 'h3',
  },
  headingStyle: {
    control: dropdownFromHeadingStyles(),
  },
};

/**
 * Comparison Table
 */
export const Default: Story = (storyProps) => {
  const data = [
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'India',
      fatherName: 'SMITH, LUTHER',
    },
    {
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'Pakistan',
      fatherName: 'SMITH, LUTHER',
    },
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'India',
      fatherName: 'SMITH, LUTHER',
    },
  ];

  const columns: IComparisonTableColumn[] = [
    {
      name: "Petitioner's Declared Data",
    },
    {
      name: 'CIS Data',
    },
    {
      name: 'CIS Card Data',
    },
  ];

  const fields: IComparisonTableField[] = [
    {
      label: 'Names',
      field: 'name',
    },
    {
      label: 'Alien Number',
      field: 'alienNumber',
    },
    {
      label: 'Date of Birth (DOB)',
      field: 'dateOfBirth',
    },
    {
      label: 'Country of Birth (COB)',
      field: 'countryOfBirth',
    },
    {
      label: "Father's Name",
      field: 'fatherName',
    },
  ];

  return (
    <div>
      <ComparisonTable
        id="primaryStory"
        title="Sample comparison table - this is required"
        summary="Shows some sample data, this is a summary that is more descriptive but not required"
        columns={columns}
        fields={fields}
        dataSources={data}
        headingType={storyProps.headingType}
        headingStyle={storyProps.headingStyle}
      />
    </div>
  );
};
Default.storyName = 'Comparison Table';
Default.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Comparison Tables"
      description="These tables are used to compare multiple columns of data side by side, and their columns are not sortable"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
Default.argTypes = argTypes;

/**
 * Comparison Table
 */
export const CustomContent: Story = (storyProps) => {
  const dataSources = [
    {
      name: 'John',
      lastName: 'Doe',
    },
  ];
  const columns: IComparisonTableColumn[] = [
    {
      name: 'Main data source',
    },
  ];
  const fields: IComparisonTableField[] = [
    {
      label: 'Full Name',
      field: 'name',
      render: (field, record) => (
        <span>
          With an{' '}
          <em>
            emphasized {record.name} {record.lastName}
          </em>{' '}
          name
        </span>
      ),
    },
  ];
  const props = { columns, fields, dataSources };
  return (
    <div className="beacon">
      <ComparisonTable
        id="withCustomRender"
        title="Custom rendering"
        headingType={storyProps.headingType}
        headingStyle={storyProps.headingStyle}
        {...props}
      />
    </div>
  );
};
CustomContent.storyName = 'Comparison Table with Custom Content';
CustomContent.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Custom Content in Comparison Tables"
      description={
        <p>
          Comparison tables can also render custom content by using the <code>render</code> property.
        </p>
      }
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
CustomContent.argTypes = argTypes;
