import React from 'react';
import { IComparisonTableColumn } from './comparison-table-types';

interface IComparisonTableHeaderProps {
  columns: IComparisonTableColumn[];
}
/**
 * Comparison Table Header component
 */
const ComparisonTableHeader = ({ columns }: IComparisonTableHeaderProps) => {
  const headers = columns.map((column: IComparisonTableColumn, index: number) => {
    return (
      <th key={index} scope="col">
        {column.name}
      </th>
    );
  });

  return (
    <thead>
      <tr>
        <th scope="col">
          <span className="sr-only">Fields</span>
        </th>
        {headers}
      </tr>
    </thead>
  );
};

export default ComparisonTableHeader;
