import React, { ReactNode } from 'react';
import { DataRenderFunction, GenericData, IComparisonTableField } from './comparison-table-types';
import './comparison-table.scss';
interface IComparisonTableBodyProps {
  fields: IComparisonTableField[];
  data: GenericData[];
}
const defaultToNull = (value: unknown): unknown => {
  return value !== undefined ? value : null;
};

const datasourcesMismatchOnField = (data: Record<string, unknown>[], field: string): boolean => {
  // if there is one or less data sources then there's no reason to check for equality
  if (data.length <= 1) {
    return false;
  }
  const primaryValue = data[0][field];
  return (
    data.map((dataSource) => defaultToNull(dataSource[field])).find((value) => value !== primaryValue) !== undefined
  );
};

const defaultRender: DataRenderFunction = (field: string, record: GenericData) => {
  return record[field] as ReactNode;
};

const outputDataElements = (data: GenericData[], field: IComparisonTableField): ReactNode => {
  const tableRow: JSX.Element[] = [];
  let fieldRender: DataRenderFunction = defaultRender;
  if (field.render != null) {
    fieldRender = field.render;
  }
  data.forEach((dataSource, index) => {
    tableRow.push(<td key={`data-${index}-${field}`}>{fieldRender(field.field, dataSource)}</td>);
  });
  return tableRow;
};

/**
 * Comparison Table Body component
 */
const ComparisonTableBody = ({ fields, data }: IComparisonTableBodyProps) => {
  const rows = fields.map((field) => {
    const highlightRow = datasourcesMismatchOnField(data, field.field);
    return (
      <tr key={`field-${field.field}`} className={`${highlightRow ? 'bg-warning' : ''}`}>
        <th key={`field-${field.field}-header`} scope="row">
          {field.label} {highlightRow ? <span className="sr-only"> - contains data mismatches</span> : ''}
        </th>
        {outputDataElements(data, field)}
      </tr>
    );
  });

  return <tbody>{rows}</tbody>;
};

export default ComparisonTableBody;
