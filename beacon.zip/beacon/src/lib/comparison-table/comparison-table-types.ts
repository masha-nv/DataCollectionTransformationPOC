import { ReactNode } from 'react';
import { HeadingStyle, HeadingType } from '../heading/heading';
import { WithId } from '../with-id';

export declare type GenericData = Record<string, unknown>;
export declare type DataRenderFunction = (field: string, record: GenericData) => ReactNode;

export interface IComparisonTableProps extends WithId {
  /**
   * Title of the comparision table, this is required for accessibility
   */
  title: string;

  /**
   * Summary of the table can provide additional context about the data in the
   * table. This is not required for accessibility but it does help.
   */
  summary?: string;

  /**
   * The column definitions for the table, this controls the column headers that will
   * be displayed for each of the datasources. The number of column headers needs to
   * match the number of datasource elements
   */
  columns: IComparisonTableColumn[];
  /**
   * the data sources for the table, each represents the values that will be displayed
   * on a column.
   */
  dataSources: GenericData[];

  /**
   * The various fields to display for each of the data sources.
   */
  fields: IComparisonTableField[];
  /**
   * The type of heading used for the title.
   */
  headingType?: HeadingType;
  /**
   * The heading style used for the title.
   */
  headingStyle?: HeadingStyle;
}

export interface IComparisonTableColumn {
  /**
   * Represents the label for the column
   */
  name: string;
}

export interface IComparisonTableField {
  /**
   * The user-friendly label to display on the rendered comparison table
   */
  label: string;

  /**
   * A basic field reference (one level only) to a field you want to display for comparison,
   * anything different needs be displayed via a custom `render` function.
   */
  field: string;

  /**
   * A rendering function that accepts the `field` and the entire
   * `record` being iterated, this can be used to customize the rendering
   * of cells for the comparison table.
   */
  render?: DataRenderFunction;
}
