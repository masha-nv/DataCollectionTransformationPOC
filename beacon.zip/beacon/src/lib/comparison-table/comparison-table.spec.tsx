import React from 'react';
import { render } from '@testing-library/react';
import { ComparisonTable } from './comparison-table';
import { Default, CustomContent } from './comparison-table.stories';

describe('Comparison Table', () => {
  const setWithMismatchedData = [
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'India',
      fatherName: 'SMITH, LUTHER',
    },
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'Pakistan',
      fatherName: 'SMITH, LUTHER',
    },
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'India',
      fatherName: 'SMITH, LUTHER',
    },
  ];

  const setWithMatchingData = [
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'India',
      fatherName: 'SMITH, LUTHER',
    },
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'India',
      fatherName: 'SMITH, LUTHER',
    },
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'India',
      fatherName: 'SMITH, LUTHER',
    },
  ];

  const columns = [
    {
      name: "Petitioner's Declared Data",
    },
    {
      name: 'CIS Data',
    },
    {
      name: 'CIS Card Data',
    },
  ];

  const fields = [
    {
      label: 'Names',
      field: 'name',
    },
    {
      label: 'Alien Number',
      field: 'alienNumber',
    },
    {
      label: 'Date Of Birth (DOB)',
      field: 'dateOfBirth',
    },
    {
      label: 'Country Of Birth (COB)',
      field: 'countryOfBirth',
    },
    {
      label: "Father's Name",
      field: 'fatherName',
    },
  ];

  const baseProps = {
    id: 'jest-table',
    title: 'Jest Test Table',
    columns,
    fields,
  };

  it('renders the default storybook example with no customized render', () => {
    const { baseElement } = render(<Default />);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with a custom render function', () => {
    const { baseElement } = render(<CustomContent />);
    expect(baseElement).toMatchSnapshot();
  });

  it('flags mismatched fields if they are undefined', () => {
    const { baseElement } = render(
      <ComparisonTable {...baseProps} dataSources={[{ name: 'John' }, { name: undefined }]} />
    );

    const firstRow = baseElement.querySelector('tbody > tr:first-child');
    expect(firstRow.className).toBe('bg-warning');
    expect(firstRow.textContent).toContain('- contains data mismatches');
  });

  it('renders with customized header', () => {
    const { baseElement } = render(
      <ComparisonTable
        {...baseProps}
        dataSources={[{ name: 'John' }, { name: undefined }]}
        headingType="h1"
        headingStyle="m"
      />
    );

    const firstRow = baseElement.querySelector('tbody > tr:first-child');
    expect(firstRow.className).toBe('bg-warning');
    expect(firstRow.textContent).toContain('- contains data mismatches');
  });
});
