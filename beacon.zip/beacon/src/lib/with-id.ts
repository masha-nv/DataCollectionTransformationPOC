export interface WithId {
  /**
   * A unique ID for this element, each component requires this
   * in order to ensure that automated tests (like serenity) can
   * get a handle of components. Each component will use this IDs
   * to generate IDs for its interactive elements.
   */
  id: string;
}
