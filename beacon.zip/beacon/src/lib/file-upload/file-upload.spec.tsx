import { fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { useState } from 'react';
import { act } from 'react-dom/test-utils';
import { noop } from '../utils';

import { FileUpload } from './file-upload';
import { UploadCategory, FilesWithCategory } from './file-upload.types';

const ONE_KB_IN_BYTES = 1024;

const createTestFile = (fileName: string, fileSize: number) => {
  const testFile = new File([], fileName);
  Object.defineProperty(testFile, 'size', { value: fileSize });
  return testFile;
};

const createFileUploadComponent = (
  maxFileCount: number,
  maxFileSizeInMB: number,
  allowedFileFormats: string[],
  fileUploadCategories: UploadCategory[],
  onClick?: (selectedFiles: FilesWithCategory[]) => void,
  selectedFiles?: FilesWithCategory[],
  hideUploadButton?: boolean,
  onChange?: (selectedFilesWithCategory: FilesWithCategory[]) => void,
  enableUnselectedDefault?: boolean
) => {
  return (
    <FileUpload
      titleText="File Upload Unit Testing"
      maxFileCount={maxFileCount}
      maxFileSizeInMBs={maxFileSizeInMB}
      allowedFileFormats={allowedFileFormats}
      fileUploadCategories={fileUploadCategories}
      hideUploadButton={hideUploadButton}
      onUploadClick={() => {
        onClick ? onClick(selectedFiles) : noop();
      }}
      onFileSelectionChange={() => {
        onChange ? onChange(selectedFiles) : noop();
      }}
      enableUnselectedDefault={enableUnselectedDefault}
    />
  );
};

/**
 * This is to test the passing of the files from the child component to the parent
 * @returns the file upload component wrapped in another component
 */
function FileUploadWrapper() {
  const [selectedFilesAndCategory, setSelectedFilesAndCategory] = useState<FilesWithCategory>({
    files: [],
    category: null,
  });
  const onClick = (filesForUpload: FilesWithCategory) => {
    setSelectedFilesAndCategory(filesForUpload);
  };
  const success = <div>Files successfully passed to parent component</div>;
  return (
    <div className="beacon react-beacon">
      <FileUpload
        titleText="File Upload Unit Testing"
        maxFileCount={1}
        maxFileSizeInMBs={1}
        allowedFileFormats={['pdf']}
        fileUploadCategories={[{ code: '1', description: 'Notice' }]}
        onUploadClick={onClick}
      />
      {selectedFilesAndCategory.files.length > 0 && success}
    </div>
  );
}

describe('FileUpload', () => {
  it('should render successfully', () => {
    const component = createFileUploadComponent(1, 1, ['pdf'], [{ code: '1', description: 'Notice' }]);
    const { baseElement } = render(component);
    expect(baseElement).toMatchSnapshot();
  });

  it('should open the file browser after clicking the Browse button', () => {
    const component = createFileUploadComponent(1, 1, ['pdf'], [{ code: '1', description: 'Notice' }]);
    const { baseElement } = render(component);
    const browseBtn = baseElement.querySelector('#browse-btn') as HTMLButtonElement;

    expect(browseBtn).toBeDefined();

    userEvent.click(browseBtn);

    expect(baseElement).toMatchSnapshot();
  });

  it('should select a file for upload and see it in the datatable', async () => {
    const component = createFileUploadComponent(1, 1, ['pdf'], [{ code: '1', description: 'Notice' }]);
    const testFile = createTestFile('test.pdf', ONE_KB_IN_BYTES);

    const { baseElement } = render(component);
    const inputElement = baseElement.querySelector('#file-upload-input') as HTMLInputElement;

    await act(async () => {
      userEvent.upload(inputElement, testFile);
    });

    await waitFor(() => {
      const datatableFile = screen.getByText('test.pdf');
      expect(datatableFile).toBeDefined();
    });

    expect(baseElement).toMatchSnapshot();
  });

  it('should present column sorting ability Descending And Ascending', async () => {
    const testFile1 = createTestFile('test1.pdf', ONE_KB_IN_BYTES);
    const testFile2 = createTestFile('dummy.pdf', ONE_KB_IN_BYTES);
    const testFile3 = createTestFile('ipsem.pdf', ONE_KB_IN_BYTES);
    const component = createFileUploadComponent(3, 1, ['pdf'], [{ code: '1', description: 'Notice' }]);

    const { baseElement } = render(component);
    const inputElement = baseElement.querySelector('#file-upload-input') as HTMLInputElement;

    await act(async () => {
      userEvent.upload(inputElement, [testFile1, testFile2, testFile3]);
    });

    const nameHeaders = await screen.findAllByRole('columnheader', {
      name: 'Activate to sort columns from table in ascending order.',
    });
    const firstHeader = nameHeaders[0];

    await act(async () => {
      userEvent.click(firstHeader);
    });

    const rowsAscSort = screen.getAllByRole('row');
    let firstDataRow = rowsAscSort[1];
    let thirdDataRow = rowsAscSort[3];

    expect(within(firstDataRow).queryAllByText('dummy.pdf')).toHaveLength(1);
    expect(within(thirdDataRow).queryAllByText('test1.pdf')).toHaveLength(1);

    await act(async () => {
      userEvent.click(firstHeader);
    });

    const rowsDescSort = screen.getAllByRole('row');
    firstDataRow = rowsDescSort[1];
    thirdDataRow = rowsDescSort[3];

    expect(within(firstDataRow).queryAllByText('test1.pdf')).toHaveLength(1);
    expect(within(thirdDataRow).queryAllByText('dummy.pdf')).toHaveLength(1);
  });

  it('should select 2 files and remove all by clicking Remove All', async () => {
    const testFile1 = createTestFile('test1.pdf', ONE_KB_IN_BYTES);
    const testFile2 = createTestFile('test2.pdf', ONE_KB_IN_BYTES);
    const component = createFileUploadComponent(2, 1, ['pdf'], [{ code: '1', description: 'Notice' }]);

    const { baseElement } = render(component);
    const inputElement = baseElement.querySelector('#file-upload-input') as HTMLInputElement;

    await act(async () => {
      userEvent.upload(inputElement, [testFile1, testFile2]);
    });

    const removeAllBtn = baseElement.querySelector('#remove-all-files-btn');

    expect(removeAllBtn).toBeDefined();

    await act(async () => {
      userEvent.click(removeAllBtn);
    });

    await waitFor(() => {
      expect(baseElement.querySelector('#selected-documents-datatable')).toBeNull();
    });

    expect(baseElement).toMatchSnapshot();
  });

  it('should select 2 files and remove one of them by clicking Remove in the datatable', async () => {
    const testFile1 = createTestFile('test1.pdf', ONE_KB_IN_BYTES);
    const testFile2 = createTestFile('test2.pdf', ONE_KB_IN_BYTES);
    const component = createFileUploadComponent(2, 1, ['pdf'], [{ code: '1', description: 'Notice' }]);

    const { baseElement } = render(component);
    const inputElement = baseElement.querySelector('#file-upload-input') as HTMLInputElement;

    await act(async () => {
      userEvent.upload(inputElement, [testFile1, testFile2]);
    });

    await waitFor(() => {
      expect(screen.getByText('test1.pdf')).toBeDefined();
      expect(screen.getByText('test2.pdf')).toBeDefined();
    });

    const removeBtns = screen.getAllByText('Remove');

    await act(async () => {
      userEvent.click(removeBtns[0]);
    });

    await waitFor(() => {
      expect(screen.getAllByText('Remove').length).toBe(1);
      expect(screen.getByText('test2.pdf')).toBeDefined();
    });

    expect(baseElement).toMatchSnapshot();
  });

  it('should not remove all files with the same name when files with duplicate names are selected', () => {
    const testFile1 = createTestFile('test2.pdf', ONE_KB_IN_BYTES);
    const testFile2 = createTestFile('test2.pdf', ONE_KB_IN_BYTES);
    const component = createFileUploadComponent(2, 1, ['pdf'], [{ code: '1', description: 'Notice' }]);

    const { baseElement } = render(component);
    const inputElement = baseElement.querySelector('#file-upload-input') as HTMLInputElement;

    act(() => {
      userEvent.upload(inputElement, [testFile1, testFile2]);
    });

    expect(screen.getAllByText('test2.pdf')).toBeDefined();

    const removeBtns = screen.getAllByText('Remove');

    act(() => {
      userEvent.click(removeBtns[0]);
    });

    expect(screen.getAllByText('Remove').length).toBe(1);
    expect(screen.getAllByText('test2.pdf')).toBeDefined();
  });

  it('should select an invlaid file and display a validation error', async () => {
    const testFile = createTestFile('test.jpg', ONE_KB_IN_BYTES);
    const component = createFileUploadComponent(2, 1, ['pdf'], [{ code: '1', description: 'Notice' }]);

    const { baseElement } = render(component);
    const inputElement = baseElement.querySelector('#file-upload-input') as HTMLInputElement;

    await act(async () => {
      userEvent.upload(inputElement, testFile);
    });

    const fileTypeErrorAlert = screen.getByText(`${testFile.name} is not in an accepted format.`);
    expect(fileTypeErrorAlert).toBeDefined();

    expect(baseElement).toMatchSnapshot();
  });

  it('should select a file by drag-and-drop', async () => {
    const testFile = createTestFile('test.pdf', ONE_KB_IN_BYTES);
    const component = createFileUploadComponent(2, 1, ['pdf'], [{ code: '1', description: 'Notice' }]);

    const { baseElement } = render(component);

    const dragAndDropBox = baseElement.querySelector('#drag-and-drop-box');

    await act(async () => {
      fireEvent.drop(dragAndDropBox, {
        dataTransfer: {
          files: [testFile],
        },
      });
    });

    await waitFor(() => {
      expect(screen.findByText('test.pdf')).toBeDefined();
    });

    expect(baseElement).toMatchSnapshot();
  });

  it('should trigger drag events on drag-and-drop box', async () => {
    const component = createFileUploadComponent(1, 1, ['pdf'], [{ code: '1', description: 'Notice' }]);

    const { baseElement } = render(component);

    const dragAndDropBox = baseElement.querySelector('#drag-and-drop-box');

    await act(async () => {
      fireEvent.dragEnter(dragAndDropBox);
      fireEvent.dragOver(dragAndDropBox);
    });

    let dropBoxDraggedOver = baseElement.querySelector('.dragging');

    await waitFor(() => {
      expect(dropBoxDraggedOver).toBeDefined();
    });

    await act(async () => {
      fireEvent.dragLeave(dragAndDropBox);
    });

    dropBoxDraggedOver = baseElement.querySelector('.dragging');

    await waitFor(() => {
      expect(dropBoxDraggedOver).toBeNull();
    });

    expect(baseElement).toMatchSnapshot();
  });

  it('should change file category from dropdown and be reflected in the datatable', async () => {
    const testFile = createTestFile('test.pdf', ONE_KB_IN_BYTES);
    const component = createFileUploadComponent(
      1,
      1,
      ['pdf'],
      [
        { code: '1', description: 'Notice' },
        { code: '2', description: 'Address Change' },
      ]
    );

    const { baseElement } = render(component);

    const categoryDropdown = screen.getByTestId('dropdown-caret-icon');
    expect(categoryDropdown).toBeDefined();

    await act(async () => {
      userEvent.click(categoryDropdown);
    });

    const addressChangeCategory = screen.getByText('Address Change');

    await waitFor(() => {
      expect(addressChangeCategory).toBeDefined();
    });

    await act(async () => {
      userEvent.click(addressChangeCategory);
    });

    const inputElement = baseElement.querySelector('#file-upload-input') as HTMLInputElement;

    await act(async () => {
      userEvent.upload(inputElement, testFile);
    });

    expect(screen.getByText('test.pdf')).toBeDefined();
    expect(screen.getAllByText('Address Change')).toBeDefined();

    expect(baseElement).toMatchSnapshot();
  });

  it('should select a file for upload, click the File Upload button, and verify that the files were passed to the parent component', async () => {
    const component = <FileUploadWrapper />;
    const testFile = createTestFile('test.pdf', ONE_KB_IN_BYTES);

    const { baseElement } = render(component);
    const inputElement = baseElement.querySelector('#file-upload-input') as HTMLInputElement;

    await act(async () => {
      userEvent.upload(inputElement, testFile);
    });

    await waitFor(() => {
      expect(screen.getByText('test.pdf')).toBeDefined();
    });

    const uploadBtn = baseElement.querySelector('#upload-btn');
    expect(uploadBtn).toBeDefined();
    expect(uploadBtn.getAttribute('disabled')).toBeFalsy();

    await act(async () => {
      userEvent.click(uploadBtn);
    });

    await waitFor(() => {
      expect(screen.getByText('Files successfully passed to parent component')).toBeDefined();
    });

    expect(baseElement).toMatchSnapshot();
  });
  it('hides internal upload button and calls onFileSelectionChange when files are selected', async () => {
    const testFile = createTestFile('test.pdf', ONE_KB_IN_BYTES);
    const mockOnFileSelectionChange = jest.fn();
    const component = createFileUploadComponent(
      2,
      1,
      ['pdf'],
      [{ code: '1', description: 'Notice' }],
      undefined,
      undefined,
      true,
      mockOnFileSelectionChange
    );

    const { baseElement } = render(component);

    const uploadButton = screen.queryByRole('button', { name: /Upload/ });
    expect(uploadButton).toBeNull();

    const inputElement = baseElement.querySelector('#file-upload-input') as HTMLInputElement;

    userEvent.upload(inputElement, testFile);

    await waitFor(() => expect(mockOnFileSelectionChange).toHaveBeenCalled());
  });
  it('selects the first select item category by default and disables the element when theres only one category and enableUnselectedDefault is false', () => {
    const component = createFileUploadComponent(
      2,
      1,
      ['pdf'],
      [{ code: '1', description: 'Notice' }],
      undefined,
      undefined,
      true,
      jest.fn()
    );

    render(component);

    const categorySelect = screen.getByLabelText('Currently Selected: Notice') as HTMLInputElement;
    expect(categorySelect.disabled).toBeTruthy();
    expect(categorySelect.value).toBe('Notice');
  });
  it('selects the first select item category by default and DOES NOT disable the element when theres more than one category and enableUnselectedDefault is false', () => {
    const component = createFileUploadComponent(
      2,
      1,
      ['pdf'],
      [
        { code: '1', description: 'Notice' },
        { code: '2', description: 'Receipt' },
      ],
      undefined,
      undefined,
      true,
      jest.fn()
    );

    render(component);

    const categorySelect = screen.getByLabelText('Currently Selected: Notice') as HTMLInputElement;
    expect(categorySelect.disabled).toBeFalsy();
    expect(categorySelect.value).toBe('Notice');
  });

  describe('with enableUnselectedDefault enabled', () => {
    it('disables the browse button and hides the drag and drop file selection box when a category is not selected', () => {
      const mockOnFileSelectionChange = jest.fn();
      const component = createFileUploadComponent(
        2,
        1,
        ['pdf'],
        [{ code: '1', description: 'Notice' }],
        undefined,
        undefined,
        true,
        mockOnFileSelectionChange,
        true
      );

      render(component);

      const dragAndDropButton = screen.queryByRole('button', { name: /Select file(s) to upload/ });
      expect(dragAndDropButton).toBeNull();

      const inputElement = screen.queryByRole('button', { name: /Browse/ }) as HTMLInputElement;
      expect(inputElement.disabled).toBeTruthy();
    });

    it('enables the browse button and shows the drag and drop file selection box when a category is selected', async () => {
      const mockOnFileSelectionChange = jest.fn();
      const component = createFileUploadComponent(
        2,
        1,
        ['pdf'],
        [{ code: '1', description: 'Notice' }],
        undefined,
        undefined,
        true,
        mockOnFileSelectionChange,
        true
      );

      render(component);

      const select = (await screen.findByLabelText(/Expand Type of Document Dropdown/)) as HTMLInputElement;
      userEvent.click(select);
      const noticeSelectOption = await screen.findByText('Notice');
      userEvent.click(noticeSelectOption);

      await screen.findByText(/Drag & drop/);

      const inputElement = screen.queryByRole('button', { name: /Browse/ }) as HTMLInputElement;
      expect(inputElement.disabled).toBeFalsy();
    });
  });
});
