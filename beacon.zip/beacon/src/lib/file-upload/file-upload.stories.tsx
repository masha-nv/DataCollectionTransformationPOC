import { Meta, Story } from '@storybook/react';
import { Documentation } from '../stories';
import { FileUpload, FileUploadProps } from './file-upload';
import { FilesWithCategory, UploadCategory } from './file-upload.types';
import { action } from '@storybook/addon-actions';
import { useState } from 'react';
import { Card } from '../cards/card';

//##### story data/props #####
const title = 'File Upload';
const childTitle = 'File Upload Child Component';
const maximumFileCount = 3;
const maxFileSize = 60;
const acceptedFileFormats = ['pdf', 'jpg', 'png'];
const uploadCategories: UploadCategory[] = [
  {
    code: '1',
    description: 'Notice',
  },
  {
    code: '2',
    description: 'Address Change',
  },
];
//##### end story data/props #####

export default {
  component: FileUpload,
  title: 'Core Components/File Upload/File Upload',
} as Meta;

export const ManualUpload: Story<FileUploadProps> = ({
  titleText,
  maxFileCount,
  maxFileSizeInMBs,
  allowedFileFormats,
  fileUploadCategories,
  onUploadClick,
}: FileUploadProps) => {
  return (
    <FileUpload
      titleText={titleText}
      maxFileCount={maxFileCount}
      maxFileSizeInMBs={maxFileSizeInMBs}
      allowedFileFormats={allowedFileFormats}
      fileUploadCategories={fileUploadCategories}
      onUploadClick={action('OnUploadClick')}
    />
  );
};

ManualUpload.storyName = 'Manual Upload';

const whenToUse = (
  <div>
    <p>Use File Upload for components that allow a user to select files for upload.</p>
    <b className="beacon-icon-danger">IMPORTANT:</b>
    <ul>
      <li>File Upload is meant to pass files and their selected category to the parent component.</li>
      <li>File Upload has no built-in API calls or payload construction.</li>
    </ul>
  </div>
);

ManualUpload.decorators = [
  (FileUploadStory: Story) => (
    <Documentation
      name="File Upload"
      description="File Upload allows users to select files for upload and performs validation on selected files."
      whenToUse={whenToUse}
    >
      <FileUploadStory />
    </Documentation>
  ),
];

ManualUpload.args = {
  titleText: title,
  maxFileCount: maximumFileCount,
  maxFileSizeInMBs: maxFileSize,
  allowedFileFormats: acceptedFileFormats,
  fileUploadCategories: uploadCategories,
  onUploadClick: () => {
    action('OnUploadClick');
  },
};

export const ManualUploadWithSingleCategory: Story<FileUploadProps> = ({
  titleText,
  maxFileCount,
  maxFileSizeInMBs,
  allowedFileFormats,
  fileUploadCategories,
  onUploadClick,
}: FileUploadProps) => {
  return (
    <FileUpload
      titleText={titleText}
      maxFileCount={maxFileCount}
      maxFileSizeInMBs={maxFileSizeInMBs}
      allowedFileFormats={allowedFileFormats}
      fileUploadCategories={fileUploadCategories}
      onUploadClick={action('OnUploadClick')}
    />
  );
};

ManualUploadWithSingleCategory.storyName = 'Manual Upload With A Single Category';

ManualUploadWithSingleCategory.decorators = [
  (FileUploadStory: Story) => (
    <Documentation
      name="File Upload"
      description="File Upload allows users to select files for upload and performs validation on selected files."
      whenToUse={whenToUse}
    >
      <FileUploadStory />
    </Documentation>
  ),
];

ManualUploadWithSingleCategory.args = {
  titleText: title,
  maxFileCount: maximumFileCount,
  maxFileSizeInMBs: maxFileSize,
  allowedFileFormats: acceptedFileFormats,
  fileUploadCategories: [uploadCategories[0]],
  onUploadClick: () => {
    action('OnUploadClick');
  },
};

export const RealTimeSync: Story<FileUploadProps> = ({
  titleText,
  maxFileCount,
  maxFileSizeInMBs,
  allowedFileFormats,
  fileUploadCategories,
  onFileSelectionChange,
}: FileUploadProps) => {
  const [selectedFilesWithCategory, setSelectedFilesWithCategory] = useState<FilesWithCategory[] | null>(null);

  const handleFileSelectionChange = (filesToUpload: FilesWithCategory[]) => {
    setSelectedFilesWithCategory(filesToUpload);
    console.log('Live-updated file list:', fileUploadCategories);
  };

  return (
    <Card id="selected-files-card" title="Parent Component">
      <div className="mb-3">
        <pre>
          Selected Files:{' '}
          {JSON.stringify(
            selectedFilesWithCategory?.map((sf) => sf.files[0].name),
            null,
            2
          )}
        </pre>
      </div>
      <FileUpload
        titleText={titleText}
        maxFileCount={maxFileCount}
        maxFileSizeInMBs={maxFileSizeInMBs}
        allowedFileFormats={allowedFileFormats}
        fileUploadCategories={fileUploadCategories}
        hideUploadButton
        onFileSelectionChange={handleFileSelectionChange}
      />
    </Card>
  );
};

RealTimeSync.storyName = 'Real-Time Sync';

const whenToUseRealTimeSync = (
  <div>
    <p>
      You can hide the upload button while still keeping the parent consumer automatically updated with the latest file
      selection
    </p>
    <b className="beacon-icon-danger">IMPORTANT:</b>
    <ul>
      <li>File Upload is meant to pass files and their selected category to the parent component.</li>
      <li>File Upload has no built-in API calls or payload construction.</li>
    </ul>
  </div>
);

RealTimeSync.decorators = [
  (FileUploadStory: Story) => (
    <Documentation
      name="Real-Time Sync"
      description="File Upload allows users to select files for upload and performs validation on selected files."
      whenToUse={whenToUseRealTimeSync}
    >
      <FileUploadStory />
    </Documentation>
  ),
];

RealTimeSync.args = {
  titleText: childTitle,
  maxFileCount: maximumFileCount,
  maxFileSizeInMBs: maxFileSize,
  allowedFileFormats: acceptedFileFormats,
  fileUploadCategories: uploadCategories,
  hideUploadButton: true,
  onFileSelectionChange: () => {
    action('OnFileSelectionChange');
  },
};

export const ManualUploadWithUnselectedDefault: Story<FileUploadProps> = ({
  titleText,
  maxFileCount,
  maxFileSizeInMBs,
  allowedFileFormats,
  fileUploadCategories,
  onUploadClick,
}: FileUploadProps) => {
  return (
    <FileUpload
      titleText={titleText}
      maxFileCount={maxFileCount}
      maxFileSizeInMBs={maxFileSizeInMBs}
      allowedFileFormats={allowedFileFormats}
      fileUploadCategories={fileUploadCategories}
      onUploadClick={action('OnUploadClick')}
      enableUnselectedDefault
    />
  );
};

ManualUploadWithUnselectedDefault.storyName = 'Manual Upload With Unselected Default State';

ManualUploadWithUnselectedDefault.decorators = [
  (FileUploadStory: Story) => (
    <Documentation
      name="File Upload"
      description="File Upload allows users to select files for upload and performs validation on selected files."
      whenToUse={whenToUse}
    >
      <FileUploadStory />
    </Documentation>
  ),
];

ManualUploadWithUnselectedDefault.args = {
  titleText: title,
  maxFileCount: maximumFileCount,
  maxFileSizeInMBs: maxFileSize,
  allowedFileFormats: acceptedFileFormats,
  fileUploadCategories: uploadCategories,
  onUploadClick: () => {
    action('OnUploadClick');
  },
};

export const ManualUploadWithUnselectedDefaultAndSingleCategory: Story<FileUploadProps> = ({
  titleText,
  maxFileCount,
  maxFileSizeInMBs,
  allowedFileFormats,
  fileUploadCategories,
  onUploadClick,
}: FileUploadProps) => {
  return (
    <FileUpload
      titleText={titleText}
      maxFileCount={maxFileCount}
      maxFileSizeInMBs={maxFileSizeInMBs}
      allowedFileFormats={allowedFileFormats}
      fileUploadCategories={fileUploadCategories}
      onUploadClick={action('OnUploadClick')}
      enableUnselectedDefault
    />
  );
};

ManualUploadWithUnselectedDefaultAndSingleCategory.storyName =
  'Manual Upload With Unselected Default State and a Single Category';

ManualUploadWithUnselectedDefaultAndSingleCategory.decorators = [
  (FileUploadStory: Story) => (
    <Documentation
      name="File Upload"
      description="File Upload allows users to select files for upload and performs validation on selected files."
      whenToUse={whenToUse}
    >
      <FileUploadStory />
    </Documentation>
  ),
];

ManualUploadWithUnselectedDefaultAndSingleCategory.args = {
  titleText: title,
  maxFileCount: maximumFileCount,
  maxFileSizeInMBs: maxFileSize,
  allowedFileFormats: acceptedFileFormats,
  fileUploadCategories: [uploadCategories[0]],
  onUploadClick: () => {
    action('OnUploadClick');
  },
};
