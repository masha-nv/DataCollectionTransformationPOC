import { Button, ButtonType } from '../button/button';
import { Datatable } from '../table/datatable/datatable';
import { formatFileSizeToMBs } from './file-upload-utils';
import { CategorizedFile } from './file-upload.types';

export interface FileUploadDataTableProps {
  currentlySelectedFiles: CategorizedFile[];
  onSingleFileRemove: (files: CategorizedFile[]) => void;
}

export function FileUploadDataTable(props: FileUploadDataTableProps) {
  const removeSingleFile = (idToRemove: number) => {
    const filteredFiles: CategorizedFile[] = props.currentlySelectedFiles.filter(
      (fileDescriptor) => fileDescriptor.id !== idToRemove
    );
    props.onSingleFileRemove(filteredFiles);
  };

  const dataTableColumns = [
    {
      id: 'file-name-col',
      name: 'File Name',
      sortable: true,
      selector: (row: CategorizedFile) => row.file.name,
      cell: (row: CategorizedFile) => <span className="file-name-row">{row.file.name}</span>,
    },
    {
      id: 'category-col',
      name: 'Category',
      sortable: true,
      selector: (row: CategorizedFile) => row.category?.description,
      cell: (row: CategorizedFile) => <span>{row.category?.description}</span>,
    },
    {
      id: 'file-size-col',
      name: 'File Size',
      sortable: true,
      selector: (row: CategorizedFile) => row.file.size,
      cell: (row: CategorizedFile) => <span>{formatFileSizeToMBs(row.file.size)}MB</span>,
    },
    {
      id: 'action-col',
      name: 'Action',
      cell: (row: CategorizedFile, index: number) => (
        <Button
          id={`remove-file-button-${row.file.name}-${index}`}
          onClick={() => removeSingleFile(row.id)}
          type={ButtonType.secondary}
        >
          Remove
        </Button>
      ),
    },
  ];

  return (
    <div className="selected-documents-datatable">
      <Datatable
        id="selected-documents-datatable"
        title="Selected Documents for Upload"
        headingType="h2"
        pagination={false}
        columns={dataTableColumns}
        data={props.currentlySelectedFiles}
      ></Datatable>
    </div>
  );
}
