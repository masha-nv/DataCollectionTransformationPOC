import {
  formatFileSizeToMBs,
  formatFileTypesToString,
  validateFileCount,
  validateFiles,
  validateFileSize,
  validateFileType,
} from './file-upload-utils';
import { CategorizedFile } from './file-upload.types';

const ONE_MB_IN_BYTES = 1048576;

const createTestFile = (fileName: string, fileSize: number) => {
  const testFile = new File([], fileName);
  Object.defineProperty(testFile, 'size', { value: fileSize });
  return testFile;
};

const createSelectedFilesObject = (files: File[]) => {
  const selectedFiles: CategorizedFile[] = [];
  let currentId = 0;
  files.forEach((file) => {
    selectedFiles.push({
      file,
      id: currentId++,
    });
  });
  return selectedFiles;
};

describe('File Upload Utility', () => {
  it('should format a file size from bytes to megabytes', () => {
    const expected = '1.00';
    const result = formatFileSizeToMBs(ONE_MB_IN_BYTES);

    expect(result).toEqual(expected);
  });

  it('should format array of string file types to a single string with a dot before each element', () => {
    const allowedFileTypes = ['pdf', 'jpg', 'png'];

    const expected = '.pdf, .jpg, .png';
    const result = formatFileTypesToString(allowedFileTypes);

    expect(result).toEqual(expected);
  });

  describe('File Type Validation', () => {
    it('should validate file type without errors', () => {
      const testFile1 = createTestFile('test1.pdf', ONE_MB_IN_BYTES);
      const testFile2 = createTestFile('test2.pdf', ONE_MB_IN_BYTES);
      const filesToValidate = createSelectedFilesObject([testFile1, testFile2]);
      const allowedFileTypes = ['pdf'];

      const result = validateFileType(filesToValidate, allowedFileTypes);

      expect(result.errors.length).toBe(0);
      expect(result.validFiles.length).toBe(2);
    });
    it('should validate file type with 1 error', () => {
      const testFile1 = createTestFile('testJPG.jpg', ONE_MB_IN_BYTES);
      const testFile2 = createTestFile('testPDF.pdf', ONE_MB_IN_BYTES);
      const filesToValidate = createSelectedFilesObject([testFile1, testFile2]);
      const allowedFileTypes = ['pdf'];

      const result = validateFileType(filesToValidate, allowedFileTypes);

      const expectedErrorMessage = 'testJPG.jpg is not in an accepted format.';

      expect(result.errors.length).toBe(1);
      expect(result.errors.includes(expectedErrorMessage)).toBe(true);
      expect(result.validFiles.length).toBe(1);
    });
  });

  describe('File Size Validation', () => {
    it('should validate file size without errors', () => {
      const testFile1 = createTestFile('test1.pdf', ONE_MB_IN_BYTES);
      const testFile2 = createTestFile('test2.pdf', ONE_MB_IN_BYTES);
      const filesToValidate = createSelectedFilesObject([testFile1, testFile2]);

      const result = validateFileSize(filesToValidate, 50);

      expect(result.errors.length).toBe(0);
      expect(result.validFiles.length).toBe(2);
    });
    it('should validate file size with 1 error', () => {
      const testFile = createTestFile('test.pdf', ONE_MB_IN_BYTES);

      const testSelection = createSelectedFilesObject([testFile]);

      const result = validateFileSize(testSelection, 0.5);

      const expectedErrorMessage = 'Size of test.pdf exceeds 0.5MB limit.';

      expect(result.errors.length).toBe(1);
      expect(result.errors.includes(expectedErrorMessage)).toBe(true);
      expect(result.validFiles.length).toBe(0);
    });
  });

  describe('File Count Validation', () => {
    it('should validate file count without errors', () => {
      const testFile1 = createTestFile('test1.pdf', ONE_MB_IN_BYTES);
      const testFile2 = createTestFile('test2.pdf', ONE_MB_IN_BYTES);
      const filesToValidate = createSelectedFilesObject([testFile1, testFile2]);

      const currentFiles: CategorizedFile[] = [];

      const result = validateFileCount(filesToValidate, currentFiles, 3);

      expect(result.errors.length).toBe(0);
      expect(result.validFiles.length).toBe(2);
    });
    it('should validate file count with errors and return no new files', () => {
      const testFile1 = createTestFile('test1.pdf', ONE_MB_IN_BYTES);
      const testFile2 = createTestFile('test2.pdf', ONE_MB_IN_BYTES);
      const filesToValidate = createSelectedFilesObject([testFile1, testFile2]);

      const currentTestFile = createTestFile('currentFile.pdf', ONE_MB_IN_BYTES);
      const currentFiles: CategorizedFile[] = [{ file: currentTestFile, id: 0 }];

      const result = validateFileCount(filesToValidate, currentFiles, 1);

      const expectedErrorMessage =
        'Too many files were selected for upload.  The maximum number that can be uploaded is 1.';

      expect(result.errors.length).toBe(1);
      expect(result.errors.includes(expectedErrorMessage)).toBe(true);
      expect(result.validFiles.length).toBe(1);
    });
  });

  describe('Entire File Validation Process', () => {
    it('should validate', () => {
      const testFile1 = createTestFile('test1.pdf', ONE_MB_IN_BYTES);
      const testFile2 = createTestFile('test2.jpg', ONE_MB_IN_BYTES);
      const testFile3 = createTestFile('test3.png', ONE_MB_IN_BYTES);
      const filesToValidate = createSelectedFilesObject([testFile1, testFile2, testFile3]);
      const currentFiles: CategorizedFile[] = [];
      const allowedFileTypes = ['pdf', 'jpg', 'png'];

      const result = validateFiles(filesToValidate, currentFiles, 1, allowedFileTypes, 3);

      expect(result.validFiles.length).toBe(3);
      expect(result.errors.length).toBe(0);
    });
  });
});
