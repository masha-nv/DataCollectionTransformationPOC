export interface UploadCategory {
  code: string;
  description: string;
}

export interface CategorizedFile {
  file: File;
  category?: UploadCategory;
  id: number;
}

export interface FilesWithCategory {
  files: File[];
  category?: UploadCategory;
}

export interface SelectedFiles {
  selectedFiles: FilesWithCategory[];
}
