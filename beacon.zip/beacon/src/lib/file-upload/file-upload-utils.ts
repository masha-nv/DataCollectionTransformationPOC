import { CategorizedFile } from './file-upload.types';

const BYTES_TO_KB = 1024;

const fileCountErrorMssg = (maxFileCount: number) => {
  return `Too many files were selected for upload.  The maximum number that can be uploaded is ${maxFileCount}.`;
};

const fileSizeErrorMssg = (fileName: string, maxFileSizeInMB: number) => {
  return `Size of ${fileName} exceeds ${maxFileSizeInMB}MB limit.`;
};

const fileTypeErrorMssg = (fileName: string) => {
  return `${fileName} is not in an accepted format.`;
};

export class FileValidationResult {
  validFiles: CategorizedFile[];
  errors: string[] = [];
  constructor(files: CategorizedFile[], errors: string[]) {
    this.validFiles = files;
    this.errors = errors;
  }
}

export const validateFiles = (
  newFiles: CategorizedFile[],
  currentFiles: CategorizedFile[],
  maxFileSizeInMB: number,
  allowedFileTypes: string[],
  maxFileCount: number
) => {
  const foundErrorMessages: string[] = [];

  const fileCountValidation: FileValidationResult = validateFileCount(newFiles, currentFiles, maxFileCount);
  foundErrorMessages.push(...fileCountValidation.errors);

  const fileSizeValidation: FileValidationResult = validateFileSize(fileCountValidation.validFiles, maxFileSizeInMB);
  foundErrorMessages.push(...fileSizeValidation.errors);

  const fileTypeValidation: FileValidationResult = validateFileType(fileSizeValidation.validFiles, allowedFileTypes);
  foundErrorMessages.push(...fileTypeValidation.errors);

  return new FileValidationResult(fileTypeValidation.validFiles, foundErrorMessages);
};

export const validateFileCount = (
  newFiles: CategorizedFile[],
  currentFiles: CategorizedFile[],
  maxFileCount: number
) => {
  const exceedsFileCount = currentFiles.length + newFiles.length > maxFileCount;
  const errorList: string[] = [];
  if (exceedsFileCount) {
    const message = fileCountErrorMssg(maxFileCount);
    errorList.push(message);
    return new FileValidationResult(currentFiles, errorList);
  }
  return new FileValidationResult([...newFiles, ...currentFiles], errorList);
};

export const validateFileSize = (files: CategorizedFile[], maxFileSizeInMB: number) => {
  const filesOverLimit: CategorizedFile[] = [];
  const filesWithinLimit = files.filter((fileDescriptor) => {
    const isOverSizeLimit = convertBytesToKB(fileDescriptor.file.size) > maxFileSizeInMB;
    if (isOverSizeLimit) {
      filesOverLimit.push(fileDescriptor);
    }
    return !isOverSizeLimit;
  });
  const errorList: string[] = [];
  filesOverLimit.forEach((fileDescriptor) => {
    const message = fileSizeErrorMssg(fileDescriptor.file.name, maxFileSizeInMB);
    errorList.push(message);
  });
  return new FileValidationResult(filesWithinLimit, errorList);
};

export const validateFileType = (files: CategorizedFile[], allowedFileTypes: string[]) => {
  const filesThatDoNotMatchType: CategorizedFile[] = [];
  const lowerCaseFileTypes = allowedFileTypes.map((type) => type.toLowerCase());
  const filesWithMatchingType = files.filter((fileDescriptor) => {
    const fileExtension = fileDescriptor.file.name
      .substring(fileDescriptor.file.name.lastIndexOf('.') + 1)
      .toLowerCase();
    const validFileExtension = lowerCaseFileTypes.includes(fileExtension);
    if (!validFileExtension) {
      filesThatDoNotMatchType.push(fileDescriptor);
    }
    return validFileExtension;
  });
  const errorList: string[] = [];
  filesThatDoNotMatchType.forEach((fileDescriptor) => {
    const message = fileTypeErrorMssg(fileDescriptor.file.name);
    errorList.push(message);
  });
  return new FileValidationResult(filesWithMatchingType, errorList);
};

/**
 *
 * @param byteSize number of bytes
 * @returns bytes converted to MBs rounded to two decimal places as a string
 */
export const formatFileSizeToMBs = (byteSize: number) => {
  return convertBytesToKB(byteSize).toFixed(2);
};

/**
 * Formats allowed file types into a format for the file input element.
 * Ex: ['pdf', 'png', 'jpg'] ===> '.pdf, .png, .jpg'
 * @param allowedFileTypes file type array passed as a prop into the component
 * @returns array elements with an added dot and joined into a single string
 */
export const formatFileTypesToString = (allowedFileTypes: string[]) => {
  const addedDot = allowedFileTypes.map((fileType: string) => '.' + fileType);
  return addedDot.join(', ');
};

const convertBytesToKB = (byteSize: number) => {
  return byteSize / Math.pow(BYTES_TO_KB, 2);
};
