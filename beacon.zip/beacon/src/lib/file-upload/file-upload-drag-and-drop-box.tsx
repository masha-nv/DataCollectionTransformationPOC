import { useState, DragEvent } from 'react';
import { Button, ButtonType } from '../button/button';

export interface FileUploadDragAndDropProps {
  selectFilesClick: () => void;
  onDropNewFiles: (files: File[]) => void;
}
export function FileUploadDragAndDropBox(props: FileUploadDragAndDropProps) {
  const [isDragging, setIsDragging] = useState(false);

  const onDropFiles = (dragEvent: DragEvent) => {
    dragEvent.preventDefault();
    dragEvent.stopPropagation();
    setIsDragging(false);
    const data = dragEvent.dataTransfer;
    const newFiles = Array.from(data.files);
    props.onDropNewFiles(newFiles);
  };

  const onDragEnterAndOver = (dragEvent: DragEvent) => {
    dragEvent.preventDefault();
    dragEvent.stopPropagation();
    setIsDragging(true);
  };

  const onDragLeave = (dragEvent: DragEvent) => {
    dragEvent.preventDefault();
    dragEvent.stopPropagation();
    setIsDragging(false);
  };

  return (
    <div
      id="drag-and-drop-box"
      className={`drag-and-drop-box ${isDragging ? 'dragging' : ''}`}
      onDrop={onDropFiles}
      onDragEnter={onDragEnterAndOver}
      onDragLeave={onDragLeave}
      onDragOver={onDragEnterAndOver}
    >
      <span>Drag & drop file(s) here or</span>{' '}
      <Button id="drag-drop-select-file-btn" onClick={props.selectFilesClick} type={ButtonType.tertiary}>
        Select file(s) to upload
      </Button>
    </div>
  );
}
