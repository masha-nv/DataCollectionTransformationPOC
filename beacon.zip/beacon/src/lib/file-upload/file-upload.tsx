import { useCallback, useEffect, useRef, useState } from 'react';
import { Button, ButtonType } from '../button/button';
import { Card, CardVariant } from '../cards/card';
import { Icon, IconType } from '../icon/icon';
import { Alert, AlertVariant } from '../notifications/alert/alert';
import { FileUploadDataTable } from './file-upload-datatable';
import { FileUploadDragAndDropBox } from './file-upload-drag-and-drop-box';
import { FileUploadCategorySelect } from './file-upload-category-select';
import { validateFiles, formatFileTypesToString } from './file-upload-utils';
import { UploadCategory, FilesWithCategory, CategorizedFile } from './file-upload.types';
import './file-upload.scss';

/* eslint-disable-next-line */
export interface FileUploadProps {
  /**
   * Text displayed at the top of the component
   */
  titleText: string;
  /**
   * Maximum number of files that can be uploaded at a time
   */
  maxFileCount: number;
  /**
   * Maximum file size in megabytes (MB)
   */
  maxFileSizeInMBs: number;
  /**
   * Array of acceptable formats of selected files. Example: ['pdf', 'jpg', 'png']
   */
  allowedFileFormats: string[];
  /**
   * List of user-selectable categories for file upload
   */
  fileUploadCategories: UploadCategory[];
  /**
   * Optionally hides the upload button (false by default)
   */
  hideUploadButton?: boolean;
  /**
   * Method to be called when the Upload button is clicked
   */
  onUploadClick?: (filesToUpload: FilesWithCategory) => void;
  /**
   * Called whenever file selection changes
   */
  onFileSelectionChange?: (filesWithCategory: FilesWithCategory[]) => void;
  /**
   * Allows for a default state of no category selected, and to reset the category selection to nothing
   */
  enableUnselectedDefault?: boolean;
}

export function FileUpload({
  hideUploadButton = false,
  onFileSelectionChange,
  onUploadClick,
  enableUnselectedDefault = false,
  ...props
}: FileUploadProps) {
  const [filesAndCategoriesToUpload, setFilesAndCategoriesToUpload] = useState<CategorizedFile[]>([]);
  const [shouldOpenFileBrowser, setShouldOpenFileBrowser] = useState(false);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<UploadCategory>();
  const inputFile = useRef<HTMLInputElement>(null);

  const openFileBrowser = () => {
    setShouldOpenFileBrowser(true);
  };

  const skipOpenFileBrowserOnReRender = useCallback(() => {
    setShouldOpenFileBrowser(false);
  }, []);

  useEffect(() => {
    if (!enableUnselectedDefault) {
      setSelectedCategory(props.fileUploadCategories[0]);
    }
  }, [props.fileUploadCategories, enableUnselectedDefault]);

  useEffect(() => {
    if (shouldOpenFileBrowser && inputFile.current) {
      inputFile.current.value = '';
      inputFile.current.click();
      skipOpenFileBrowserOnReRender();
    }
  }, [shouldOpenFileBrowser, skipOpenFileBrowserOnReRender]);

  useEffect(() => {
    const selectedFiles = filesAndCategoriesToUpload.map((file) => ({ files: [file.file], category: file.category }));
    onFileSelectionChange?.(selectedFiles);
  }, [filesAndCategoriesToUpload, onFileSelectionChange]);

  const addFiles = (newFiles: File[]) => {
    setValidationErrors([]);
    const newFilesWithAddedCategory: CategorizedFile[] = [];
    let nextId = Math.max(0, ...filesAndCategoriesToUpload.map((fileDescriptor) => fileDescriptor.id)) + 1;
    newFiles.forEach((file) => {
      const id = nextId++;
      const fileWithCategory: CategorizedFile = {
        file,
        id,
        category: selectedCategory,
      };
      newFilesWithAddedCategory.push(fileWithCategory);
    });

    const validationResults = validateFiles(
      newFilesWithAddedCategory,
      filesAndCategoriesToUpload,
      props.maxFileSizeInMBs,
      props.allowedFileFormats,
      props.maxFileCount
    );

    setFilesAndCategoriesToUpload(validationResults.validFiles);

    if (validationResults.errors.length > 0) {
      setValidationErrors(validationResults.errors);
    }
  };

  const fileBrowseInputOnChange = () => {
    if (inputFile.current?.files) {
      const newFiles = Array.from(inputFile.current.files);
      addFiles(newFiles);
    }
  };

  const removeAllFiles = () => {
    setFilesAndCategoriesToUpload([]);
  };

  const onSingleFileRemove = (files: CategorizedFile[]) => {
    setFilesAndCategoriesToUpload(files);
  };

  const onSelectCategoryChange = (category: UploadCategory | undefined) => {
    setSelectedCategory(category);
  };

  const newDroppedFiles = (newFiles: File[]) => {
    addFiles(newFiles);
  };

  const iterateOnUploadClick = () => {
    filesAndCategoriesToUpload
      .map((fileDescriptor) => ({
        files: [fileDescriptor.file],
        category: fileDescriptor.category,
      }))
      .forEach((filesWithCategory) => {
        onUploadClick?.(filesWithCategory);
      });
  };

  return (
    <div>
      <h3>{props.titleText}</h3>
      <Card id="upload-file-card" variant={CardVariant.gray}>
        <ul className="file-upload-instr-list">
          <li>
            <b>Only {props.maxFileCount} file(s)</b> may be uploaded at a time.
          </li>
          <li>
            Maximum file-size is <b>{props.maxFileSizeInMBs}MB</b> per file.
          </li>
          <li>
            Please make sure your file is in the proper format <b>({props.allowedFileFormats.join(', ')})</b>.
          </li>
        </ul>
        <FileUploadCategorySelect
          fileUploadCategories={props.fileUploadCategories}
          onCategoryChange={onSelectCategoryChange}
          enableUnselectedDefault={enableUnselectedDefault}
        />
        <span className="browse-btn">
          <Button
            id="browse-btn"
            onClick={openFileBrowser}
            type={ButtonType.secondary}
            disabled={
              filesAndCategoriesToUpload.length >= props.maxFileCount || (enableUnselectedDefault && !selectedCategory)
            }
          >
            <Icon type={IconType.search} />
            Browse
          </Button>
        </span>
      </Card>
      <input
        id="file-upload-input"
        type="file"
        ref={inputFile}
        onChange={fileBrowseInputOnChange}
        style={{ display: 'none' }}
        multiple={props.maxFileCount > 1}
        accept={formatFileTypesToString(props.allowedFileFormats)}
      />
      {filesAndCategoriesToUpload.length < props.maxFileCount && (!enableUnselectedDefault || selectedCategory) && (
        <FileUploadDragAndDropBox selectFilesClick={openFileBrowser} onDropNewFiles={newDroppedFiles} />
      )}
      {filesAndCategoriesToUpload.length > 0 && (
        <FileUploadDataTable
          currentlySelectedFiles={filesAndCategoriesToUpload}
          onSingleFileRemove={onSingleFileRemove}
        />
      )}
      {validationErrors.length > 0 &&
        validationErrors.map((error, index) => {
          return (
            <div key={index}>
              <Alert variant={AlertVariant.error} key={index}>
                {error}
              </Alert>
            </div>
          );
        })}
      <div className="file-upload-footer">
        {filesAndCategoriesToUpload.length > 0 && (
          <Button id="remove-all-files-btn" onClick={removeAllFiles} type={ButtonType.secondary}>
            Remove All
          </Button>
        )}
        {!hideUploadButton && (
          <div className="upload-btn">
            <Button
              id="upload-btn"
              onClick={iterateOnUploadClick}
              type={ButtonType.primary}
              disabled={filesAndCategoriesToUpload.length < 1}
            >
              <Icon type={IconType.cloudArrowUp} />
              Upload
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
