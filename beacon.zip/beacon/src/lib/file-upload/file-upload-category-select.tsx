import { Select, SelectOption } from '../forms/select/select';
import { UploadCategory } from './file-upload.types';
import { ISelectOption } from '../forms/select/select.types';
import { useState } from 'react';

export interface FileUploadCategorySelectProps {
  fileUploadCategories: UploadCategory[];
  onCategoryChange: (selectedCategory: UploadCategory | undefined) => void;
  enableUnselectedDefault: boolean;
}

export function FileUploadCategorySelect(props: FileUploadCategorySelectProps) {
  const [categorySelection, setCategorySelection] = useState<ISelectOption>();

  const onCategorySelect = (event: unknown, selection: ISelectOption) => {
    props.onCategoryChange(props.fileUploadCategories.find((category) => category.code === selection.value));
    setCategorySelection(selection);
  };

  return (
    <Select
      id="upload-file-select-category"
      label="Type of Document"
      filterable
      disabled={!props.enableUnselectedDefault && props.fileUploadCategories.length === 1}
      onChange={onCategorySelect}
      nullable={props.enableUnselectedDefault}
      required={true}
      unselectedText="Select Category..."
      value={categorySelection?.value}
    >
      {props.fileUploadCategories.map((category: UploadCategory) => {
        return (
          <SelectOption
            id={`category-option-${category.code}`}
            value={category.code}
            key={`select-option-${category.code}`}
          >
            {category.description}
          </SelectOption>
        );
      })}
    </Select>
  );
}
