import { create } from '@storybook/theming';
import image from './react-beacon-storybook.png';

export default create({
  base: 'light',
  brandTitle: 'React Beacon',
  brandUrl: 'https://pages.git.uscis.dhs.gov/USCIS/react-beacon',
  brandImage: image,
  colorSecondary: '#0071bb',
  barTextColor: '#767676',
  appBg: '#FDFEFE',
});
