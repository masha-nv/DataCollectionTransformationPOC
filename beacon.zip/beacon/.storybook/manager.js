import { addons } from '@storybook/addons';
import elisTheme from './ElisTheme';

addons.setConfig({
  theme: elisTheme,
  sidebar: {
    showRoots: false,
  },
});
