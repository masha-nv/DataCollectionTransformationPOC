import { addDecorator } from '@storybook/react';
import { withKnobs } from '@storybook/addon-knobs';
import { addParameters } from '@storybook/react';

addParameters({
  badgesConfig: {
    beta: {
      contrast: '#691212',
      color: '#fff',
      title: 'Beta',
    },
    espresso: {
      contrast: '#80140F',
      color: '#fff',
      title: 'Needs Espresso Review',
    },
    needs508: {
      contrast: '#4b1269',
      color: '#fff',
      title: 'Needs 508',
    },
    ready: {
      contrast: '#126914',
      color: '#fff',
      title: 'Ready',
    },
  },
});

addDecorator(withKnobs);

export const parameters = {
  controls: { expanded: true },
  options: {
    storySort: {
      method: 'alphabetical',
      order: [
        'Getting Started',
        'Styling',
        ['Color Palette', 'Typography', 'Icons'],
        'MDX',
        'Core Components',
        [
          'Accordions',
          'Action Menus',
          'AI Suggestions',
          'Buttons',
          'Cards',
          'Data View',
          'Form Controls',
          [
            'Checkboxes',
            'Date Picker',
            'Label',
            'Dropdowns (Multi-select)',
            'Dropdowns (Single-select)',
            'Radio Buttons',
            'Required Field Legend',
            'Rich Text Editor',
            'Search Bar',
            'Switch',
            'Text Area',
            'Text Input',
          ],
        ],
        'Design System',
        'Matomo Analytics',
      ],
      locales: '',
    },
  },
};
