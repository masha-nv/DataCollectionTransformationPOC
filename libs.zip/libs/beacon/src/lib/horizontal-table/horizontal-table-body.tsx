import { ReactNode } from 'react';
import { IHorizontalTableField } from './horizontal-table-types';
import './horizontal-table.scss';
import { Icon } from '../icon/icon';
import { IconType } from '../icon/constants';

interface IHorizontalTableBodyProps<T> {
  editMode: boolean;
  fields: IHorizontalTableField<T>[];
  data: T[];
}

const outputDataElements = <T,>(
  data: T[],
  field: IHorizontalTableField<T>,
  columnIndex: number,
  editMode: boolean
): ReactNode => {
  const tableRow: JSX.Element[] = [];

  data.forEach((record, index) => {
    let displayComponent: ReactNode = null;
    if ((field.showEdit || editMode) && field.edit != null) {
      displayComponent = field.edit(record, index);
    } else {
      displayComponent = field.cell ? field.cell(record, index) : record[field.field];
    }

    tableRow.push(
      <td className="data" key={`data-${index}-${field}`}>
        {displayComponent}
        {field.cellDecorator && field.cellDecorator(record, index) && (
          <span className="pl-2">
            <Icon
              type={field.cellDecorator(record, index).icon as IconType}
              variant={field.cellDecorator(record, index).variant}
            />
          </span>
        )}
      </td>
    );
  });
  return tableRow;
};

/**
 * Horizontal Table Body component
 */
const HorizontalTableBody = <T,>({ fields, data, editMode }: IHorizontalTableBodyProps<T>) => {
  const rows = fields.map((field, index) => {
    return (
      <tr key={`field-${index}`} style={{ backgroundColor: field.highlight ? field.highlight(data) : '' }}>
        <th
          style={{ backgroundColor: field.highlight ? field.highlight(data) : '' }}
          className="field"
          key={`field-${field.field.toString}-header`}
          scope="row"
        >
          {field.icon && (
            <>
              <Icon
                key={`icon-${field.field.toString}-${index}`}
                type={field.icon(data).icon as IconType}
                variant={field.icon(data).variant}
                description={field.icon(data).description}
              />
              <span key={`span-${field.field.toString}-${index}`} className="pl-2"></span>
            </>
          )}
          {field.label}
          <span key={`span-field-dec-${field.field.toString}-${index}`} className="float-right">
            {field.decorator && field.decorator(data)}
          </span>
        </th>
        {outputDataElements(data, field, index, editMode)}
      </tr>
    );
  });
  return <tbody>{rows}</tbody>;
};

export default HorizontalTableBody;
