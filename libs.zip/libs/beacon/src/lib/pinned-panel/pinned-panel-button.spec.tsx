import React from 'react';
import { render, screen } from '@testing-library/react';
import { PinnedPanelButton } from './pinned-panel-button';
import { IconType } from '../icon/constants';
import { track } from '../analytics/matomo';
import { TrackableEvent } from '../analytics';

jest.mock('../analytics/matomo', () => {
  const module = jest.requireActual('../analytics/matomo');
  return {
    ...module,
    track: jest.fn(),
  };
});

const myHandler = jest.fn();

describe('PinnedPanelButton', () => {
  it('renders successfully', () => {
    const { baseElement } = render(
      <PinnedPanelButton
        id="test-panel"
        title="Open Comments and Testimony"
        onClick={myHandler}
        icon={IconType.externalLinkAlt}
      />
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders with metaCount successfully', () => {
    const { baseElement } = render(
      <PinnedPanelButton
        id="test-panel"
        title="Open Comments and Testimony"
        metaCount={10}
        onClick={myHandler}
        icon={IconType.externalLinkAlt}
      />
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders with disabled true successfully', () => {
    const { baseElement } = render(
      <PinnedPanelButton
        id="test-panel"
        title="Open Comments and Testimony"
        disabled
        onClick={myHandler}
        icon={IconType.externalLinkAlt}
      />
    );
    expect(baseElement.querySelector('button')?.hasAttribute('disabled')).toBeTruthy();
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with default analytics', async () => {
    const { baseElement } = render(
      <PinnedPanelButton
        id="test-panel"
        title="Open Comments and Testimony"
        onClick={myHandler}
        icon={IconType.externalLinkAlt}
      />
    );

    const panel = screen.getByText('Open Comments and Testimony');
    panel.click();

    expect(myHandler).toHaveBeenCalled();
    expect(track).toHaveBeenCalledWith({
      grouping: 'Ungrouped',
      action: 'Clicked',
      trackingKey: 'PinnedPanel-test-panel',
    } as TrackableEvent);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with user provided analytics', async () => {
    const myCustomTracking: TrackableEvent = {
      grouping: 'Tests',
      action: 'Ran a test',
      trackingKey: 'Coolest of pinned panels',
    };

    const { baseElement } = render(
      <PinnedPanelButton
        id="test-panel"
        title="Open Comments and Testimony"
        tracking={myCustomTracking}
        onClick={myHandler}
        icon={IconType.externalLinkAlt}
      />
    );

    const panel = screen.getByText('Open Comments and Testimony');
    panel.click();

    expect(myHandler).toHaveBeenCalled();
    expect(track).toHaveBeenCalledWith({
      grouping: 'Tests',
      action: 'Ran a test',
      trackingKey: 'Coolest of pinned panels',
    } as TrackableEvent);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with customized heading', () => {
    const { baseElement } = render(
      <PinnedPanelButton
        id="test-panel"
        title="Open Comments and Testimony"
        headingType="h1"
        onClick={myHandler}
        icon={IconType.externalLinkAlt}
      />
    );

    expect(baseElement).toMatchSnapshot();
  });
});
