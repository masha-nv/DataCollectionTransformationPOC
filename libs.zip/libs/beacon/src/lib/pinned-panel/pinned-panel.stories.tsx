import React, { SyntheticEvent, useState } from 'react';
import { Meta, Story } from '@storybook/react';
import { a11yConfig } from '../stories/story.config';
import { IPinnedPanelProps, PinnedPanel } from './pinned-panel';
import { Documentation, dropdownFromHeadingTypes, StoryBadge } from '../stories';
import { PinnedPanelGroup } from './pinned-panel-group';
import { Button } from '../button/button';
import { PinnedPanelButton } from './pinned-panel-button';
import { action } from '@storybook/addon-actions';

export default {
  component: PinnedPanel,
  title: 'Core Components/Accordions/Pinned Panel',
  parameters: {
    a11y: a11yConfig,
    badges: [StoryBadge.READY],
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const argTypes = {
  headingType: {
    control: dropdownFromHeadingTypes(),
    defaultValue: 'h2',
  },
};

export const PrimaryPinnedPanel: Story<IPinnedPanelProps> = ({ headingType }: IPinnedPanelProps) => {
  const [disabled, setDisabled] = useState(true);

  return (
    <div>
      <Button id="disable-toggle" onClick={() => setDisabled(!disabled)}>
        Toggle Pinned Accordion Disable
      </Button>
      <PinnedPanelGroup id="sample-pinned-panel-group">
        <PinnedPanel
          id="panel-medical-records"
          title="Panel with count disclosure"
          metaCount={100}
          headingType={headingType}
        >
          <p>Inside the pinned panel you can add a lot of information including lists:</p>
          <ul>
            <li>Name: Smith Task</li>
            <li>Age: 32</li>
          </ul>
          <p className="mb-0">But don't get carried away!</p>
        </PinnedPanel>
        <PinnedPanel
          id="panel-lorem-ipsum"
          title="Panel with a fixed height (scrollable content)"
          maxHeight="200px"
          headingType={headingType}
        >
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque a nisl eget diam scelerisque molestie
            quis sed nibh. Nunc eu facilisis lacus, vitae pretium ex. Sed ligula nisi, ullamcorper a hendrerit vel,
            mattis vitae lacus. Sed ut nisi in dui rutrum faucibus ut ac nulla. Donec a enim interdum, pulvinar libero
            in, eleifend purus. Donec dignissim sapien imperdiet, malesuada neque a, maximus urna. Ut semper dapibus
            ipsum.
          </p>

          <p>
            Vivamus sollicitudin metus vel purus lobortis, nec mattis neque rhoncus. Proin risus velit, sodales vel
            congue in, molestie a eros. Maecenas vulputate, quam ut dignissim facilisis, nisl enim tristique justo,
            hendrerit convallis leo purus non nunc. Vestibulum sit amet posuere mauris. Maecenas molestie lectus quis
            nunc posuere mollis. Donec at ipsum ut orci euismod ornare ut dapibus nisi. Ut tincidunt, magna vel
            facilisis interdum, est neque congue est, sollicitudin dapibus metus ex id dui. Aliquam quis nisi id erat
            auctor congue vitae vitae felis. Vestibulum quis nulla ut eros iaculis auctor at eget urna. Morbi placerat
            turpis a diam feugiat bibendum. Aliquam eu augue nunc. Pellentesque tristique ante quis iaculis tempus.
            Etiam sagittis ipsum viverra justo eleifend, eget tincidunt ipsum luctus. Quisque consequat tellus ut justo
            aliquam, ut bibendum lectus imperdiet. Vestibulum sed augue eget odio efficitur aliquam sed et nulla.
          </p>

          <p>
            Sed pellentesque rutrum neque, ut finibus lacus sollicitudin et. Donec sit amet erat imperdiet est fermentum
            vestibulum at in velit. Suspendisse dolor metus, accumsan sit amet enim sit amet, congue hendrerit purus.
            Nulla scelerisque ipsum faucibus diam gravida feugiat. Nullam lacinia feugiat euismod. Nunc molestie, mauris
            a porttitor ornare, elit nunc posuere lectus, id fermentum nulla augue vel risus. Nunc lectus arcu,
            tincidunt sed ullamcorper eu, blandit vel nisl. Vestibulum semper consectetur nulla, in auctor velit
            malesuada vitae. Proin id lacus risus. Nullam elementum purus dapibus leo ultrices, a gravida dolor
            placerat. Quisque consectetur massa dui, non facilisis augue sodales non. Nunc sodales a metus et ultrices.
            Proin in orci velit. Quisque arcu diam, malesuada eget augue vel, ornare facilisis felis. Morbi ut vehicula
            augue.
          </p>

          <p>
            In et dictum ipsum, quis pellentesque risus. Nam tortor orci, tempus ac varius hendrerit, porta ut risus.
            Proin enim mauris, fringilla quis lobortis a, molestie eu elit. Etiam dapibus, nulla sed iaculis faucibus,
            felis massa auctor mi, vitae malesuada urna eros vitae mi. Etiam molestie consequat lacus, sit amet porta
            odio facilisis vitae. Vestibulum dignissim diam ut quam fringilla fermentum. Integer eu purus et nunc mollis
            volutpat. Donec pellentesque rhoncus elit, ut mattis velit gravida condimentum. Donec et fringilla nibh.
            Donec vulputate nibh ex, non imperdiet ante laoreet eu. Quisque ipsum arcu, varius a blandit vitae, tempus
            ut quam. Mauris ullamcorper ante nisl, a faucibus nibh fringilla at.
          </p>
        </PinnedPanel>
        <PinnedPanel
          id="disabled-panel"
          title="Disabled and not expandable"
          disabled={disabled}
          headingType={headingType}
        >
          Nothing to see here
        </PinnedPanel>
      </PinnedPanelGroup>
    </div>
  );
};

PrimaryPinnedPanel.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Pinned Panel"
      description={
        <>
          Pinned panel accordions are sticky to the bottom of the screen. They expand upwards when opened. Their primary
          use is for officer comments and testimony.
        </>
      }
      whenToUse={
        <p>
          Pinned panels should be used when it is necessary to display large amounts of data in an environment where
          screen real estate is limited, particularly when the data is connected or relevant to most of the existing
          page content.
        </p>
      }
    >
      <ComponentStory />
    </Documentation>
  ),
];
PrimaryPinnedPanel.storyName = 'Pinned Panel';
PrimaryPinnedPanel.argTypes = argTypes;

export const CustomAnalytics: Story<IPinnedPanelProps> = ({ headingType }: IPinnedPanelProps) => {
  const onClickHandler = (e: SyntheticEvent) => action('button-click')(e);

  return (
    <PinnedPanelGroup id="analytics-panels">
      <PinnedPanel id="emails-panel" title="Emails" headingType={headingType}>
        This uses the default tracking values
      </PinnedPanel>
      <PinnedPanel
        id="names-panel"
        title="Names"
        tracking={{
          grouping: 'Storybook Panels',
          action: 'Open/Close the panel',
        }}
        headingType={headingType}
      >
        This one just overrides the default <code>grouping</code>, note that the <code>action</code> even if specified,
        cannot be overriden
      </PinnedPanel>
      <PinnedPanel
        id="addresses-panel"
        title="Addresses"
        tracking={{
          grouping: 'Storybook Panels',
          trackingKey: 'Addresses area',
        }}
        headingType={headingType}
      >
        Addresses, this one will track with a custom <code>grouping</code> and <code>trackingKey</code>
      </PinnedPanel>
      <PinnedPanelButton title={'Dates of Birth'} onClick={onClickHandler} id={'dob-panel'} />
    </PinnedPanelGroup>
  );
};

CustomAnalytics.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Overriding analytics reporting"
      description={
        <>
          Take a look at the code for the following and open your developer tools. You'll notice each{' '}
          <code>PinnedPanel</code> on this canvas overrides the <code>tracking</code> property with a partial{' '}
          <code>TrackableEvent</code>.These get applied by the <code>PinnedPanel</code> to customize the tracking
          parameters.
          <br />
          <br />
          The first parameter uses the default tracking that you get out of the box. The second overrides the grouping
          and action (but the action is ignored). The third overrides the tracking key and grouping. The fourth is an
          example using the <code>PinnedPanelButton</code> which has a different default action parameter. Notice on the
          console logs how each of those will report to Matomo.
        </>
      }
    >
      <ComponentStory />
    </Documentation>
  ),
];
CustomAnalytics.storyName = 'Pinned Panel Custom Analytics';
CustomAnalytics.argTypes = argTypes;
