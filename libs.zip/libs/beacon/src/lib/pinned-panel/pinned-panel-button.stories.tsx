import React, { SyntheticEvent } from 'react';
import { Meta, Story } from '@storybook/react';
import { a11yConfig } from '../stories/story.config';
import { IPinnedPanelProps } from './pinned-panel';
import { Documentation, dropdownFromHeadingTypes, StoryBadge } from '../stories';
import { PinnedPanelGroup } from './pinned-panel-group';
import { PinnedPanelButton } from './pinned-panel-button';
import { IconType } from '../icon/constants';
import { action } from '@storybook/addon-actions';

export default {
  component: PinnedPanelButton,
  title: 'Core Components/Accordions/Pinned Panel',
  parameters: {
    a11y: a11yConfig,
    badges: [StoryBadge.READY],
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const argTypes = {
  headingType: {
    control: dropdownFromHeadingTypes(),
    defaultValue: 'h2',
  },
};

export const ButtonPinnedPanel: Story<IPinnedPanelProps> = ({ headingType }: IPinnedPanelProps) => {
  const onClickHandler = (e: SyntheticEvent) => action('button-click')(e);

  return (
    <div>
      <PinnedPanelGroup id="sample-pinned-panel-group">
        <PinnedPanelButton
          id="panel-open-testimony"
          title="Open Comments and Testimony"
          metaCount={100}
          headingType={headingType}
          icon={IconType.externalLinkAlt}
          onClick={onClickHandler}
        />
        <PinnedPanelButton
          id="panel-open-testimony"
          title="Open Comments (Disabled)"
          metaCount={100}
          headingType={headingType}
          icon={IconType.externalLinkAlt}
          onClick={onClickHandler}
          disabled
        />
      </PinnedPanelGroup>
    </div>
  );
};

ButtonPinnedPanel.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Pinned Panel Button"
      description={
        <>
          Pinned panel buttons stick to the bottom of the screen like normal pinned panels, but act as buttons, and are
          not expandable. Their primary use is for officer comments and testimony.
        </>
      }
      whenToUse={
        <p>
          Pinned panel buttons should be used when it is necessary to make an specific action available in an
          environment where screen real estate is limited, particularly when the action is connected or relevant to most
          of the existing page content.
        </p>
      }
    >
      <ComponentStory />
    </Documentation>
  ),
];
ButtonPinnedPanel.storyName = 'Pinned Panel Button';
ButtonPinnedPanel.argTypes = argTypes;
