import { SyntheticEvent } from 'react';
import { Trackable, defaultTracking, getTrackableClickHandler } from '../analytics';
import { HeadingType, Heading } from '../heading/heading';
import { IconType } from '../icon/constants';
import { Icon } from '../icon/icon';
import { Bubble, BubbleType } from '../notifications/bubble/bubble';
import { WithId } from '../with-id';

export interface IPinnedPanelButtonProps extends Trackable, WithId {
  /**
   * Value that will be displayed for pinned-panel
   */
  title: string;
  /**
   * (optional) An integer to display inside a bubble next to the title.
   */
  metaCount?: number;
  /**
   * (optional) Default state for disable/enabled when the component loads
   */
  disabled?: boolean;
  /**
   * (optional) function to be executed when the panel title is clicked
   */
  onClick: (param: SyntheticEvent) => void;
  /**
   * The type of heading used for the title.
   */
  headingType?: HeadingType;
  /**
   * (optional) The type of icon used for non-collapsable headers
   */
  icon?: IconType;
}
export const PinnedPanelButton = ({
  id,
  title,
  metaCount,
  disabled,
  tracking,
  onClick,
  headingType,
  icon,
}: IPinnedPanelButtonProps) => {
  const trackingDefaults = defaultTracking(tracking, {
    grouping: 'Ungrouped',
    action: 'Clicked',
    trackingKey: 'PinnedPanel-' + id,
  });
  const titleClass =
    metaCount !== null && metaCount !== undefined ? 'beacon-accordion-title mr-2' : 'beacon-accordion-title';

  return (
    <div id={id} className={`accordion-tab pinned-panel-container ${disabled ? 'accordion-tab-disabled' : ''}`}>
      <button
        id={id}
        className={`text-left pinned-panel-header ${disabled ? 'pinned-panel-disabled' : ''}`}
        disabled={disabled}
        onClick={getTrackableClickHandler(tracking, trackingDefaults, onClick)}
      >
        <span className={titleClass}>
          <Heading headingType={headingType ? headingType : 'h2'} headingStyle="m">
            {title}
          </Heading>
        </span>
        {metaCount !== null && metaCount !== undefined && <Bubble type={BubbleType.default}>{metaCount}</Bubble>}
        {icon && (
          <div className="toggle-icon fas">
            <Icon type={icon}></Icon>
          </div>
        )}
      </button>
    </div>
  );
};
