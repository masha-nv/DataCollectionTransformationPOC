import React from 'react';
import { render } from '@testing-library/react';

import { PinnedPanel } from './pinned-panel';

describe('PinnedPanel', () => {
  it('renders successfully', () => {
    const { baseElement } = render(
      <PinnedPanel id="test-panel" title="Medical Records">
        <p>Test</p>
      </PinnedPanel>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders with maxHeight successfully', () => {
    const { baseElement } = render(
      <PinnedPanel id="test-panel" title="Medical Records" maxHeight="10px">
        <p>Test</p>
      </PinnedPanel>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('renders with metaCount successfully', () => {
    const { baseElement } = render(
      <PinnedPanel id="test-panel" title="Medical Records" metaCount={10}>
        <p>Test</p>
      </PinnedPanel>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('cannot be expanded when disabled', () => {
    const { baseElement } = render(
      <PinnedPanel id="test-panel" title="Medical Records" disabled>
        <p>Test</p>
      </PinnedPanel>
    );
    let button = baseElement.querySelector('button');
    button.click();

    button = baseElement.querySelector('button');
    expect(button.className.includes('collapsed')).toBeTruthy();
    expect(baseElement).toMatchSnapshot();
  });

  it('can be expanded by default', () => {
    const { baseElement } = render(
      <PinnedPanel id="test-panel" title="Medical Records" defaultExpanded>
        <p>Test</p>
      </PinnedPanel>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('does not display content when disabled', () => {
    const { baseElement } = render(
      <PinnedPanel id="test-panel" title="Medical Records" disabled defaultExpanded>
        <p>Test</p>
      </PinnedPanel>
    );

    expect(baseElement).toMatchSnapshot();
  });

  it('successfully expands', () => {
    const { baseElement } = render(
      <PinnedPanel id="test-panel" title="Medical Records">
        <p>Tomato</p>
      </PinnedPanel>
    );
    let button = baseElement.querySelector('button');
    button.click();

    button = baseElement.querySelector('button');
    expect(button.className.includes('collapsed')).toBeFalsy();
  });

  it('renders with customized heading', () => {
    const { baseElement } = render(
      <PinnedPanel id="test-panel" title="Medical Records" headingType="h1">
        <p>Test</p>
      </PinnedPanel>
    );

    expect(baseElement).toMatchSnapshot();
  });
});
