import { ReactElement, ReactNode, SyntheticEvent } from 'react';
import { WithId } from '../with-id';
import { IBadgeProps } from '../notifications/badge/badge';
import { IButtonProps } from '../button/button';
import { HeadingStyle, HeadingType } from '../heading/heading';
import { FieldValues, UseFormHandleSubmit } from 'react-hook-form';

export interface IDataViewRowProps<T> extends WithId {
  /**
   * The object that contains the values to be displayed
   */
  data: T;
  /**
   * The index of the row in the fields array
   */
  index: number;
  /**
   * The options to describe the row
   */
  field: IDataViewFieldProps<T>;
  /**
   * Is the row in edit view
   */
  isEditing: boolean;
  /**
   * Toggle to expand the row
   */
  isExpanded?: boolean;
  /**
   * Show badge column only if there are badges present
   */
  showBadgeColumns: boolean;
}

export interface IDataViewFieldAction {
  /**
   * Label of the Action when Details is hidden.
   */
  label: string;
  /**
   * callback function of the Action when Detils is hidden.
   */
  onClick: (param: SyntheticEvent) => void;
  /**
   * Label of the Action when Details is shown. Will default to `label`.
   */
  labelSecondary?: string;
  /**
   * callback function of the Action when Details is shown. Will default to `onClick`.
   */
  onClickSecondary?: (param: SyntheticEvent) => void;
}

export interface IDataViewFieldProps<T> {
  /**
   * The label of the field
   */
  label: string | ReactElement;
  /**
   * The path to the data in the Data object
   */
  field?: string;
  /**
   * Toogle to require the field in edit view
   */
  isFieldRequired?: boolean;
  /**
   * Toogle to to shift the action menu left (true by default)
   */
  isShiftedLeft?: boolean;
  /**
   * Tooltip text for the ActionMenu button
   */
  menuButtonTitle?: string;
  /**
   * The function to display the readonly view of the data
   */
  readonly?: (value: unknown, data: T, index: number) => ReactNode;
  /**
   * The function to display the details of the data
   */
  details?: (value: unknown, data: T, index: number) => ReactNode;
  /**
   * The function that return an array of actions for the row
   */
  actions?: (value: unknown, data: T, index: number, toggle: () => void) => IDataViewFieldAction[];
  /**
   * the function to display the edit view of the data
   */
  edit?: (value: unknown, data: T, index: number) => ReactNode;
  badge?: (value: unknown, data: T, index: number) => ReactElement<IBadgeProps>;
  /**
   * whether to omit this field
   */
  omit?: boolean;
  isEditable?: boolean;
  /**
   * Whether the field is deactivated. If it is, the value will appear crossed out.
   */
  isDeactivated?: boolean;
}

export enum DataViewLabelColumnWidth {
  default = 'dataview-row-col-label-default',
  small = 'dataview-row-col-label-sm',
  medium = 'dataview-row-col-label-md',
  large = 'dataview-row-col-label-lg',
}

export interface IDataViewProps<T> extends WithId {
  /**
   * Object that contains the values to be displayed
   */
  data: T;
  /**
   * Array of fields to describe each row.
   */
  fields: IDataViewFieldProps<T>[];
  /**
   * Title of the dataview
   */
  title: string | ReactNode;
  /**
   * Toggle to switch to edit view
   */
  isEditable?: boolean;
  /**
   * Toggle to expanded all details
   */
  isDetailsExpanded?: boolean;
  /**
   * Optional setting to explicitly define the width of the data view's label column
   */
  labelColumnWidth?: DataViewLabelColumnWidth;

  /**
   * Custom controls for the toolbar.  Only rendered when isEditable is false
   * and is only rendered on the right half of the data-view
   */
  toolbar?: ReactNode;

  /**
   * Footer buttons. Only rendered when isEditable is true
   */
  footerBar?: React.ReactElement<IButtonProps>[];
  /**
   * The type of heading used for the title.
   */
  headingType?: HeadingType;
  /**
   * The heading style used for the title.
   */
  headingStyle?: HeadingStyle;
}

export interface IDataViewFormProps<T, SubmitDataType> extends IDataViewProps<T> {
  /**
   * onSubmit to pass to the form
   */
  onSubmit: (formData: SubmitDataType) => void;
  /**
   * onError to pass to the form
   */
  onError: (formData: FieldValues) => void;
  /**
   * handleSubmit to pass to the form
   */
  handleSubmit: UseFormHandleSubmit<FieldValues>;
  /**
   * Any errors to display in the header
   */
  errorMessages?: string[];
}
