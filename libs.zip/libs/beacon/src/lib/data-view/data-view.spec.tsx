import React, { ReactNode } from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { DataView } from './data-view';
import userEvent from '@testing-library/user-event';
import { TextInput } from '../forms/text-input/text-input';
import { IDataViewFieldAction, IDataViewFieldProps } from './data-view-types';
import { noop } from '../utils';
import { ReadonlyExample } from './data-view.stories';
import { SubmitButton } from '../button/submit-button';
import { Button, ButtonType } from '../button/button';

export interface ITestData {
  basic: string;
  more: string;
}

const getBasicFields = () =>
  [
    { field: 'basic', label: 'basic-label' },
    { field: 'more', label: 'more-label' },
  ] as IDataViewFieldProps<ITestData>[];
const getBasicData = () =>
  ({
    basic: 'basic',
    more: 'more',
  } as ITestData);

const getBasicDataView = ({ data = getBasicData(), fields = getBasicFields() }) => (
  <DataView id="dataview" title="Default View" data={data} fields={fields} />
);
const getRequiredFields = () =>
  [
    { field: 'basic', label: 'basic-label', isFieldRequired: true },
    { field: 'more', label: 'more-label', isFieldRequired: true },
  ] as IDataViewFieldProps<ITestData>[];
describe('DataView Component', () => {
  it('renders default', async () => {
    const { baseElement } = render(getBasicDataView({}));
    await waitFor(() => {
      expect(baseElement).toMatchSnapshot();
    });
  });

  it('renders without specific field', async () => {
    const fields = getBasicFields();
    fields[0].field = null;
    const { baseElement } = render(getBasicDataView({ fields }));
    await waitFor(() => {
      expect(baseElement).toMatchSnapshot();
    });
  });

  it('renders custom readonly', async () => {
    const fields = getBasicFields();
    fields[0]['readonly'] = (value, data, index): ReactNode => {
      return (
        <div>
          <div>Custom Readonly</div>
          <div>{value}</div>
        </div>
      );
    };
    const { baseElement } = render(getBasicDataView({ fields: fields }));
    await waitFor(() => {
      expect(baseElement).toMatchSnapshot();
    });
  });

  it('renders with nested data', async () => {
    const fields = getBasicFields();
    fields[0].field = 'nest.data';
    const data = getBasicData() as ITestData & { nest: unknown };
    data.nest = {
      data: 'nestedData',
    };
    const { baseElement } = render(getBasicDataView({ data: data, fields: fields }));
    await waitFor(() => {
      expect(baseElement).toMatchSnapshot();
    });
  });

  it('renders without data field', async () => {
    const fields = getBasicFields();
    fields[0].field = 'nest.test';
    const { baseElement } = render(getBasicDataView({ fields: fields }));
    await waitFor(() => {
      expect(baseElement).toMatchSnapshot();
    });
  });

  it('with omitted row', async () => {
    const fields = getBasicFields();
    fields[0].omit = true;
    const { baseElement } = render(getBasicDataView({ fields: fields }));
    await waitFor(() => {
      expect(baseElement).toMatchSnapshot();
    });
  });

  it('render with details and actions', async () => {
    const fields = getBasicFields();
    fields[0]['details'] = (value, data, index): ReactNode => {
      return <p>Testing Details</p>;
    };

    fields[0].menuButtonTitle = 'Custom title for an action';
    fields[0].actions = (value: unknown, data: unknown, index: number, toggle: () => void): IDataViewFieldAction[] => [
      {
        label: 'test label',
        onClick: noop,
        labelSecondary: 'second label',
        onClickSecondary: noop,
      },
    ];
    const { baseElement } = render(getBasicDataView({ fields: fields }));
    await waitFor(() => {
      expect(baseElement).toMatchSnapshot();
    });
  });

  it('render with details and actions without secondary', async () => {
    const fields = getBasicFields();
    fields[0]['details'] = (field, record, index): ReactNode => {
      return <p>Testing Details</p>;
    };
    fields[0].actions = (value: unknown, data: unknown, index: number, toggle: () => void): IDataViewFieldAction[] => [
      {
        label: 'test label',
        onClick: noop,
      },
    ];
    const { baseElement } = render(getBasicDataView({ fields: fields }));
    await waitFor(() => {
      expect(baseElement).toMatchSnapshot();
    });
  });

  it('render with details while expanded', async () => {
    const fields = getBasicFields();
    fields[0]['details'] = (value, data, index): ReactNode => {
      return <p>Testing Details</p>;
    };
    const { baseElement } = render(
      <DataView id="dataview" title="Default View" data={getBasicData()} fields={fields} isDetailsExpanded={true} />
    );
    await waitFor(() => {
      expect(baseElement).toMatchSnapshot();
    });
  });

  it('click details action trigger', async () => {
    const stub = jest.fn();
    const label = 'test label';
    const fields = getBasicFields();
    fields[0]['details'] = (value, data, index): ReactNode => {
      return <p>Testing Details</p>;
    };
    fields[0].actions = (
      field: unknown,
      record: unknown,
      index: number,
      toggle: () => void
    ): IDataViewFieldAction[] => [
      {
        label: label,
        onClick: () => {
          toggle();
          stub();
        },
      },
    ];
    const { baseElement } = render(
      <DataView id="dataview" title="Default View" data={getBasicData()} fields={fields} />
    );
    userEvent.click(screen.getByText(label));
    expect(stub).toHaveBeenCalled();
    await waitFor(() => {
      expect(baseElement).toMatchSnapshot();
    });
  });

  it('renders badges correctly', async () => {
    const { baseElement } = render(<ReadonlyExample />);

    await waitFor(() => {
      expect(baseElement).toMatchSnapshot();
    });
  });

  it('renders toolbar correctly', async () => {
    const fields = getBasicFields();
    const { baseElement } = render(
      <DataView
        id="dataview"
        title="Default View"
        data={getBasicData()}
        fields={fields}
        toolbar={
          <Button id="btn-edit" type={ButtonType.tertiary} onClick={noop}>
            Edit
          </Button>
        }
      />
    );
    await waitFor(() => {
      expect(baseElement).toMatchSnapshot();
    });
  });

  it('renders Edit mode correctly', async () => {
    const fields = getRequiredFields();
    fields[0].edit = (value: unknown, data, index): ReactNode => {
      return <TextInput id="edit-input" name="edit-input" defaultValue={value as string}></TextInput>;
    };
    const { baseElement } = render(
      <DataView
        id="dataview"
        title="Default View"
        data={getBasicData()}
        fields={fields}
        isEditable={true}
        footerBar={[
          <SubmitButton key="btn-save" id={`btn-save`}>
            Save
          </SubmitButton>,
        ]}
      />
    );
    await waitFor(() => {
      expect(baseElement).toMatchSnapshot();
    });
  });

  it('renders with customized header', async () => {
    const data = getBasicData();
    const fields = getBasicFields();
    const { baseElement } = render(
      <DataView id="dataview" title="Default View" data={data} fields={fields} headingType="h1" headingStyle="m" />
    );
    await waitFor(() => {
      expect(baseElement).toMatchSnapshot();
    });
  });

  it('renders custom label', async () => {
    const fields = getBasicFields();
    fields[0].label = (
      <p>
        <strong>test</strong> test test
      </p>
    );
    fields[0].actions = (value: unknown, data: unknown, index: number, toggle: () => void): IDataViewFieldAction[] => [
      {
        label: 'test',
        onClick: noop,
      },
    ];
    const { baseElement } = render(getBasicDataView({ fields: fields }));
    await waitFor(() => {
      expect(baseElement).toMatchSnapshot();
    });
  });

  it('renders empty dataview message', async () => {
    const fields: IDataViewFieldProps<ITestData>[] = [];
    const data = {} as ITestData;
    const { baseElement } = render(getBasicDataView({ fields: fields, data: data }));
    expect(baseElement).toMatchSnapshot();
  });

  it('renders empty dataview message with null fields', async () => {
    const fields: IDataViewFieldProps<ITestData>[] = [];
    const data = {} as ITestData;
    const { baseElement } = render(getBasicDataView({ fields: null, data: data }));
    expect(baseElement).toMatchSnapshot();
  });

  it('renders empty dataview message with empty fields', async () => {
    const fields: IDataViewFieldProps<ITestData>[] = [];
    const data = {} as ITestData;
    const { baseElement } = render(getBasicDataView({ fields: {} as IDataViewFieldProps<unknown>[], data: data }));
    expect(baseElement).toMatchSnapshot();
  });
});
