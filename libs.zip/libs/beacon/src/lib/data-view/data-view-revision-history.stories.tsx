import { useState } from 'react';
import { Meta, Story } from '@storybook/react';
import { Documentation, dropdownFromHeadingStyles, dropdownFromHeadingTypes, StoryBadge } from '../stories';
import { a11yConfig } from '../stories/story.config';
import { DataViewLabelColumnWidth, IDataViewFieldProps, IDataViewFormProps, IDataViewProps } from './data-view-types';
import * as yup from 'yup';
import { FieldValues, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { action } from '@storybook/addon-actions';
import {
  IRevisionHistoryWrapperData,
  RevisionHistory,
} from './revision-history-wrapper-rows/data-view-revision-history-wrapper-types';
import { RevisionHistoryWrapperYesNoDataView } from './revision-history-wrapper-rows/data-view-revision-history-yes-no';
import {
  CurrencyDataViewRow,
  PHONE_MATCHES_FAIL_MESSAGE,
  PHONE_REGEXP,
  PhoneDataViewRow,
  RevisionHistoryWrapperTextView,
} from './revision-history-wrapper-rows/data-view-revision-history-text';
import { IRevisionHistoryWrapperRadioOption } from './revision-history-wrapper-rows/data-view-revision-history-radio-types';
import { RevisionHistoryWrapperRadioDataView } from './revision-history-wrapper-rows/data-view-revision-history-radio';
import {
  RevisionHistoryWrapperSingleSelectView,
  SelectDataViewRow,
} from './revision-history-wrapper-rows/data-view-revision-history-single-select';
import { RevisionHistoryWrapperDatePickerView } from './revision-history-wrapper-rows/data-view-revision-history-date-picker';
import { RevisionHistoryWrapperCheckboxesView } from './revision-history-wrapper-rows/data-view-revision-history-checkboxes';
import { ISimpleCheckboxOptionProp } from '../forms/checkboxes/simple-checkboxes/simple-checkbox-list-types';
import { RadioOptionType } from '../forms/radio/radio-option';
import { Alert, AlertVariant } from '../notifications/alert/alert';
import { Button, ButtonType } from '../button/button';
import { IconType } from '../icon/constants';
import { Icon } from '../icon/icon';
import { SubmitButton } from '../button/submit-button';
import { Form } from '../forms/form/form';
import { DataView } from './data-view';
import { SelectOptionValue } from '../forms/select/select.types';

const buildErrorAlert = (message: string, index: number) => {
  return (
    <Alert variant={AlertVariant.error} key={index}>
      {message}
    </Alert>
  );
};

const DataViewForm = <T, SubmitDataType>({
  id,
  isEditable = false,
  onSubmit,
  onError,
  handleSubmit,
  title,
  labelColumnWidth = DataViewLabelColumnWidth.default,
  fields,
  isDetailsExpanded,
  data,
  headingType,
  headingStyle,
  errorMessages,
}: IDataViewFormProps<T, SubmitDataType>) => {
  const [editModeActive, setEditModeActive] = useState<boolean>(isEditable);

  const formSubmit = (formData: FieldValues) => {
    onSubmit(formData as SubmitDataType);
    setEditModeActive(false);
  };

  const toolbar = (
    <Button
      id={`${id}-btn-edit`}
      type={ButtonType.tertiary}
      onClick={() => {
        setEditModeActive(true);
      }}
    >
      <Icon type={IconType.pencilAlt} />
      Edit
    </Button>
  );
  const footerBar = [
    <Button
      id={`${id}-btn-cancel`}
      key={`${id}-btn-cancel`}
      onClick={() => {
        setEditModeActive(false);
      }}
      type={ButtonType.secondary}
    >
      Cancel
    </Button>,
    <SubmitButton id={`${id}-btn-save`} key={`${id}-btn-save`}>
      Save
    </SubmitButton>,
  ];

  return (
    <div className="w-75">
      {errorMessages && errorMessages.map((message: string, index: number) => buildErrorAlert(message, index))}
      <Form onSubmit={handleSubmit(formSubmit, onError)}>
        <DataView
          id={id}
          isEditable={editModeActive}
          title={title}
          toolbar={toolbar}
          labelColumnWidth={labelColumnWidth}
          fields={fields}
          isDetailsExpanded={isDetailsExpanded}
          footerBar={footerBar}
          data={data}
          headingType={headingType}
          headingStyle={headingStyle}
        />
      </Form>
    </div>
  );
};

export default {
  component: DataViewForm,
  title: 'Core Components/Data View/Revisioned',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const argTypes = {
  headingType: {
    control: dropdownFromHeadingTypes(),
    defaultValue: 'h3',
  },
  headingStyle: {
    control: dropdownFromHeadingStyles(),
    defaultValue: 's',
  },
};

interface EmployerRevisionHistoryWrapperData {
  yesNoLatestIsYes: IRevisionHistoryWrapperData<string>;
  yesNoLatestIsNo: IRevisionHistoryWrapperData<string>;
  yesNoLatestIsBoth: IRevisionHistoryWrapperData<string>;
  phoneNumber: IRevisionHistoryWrapperData<string>;
}

const REVISION_HISTORY_DATA = {
  yesNoLatestIsYes: {
    latest: {
      item: 'Yes',
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1743699400657,
      sourceType: 'INTERNAL',
      revisionNumber: 2,
    },
    history: [] as RevisionHistory<string>[],
  },
  yesNoLatestIsNo: {
    latest: {
      item: 'No',
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1743699459708,
      sourceType: 'INTERNAL',
      revisionNumber: 2,
    },
    history: [] as RevisionHistory<string>[],
  },
  yesNoLatestIsBoth: {
    latest: {
      item: 'Yes & No',
      enteredBy: 'LOCKBOX',
      dateOfAnswer: 1743699351187,
      sourceType: 'EXTERNAL',
      revisionNumber: 2,
    },
    history: [
      {
        item: 'Yes & No',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351087,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
  textExample: {
    latest: {
      item: 'Here is the latest text',
      enteredBy: 'LOCKBOX',
      dateOfAnswer: 1743699351187,
      sourceType: 'EXTERNAL',
      revisionNumber: 3,
    },
    history: [
      {
        item: 'Here is the deactivated text',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351087,
        sourceType: 'EXTERNAL',
        revisionNumber: 2,
        isDeactivated: true,
      },
      {
        item: 'Here is the older text',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351087,
        sourceType: 'EXTERNAL',
        revisionNumber: 2,
      },
      {
        item: null,
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351080,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
  phoneNumber: {
    latest: {
      item: '3029579631',
      enteredBy: 'LOCKBOX',
      dateOfAnswer: 1743699351187,
      sourceType: 'EXTERNAL',
      revisionNumber: 2,
    },
    history: [
      {
        item: '9851345826',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351087,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
  currency: {
    latest: {
      item: '102500.50',
      enteredBy: 'LOCKBOX',
      dateOfAnswer: 1743699351187,
      sourceType: 'EXTERNAL',
      revisionNumber: 2,
    },
    history: [
      {
        item: '102500',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351087,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
  textExampleUneditable: {
    latest: {
      item: 'Here is the latest uneditable text',
      enteredBy: 'LOCKBOX',
      dateOfAnswer: 1743699351187,
      sourceType: 'EXTERNAL',
      revisionNumber: 3,
    },
    history: [
      {
        item: 'Here is the older text',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351087,
        sourceType: 'EXTERNAL',
        revisionNumber: 2,
      },
      {
        item: null,
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351080,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
  singleSelectExample: {
    latest: {
      item: '7623',
      enteredBy: 'LOCKBOX',
      dateOfAnswer: 1743699351187,
      sourceType: 'EXTERNAL',
      revisionNumber: 3,
    },
    history: [
      {
        item: '56345',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351087,
        sourceType: 'EXTERNAL',
        revisionNumber: 2,
      },
      {
        item: '1243',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351087,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
  radioExample: {
    latest: {
      item: 3,
      enteredBy: 'LOCKBOX',
      dateOfAnswer: 1743699351187,
      sourceType: 'EXTERNAL',
      revisionNumber: 2,
    },
    history: [
      {
        item: 2,
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1743699351087,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
  datePickerExample: {
    latest: {
      item: '09/05/2025',
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1744733233310,
      sourceType: 'INTERNAL',
      revisionNumber: 2,
    },
    history: [
      {
        item: '03/26/1983',
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1744732689645,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
  checkboxListExample: {
    latest: {
      item: ['OPTION_1', 'OPTION_3', 'OPTION_5', 'An option that is no longer there'],
      enteredBy: 'FIVE, CASEACCESS',
      dateOfAnswer: 1744819729168,
      sourceType: 'INTERNAL',
      revisionNumber: 2,
    },
    history: [
      {
        item: ['OPTION_1', 'OPTION_5', 'An option that is no longer there'],
        enteredBy: 'LOCKBOX',
        dateOfAnswer: 1744819694199,
        sourceType: 'EXTERNAL',
        revisionNumber: 1,
      },
    ],
  },
};

export const RevisionHistoryExample: Story<IDataViewProps<EmployerRevisionHistoryWrapperData>> = ({
  headingType,
  headingStyle,
}: IDataViewProps<EmployerRevisionHistoryWrapperData>) => {
  const dataViewId = 'dataview-revision-history-example';

  const schema = yup.object({
    yesNoLatestIsYes: yup.string(),
    yesNoLatestIsNo: yup.string(),
    yesNoLatestIsBoth: yup.string().required('Yes or No must be selected'),
    phoneNumber: yup.string().matches(PHONE_REGEXP, PHONE_MATCHES_FAIL_MESSAGE),
  });

  const {
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm({
    resolver: yupResolver(schema),
  });
  type RevisionHistoryExampleData = {
    yesNoLatestIsYes: string;
    yesNoLatestIsNo: string;
    yesNoLatestIsBoth: string;
    textExample: string;
    phoneNumber: string;
    currency: string;
    textExampleUneditable: string;
    singleSelectExample: string;
    radioExample: RadioOptionType;
    datePickerExample: string;
    checkboxListExample: string[];
  };

  const [errorMessages, setErrorMessages] = useState<string[]>([]);

  const onSubmit = (formData: RevisionHistoryExampleData) => {
    if (errorMessages.length === 2) {
      setErrorMessages([]);
    } else {
      errorMessages.push('Error # ' + (errorMessages.length + 1) + ' occured, it will clear on submission 3');
      setErrorMessages(errorMessages);
    }

    action('submit-action')(formData);

    if (REVISION_HISTORY_DATA.yesNoLatestIsYes.latest.item !== formData.yesNoLatestIsYes) {
      REVISION_HISTORY_DATA.yesNoLatestIsYes.history.unshift(
        JSON.parse(JSON.stringify(REVISION_HISTORY_DATA.yesNoLatestIsYes.latest))
      );
      REVISION_HISTORY_DATA.yesNoLatestIsYes.latest.item = formData.yesNoLatestIsYes;
      REVISION_HISTORY_DATA.yesNoLatestIsYes.latest.revisionNumber =
        REVISION_HISTORY_DATA.yesNoLatestIsYes.latest.revisionNumber + 1;
      REVISION_HISTORY_DATA.yesNoLatestIsYes.latest.dateOfAnswer = Date.now();
      REVISION_HISTORY_DATA.yesNoLatestIsYes.latest.enteredBy = 'Storybook';
    }

    if (REVISION_HISTORY_DATA.yesNoLatestIsNo.latest.item !== formData.yesNoLatestIsNo) {
      REVISION_HISTORY_DATA.yesNoLatestIsNo.history.unshift(
        JSON.parse(JSON.stringify(REVISION_HISTORY_DATA.yesNoLatestIsNo.latest))
      );
      REVISION_HISTORY_DATA.yesNoLatestIsNo.latest.item = formData.yesNoLatestIsNo;
      REVISION_HISTORY_DATA.yesNoLatestIsNo.latest.revisionNumber =
        REVISION_HISTORY_DATA.yesNoLatestIsNo.latest.revisionNumber + 1;
      REVISION_HISTORY_DATA.yesNoLatestIsNo.latest.dateOfAnswer = Date.now();
      REVISION_HISTORY_DATA.yesNoLatestIsNo.latest.enteredBy = 'Storybook';
    }

    if (REVISION_HISTORY_DATA.yesNoLatestIsBoth.latest.item !== formData.yesNoLatestIsBoth) {
      REVISION_HISTORY_DATA.yesNoLatestIsBoth.history.unshift(
        JSON.parse(JSON.stringify(REVISION_HISTORY_DATA.yesNoLatestIsBoth.latest))
      );
      REVISION_HISTORY_DATA.yesNoLatestIsBoth.latest.item = formData.yesNoLatestIsBoth;
      REVISION_HISTORY_DATA.yesNoLatestIsBoth.latest.revisionNumber =
        REVISION_HISTORY_DATA.yesNoLatestIsBoth.latest.revisionNumber + 1;
      REVISION_HISTORY_DATA.yesNoLatestIsBoth.latest.dateOfAnswer = Date.now();
      REVISION_HISTORY_DATA.yesNoLatestIsBoth.latest.enteredBy = 'Storybook';
    }

    if (REVISION_HISTORY_DATA.textExample.latest.item !== formData.textExample) {
      REVISION_HISTORY_DATA.textExample.history.unshift(
        JSON.parse(JSON.stringify(REVISION_HISTORY_DATA.textExample.latest))
      );
      REVISION_HISTORY_DATA.textExample.latest.item = formData.textExample;
      REVISION_HISTORY_DATA.textExample.latest.revisionNumber =
        REVISION_HISTORY_DATA.textExample.latest.revisionNumber + 1;
      REVISION_HISTORY_DATA.textExample.latest.dateOfAnswer = Date.now();
      REVISION_HISTORY_DATA.textExample.latest.enteredBy = 'Storybook';
    }

    if (REVISION_HISTORY_DATA.phoneNumber.latest.item !== formData.phoneNumber) {
      REVISION_HISTORY_DATA.phoneNumber.history.unshift(
        JSON.parse(JSON.stringify(REVISION_HISTORY_DATA.phoneNumber.latest))
      );
      REVISION_HISTORY_DATA.phoneNumber.latest.item = formData.phoneNumber;
      REVISION_HISTORY_DATA.phoneNumber.latest.revisionNumber =
        REVISION_HISTORY_DATA.phoneNumber.latest.revisionNumber + 1;
      REVISION_HISTORY_DATA.phoneNumber.latest.dateOfAnswer = Date.now();
      REVISION_HISTORY_DATA.phoneNumber.latest.enteredBy = 'Storybook';
    }

    if (REVISION_HISTORY_DATA.currency.latest.item !== formData.currency) {
      REVISION_HISTORY_DATA.currency.history.unshift(JSON.parse(JSON.stringify(REVISION_HISTORY_DATA.currency.latest)));
      REVISION_HISTORY_DATA.currency.latest.item = formData.currency;
      REVISION_HISTORY_DATA.currency.latest.revisionNumber = REVISION_HISTORY_DATA.currency.latest.revisionNumber + 1;
      REVISION_HISTORY_DATA.currency.latest.dateOfAnswer = Date.now();
      REVISION_HISTORY_DATA.currency.latest.enteredBy = 'Storybook';
    }

    if (REVISION_HISTORY_DATA.textExampleUneditable.latest.item !== formData.textExampleUneditable) {
      REVISION_HISTORY_DATA.textExampleUneditable.history.unshift(
        JSON.parse(JSON.stringify(REVISION_HISTORY_DATA.textExampleUneditable.latest))
      );
      REVISION_HISTORY_DATA.textExampleUneditable.latest.item = formData.textExampleUneditable;
      REVISION_HISTORY_DATA.textExampleUneditable.latest.revisionNumber =
        REVISION_HISTORY_DATA.textExampleUneditable.latest.revisionNumber + 1;
      REVISION_HISTORY_DATA.textExampleUneditable.latest.dateOfAnswer = Date.now();
      REVISION_HISTORY_DATA.textExampleUneditable.latest.enteredBy = 'Storybook';
    }
    if (REVISION_HISTORY_DATA.singleSelectExample.latest.item !== formData.singleSelectExample) {
      REVISION_HISTORY_DATA.singleSelectExample.history.unshift(
        JSON.parse(JSON.stringify(REVISION_HISTORY_DATA.singleSelectExample.latest))
      );
      REVISION_HISTORY_DATA.singleSelectExample.latest.item = formData.singleSelectExample;
      REVISION_HISTORY_DATA.singleSelectExample.latest.revisionNumber =
        REVISION_HISTORY_DATA.singleSelectExample.latest.revisionNumber + 1;
      REVISION_HISTORY_DATA.singleSelectExample.latest.dateOfAnswer = Date.now();
      REVISION_HISTORY_DATA.singleSelectExample.latest.enteredBy = 'Storybook';
    }

    if (REVISION_HISTORY_DATA.radioExample.latest.item !== formData.radioExample) {
      // @ts-expect-error this is a data object we use for testing, it can be a number or string
      // but since it's not strongly defined typescript is forcing it to be a string.
      // Not bothering making it better as this is just a story and it shouldn't
      // happen elsewhere with stronger typed data
      REVISION_HISTORY_DATA.radioExample.latest.item = formData.radioExample;
      REVISION_HISTORY_DATA.radioExample.latest.revisionNumber =
        REVISION_HISTORY_DATA.radioExample.latest.revisionNumber + 1;
      REVISION_HISTORY_DATA.radioExample.latest.dateOfAnswer = Date.now();
      REVISION_HISTORY_DATA.radioExample.latest.enteredBy = 'Storybook';
      REVISION_HISTORY_DATA.radioExample.history.unshift(
        JSON.parse(JSON.stringify(REVISION_HISTORY_DATA.radioExample.latest))
      );
    }

    if (REVISION_HISTORY_DATA.datePickerExample.latest.item !== formData.datePickerExample) {
      REVISION_HISTORY_DATA.datePickerExample.history.unshift(
        JSON.parse(JSON.stringify(REVISION_HISTORY_DATA.datePickerExample.latest))
      );
      REVISION_HISTORY_DATA.datePickerExample.latest.item = formData.datePickerExample;
      REVISION_HISTORY_DATA.datePickerExample.latest.revisionNumber =
        REVISION_HISTORY_DATA.datePickerExample.latest.revisionNumber + 1;
      REVISION_HISTORY_DATA.datePickerExample.latest.dateOfAnswer = Date.now();
      REVISION_HISTORY_DATA.datePickerExample.latest.enteredBy = 'Storybook';
    }

    if (REVISION_HISTORY_DATA.checkboxListExample.latest.item !== formData.checkboxListExample) {
      REVISION_HISTORY_DATA.checkboxListExample.history.unshift(
        JSON.parse(JSON.stringify(REVISION_HISTORY_DATA.checkboxListExample.latest))
      );
      REVISION_HISTORY_DATA.checkboxListExample.latest.item = formData.checkboxListExample;
      REVISION_HISTORY_DATA.checkboxListExample.latest.revisionNumber =
        REVISION_HISTORY_DATA.checkboxListExample.latest.revisionNumber + 1;
      REVISION_HISTORY_DATA.checkboxListExample.latest.dateOfAnswer = Date.now();
      REVISION_HISTORY_DATA.checkboxListExample.latest.enteredBy = 'Storybook';
    }
  };

  const DATAVIEW_SINGLE_SELECT_OPTIONS = [
    {
      value: '1243',
      label: 'Option 1',
    },
    {
      value: '56345',
      label: 'Option 2',
    },
    {
      value: '7623',
      label: 'Option 3',
    },
  ];

  const onError = (formData: FieldValues) => action('error-action')(formData);

  const yesNoLatestIsYes: IDataViewFieldProps<EmployerRevisionHistoryWrapperData> =
    RevisionHistoryWrapperYesNoDataView<EmployerRevisionHistoryWrapperData>({
      field: 'yesNoLatestIsYes',
      label: 'This entry defaults to yes',
      errors: errors,
      setValue: setValue,
    });

  const yesNoLatestIsNo: IDataViewFieldProps<EmployerRevisionHistoryWrapperData> =
    RevisionHistoryWrapperYesNoDataView<EmployerRevisionHistoryWrapperData>({
      field: 'yesNoLatestIsNo',
      label: 'This entry defaults to no',
      errors: errors,
      setValue: setValue,
    });

  const yesNoLatestIsBoth: IDataViewFieldProps<EmployerRevisionHistoryWrapperData> =
    RevisionHistoryWrapperYesNoDataView<EmployerRevisionHistoryWrapperData>({
      field: 'yesNoLatestIsBoth',
      label: 'This is a combined Yes and No entry',
      errors: errors,
      setValue: setValue,
    });

  const textExample: IDataViewFieldProps<EmployerRevisionHistoryWrapperData> =
    RevisionHistoryWrapperTextView<EmployerRevisionHistoryWrapperData>({
      field: 'textExample',
      label: 'This is a free text entry',
      errors: errors,
      setValue: setValue,
    });

  const phoneNumber: IDataViewFieldProps<EmployerRevisionHistoryWrapperData> = PhoneDataViewRow<
    string,
    EmployerRevisionHistoryWrapperData
  >({
    field: 'phoneNumber',
    label: 'Phone Number',
    errors: errors,
    setValue: setValue,
    valueExtractor: function (data: string | null): string | null {
      return data ? data : null;
    },
  });

  const currency: IDataViewFieldProps<EmployerRevisionHistoryWrapperData> = CurrencyDataViewRow<
    string,
    EmployerRevisionHistoryWrapperData
  >({
    field: 'currency',
    label: 'Currency',
    errors: errors,
    setValue: setValue,
    valueExtractor: function (data: string | null): string | null {
      return data ? data : null;
    },
  });

  const textExampleUneditable: IDataViewFieldProps<EmployerRevisionHistoryWrapperData> =
    RevisionHistoryWrapperTextView<EmployerRevisionHistoryWrapperData>({
      field: 'textExampleUneditable',
      label: 'This is a free text entry that is uneditable',
      errors: errors,
      setValue: setValue,
      isEditable: false,
    });

  const singleSelectExample: IDataViewFieldProps<EmployerRevisionHistoryWrapperData> =
    RevisionHistoryWrapperSingleSelectView<EmployerRevisionHistoryWrapperData>({
      field: 'singleSelectExample',
      label: 'This is a Single Select entry',
      errors: errors,
      setValue: setValue,
      options: DATAVIEW_SINGLE_SELECT_OPTIONS,
    });
  const RADIO_OPTIONS: IRevisionHistoryWrapperRadioOption[] = [
    {
      value: 1,
      label: 'A',
    },
    {
      value: 2,
      label: 'B',
    },
  ];

  const CHECBOX_OPTIONS: ISimpleCheckboxOptionProp[] = [
    {
      value: 'OPTION_1',
      label: 'This is the first option',
    },
    {
      value: 'OPTION_2',
      label: 'This is the second option',
    },
    {
      value: 'OPTION_3',
      label: 'This is the third option',
    },
    {
      value: 'OPTION_4',
      label: 'This is the fourth option',
    },
    {
      value: 'OPTION_5',
      label: 'This is the fifth option',
    },
  ];

  const radioExample: IDataViewFieldProps<EmployerRevisionHistoryWrapperData> =
    RevisionHistoryWrapperRadioDataView<EmployerRevisionHistoryWrapperData>({
      field: 'radioExample',
      label: 'A maps to 1 and B maps to 2',
      errors: errors,
      setValue: setValue,
      options: RADIO_OPTIONS,
    });

  const datePickerExample: IDataViewFieldProps<EmployerRevisionHistoryWrapperData> =
    RevisionHistoryWrapperDatePickerView<EmployerRevisionHistoryWrapperData>({
      field: 'datePickerExample',
      label: 'Item that is a date',
      errors: errors,
      setValue: setValue,
    });

  const checkboxListExample: IDataViewFieldProps<EmployerRevisionHistoryWrapperData> =
    RevisionHistoryWrapperCheckboxesView<EmployerRevisionHistoryWrapperData>({
      field: 'checkboxListExample',
      label: 'Multiple checkboxes for this field',
      errors: errors,
      setValue: setValue,
      options: CHECBOX_OPTIONS,
    });
  const singleSelectWithResponseTypeExample: IDataViewFieldProps<EmployerRevisionHistoryWrapperData> =
    SelectDataViewRow<SelectOptionValue, EmployerRevisionHistoryWrapperData>({
      field: 'singleSelectExample',
      label: 'This is a Single Select with a response type',
      errors: errors,
      setValue: setValue,
      options: DATAVIEW_SINGLE_SELECT_OPTIONS,
      valueExtractor: function (data: SelectOptionValue): SelectOptionValue {
        return data;
      },
    });

  const REVISION_HISTORY_EXAMPLE_FIELDS = [
    yesNoLatestIsYes,
    yesNoLatestIsNo,
    yesNoLatestIsBoth,
    textExample,
    phoneNumber,
    currency,
    textExampleUneditable,
    singleSelectExample,
    radioExample,
    datePickerExample,
    checkboxListExample,
    singleSelectWithResponseTypeExample,
  ];

  return (
    <div className="w-75">
      <div>
        <DataViewForm
          id={dataViewId}
          title="Details with History Example"
          labelColumnWidth={DataViewLabelColumnWidth.medium}
          fields={REVISION_HISTORY_EXAMPLE_FIELDS}
          data={REVISION_HISTORY_DATA}
          headingType={headingType}
          headingStyle={headingStyle}
          onSubmit={onSubmit}
          onError={onError}
          handleSubmit={handleSubmit}
          errorMessages={errorMessages}
        />
      </div>
    </div>
  );
};

RevisionHistoryExample.storyName = 'Example using revision history';
const whenToUse = (
  <>
    <p>
      This data view style is ideal for quickly scanning relatively small amount of data. As a result, they can be more
      visually compact than a sortable or data comparison table. They are primarily used for displaying information
      about an applicant.
    </p>
    <p>
      Generally, quick views should only have a label column and a single data column. If you have more than two
      columns, use a data comparison table or a sortable table.
    </p>
  </>
);

RevisionHistoryExample.storyName = 'Data View with Revisioned Information';

RevisionHistoryExample.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Data View with Revisioned Information"
      description={<p>Used when you want entries in a dataview that are individually revisioned</p>}
      whenToUse={whenToUse}
    >
      <ComponentStory />
    </Documentation>
  ),
];

RevisionHistoryExample.argTypes = argTypes;
