import React from 'react';
import { DataViewRow } from './data-view-row';
import { DataViewLabelColumnWidth, IDataViewProps } from './data-view-types';
import './data-view.scss';
import { ButtonGroup } from '../button/button-group';
import { RequiredFieldLegend } from '../forms/required-field-legend/required-field-legend';
import { Heading } from '../heading/heading';

export declare type DataViewElement = HTMLDivElement & { postSave: () => void };

export const DataView = <T,>({
  id,
  isEditable = false,
  title,
  toolbar,
  labelColumnWidth = DataViewLabelColumnWidth.default,
  fields,
  isDetailsExpanded,
  footerBar,
  data,
  headingType,
  headingStyle,
}: IDataViewProps<T>) => {
  const hasRequiredFields = () => {
    const requiredFields = fields.filter((f) => {
      return f.isFieldRequired === true;
    });

    return requiredFields.length > 0;
  };

  const hasData = fields && fields.length > 0;

  const showBadgeColumns = hasData && fields.findIndex((field) => field.badge !== undefined) > -1;

  return (
    <div id={id} className="dataview-container">
      <div className="quick-view-title d-flex">
        <span className="table-title dataview-table-title">
          <Heading headingType={headingType ? headingType : 'h3'} headingStyle={headingStyle ? headingStyle : 's'}>
            {title}
          </Heading>
        </span>
        {toolbar && !isEditable && (
          <div className="dataview-actions mb-1 ml-auto d-flex align-items-center">{toolbar}</div>
        )}
        {isEditable && hasRequiredFields() && (
          <div className="dataview-legend mb-1 ml-auto">
            <RequiredFieldLegend />
          </div>
        )}
      </div>
      <table className={`dataview ${labelColumnWidth} dataview-${isEditable && footerBar ? 'edit-mode' : 'view-mode'}`}>
        <tbody>
          {!hasData && (
            <tr id={`${id}-empty-item`} className={`dataview-row`} tabIndex={0}>
              <td className="dataview-row-col-label" style={{ textAlign: 'center' }}>
                No data available
              </td>
            </tr>
          )}
          {hasData &&
            fields
              .filter((field) => !field.omit)
              .map((field, index) => (
                <DataViewRow
                  key={`${id}-item-${index}`}
                  id={`${id}-item-${index}`}
                  data={data}
                  field={field}
                  index={index}
                  isEditing={isEditable}
                  isExpanded={isDetailsExpanded}
                  showBadgeColumns={showBadgeColumns}
                />
              ))}
        </tbody>
      </table>
      {isEditable && footerBar && footerBar.length > 0 && (
        <div className="table-quickview-save card">
          <ButtonGroup>{footerBar}</ButtonGroup>
        </div>
      )}
    </div>
  );
};
