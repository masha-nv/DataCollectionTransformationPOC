import { IRevisionHistoryWrapperData } from './data-view-revision-history-wrapper-types';
import { FormGroup } from '../../forms/form-group/form-group';
import { hookFormUtils } from '../../forms/utils/hookform-utils';
import { DeepMap, FieldError, FieldValues, UseFormSetValue } from 'react-hook-form';
import { IDataViewFieldProps } from '../data-view-types';
import { DataViewRow, getValueFromRevisionHistory } from './data-view-revision-history';
import { ISelectOption, SelectOptionValue, SelectType } from '../../forms/select/select.types';
import { SimpleSelect } from '../../forms/select/simple-select/simple-select';
import {
  IRevisionHistoryWrapperDataViewSingleSelectProp,
  SelectDataViewRowProps,
} from './data-view-revision-history-single-select-types';
import { isDataViewRowReadOnly } from '../data-view-row';

const EditSingleSelect = (props: {
  field: string;
  value: SelectOptionValue;
  setValue?: UseFormSetValue<FieldValues>;
  errors?: DeepMap<FieldValues, FieldError>;
  options: ISelectOption[];
  isReadOnly?: boolean;
}) => {
  //SimpleSelect should probably have done this to begin with but that causes
  //unit test failures. Unsure if anyone is relying on it yet so doing it here
  if (props.setValue) {
    props.setValue(props.field, props.value);
  }

  return (
    <FormGroup
      id={`${props.field}-fg`}
      errorMessages={props.errors ? hookFormUtils.getErrorMessages(props.errors, props.field) : undefined}
    >
      <SimpleSelect
        id={`${props.field}`}
        type={SelectType.primary}
        value={props.value}
        field={props.field}
        setValue={props.setValue}
        options={props.options}
        isReadOnly={props.isReadOnly}
      />
    </FormGroup>
  );
};

const convertToDisplayValue = (value: SelectOptionValue, options: ISelectOption[]): SelectOptionValue => {
  if (value) {
    let text = undefined;
    options.forEach((option) => {
      if (value === option.value) {
        text = option.label;
      }
    });
    if (text) {
      return text;
    }
    return value;
  } else {
    return '';
  }
};

export const SelectDataViewRow = <WrapperDataType, ResponseType>(
  props: SelectDataViewRowProps<WrapperDataType, SelectOptionValue>
): IDataViewFieldProps<ResponseType> => {
  const displayConverter = (value: SelectOptionValue) => convertToDisplayValue(value, props.options);

  return DataViewRow({
    ...props,
    displayConverter: displayConverter,
    createEditMode: (typedValue: IRevisionHistoryWrapperData<WrapperDataType>) => {
      return (
        <EditSingleSelect
          field={props.field}
          value={getValueFromRevisionHistory(typedValue, props.valueExtractor)}
          setValue={props.setValue}
          errors={props.errors}
          options={props.options}
          isReadOnly={isDataViewRowReadOnly(props.isEditable)}
        />
      );
    },
  });
};

export const RevisionHistoryWrapperSingleSelectView = <Data,>(
  props: IRevisionHistoryWrapperDataViewSingleSelectProp
): IDataViewFieldProps<Data> => {
  const textLineItemProps: SelectDataViewRowProps<SelectOptionValue, SelectOptionValue> = {
    ...props,
    valueExtractor: function (data: SelectOptionValue): SelectOptionValue {
      return data;
    },
  };

  return SelectDataViewRow(textLineItemProps);
};
