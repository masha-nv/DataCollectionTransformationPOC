import { ReactNode } from 'react';
import { IDataViewFieldProps } from '../data-view-types';
import {
  IRevisionHistoryWrapperData,
  IRevisionHistoryWrapperDataViewProp,
  RevisionHistory,
} from './data-view-revision-history-wrapper-types';
import { Badges } from '../../notifications/badge/badges';
const formatDate = (date: number): string | undefined => {
  return `${new Date(date).toLocaleDateString()} ${new Date(date).toLocaleTimeString()}`;
};
export const DataViewReadOnly = <V,>(displayValue: V, isUpdated: boolean, isAdded?: boolean) => {
  return (
    <div style={{ paddingLeft: '4em', whiteSpace: 'pre-line' }}>
      {isAdded && !isUpdated && <Badges.ADDED />}
      {isUpdated && <Badges.UPDATED />}
      <span>{displayValue}</span>
    </div>
  );
};

export const getDisplayFromRevisionHistory = <WrapperDataType, DataType, DisplayType>(
  typedValue: IRevisionHistoryWrapperData<WrapperDataType>,
  getValue: (data: WrapperDataType) => DataType | null,
  getDisplayValue: (data: DataType | null) => DisplayType | null
): DisplayType | null => {
  if (typedValue.latest != null) {
    return getDisplayValue(getValueFromRevisionHistory(typedValue, getValue));
  } else {
    return null;
  }
};

export const getValueFromRevisionHistory = <WrapperDataType, DataType>(
  typedValue: IRevisionHistoryWrapperData<WrapperDataType>,
  getValue: (data: WrapperDataType) => DataType | null
): DataType | null => {
  if (typedValue.latest != null) {
    return getValue(typedValue.latest.item);
  } else {
    return null;
  }
};

export const DataRowHistory = <WrapperDataType, DataType, DisplayType>(props: {
  data: IRevisionHistoryWrapperData<WrapperDataType>;
  getValue: (item: WrapperDataType | null) => DataType | null;
  getDisplayValue: (value: DataType | null) => DisplayType;
}) => {
  return (
    <>
      <div className="mb-3">
        {props.data.latest && (
          <div>
            {props.data.latest.sourceType} | {props.data.latest.enteredBy} |{' '}
            {formatDate(props.data.latest.dateOfAnswer)}
          </div>
        )}
      </div>
      <ul>
        {props.data.history.map((revisionHistory: RevisionHistory<WrapperDataType>, index) => (
          <div className="mb-3" key={`${revisionHistory.revisionNumber}-${index}`}>
            <div className="card card-gray">
              <div className="card-body p-2">
                <span className="pt-2">
                  <b>
                    {revisionHistory.isDeactivated && (
                      <s>{props.getDisplayValue(props.getValue(revisionHistory.item))}</s>
                    )}
                    {!revisionHistory.isDeactivated && (
                      <>{props.getDisplayValue(props.getValue(revisionHistory.item))}</>
                    )}
                  </b>
                </span>
                <br />
                <span className="pt-2">
                  {revisionHistory.sourceType} | {revisionHistory.enteredBy} |{' '}
                  {formatDate(revisionHistory.dateOfAnswer)}
                </span>
              </div>
            </div>
          </div>
        ))}
      </ul>
    </>
  );
};

export interface DataViewRowProps<WrapperDataType, DataType, DisplayType> extends IRevisionHistoryWrapperDataViewProp {
  valueExtractor: (data: WrapperDataType | null) => DataType | null;
  displayConverter: (value: DataType | null) => DisplayType;
  createEditMode: (value: IRevisionHistoryWrapperData<WrapperDataType>) => ReactNode;
}

const checkIsAdded = <T,>(value: IRevisionHistoryWrapperData<T>) => {
  if (value.history.length === 0 && value.latest?.sourceType === 'INTERNAL') {
    return true;
  }
  return false;
};

const castToRevisionHistoryWrapperData = <WrapperDataType,>(value: unknown) => {
  const typedOrNull = value as IRevisionHistoryWrapperData<WrapperDataType> | null;
  let typedValue: IRevisionHistoryWrapperData<WrapperDataType>;
  if (typedOrNull) {
    typedValue = typedOrNull;
  } else {
    typedValue = {
      latest: null,
      history: [],
    };
  }
  return typedValue;
};

export const DataViewRow = <WrapperDataType, DataType, DisplayType, ResponseType>(
  props: DataViewRowProps<WrapperDataType, DataType, DisplayType>
): IDataViewFieldProps<ResponseType> => {
  return {
    ...props,
    readonly: (value: unknown): ReactNode => {
      const typedValue: IRevisionHistoryWrapperData<WrapperDataType> = castToRevisionHistoryWrapperData(value);
      const isUpdated = typedValue.history.length > 0;
      const isAdded = checkIsAdded(typedValue);
      return DataViewReadOnly(
        getDisplayFromRevisionHistory(typedValue, props.valueExtractor, props.displayConverter),
        isUpdated,
        isAdded
      );
    },
    details: (value: unknown): ReactNode => {
      const typedValue: IRevisionHistoryWrapperData<WrapperDataType> = castToRevisionHistoryWrapperData(value);
      return (
        <DataRowHistory data={typedValue} getValue={props.valueExtractor} getDisplayValue={props.displayConverter} />
      );
    },
    edit: (value: unknown): ReactNode => {
      const typedValue: IRevisionHistoryWrapperData<WrapperDataType> = castToRevisionHistoryWrapperData(value);
      return props.createEditMode(typedValue);
    },
  };
};
