import React, { KeyboardEvent, ChangeEvent, ReactNode, useRef, useState, CSSProperties, forwardRef } from 'react';
import { usePopper } from 'react-popper';
import useOnClickOutside from 'use-onclickoutside';
import { Icon, IconType } from '../../icon/icon';
import { noop } from '../../utils';
import { WithId } from '../../with-id';
import { WithInput } from '../../with-input';
import './search-bar.scss';
import { IconButton } from '../../button/icon-button';

export interface ISearchBarProps<T extends unknown> extends WithId, WithInput {
  /**
   * The results that the search bar will show.
   */
  results?: T[];
  /**
   * The placeholder for the search bar input
   */
  placeholder?: string;
  /**
   * The width of the search result
   */
  size?: SearchResultSize;
  /**
   * The function that is used to verify if that query is valid and ready to searching.
   * If this function resolves as true, then the search bar will display component for invalid results.
   */
  validate?: (query: string) => boolean;
  /**
   * Whether the search bar should display itself as loading.
   */
  loading?: boolean;
  /**
   * The time in milliseconds of how long to debounce input before processing it
   */
  debounce?: number;
  /**
   * The component that displays of the result of a search
   */
  resultsComponent?: (results: T[], onSelect: (result: T) => void) => ReactNode;
  /**
   * The component that is displayed when there are not any results
   */
  noResultsComponent?: (query: string) => ReactNode;
  /**
   * The component that is displayed when the input/query is not valid (via the validate property)
   */
  invalidQueryComponent?: (query: string) => ReactNode;
  /**
   * The component that is displyed when results are loading (via the loading property)
   */
  loadingComponent?: ReactNode;
  /**
   * The callback for whenever the user press the enter key
   */
  onPressEnter?: (query: string) => void;
  /**
   * The callback for whenever the user chooses a search result
   */
  onSelect?: (result: T) => void;
  /**
   * Whether the result are displayed
   */
  hideResults?: boolean;
  /**
   * Whether the search bar listens to events for changes where the input is empty
   */
  allowEmpty?: boolean;
  /**
   * Whether the search bar should have a clear button
   */
  clearable?: boolean;
}

export enum SearchResultSize {
  small = 'small',
  medium = 'medium',
  large = 'large',
}

const DefaultResultsComponent = (results: unknown[], onSelect: (result: unknown) => void) => {
  return results.map((result, index) => (
    <div className="beacon-default-search-result" tabIndex={0} onClick={() => onSelect(result)} key={index}>
      {result as ReactNode}
    </div>
  ));
};

const DefaultNoResultComponent = (query: string) => {
  return (
    <div className="beacon-default-no-search-result" tabIndex={0}>
      No results found for <strong>{query}</strong>
    </div>
  );
};

const DefaultInvalidQueryComponent = () => {
  return <div className="beacon-default-invalid-query">Your input is not valid.</div>;
};

const DefaultLoadingComponent = () => {
  return <div className="beacon-default-loading">Loading...</div>;
};

export const SearchBar = forwardRef<HTMLInputElement, ISearchBarProps<unknown>>(
  (
    {
      onChange = noop,
      onPressEnter = noop,
      onSelect = noop,
      size = SearchResultSize.medium,
      placeholder = 'Search...',
      validate = () => true,
      debounce = 0,
      resultsComponent = DefaultResultsComponent,
      noResultsComponent = DefaultNoResultComponent,
      invalidQueryComponent = DefaultInvalidQueryComponent,
      loadingComponent = <DefaultLoadingComponent />,
      ...props
    },
    forwardedRef
  ) => {
    const ref = useRef<HTMLDivElement>(null);
    const [query, setQuery] = useState('');
    const [referenceElement, setReferenceElement] = useState<HTMLDivElement | null>(null);
    const [popperElement, setPopperElement] = useState<HTMLDivElement | null>(null);
    const [popperVisible, setPopperVisible] = useState(false);
    const [searchValue, setSearchValue] = useState('');
    useOnClickOutside(ref, () => setPopperVisible(false));
    const timer = useRef<ReturnType<typeof setTimeout>>();

    const { styles, attributes } = usePopper(referenceElement, popperElement, {
      placement: 'bottom-start',
    });

    const popperStyles: CSSProperties = {
      ...styles.popper,
      zIndex: 9999,
    };

    const isQueryValid = (query: string) => {
      return (props.allowEmpty || query.length > 0) && (!validate || validate(query));
    };

    const onInputChange = (event: ChangeEvent<HTMLInputElement>) => {
      setSearchValue(event.target.value);

      if (timer.current) {
        clearTimeout(timer.current);
      }

      timer.current = setTimeout(() => {
        const query = event.target.value;
        setQuery(query);
        setPopperVisible(query.length > 0);
        if (isQueryValid(query)) {
          onChange(event, query);
        }
      }, debounce);
    };

    const onInputFocus = () => {
      setPopperVisible(true);
    };

    const onBlur = (e: React.FocusEvent<HTMLDivElement>) => {
      /**
       * setTimeout used here because in some scenarios,
       * the document is activeElement until React creates the
       * search result elements.
       */
      setTimeout(() => {
        if (ref.current && !ref.current.contains(document.activeElement)) {
          setPopperVisible(false);
        }
      });
    };

    const onInputKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
      //We must get the query from the event instead of using it from onChange
      //as there is no guarantee onInputKeyDown isn't called before onChange completes
      //and saves the value of query
      const queryValue = (event.target as HTMLInputElement).value;

      if (event.key === 'Enter' && (props.allowEmpty || queryValue.length > 0)) {
        onPressEnter(queryValue);
      }
    };

    const onIconClick = () => {
      if (props.allowEmpty || query.length > 0) {
        onPressEnter(query);
      }
    };

    const onResultSelect = (result: unknown) => {
      onSelect(result);
    };

    const onClear = () => {
      setSearchValue('');

      if (timer.current) {
        clearTimeout(timer.current);
      }

      timer.current = setTimeout(() => {
        setQuery('');
        setPopperVisible(false);
        onChange({ target: { value: '' } } as ChangeEvent<HTMLInputElement>, '');
      }, debounce);
    };

    const validQuery = isQueryValid(query);
    const resultsVisible = props.results && props.results.length > 0;

    return (
      <div id={props.id} ref={ref} className="beacon-search-bar" onBlur={onBlur}>
        <div className="input-group" ref={setReferenceElement}>
          <input
            ref={forwardedRef}
            id={`${props.id}-input`}
            type="search"
            className="form-control"
            placeholder={placeholder}
            onFocus={onInputFocus}
            onChange={onInputChange}
            autoComplete="off"
            onKeyDown={onInputKeyDown}
            name={props.name}
            disabled={props.disabled}
            value={searchValue}
          />
          {popperVisible && !props.hideResults && (
            <div ref={setPopperElement} style={popperStyles} {...attributes.popper}>
              <div id={`${props.id}-results`} className={`beacon-search-results beacon-search-results-${size}`}>
                {!validQuery && invalidQueryComponent && invalidQueryComponent(query)}
                {validQuery && (
                  <>
                    {props.loading && loadingComponent}
                    {!props.loading && (
                      <>
                        {resultsVisible &&
                          props.results &&
                          resultsComponent &&
                          resultsComponent(props.results, onResultSelect)}
                        {!resultsVisible && noResultsComponent && noResultsComponent(query)}
                      </>
                    )}
                  </>
                )}
              </div>
            </div>
          )}
          {props.clearable && (
            <span className="clear-icon">
              <IconButton id="clear-btn" label="Clear Input" onClick={onClear}>
                <Icon description="Clear" type={IconType.times} />
              </IconButton>
            </span>
          )}
          <span className="input-group-append">
            <span className="input-group-text">
              <Icon description="Perform Search" type={IconType.search} onClick={onIconClick} isClickable={true} />
            </span>
          </span>
        </div>
      </div>
    );
  }
);

SearchBar.displayName = 'SearchBar';
