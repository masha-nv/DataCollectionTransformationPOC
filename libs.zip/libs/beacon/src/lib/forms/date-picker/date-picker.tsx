import React, {
  ChangeEvent,
  CSSProperties,
  forwardRef,
  KeyboardEventHandler,
  useEffect,
  useRef,
  useState,
} from 'react';
import { WithId } from '../../with-id';
import { Calendar } from './calendar';
import moment from 'moment';
import { DATE_FORMAT, MAX_POSSIBLE_DATE, MIN_POSSIBLE_DATE } from './constants';
import { Tooltip } from '../../modals/tooltip/tooltip';
import FocusTrap from '@elis/elis-focus-trap-react';
import ReactDOM from 'react-dom';
import './date-picker.scss';
import { noop } from '../../utils';
import { Icon, IconType } from '../../icon/icon';
import { WithInput } from '../../with-input';
import { mergeRefs } from 'use-callback-ref';
import { usePopper } from 'react-popper';

export interface IDatePickerProps extends WithId, WithInput {
  /**
   * Control value
   */
  value?: string;
  /**
   * Minimun date selectable through the calendar popup
   */
  minDate?: Date;
  /**
   * Maximun date selectable through the calendar popup
   */
  maxDate?: Date;
  /**
   * Direction at which the calendar popup opens
   */
  direction?: CalendarPopupDirection;
  /**
   * The event handler for when a key is being pressed
   */
  onKeyDown?: KeyboardEventHandler<HTMLInputElement>;
}

export enum CalendarPopupDirection {
  left,
  right,
}

const formatDate = (date: Date): string => {
  return moment(date).format(DATE_FORMAT);
};

const getNumSlashes = (str: string): number => {
  return (str.match(/\D/g) || []).length;
};

const formatInput = (str: string) => {
  const cleanedInput = str.replace(/\D/g, '');
  const month = cleanedInput.substring(0, 2);
  const day = cleanedInput.substring(2, 4);
  const year = cleanedInput.substring(4, 8);
  if (cleanedInput.length > 4) {
    return month + '/' + day + '/' + year;
  }
  if (cleanedInput.length > 2) {
    return month + '/' + day;
  }
  return month;
};

/**
 * Set raw input value and raise onChange event
 */
export const setRawInputValueWithChangeEvent = (input: HTMLInputElement | null, value: string) => {
  if (!input) {
    return;
  }
  const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
  nativeInputValueSetter?.call(input, value);

  // Manually trigger OnChange event for the input
  const event = new Event('input', { bubbles: true });
  input.dispatchEvent(event);
};

export const DatePicker = forwardRef<HTMLInputElement, IDatePickerProps>(
  (
    {
      id,
      name,
      value,
      disabled = false,
      required,
      minDate = MIN_POSSIBLE_DATE,
      maxDate = MAX_POSSIBLE_DATE,
      direction = CalendarPopupDirection.right,
      onChange = noop,
      onKeyDown = noop,
    },
    ref
  ) => {
    // Wrapper ref is created for the state object so that it can used within the event listners
    const [isExpanded, _setIsExpanded] = useState(false);
    const [referenceElement, setReferenceElement] = useState<HTMLDivElement | null>(null);
    const [popperElement, setPopperElement] = useState<HTMLDivElement | null>(null);
    const isExpandedRef = React.useRef(isExpanded);
    const setIsExpanded = (data: boolean) => {
      isExpandedRef.current = data;
      _setIsExpanded(data);
    };

    const { styles, attributes } = usePopper(referenceElement, popperElement, {
      placement: direction === CalendarPopupDirection.right ? 'bottom-start' : 'bottom-end',
    });

    const popperStyles: CSSProperties = {
      ...styles.popper,
      zIndex: 9999,
    };

    const inputRef = useRef<HTMLInputElement>(null);

    let selectedDate: Date | null = null;
    const momentObj = moment(inputRef.current?.value, DATE_FORMAT, true);
    if (momentObj.isValid()) {
      selectedDate = momentObj.toDate();
    }

    const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
      if (inputRef.current) {
        const cursor = inputRef.current.selectionStart ?? 0;
        const numSlashesOnLeftBeforeFormat = getNumSlashes(inputRef.current.value.substring(0, cursor));

        const result = formatInput(e.target.value);
        inputRef.current.value = result;

        const numSlashesOnLeftAfterFormat = getNumSlashes(result.substring(0, cursor));
        const newCursor = cursor + (numSlashesOnLeftAfterFormat - numSlashesOnLeftBeforeFormat);
        inputRef.current.setSelectionRange(newCursor, newCursor);

        onChange(e, result);
      }
    };

    const onDateSelectionHandler = (date: Date) => {
      setIsExpanded(false);
      const dateStr = formatDate(date);

      setRawInputValueWithChangeEvent(inputRef.current, dateStr);
    };

    useEffect(() => {
      // close calendar popup on clicking outside the popup area
      const mouseDownHandler = (event: MouseEvent) => {
        if (!referenceElement?.contains(event.target as Node) && !popperElement?.contains(event.target as Node)) {
          setIsExpanded(false);
        }
      };

      document.addEventListener('mousedown', mouseDownHandler);
      return () => {
        // event cleanup on destroy
        document.removeEventListener('mousedown', mouseDownHandler);
      };
    }, [popperElement, referenceElement]);

    return (
      <div className="beacon-datepicker">
        <div className="input-group">
          <input
            ref={mergeRefs([ref, inputRef])}
            id={id}
            type="text"
            autoComplete="off"
            name={name}
            className={`form-control date-picker-input ${isExpanded ? 'show' : ''}`}
            value={value}
            onChange={handleInputChange}
            onKeyDown={onKeyDown}
            disabled={disabled}
            required={required}
            maxLength={10}
            title="Enter MM/DD/YYYY"
          />
          <div className="input-group-append" ref={setReferenceElement}>
            <Tooltip id={`${id}-tooltip`} content="Toggle Calendar View">
              <button
                type="button"
                className={`date-picker-button ${isExpanded ? 'opened' : ''}`}
                id={`${id}-calendar-toggle`}
                aria-label="Toggle Calendar View"
                aria-haspopup="true"
                aria-expanded="false"
                disabled={disabled}
                onClick={() => {
                  setIsExpanded(!isExpanded);
                }}
              >
                <Icon type={IconType.calendarAlt} />
              </button>
            </Tooltip>
          </div>
          {isExpanded && inputRef.current
            ? ReactDOM.createPortal(
                <FocusTrap
                  returnFocusTo={inputRef.current}
                  focusTrapOptions={{
                    initialFocus: false,
                    fallbackFocus: `#${id}-calendar-popup`,
                    clickOutsideDeactivates: true,
                    returnFocusOnDeactivate: true,
                  }}
                >
                  <div
                    id={`${id}-calendar-popup`}
                    ref={setPopperElement}
                    tabIndex={-1}
                    className="beacon date-picker-popover-parent"
                    style={popperStyles}
                    {...attributes.popper}
                  >
                    <Calendar
                      id={`${id}-calendar`}
                      minDate={minDate}
                      maxDate={maxDate}
                      selectedDate={selectedDate}
                      onDateSelection={onDateSelectionHandler}
                      onClose={() => setIsExpanded(false)}
                    />
                  </div>
                </FocusTrap>,
                document.body
              )
            : null}
        </div>
        <div className="pt-1 support-text">Enter MM/DD/YYYY</div>
      </div>
    );
  }
);

DatePicker.displayName = 'DatePicker';

export { DATE_FORMAT } from './constants';
