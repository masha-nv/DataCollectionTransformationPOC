import React from 'react';
import { render, fireEvent, screen, waitFor } from '@testing-library/react';
import { CalendarPopupDirection, DatePicker, DATE_FORMAT } from './date-picker';
import moment from 'moment';
import userEvent from '@testing-library/user-event';

const mockCalenderSelectionDate = new Date(2020, 11, 11);

jest.mock('./calendar', () => {
  const ComponentToMock = ({ onDateSelection }: { onDateSelection: (date: Date) => void }) => {
    const dateSelectionMockEvent = () => {
      onDateSelection(mockCalenderSelectionDate);
    };
    return (
      <div tabIndex={0}>
        <span>Calendar Mock</span>
        <input type="button" value="CalenderSelection" onClick={dateSelectionMockEvent} />
      </div>
    );
  };

  return {
    Calendar: ComponentToMock,
  };
});

describe('DatePicker', () => {
  afterAll(() => {
    jest.dontMock('./calendar');
  });
  it('renders DatePicker correctly', () => {
    const { baseElement } = render(<DatePicker id="date-picker-id" name="date-picker-name" value="11/11/2020" />);
    expect(baseElement).toMatchSnapshot();
  });

  it('formats date correctly', async () => {
    const handler = jest.fn();
    const { container } = render(<DatePicker id="date-picker-id" name="date-picker-name" onChange={handler} />);
    const input = container.getElementsByClassName('date-picker-input')[0] as HTMLInputElement;
    userEvent.type(input, '111');
    expect(input.value).toBe('11/1');

    userEvent.clear(input);
    userEvent.type(input, '11111');
    expect(input.value).toBe('11/11/1');

    userEvent.clear(input);
    userEvent.type(input, '111111111111111');
    expect(input.value).toBe('11/11/1111');

    expect(handler).toBeCalledTimes(18);
  });

  it('renders Calendar popup correctly', async () => {
    const { baseElement, container } = render(
      <DatePicker id="date-picker-id" name="date-picker-name" value="11/11/2020" />
    );

    const button = container.getElementsByClassName('date-picker-button')[0];
    expect(button.className).not.toContain('opened');
    await waitFor(() => userEvent.click(screen.getByLabelText('Toggle Calendar View')));
    expect(button.className).toContain('opened');

    expect(baseElement).toMatchSnapshot();
  });

  it('renders Calendar popup direction correctly', async () => {
    const { baseElement } = render(
      <DatePicker
        id="date-picker-id"
        name="date-picker-name"
        value="11/11/2020"
        direction={CalendarPopupDirection.left}
      />
    );

    await waitFor(() => userEvent.click(screen.getByLabelText('Toggle Calendar View')));

    expect(baseElement).toMatchSnapshot();
  });

  it('Calendar popup onDateSelection', async () => {
    const { container, getByText } = render(
      <DatePicker direction={CalendarPopupDirection.left} id="date-picker-id" name="date-picker-name" />
    );

    const button = container.getElementsByClassName('date-picker-button')[0];
    // Opening popup
    fireEvent.click(button);

    //Raising onDateSelection event from the mock component
    fireEvent.click(getByText(/CalenderSelection/));

    const input = container.getElementsByClassName('date-picker-input')[0] as HTMLInputElement;

    expect(input.value).toBe(moment(mockCalenderSelectionDate).format(DATE_FORMAT));
  });

  it('closes Calendar popup on outside click', async () => {
    const { container } = render(
      <DatePicker id="date-picker-id" name="date-picker-name" value="11/11/2020" />
    );

    const button = container.getElementsByClassName('date-picker-button')[0];
    expect(button.className).not.toContain('opened');
    fireEvent.click(button);
    expect(button.className).toContain('opened');

    fireEvent.mouseDown(container.firstChild);
    expect(button.className).not.toContain('opened');
  });

  it('calls onKeyDown handler', async () => {
    const onKeyDown = jest.fn();
    render(
      <div>
        <label htmlFor="date-picker-id">Date</label>
        <DatePicker id="date-picker-id" name="date-picker-name" value="11/11/2020" onKeyDown={onKeyDown} />
      </div>
    );

    screen.getByLabelText('Date').focus();
    userEvent.keyboard('{ENTER}');

    expect(onKeyDown).toHaveBeenCalled();
    expect(onKeyDown.mock.calls[0][0].key).toEqual('Enter');
  });
});
