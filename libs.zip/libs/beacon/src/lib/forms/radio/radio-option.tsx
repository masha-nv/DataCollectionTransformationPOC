import React, { ChangeEvent, forwardRef, ReactNode } from 'react';
import { getTrackableClickHandler, Trackable } from '../../analytics';
import { WithId } from '../../with-id';
import { WithInput } from '../../with-input';
import './radio-option.scss';

export type RadioOptionType = string | number | readonly string[];

export interface IRadioOptionProps extends Trackable, WithId, WithInput {
  /**
   * The value of the radio option. When selected/checked, this will be the value of the field in the form.
   */
  value?: RadioOptionType;
  /**
   * The contents of the label for the radio option.
   */
  children: ReactNode;
  /**
   * When this radio option is checked
   */
  checked?: boolean;
  /**
   * When this radio option is checked by default (e.g. when a page loads)
   */
  defaultChecked?: boolean;
  /**
   * Display this radio option as inline
   */
  inline?: boolean;
  /**
   * Hides the content of the label
   */
  hiddenLabel?: boolean;
}

export const RadioOption = forwardRef<HTMLInputElement, IRadioOptionProps>((props, ref) => {
  const trackingDefaults = {
    grouping: 'Ungrouped',
    action: 'Checked',
    trackingKey: `Radio-${props.id}`,
  };

  const onChangeEventHandler = (event: ChangeEvent<HTMLInputElement>) => {
    props.onChange && props.onChange(event, event.target.value);
  };
  return (
    <div className={`custom-control custom-radio ${props.inline ? 'd-inline mr-4' : ''}`}>
      <input
        required={props.required}
        ref={ref}
        id={props.id}
        type="radio"
        className="custom-control-input"
        name={props.name}
        value={props.value}
        checked={props.checked}
        defaultChecked={props.defaultChecked}
        disabled={props.disabled}
        onChange={getTrackableClickHandler(props.tracking, trackingDefaults, onChangeEventHandler)}
      />
      <label className={`custom-control-label ${props.hiddenLabel ? 'beacon-hidden-label' : ''}`} htmlFor={props.id}>
        {props.hiddenLabel ? <span className="sr-only">{props.children}</span> : props.children}
      </label>
    </div>
  );
});

RadioOption.displayName = 'RadioOption';
