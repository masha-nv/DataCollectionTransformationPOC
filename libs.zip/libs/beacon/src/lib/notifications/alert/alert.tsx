import classNames from 'classnames';
import React, { ReactNode, SyntheticEvent, useEffect, useRef } from 'react';
import './alert.scss';
import { Icon, IconType } from '../../icon/icon';
import { Button, ButtonType } from '../../button/button';

export interface IAlertProps {
  /**
   * The content of this alert
   */
  children: ReactNode;

  /**
   * Alert type
   */
  variant?: AlertVariant;

  /**
   * Alternate title rather than alert type
   */
  title?: string;

  /**
   * Determines whether a button appears for dismissing the alert
   * - false by default
   * - must be used with onClose
   */
  withCloseButton?: boolean;

  /**
   * Determines whether a button appears for calling a custom action from the alert
   * - false by default
   * - must be used in conjuction with onActionClick and actionButtonLabel
   */
  withActionButton?: boolean;

  /**
   * Alternative to skip the automatic alert focusing
   */
  skipFocus?: boolean;
  /**
   * The inner-text and title for the custom action button
   */
  actionButtonLabel?: string;

  /**
   * Called when the close button is clicked
   */
  onClose?: () => void;

  /**
   * Called when the action button is clicked
   */
  onActionClick?: (e?: SyntheticEvent) => void;
}

export enum AlertVariant {
  info = 'info',
  success = 'success',
  warning = 'warning',
  error = 'error',
  suggestion = 'suggestion',
}

const AlertCSS = {
  [AlertVariant.info]: 'fa-info-circle',
  [AlertVariant.success]: 'fa-check-circle',
  [AlertVariant.warning]: 'fa-exclamation-triangle',
  [AlertVariant.error]: 'fa-exclamation-circle',
  [AlertVariant.suggestion]: 'fa-wand-magic-sparkles',
};

/**
 * Alert component
 */
export const Alert = ({
  variant = AlertVariant.info,
  children,
  withActionButton = false,
  actionButtonLabel,
  title,
  withCloseButton = false,
  skipFocus,
  onActionClick,
  onClose,
}: IAlertProps) => {
  const alertClasses = classNames(`alert alert-${variant}`, {
    suggestion: variant === AlertVariant.suggestion,
  });
  const ref = useRef<HTMLDivElement>(null);

  if (withCloseButton && !onClose) {
    console.warn(
      'The "withCloseButton" prop must be used together with "onClose", but an "onClose" handler was not provided'
    );
  }

  if (withActionButton && (!actionButtonLabel || !onActionClick)) {
    console.warn(
      'The "withActionButton" prop must be used in conjuction with "actionButtonLabel" and "onActionClick" props, but all three were not provided together'
    );
  }

  useEffect(() => {
    if (!skipFocus) {
      ref?.current?.focus();
    }
  }, [skipFocus]);

  return (
    <div ref={ref} tabIndex={0} role="alert" className={alertClasses}>
      <div className="alert-icon">
        <i className={`fas ${AlertCSS[variant]}`} aria-hidden="true"></i>
        <span className="sr-only">{variant} alert</span>
      </div>
      <div className="alert-content">
        <div className='alert-body'>
          <div className="alert-label">
            {title ?? (variant === AlertVariant.suggestion ? 'Suggested by ELIS' : variant)}
          </div>
          <div className='alert-text'>{children}</div>
          {withActionButton && actionButtonLabel && onActionClick && (
            <div className="alert-action-btn">
              <Button
                id={`alert-action-btn-${actionButtonLabel}`}
                title={actionButtonLabel}
                type={ButtonType.tertiary}
                onClick={onActionClick}
              >
                {actionButtonLabel}
              </Button>
            </div>
          )}
        </div>
      </div>
      {withCloseButton && onClose && (
        <div className="alert-dismiss">
            <div className="alert-dismiss-btn">
              <Button id={'dismiss-btn'} title="Close" type={ButtonType.tertiary} onClick={onClose}>
                <Icon type={IconType.times} />
              </Button>
            </div>
        </div>
      )}
    </div>
  );
};