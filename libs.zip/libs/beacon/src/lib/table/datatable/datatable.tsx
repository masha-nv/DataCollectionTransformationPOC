import UscisReactDatatable, { IDataTableProps as UscisReactDataTableProps } from '@elis/uscis-react-datatable';
import React, { Dispatch, SetStateAction, useEffect, useState } from 'react';
import { Button, ButtonType } from '../../button/button';
import { Heading, HeadingStyle, HeadingType } from '../../heading/heading';
import { Icon, IconSize, IconType, IconVariant } from '../../icon/icon';
import { Direction, Theme } from '../../modals/modal-types';
import { Popover } from '../../modals/popover/popover';
import { noop } from '../../utils';
import { WithId } from '../../with-id';
import './datatable.scss';
import classNames from 'classnames';

declare type RowVariantCondition<T> = {
  label: string;
  condition: (row: T) => boolean;
};

declare type TypedVariantDefinition<T> = {
  active?: (row: T) => boolean;
  success?: RowVariantCondition<T>;
  info?: RowVariantCondition<T>;
  warning?: RowVariantCondition<T>;
  danger?: RowVariantCondition<T>;
};

declare type ConditionalRowStyle<T> = {
  when: (row: T) => boolean;
  style: React.CSSProperties;
};

export interface IDatatableProps<T = unknown> extends WithId {
  /**
   * The title displayed in the table header
   */
  title: string;
  /**
   * The column configuration
   */
  columns: IDatatableColumn<T>[];
  /**
   * The data of the table. It is **highly recommended**
   * that your data have a unique identifier (keyField).
   * The default keyField is id. If you need to override this value
   * then see keyField
   */
  data: T[];
  /**
   * **Your data should have a unique identifier.**
   * By default, a datatable looks for an id property on each item in your data.
   * If a unique id is not present, the datatable will attempt to use
   * the row index and by reference checks as fallbacks, however,
   * certain features will not work correctly.
   */
  keyField?: string;
  /**
   * Enable pagination.
   */
  pagination?: boolean;
  /**
   * changes the default pagination to work with server side pagination
   */
  paginationServer?: boolean;
  /**
   * allows you to provide the total row count for your table as represented by
   * your API when performing server side pagination.
   * if this property is not provided then the datatable will use
   * `data.length`
   */
  paginationTotalRows?: number;
  /**
   * the default rows per page to use when the table initially loads
   */
  paginationPerPage?: number;
  /**
   * callback when paged that returns `onChangePage(page, totalRows)`
   */
  onChangePage?: (page: number, totalRows: number) => void;
  /**
   * callback when rows per page is changed returns
   * `onChangeRowsPerPage(currentRowsPerPage, currentPage)`
   */
  onChangeRowsPerPage?: (currentRowsPerPage: number, currentPage: number) => void;

  /**
   * Disables the table and displays a plain text Loading Indicator
   */
  progressPending?: boolean;
  /**
   * Whether to make a row expandable, if true it requires an
   * `expandableRowsComponent`.
   */
  expandableRows?: boolean;
  /**
   * A custom component to display in the expanded row.
   * It will have the `data` prop composed so that you may access the row
   * data.
   */
  expandableRowsComponent?: React.ReactNode;
  /**
   * Function to determine if an expandable row should be disabled
   */
  expandableRowDisabled?: (row: T) => boolean;

  /**
   * Whether to show selectable checkboxes
   */
  selectableRows?: boolean;
  /**
   * The attribute within the data set that will be used in the checkbox title to refer to each row.
   */
  selectableTitleField?: string;

  /**
   * The heading level of the table header (defaults to "1").
   */
  tableHeaderLevel?: string;

  /**
   * Fucntion to determine if a selectable row should be disabled
   */
  selectableRowDisabled?: (row: T) => boolean;

  /**
   * Defines conditions for certain rows in this datatable to be displayed with variant styling.
   */
  rowVariantConditions?: TypedVariantDefinition<T>;

  /**
   * Controls visibility of Legend button. Default value is TRUE.
   */
  showLegend?: boolean;

  /**
   * Callback that fires when a row in this datatable is clicked.
   */
  onRowClicked?: (row: T, e: MouseEvent) => void;

  /**
   * Callback that fires anytime the rows selected state changes.
   * Returns ({ allSelected, selectedCount, selectedRows }).
   *
   * **Note:** It is highly recommended that you memoize the callback that you
   * pass to `onSelectedRowsChange` if it updates the state of
   * your parent component. This prevents `Datatable` from unnecessary
   * re-renders every time your parent component is re-rendered
   */
  onSelectedRowsChange?: (selectedRowState: { allSelected: boolean; selectedCount: number; selectedRows: T[] }) => void;
  /**
   * Show a sub header between the table and table header
   */
  subHeader?: boolean;
  /**
   * A component you want to render for the subheader
   */
  subHeaderComponent?: React.ReactNode | React.ReactNode[];

  /**
   * Adds action button the header to allow for Expand/Collapse all
   */
  expandAll?: boolean;
  /**
   * Whether to expand the rows by default
   */
  expandDefault?: boolean;

  /**
   * Custom component to add to the table header
   */
  actions?: React.ReactNode | React.ReactNode[];
  /**
   * The type of heading used for the title.
   */
  headingType?: HeadingType;
  /**
   * The heading style used for the title.
   */
  headingStyle?: HeadingStyle;
  /**
   * Applies an aria-label to the table
   */
  ariaLabel?: string;
  /**
   * Initially sorts the table by this column id
   */
  defaultSortField?: string;
  /**
   * defaults to ASC sort
   */
  defaultSortAsc?: boolean;
  /**
   * Optional flag to select all rows
   */
  selectAll?: boolean;
  /** Optional function to determine whether or not a row's initial state should be selected (checked)  */
  defaultSelected?: (row: T) => boolean;
  /**
   * Clears the selected rows if toggled on
   */
  clearSelectedRows?: boolean;
  /**
   * Rows per page options
   */
  paginationRowsPerPageOptions?: number[];
  /**
   * Optional callback to call when a column is sorted
   */
  onSort?: (column: IDatatableColumn<T>, sortDirection: 'asc' | 'desc') => void;
  /**
   * Optional flag to enable zebra-striped styling of datatable rows
   */
  zebraStriping?: boolean;
  /**
   * Optional flag to enable hoverable rows in this datatable
   */
  hoverableRows?: boolean;
  /**
   * Optional flag to allow data table to scroll with a sticky header at a set height
   */
  scrollable?: string;
  /**
   * Optional: applies style to a row when the provided condition is met
   */
  conditionalRowStyles?: { when: (row: T) => boolean; style: React.CSSProperties }[];
  /**
   * Optional: enables the displaying of child data in expandable rows
   */
  showChildRowData?: boolean;
  /**
   * Optional: the name of the field in data[] which contains child data
   */
  childRowDataField?: string;
  /**
   * Optional: applies style to table and rows for a more slimfast view
   */
  compact?: boolean;
  /**
   * Optional: allows rows to be draggable
   */
  draggable?: boolean;
  /**
   * Callback that fires when a row in this datatable is dragged.
   */
  onDraggedRowChange?: (draggedRowState: { draggedRows: T[]; isDragging: boolean }) => void;
  /**
   * Optional: Given a column's selector, it will display when a row is dragged.
   */
  primaryDraggingColumn?: string;
  /**
   * Optional: enables table header and pagination when table is empty.
   */
  showTableWhenEmpty?: boolean;
  /**
   * Optional: enables the adjustment of the table column header tab index.
   */
  columnHeaderTabIndex?: number;
}

export interface IDatatableColumn<T = unknown> {
  id?: string | number;
  /**
   * the display name of our Column
   */
  name: string | number | React.ReactNode;
  /**
   * a data set property in dot notation. A selector is required anytime
   * you want to display data but can be ommitted if your column
   * does not require showing data (e.g. custom content)
   */
  selector?: string | ((row: T, rowIndex: number) => React.ReactNode);
  /**
   * if the column is sortable.
   *
   * **Note:** selector is required for the column to sort
   */
  sortable?: boolean;
  /**
   * custom sorting function e.g. `(rowA, rowB) => rowA.myIndex - rowB.myIndex`
   */
  sortFunction?: (a: T, b: T) => number;
  /**
   * jsx function to render custom cell content!
   * e.g `(row) => <h2>{row.title}</h2>.`
   */
  cell?: (row: T, rowIndex: number, column: IDatatableColumn, id: string | number) => React.ReactNode;
  /**
   * give the column a fixed width
   */
  width?: string;
  /**
   * give the column a minWidth
   */
  minWidth?: string;
  /**
   * give the column a maxWidth
   */
  maxWidth?: string;
  /**
   * how the column should handle overflowed cells.
   */
  overflow?: DatatableOverflow;
  /**
   * allow a column to be omitted
   */
  omit?: boolean;
}

export enum DatatableOverflow {
  wrap = 'wrap',
  hide = 'hide',
  ellipsis = 'ellipsis',
}

const DatatableVariantColors = {
  Active: { dark: '#0f71bb', light: '#f0f0f0' },
  Success: { dark: '#2c7e3e', light: '#e9f9e3' },
  Info: { dark: '#4094cc', light: '#e6f1f8' },
  Warning: { dark: '#fdb81e', light: '#fff1d2' },
  Danger: { dark: '#e21c3d', light: '#ffefef' },
};

const CompactStyles = {
  header: {
    style: {
      minHeight: '36px',
    },
  },
  headRow: {
    style: {
      minHeight: '36px',
      fontSize: '14px',
    },
  },
  rows: {
    style: {
      minHeight: '30px',
      fontSize: '14px',
    },
  },
  pagination: {
    style: {
      minHeight: '36px',
      fontSize: '14px',
    },
  },
};

/**
 * Resize array. Sets default value if the origianl array is empty
 */
const resizeArray = function <Type>(originalArray: Type[], newSize: number, defaultValue: boolean) {
  const newArray = Array(newSize);
  if (originalArray.length === 0) {
    newArray.fill(defaultValue);
  } else {
    for (let i = 0; i < originalArray.length && i < newArray.length; i++) {
      newArray[i] = originalArray[i];
    }
  }
  return newArray;
};

const getConditionalRowStyles = <T,>(
  rowVariantConditions: TypedVariantDefinition<T> | undefined,
  conditionalRowStylesProp: ConditionalRowStyle<T>[] | undefined,
  omitActive: boolean
) => {
  const conditionalRowStyles = [];
  if (rowVariantConditions) {
    const backgroundStyle = (variantColor: { dark: string; light: string }) =>
      `linear-gradient(90deg, ${variantColor.dark}, ${variantColor.dark} 3px, ${variantColor.light} 3px, ${variantColor.light})`;
    if (rowVariantConditions.success) {
      conditionalRowStyles.push({
        when: rowVariantConditions.success.condition,
        style: { background: backgroundStyle(DatatableVariantColors.Success) },
      });
    }
    if (rowVariantConditions.info) {
      conditionalRowStyles.push({
        when: rowVariantConditions.info.condition,
        style: { background: backgroundStyle(DatatableVariantColors.Info) },
      });
    }
    if (rowVariantConditions.warning) {
      conditionalRowStyles.push({
        when: rowVariantConditions.warning.condition,
        style: { background: backgroundStyle(DatatableVariantColors.Warning) },
      });
    }
    if (rowVariantConditions.danger) {
      conditionalRowStyles.push({
        when: rowVariantConditions.danger.condition,
        style: { background: backgroundStyle(DatatableVariantColors.Danger) },
      });
    }
    if (!omitActive && rowVariantConditions.active) {
      conditionalRowStyles.push({
        when: rowVariantConditions.active,
        style: { background: backgroundStyle(DatatableVariantColors.Active) },
      });
    }
  }
  if (Array.isArray(conditionalRowStylesProp)) {
    conditionalRowStylesProp.forEach((conditionalStyle) => conditionalRowStyles.push(conditionalStyle));
  }
  return conditionalRowStyles;
};

const generateLegend = <T,>(rowVariantConditions: TypedVariantDefinition<T> | undefined) => (
  <ol className="legend-popover">
    {rowVariantConditions && rowVariantConditions.success && (
      <li key="success">
        <Icon type={IconType.checkCircle} variant={IconVariant.success} />
        <em>{rowVariantConditions.success.label}</em>
      </li>
    )}
    {rowVariantConditions && rowVariantConditions.info && (
      <li key="info">
        <Icon type={IconType.infoCircle} variant={IconVariant.info} />
        <em>{rowVariantConditions.info.label}</em>
      </li>
    )}
    {rowVariantConditions && rowVariantConditions.warning && (
      <li key="warning">
        <Icon type={IconType.exclamationTriangle} variant={IconVariant.warning} />
        <em>{rowVariantConditions.warning.label}</em>
      </li>
    )}
    {rowVariantConditions && rowVariantConditions.danger && (
      <li key="danger">
        <Icon type={IconType.exclamationCircle} variant={IconVariant.danger} />
        <em>{rowVariantConditions.danger.label}</em>
      </li>
    )}
  </ol>
);

const addRowStyling = (
  tableProps: Partial<IDatatableProps>,
  headerActions: (React.ReactChild | React.ReactFragment | React.ReactPortal)[]
) => {
  // if there are conditional row styles that aren't just for the active row...
  const conditionalRowStylesForLegend = getConditionalRowStyles(tableProps.rowVariantConditions, undefined, true);
  if (conditionalRowStylesForLegend && conditionalRowStylesForLegend.length > 0 && tableProps.showLegend) {
    const legend = generateLegend(tableProps.rowVariantConditions);
    const legendButton = (
      <Popover key={`${tableProps.id}-legend`} content={legend} direction={Direction.bottom} theme={Theme.light}>
        <Button id={`${tableProps.id}-legend`} type={ButtonType.secondary} onClick={noop}>
          <Icon type={IconType.infoCircle} variant={IconVariant.info} />
          Legend
        </Button>
      </Popover>
    );
    headerActions.push(legendButton);
  }
};

const generateToggleAllRowsButton = <T,>(
  tableId: string,
  allExpanded: boolean,
  setAllExpanded: Dispatch<SetStateAction<boolean>>,
  setRowExpandedState: Dispatch<SetStateAction<boolean[]>>
) => (
  <span className="datatable-action-button" key={`btn-expand-collapse-all-${tableId}`}>
    <Button
      id={`btn-expand-collapse-all-${tableId}`}
      onClick={() => {
        setAllExpanded(!allExpanded);
        setRowExpandedState([]);
      }}
    >
      <Icon type={allExpanded ? IconType.chevronUp : IconType.chevronDown} size={IconSize.regular} />{' '}
      {allExpanded ? 'Collapse All Rows' : 'Expand All Rows'}
    </Button>
  </span>
);

const generateHeading = <T,>(
  title: string,
  headingType: HeadingType | undefined,
  headingStyle: HeadingStyle | undefined
) => {
  if (title === '') {
    return '';
  } else {
    return (
      <Heading headingType={headingType ? headingType : 'h3'} headingStyle={headingStyle ? headingStyle : undefined}>
        {title}
      </Heading>
    );
  }
};

export const Datatable = <T,>({
  expandAll = true,
  expandDefault = false,
  onChangePage,
  zebraStriping = true,
  hoverableRows = true,
  scrollable,
  pagination = true,
  paginationRowsPerPageOptions = [10, 25, 50, 100],
  actions = [],
  compact,
  showLegend = true,
  defaultSelected,
  selectAll,
  ...tableProps
}: IDatatableProps<T>) => {
  const [allExpanded, setAllExpanded] = useState(expandDefault);
  const [rowExpandedState, setRowExpandedState] = useState<boolean[]>([]);

  const resetExpandedState = () => {
    setAllExpanded(expandDefault);
    setRowExpandedState([]);
  };

  useEffect(() => {
    // change allExpanded state if all rows have the same state
    if (
      rowExpandedState.length > 0 &&
      rowExpandedState.every((item, index, arr) => item === arr[0]) &&
      rowExpandedState[0] !== allExpanded
    ) {
      setAllExpanded(rowExpandedState[0]);
    }
  }, [allExpanded, rowExpandedState]);

  const headerActions = React.Children.toArray(actions);

  if (expandAll && (tableProps.expandableRows || tableProps.showChildRowData)) {
    headerActions.push(generateToggleAllRowsButton(tableProps.id, allExpanded, setAllExpanded, setRowExpandedState));
  }

  if (!tableProps.ariaLabel) {
    tableProps.ariaLabel = tableProps.title;
  }

  const props: UscisReactDataTableProps<T> = {
    pagination: pagination,
    paginationRowsPerPageOptions: paginationRowsPerPageOptions,
    ...tableProps,
  } as UscisReactDataTableProps<T>;
  props.title = generateHeading(tableProps.title, tableProps.headingType, tableProps.headingStyle);

  addRowStyling({ showLegend, ...tableProps } as Partial<IDatatableProps>, headerActions);

  const className = classNames('beacon-datatable', {
    'beacon-datatable-zebra-striped': zebraStriping,
    'beacon-datatable-hover': hoverableRows,
    'beacon-datatable-scrollable': scrollable,
  });

  return (
    <UscisReactDatatable
      {...props}
      className={className}
      style={{ '--dynamic-table-height': scrollable }}
      customStyles={compact ? { ...CompactStyles } : {}}
      actions={headerActions}
      columnHeaderTabIndex={props.columnHeaderTabIndex}
      onChangePage={(page, totalRows) => {
        onChangePage && onChangePage(page, totalRows);
        resetExpandedState();
      }}
      conditionalRowStyles={getConditionalRowStyles(
        tableProps.rowVariantConditions,
        tableProps.conditionalRowStyles,
        false
      )}
      selectableRowSelected={selectAll ? (row: T) => !props.selectableRowDisabled?.(row) : defaultSelected}
      tableHeaderLevel={tableProps.tableHeaderLevel}
      expandableRowExpanded={(row: T) => allExpanded && !tableProps.expandableRowDisabled?.(row)}
      expandableRowDisabled={tableProps.expandableRowDisabled}
      onRowExpandToggled={(expanded, row, rowIndex, rowCount) => {
        const newState =
          rowExpandedState.length !== rowCount
            ? resizeArray(rowExpandedState, rowCount, allExpanded)
            : [...rowExpandedState];

        newState[rowIndex] = expanded;

        setRowExpandedState(newState);
      }}
      paginationServerOptions={{
        persistSelectedOnPageChange: true,
        persistSelectedOnSort: true,
      }}
    />
  );
};

export { datatableUtils } from './datatable-utils';
