import React from 'react';
import { Heading } from '../heading/heading';
import ComparisonTableBody from './comparison-table-body';
import ComparisonTableHeader from './comparison-table-header';
import { IComparisonTableProps } from './comparison-table-types';

export const ComparisonTable = ({
  id,
  summary,
  title,
  columns,
  dataSources: data,
  fields,
  headingType,
  headingStyle,
  headerActions,
  disableMismatchColumns,
}: IComparisonTableProps) => {
  return (
    <table id={id} className="comparison-table">
      <caption className="comparison-table-caption">
        <div className="d-flex">
          <span className="comparison-table-title">
            <Heading
              headingType={headingType ? headingType : 'h3'}
              headingStyle={headingStyle ? headingStyle : undefined}
            >
              {title}
            </Heading>
          </span>
          {headerActions && <span className="ml-auto custom-checkbox pr-3">{headerActions}</span>}
        </div>
        <span className="comparison-table-summary support-text">{summary}</span>
      </caption>
      <ComparisonTableHeader columns={columns} />
      <ComparisonTableBody fields={fields} data={data} disableMismatchColumns={disableMismatchColumns} />
    </table>
  );
};
