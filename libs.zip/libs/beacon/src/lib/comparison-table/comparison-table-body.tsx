import React, { ReactNode } from 'react';
import { DataRenderFunction, GenericData, IComparisonTableField } from './comparison-table-types';
import './comparison-table.scss';
interface IComparisonTableBodyProps {
  fields: IComparisonTableField[];
  data: GenericData[];
  disableMismatchColumns?: number[];
}
const defaultToNull = (value: unknown): unknown => {
  return value !== undefined ? value : null;
};

const datasourcesMismatchOnField = (
  data: Record<string, unknown>[],
  field: string,
  disableMismatchColumns?: number[]
): boolean => {
  // filter out disabled mismatch columns if they exist
  if (disableMismatchColumns && disableMismatchColumns.length > 0) {
    data = data.filter((_, index) => !disableMismatchColumns.includes(index));
  }
  // if there is one or less data sources then there's no reason to check for equality
  if (data.length <= 1) {
    return false;
  }

  const primaryValue = data[0][field];
  if (Array.isArray(primaryValue)) {
    const primaryValueDefaultedToNull = [...primaryValue].map((value) => defaultToNull(value)).sort();
    //discard first element as it's being used for primaryValue
    return data.slice(1).some((dataSource) => {
      const fieldData = dataSource[field];
      if (!Array.isArray(fieldData) || fieldData.length !== primaryValueDefaultedToNull.length) {
        return true;
      }
      return ![...fieldData].sort().every((value, index) => value === primaryValueDefaultedToNull[index]);
    });
  } else {
    return (
      data.map((dataSource) => defaultToNull(dataSource[field])).find((value) => value !== primaryValue) !== undefined
    );
  }
};

const defaultRender: DataRenderFunction = (field: string, record: GenericData) => {
  return record[field] as ReactNode;
};

const outputDataElements = (data: GenericData[], field: IComparisonTableField): ReactNode => {
  const tableRow: JSX.Element[] = [];
  let fieldRender: DataRenderFunction = defaultRender;
  if (field.render != null) {
    fieldRender = field.render;
  }
  data.forEach((dataSource, index) => {
    tableRow.push(<td key={`data-${index}-${field}`}>{fieldRender(field.field, dataSource)}</td>);
  });
  return tableRow;
};

/**
 * Comparison Table Body component
 */
const ComparisonTableBody = ({ fields, data, disableMismatchColumns }: IComparisonTableBodyProps) => {
  const rows = fields.map((field) => {
    const highlightRow = field.disableMismatchRow
      ? false
      : datasourcesMismatchOnField(data, field.field, disableMismatchColumns);
    return (
      <tr key={`field-${field.field}`} className={`${highlightRow ? 'bg-warning' : ''}`}>
        <th key={`field-${field.field}-header`} scope="row">
          {field.label} {highlightRow ? <span className="sr-only"> - contains data mismatches</span> : ''}
        </th>
        {outputDataElements(data, field)}
      </tr>
    );
  });

  return <tbody>{rows}</tbody>;
};

export default ComparisonTableBody;
