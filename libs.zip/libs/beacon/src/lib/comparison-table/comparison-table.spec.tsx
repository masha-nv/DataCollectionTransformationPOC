import React from 'react';
import { render } from '@testing-library/react';
import { ComparisonTable } from './comparison-table';
import { Default, CustomContent, CustomComparisonLogic, ComparisonTableArrayContent } from './comparison-table.stories';

describe('Comparison Table', () => {
  const setWithMismatchedData = [
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'India',
      fatherName: 'SMITH, LUTHER',
    },
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'Pakistan',
      fatherName: 'SMITH, LUTHER',
    },
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'India',
      fatherName: 'SMITH, LUTHER',
    },
  ];

  const setWithMatchingData = [
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'India',
      fatherName: 'SMITH, LUTHER',
    },
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'India',
      fatherName: 'SMITH, LUTHER',
    },
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'India',
      fatherName: 'SMITH, LUTHER',
    },
  ];

  const columns = [
    {
      name: "Petitioner's Declared Data",
    },
    {
      name: 'CIS Data',
    },
    {
      name: 'CIS Card Data',
    },
  ];

  const fields = [
    {
      label: 'Names',
      field: 'name',
    },
    {
      label: 'Alien Number',
      field: 'alienNumber',
    },
    {
      label: 'Date Of Birth (DOB)',
      field: 'dateOfBirth',
    },
    {
      label: 'Country Of Birth (COB)',
      field: 'countryOfBirth',
    },
    {
      label: "Father's Name",
      field: 'fatherName',
    },
  ];

  const baseProps = {
    id: 'jest-table',
    title: 'Jest Test Table',
    columns,
    fields,
  };

  it('renders the default storybook example with no customized render', () => {
    const { baseElement } = render(<Default />);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with a custom render function', () => {
    const { baseElement } = render(<CustomContent />);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with custom comparison properties', () => {
    const { baseElement } = render(<CustomComparisonLogic />);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with array content comparison', () => {
    const { baseElement } = render(<ComparisonTableArrayContent />);
    expect(baseElement).toMatchSnapshot();
  });

  it('flags mismatched fields if they are undefined', () => {
    const { baseElement } = render(
      <ComparisonTable {...baseProps} dataSources={[{ name: 'John' }, { name: undefined }]} />
    );

    const firstRow = baseElement.querySelector('tbody > tr:first-child');
    expect(firstRow.className).toBe('bg-warning');
    expect(firstRow.textContent).toContain('- contains data mismatches');
  });

  it('renders with customized header', () => {
    const { baseElement } = render(
      <ComparisonTable
        {...baseProps}
        dataSources={[{ name: 'John' }, { name: undefined }]}
        headingType="h1"
        headingStyle="m"
      />
    );

    const firstRow = baseElement.querySelector('tbody > tr:first-child');
    expect(firstRow.className).toBe('bg-warning');
    expect(firstRow.textContent).toContain('- contains data mismatches');
  });

  it('renders with disableMismatchColumns property', () => {
    const { baseElement } = render(
      <ComparisonTable
        {...baseProps}
        dataSources={[
          ...setWithMatchingData,
          ...[
            {
              name: '',
              alienNumber: '',
              dateOfBirth: '',
              countryOfBirth: '',
              fatherName: '',
            },
          ],
        ]}
        disableMismatchColumns={[3]}
      />
    );
    const firstRow = baseElement.querySelector('tbody > tr:first-child');
    expect(firstRow.className).not.toBe('bg-warning');
    expect(firstRow.textContent).not.toContain('- contains data mismatches');
  });

  it('renders with empty disableMismatchColumns property', () => {
    const { baseElement } = render(
      <ComparisonTable
        {...baseProps}
        dataSources={[
          ...setWithMatchingData,
          ...[
            {
              name: '',
              alienNumber: '',
              dateOfBirth: '',
              countryOfBirth: '',
              fatherName: '',
            },
          ],
        ]}
        disableMismatchColumns={[]}
      />
    );
    const firstRow = baseElement.querySelector('tbody > tr:first-child');
    expect(firstRow.className).toBe('bg-warning');
    expect(firstRow.textContent).toContain('- contains data mismatches');
  });

  it('renders with true disableMismatchRow property', () => {
    const { baseElement } = render(
      <ComparisonTable
        {...baseProps}
        fields={[
          {
            label: 'Names',
            field: 'name',
          },
          {
            label: 'Alien Number',
            field: 'alienNumber',
          },
          {
            label: 'Date Of Birth (DOB)',
            field: 'dateOfBirth',
          },
          {
            label: 'Country Of Birth (COB)',
            field: 'countryOfBirth',
            disableMismatchRow: true,
          },
          {
            label: "Father's Name",
            field: 'fatherName',
          },
        ]}
        dataSources={setWithMismatchedData}
      />
    );
    const firstRow = baseElement.querySelector('tbody > tr:nth-child(4)');
    expect(firstRow.className).not.toBe('bg-warning');
    expect(firstRow.textContent).not.toContain('- contains data mismatches');
  });

  it('renders with false disableMismatchRow property', () => {
    const { baseElement } = render(
      <ComparisonTable
        {...baseProps}
        fields={[
          {
            label: 'Names',
            field: 'name',
          },
          {
            label: 'Alien Number',
            field: 'alienNumber',
          },
          {
            label: 'Date Of Birth (DOB)',
            field: 'dateOfBirth',
          },
          {
            label: 'Country Of Birth (COB)',
            field: 'countryOfBirth',
            disableMismatchRow: false,
          },
          {
            label: "Father's Name",
            field: 'fatherName',
          },
        ]}
        dataSources={setWithMismatchedData}
      />
    );
    const firstRow = baseElement.querySelector('tbody > tr:nth-child(4)');
    expect(firstRow.className).toBe('bg-warning');
    expect(firstRow.textContent).toContain('- contains data mismatches');
  });

  it('renders with array data mismatch', () => {
    const { baseElement } = render(
      <ComparisonTable
        {...baseProps}
        dataSources={[
          {
            name: ['Jack'],
          },
          {
            name: ['John'],
          },
        ]}
      />
    );
    const firstRow = baseElement.querySelector('tbody > tr:first-child');
    expect(firstRow.className).toBe('bg-warning');
    expect(firstRow.textContent).toContain('- contains data mismatches');
  });

  it('renders with differently ordered array data', () => {
    const { baseElement } = render(
      <ComparisonTable
        {...baseProps}
        dataSources={[
          {
            name: ['Jack', 'John'],
          },
          {
            name: ['John', 'Jack'],
          },
        ]}
      />
    );
    const firstRow = baseElement.querySelector('tbody > tr:first-child');
    expect(firstRow.className).not.toBe('bg-warning');
    expect(firstRow.textContent).not.toContain('- contains data mismatches');
  });

  it('renders with multiple arrays', () => {
    const { baseElement } = render(
      <ComparisonTable
        {...baseProps}
        dataSources={[
          {
            name: ['Jack', 'John'],
            alienNumber: ['A111111111', 'A222222222', 'A333333333'],
          },
          {
            name: ['John', 'Jack'],
            alienNumber: ['A111111111', 'A222222222', 'A333333333'],
          },
        ]}
      />
    );
    const firstRow = baseElement.querySelector('tbody > tr:first-child');
    expect(firstRow.className).not.toBe('bg-warning');
    expect(firstRow.textContent).not.toContain('- contains data mismatches');

    const secondRow = baseElement.querySelector('tbody > tr:nth-child(2)');
    expect(secondRow.className).not.toBe('bg-warning');
    expect(secondRow.textContent).not.toContain('- contains data mismatches');
  });

  it('renders with empty array data', () => {
    const { baseElement } = render(
      <ComparisonTable
        {...baseProps}
        dataSources={[
          {
            name: ['Jack'],
          },
          {
            name: [],
          },
        ]}
      />
    );
    const firstRow = baseElement.querySelector('tbody > tr:first-child');
    expect(firstRow.className).toBe('bg-warning');
    expect(firstRow.textContent).toContain('- contains data mismatches');
  });
});
