import React from 'react';
import { ComparisonTable } from './comparison-table';
import { IComparisonTableColumn, IComparisonTableField } from './comparison-table-types';
import { Meta, Story } from '@storybook/react';
import { Documentation, dropdownFromHeadingStyles, dropdownFromHeadingTypes, StoryBadge } from '../stories';
import { a11yConfig } from '../stories/story.config';
import { Button, ButtonType } from '../button/button';
import { noop } from '../utils';
import { Icon, IconType, IconVariant } from '../icon/icon';

export default {
  component: ComparisonTable,
  title: 'Core Components/Tables/Comparison Table',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const whenToUse = (
  <ul>
    <li>Generally, data comparison tables are used to display information about an applicant</li>
    <li>
      Tables that compare data and indicate which data does not match should highlight the rows that show non-matching
      data, and should include a warning notification above the table directing users to review the highlighted rows.
    </li>
    <li>
      Tables that compare data and indicate which data does match should indicate which column has the canonical data.
      In the tables that are compared, the data elements that match should be indicated with a fa-check-circle icon,
      with the circle in green.
    </li>
  </ul>
);

const accessibilityConsiderations = (
  <ul>
    <li>
      The <code>title</code> will serve as a caption for the table and should be unique, if you need additional space,
      then use the <code>summary</code> attribute to provide more context about the information on the table
    </li>
  </ul>
);

const argTypes = {
  headingType: {
    control: dropdownFromHeadingTypes(),
    defaultValue: 'h3',
  },
  headingStyle: {
    control: dropdownFromHeadingStyles(),
  },
};

/**
 * Comparison Table
 */
export const Default: Story = (storyProps) => {
  const data = [
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'India',
      fatherName: 'SMITH, LUTHER',
    },
    {
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'Pakistan',
      fatherName: 'SMITH, LUTHER',
    },
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'India',
      fatherName: 'SMITH, LUTHER',
    },
  ];

  const columns: IComparisonTableColumn[] = [
    {
      name: "Petitioner's Declared Data",
    },
    {
      name: 'CIS Data',
    },
    {
      name: 'CIS Card Data',
    },
  ];

  const fields: IComparisonTableField[] = [
    {
      label: 'Names',
      field: 'name',
    },
    {
      label: 'Alien Number',
      field: 'alienNumber',
    },
    {
      label: 'Date of Birth (DOB)',
      field: 'dateOfBirth',
    },
    {
      label: 'Country of Birth (COB)',
      field: 'countryOfBirth',
    },
    {
      label: "Father's Name",
      field: 'fatherName',
    },
  ];

  return (
    <div>
      <ComparisonTable
        id="primaryStory"
        title="Sample comparison table - this is required"
        summary="Shows some sample data, this is a summary that is more descriptive but not required"
        columns={columns}
        fields={fields}
        dataSources={data}
        headingType={storyProps.headingType}
        headingStyle={storyProps.headingStyle}
        headerActions={
          <>
            <div className="support-text text-right nowrap pb-3">
              <span className="pr-3">Refreshed Apr 06, 2026, 2:58:41 PM</span>
              <Button id={`refresh-from-cis-btn`} type={ButtonType.secondary} onClick={noop}>
                <Icon type={IconType.sync} />
                Refresh from CIS
              </Button>
            </div>
            <div className="text-right">
              <span>
                <Icon type={IconType.star} variant={IconVariant.default} />
                Indicates Primary Field
              </span>
              <span className="pl-3">
                <Icon type={IconType.exclamationTriangle} variant={IconVariant.warning} />
                Indicates Mismatch Field
              </span>
            </div>
          </>
        }
      />
    </div>
  );
};
Default.storyName = 'Comparison Table';
Default.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Comparison Tables"
      description="These tables are used to compare multiple columns of data side by side, and their columns are not sortable"
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
Default.argTypes = argTypes;

/**
 * Comparison Table
 */
export const CustomContent: Story = (storyProps) => {
  const dataSources = [
    {
      name: 'John',
      lastName: 'Doe',
    },
  ];
  const columns: IComparisonTableColumn[] = [
    {
      name: 'Main data source',
    },
  ];
  const fields: IComparisonTableField[] = [
    {
      label: 'Full Name',
      field: 'name',
      render: (field, record) => (
        <span>
          With an{' '}
          <em>
            emphasized {record.name} {record.lastName}
          </em>{' '}
          name
        </span>
      ),
    },
  ];
  const props = { columns, fields, dataSources };
  return (
    <div className="beacon">
      <ComparisonTable
        id="withCustomRender"
        title="Custom rendering"
        headingType={storyProps.headingType}
        headingStyle={storyProps.headingStyle}
        {...props}
      />
    </div>
  );
};
CustomContent.storyName = 'Comparison Table with Custom Content';
CustomContent.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Custom Content in Comparison Tables"
      description={
        <p>
          Comparison tables can also render custom content by using the <code>render</code> property.
        </p>
      }
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
CustomContent.argTypes = argTypes;

/**
 * Custom Comparison Logic Comparison Table
 */
export const CustomComparisonLogic: Story = (storyProps) => {
  const data = [
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'India',
      fatherName: 'SMITH, LUTHER',
      ignoredComparisonField: 'This row will',
    },
    {
      name: 'John Smith',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'Pakistan',
      fatherName: 'SMITH, LUTHER',
      ignoredComparisonField: 'ignore all field',
    },
    {
      name: 'John Wilson',
      alienNumber: 'A0123456789',
      dateOfBirth: '04/15/1973',
      countryOfBirth: 'India',
      fatherName: 'SMITH, LUTHER',
      ignoredComparisonField: 'comparison logic',
    },
    {
      name: (
        <Button onClick={noop} id={'editNameDobButton'} type={ButtonType.primary}>
          Edit Name/DOB
        </Button>
      ),
      alienNumber: '',
      dateOfBirth: (
        <Button onClick={noop} id={'editNameDobButton'} type={ButtonType.primary}>
          Edit Name/DOB
        </Button>
      ),
      countryOfBirth: '',
      fatherName: '',
    },
  ];

  const columns: IComparisonTableColumn[] = [
    {
      name: "Petitioner's Declared Data",
    },
    {
      name: 'CIS Data',
    },
    {
      name: 'CIS Card Data',
    },
    {
      name: 'Actions',
    },
  ];

  const fields: IComparisonTableField[] = [
    {
      label: 'Names',
      field: 'name',
    },
    {
      label: 'Alien Number',
      field: 'alienNumber',
    },
    {
      label: 'Date of Birth (DOB)',
      field: 'dateOfBirth',
    },
    {
      label: 'Country of Birth (COB)',
      field: 'countryOfBirth',
    },
    {
      label: "Father's Name",
      field: 'fatherName',
    },
    {
      label: 'Ignored Comparison Field',
      field: 'ignoredComparisonField',
      disableMismatchRow: true,
    },
  ];

  return (
    <div>
      <ComparisonTable
        id="primaryStory"
        title="Sample comparison table - this is required"
        summary="Shows some sample data, this is a summary that is more descriptive but not required"
        columns={columns}
        fields={fields}
        dataSources={data}
        headingType={storyProps.headingType}
        headingStyle={storyProps.headingStyle}
        disableMismatchColumns={[3]}
      />
    </div>
  );
};
CustomComparisonLogic.storyName = 'Comparison Table with Custom Comparison Logic';
CustomComparisonLogic.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Custom Comparison Logic in Comparison Tables"
      description={
        <p>
          Comparison tables can also conditionally highlight data mismatch rows by using the{' '}
          <code>disableMismatchRow</code> or <code>disableMismatchColumns</code> properties.
          <br />
          <code>disableMismatchRow</code> is added to the <code>IComparisonTableField</code> and allows the given row to
          be excluded from comparison logic.
          <br />
          <code>disableMismatchColumns</code> is added to the <code>IComparisonTableProps</code> and allows the given
          column index to be excluded from comparison logic.
          <br />
        </p>
      }
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
CustomComparisonLogic.argTypes = argTypes;

/**
 * Comparison Table with array data
 */
export const ComparisonTableArrayContent: Story = (storyProps) => {
  const dataSources = [
    {
      name: 'John',
      alienNumbers: ['A111111111', 'A222222222'],
      spouseAlienNumbers: ['A333333333', 'A444444444'],
      aliases: ['Jon', null, undefined, ''],
      consolidatedAlienNumbers: ['A555555555', 'A666666666', 'A777777777', 'A888888888', 'A999999999'],
    },
    {
      name: 'Mark',
      alienNumbers: ['A111111111', 'A222222222'],
      spouseAlienNumbers: ['A444444444', 'A333333333'],
      aliases: ['Jon', 'Jack'],
      childrenAges: [2, 4, 6],
    },
  ];
  const columns: IComparisonTableColumn[] = [
    {
      name: 'Column 1',
    },
    {
      name: 'Column 2',
    },
  ];
  const fields: IComparisonTableField[] = [
    {
      label: 'Full Name',
      field: 'name',
    },
    {
      label: 'Alien Numbers',
      field: 'alienNumbers',
      render: (field, record) => {
        return (record[field] as string[]).map((item, index) => <div key={item + index}>{item}</div>);
      },
    },
    {
      label: 'Spouse Alien Numbers',
      field: 'spouseAlienNumbers',
      render: (field, record) => {
        return (record[field] as string[]).map((item, index) => <div key={item + index}>{item}</div>);
      },
    },
    {
      label: 'Aliases',
      field: 'aliases',
      render: (field, record) => {
        return (record[field] as string[]).map((item, index) => <div key={item + index}>{item}</div>);
      },
    },
    {
      label: 'Children Ages',
      field: 'childrenAges',
      render: (field, record) => {
        return record[field] ? (record[field] as string[]).join(', ') : '';
      },
    },
    {
      label: 'Consolidated Alien Numbers',
      field: 'consolidatedAlienNumbers',
      render: (field, record) => {
        return record[field]
          ? (record[field] as string[]).map((item, index) => <div key={item + index}>{item}</div>)
          : '';
      },
    },
  ];
  const props = { columns, fields, dataSources };
  return (
    <div className="beacon">
      <ComparisonTable
        id="withCustomRender"
        title="Custom rendering"
        headingType={storyProps.headingType}
        headingStyle={storyProps.headingStyle}
        {...props}
      />
    </div>
  );
};
ComparisonTableArrayContent.storyName = 'Comparison Table with array data';
ComparisonTableArrayContent.decorators = [
  (ComponentStory: Story) => (
    <Documentation
      name="Comparison Tables with array data"
      description={
        <p>
          Comparison tables can also compare data arrays. Arrays are be sorted alphabetically before comparison, so even
          if the data exists in different orders it will not trigger a data mismatch.
          <br />
          Comparisons can also be made against an empty array or undefined/null data.
        </p>
      }
      whenToUse={whenToUse}
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <ComponentStory />
    </Documentation>
  ),
];
ComparisonTableArrayContent.argTypes = argTypes;
