import React from 'react';
import { fireEvent, render } from '@testing-library/react';
import { SideNavigation } from './side-navigation';
import { SideNavigationItem } from './side-navigation-item';
import userEvent from '@testing-library/user-event';
import { Badge } from '../../notifications/badge/badge';
describe('Side Navigation Component', () => {
  it('renders single-level side-navigaiton', () => {
    const { baseElement } = render(basicSideNav);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders multi-level side-navigaiton', () => {
    const { baseElement } = render(multiLevelSideNav);
    expect(baseElement).toMatchSnapshot();
  });
  it('renders single level with achors and links', () => {
    const { baseElement } = render(singleLevelWithAnchorAndLink);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders default collapsed', () => {
    const { baseElement } = render(defaultCollapsed);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with href links', () => {
    const { baseElement } = render(basicWithHref);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with a fancy label', () => {
    const { baseElement } = render(withFancyLabel);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with completed, inView and active classes', () => {
    const { baseElement } = render(withCompletedInViewActive);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with draggedOn', () => {
    const { baseElement } = render(withDraggedOn);
    expect(baseElement).toMatchSnapshot();
  });

  it('expands nav item on click', () => {
    const { baseElement } = render(defaultCollapsed);
    const navItem1CollapseButton = baseElement.querySelector('#item-1-collapse-button');
    fireEvent.click(navItem1CollapseButton);

    expect(baseElement).toMatchSnapshot();
  });

  it('expands nav item on click', () => {
    const { baseElement } = render(defaultCollapsed);
    const navItem1CollapseButton = baseElement.querySelector('#item-1-collapse-button');
    fireEvent.click(navItem1CollapseButton);

    expect(baseElement).toMatchSnapshot();
  });

  it('calls onClick when link is clicked on anchor link', () => {
    const onClick = jest.fn();
    const { baseElement } = render(basicSideNavWithOnClick(onClick));
    const navItem1 = baseElement.querySelector('#item-1');
    fireEvent.click(navItem1);

    expect(onClick).toHaveBeenCalled();
  });

  it('calls onClick when link is clicked on span', () => {
    const onClick = jest.fn();
    const { baseElement } = render(basicSideNavWithOnClick(onClick));
    const navItem2 = baseElement.querySelector('#item-2');
    fireEvent.click(navItem2);

    expect(onClick).toHaveBeenCalled();
  });

  it('calls onToggleCollapse when navigation item is collapsed and expanded', () => {
    const onToggleCollapse = jest.fn();
    const { baseElement } = render(basicSideNavWithOnToggleCollapse(onToggleCollapse));
    const navItem = baseElement.querySelector('#item-1-collapse-button');

    fireEvent.click(navItem);
    expect(onToggleCollapse).toHaveBeenCalled();
    expect(navItem.innerHTML).toContain('Navigation Item Expanded');

    fireEvent.click(navItem);
    expect(onToggleCollapse).toHaveBeenCalled();
    expect(navItem.innerHTML).toContain('Navigation Item Collapsed');
  });

  it('calls onDragEnter when dragged on', () => {
    const onDragEnter = jest.fn();
    const { baseElement } = render(basicSideNavWithOnDragEnter(onDragEnter));
    const navItem = baseElement.querySelector('#item-1');
    fireEvent.dragEnter(navItem);

    expect(onDragEnter).toHaveBeenCalled();
  });

  it('calls onDragLeave when dragged away', () => {
    const onDragLeave = jest.fn();
    const { baseElement } = render(basicSideNavWithOnDragLeave(onDragLeave));
    const navItem = baseElement.querySelector('#item-1');
    fireEvent.dragLeave(navItem);

    expect(onDragLeave).toHaveBeenCalled();
  });

  it('calls onDragOver when dragged away', () => {
    const onDragOver = jest.fn();
    const { baseElement } = render(basicSideNavWithOnDragOver(onDragOver));
    const navItem = baseElement.querySelector('#item-1');
    fireEvent.dragOver(navItem);

    expect(onDragOver).toHaveBeenCalled();
  });

  it('calls onDrop when dropped on', () => {
    const onDrop = jest.fn();
    const { baseElement } = render(basicSideNavWithOnDrag(onDrop));
    const navItem = baseElement.querySelector('#item-1');
    fireEvent.drop(navItem);

    expect(onDrop).toHaveBeenCalled();
  });

  it('renders with a skipToEnd button and focuses on the end element when buttonis clicked', () => {
    const { baseElement } = render(basicWithSkipToEnd);
    const skipToEndButton = baseElement.querySelector('#basic-side-nav-skip-to-end-button');
    userEvent.click(skipToEndButton);

    expect(document.activeElement?.getAttribute('id')).toEqual('basic-side-nav-menu-end');
    expect(baseElement).toMatchSnapshot();
  });

  it('logs warning when SideNavigation is provided a child that is not SideNavigation or SideNavigationItem, and renders correctly', () => {
    const consoleSpy = jest.spyOn(console, 'warn').mockImplementation();
    const { baseElement } = render(withBadTemplating);
    expect(baseElement).toMatchSnapshot();
    expect(consoleSpy).toBeCalled();
  });

  it('renders with customized heading', () => {
    const { baseElement } = render(
      <SideNavigation id="basic-side-nav" title="Basic Side Navigation" headingType="h1">
        <SideNavigationItem id="item-1" label="Item 1" title="Item 1" />
      </SideNavigation>
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with aria-label', () => {
    const { baseElement } = render(
      <SideNavigation id="basic-side-nav" title="Basic Side Navigation" headingType="h1">
        <SideNavigationItem id="item-1" label="Item 1" ariaLabel="Item 1 aria label" />
      </SideNavigation>
    );
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with element title heading', () => {
    const { baseElement } = render(basicWithElementTitle);
    expect(baseElement).toMatchSnapshot();
  });

  it('renders with tooltip', () => {
    const { baseElement } = render(
      <SideNavigation id="basic-side-nav" title="Basic Side Navigation" headingType="h1">
        <SideNavigationItem id="item-1" label="Item 1" ariaLabel="Item 1 aria label" tooltipContent="Tooltip Label" />
      </SideNavigation>
    );
    expect(baseElement).toMatchSnapshot();
  });
});

const basicSideNav = (
  <SideNavigation id="basic-side-nav" title="Basic Side Navigation">
    <SideNavigationItem id="item-1" label="Item 1" title="Item 1" />
    <SideNavigationItem id="item-2" label="Item 2" />
  </SideNavigation>
);

const withFancyLabel = (
  <SideNavigation id="basic-side-nav" title="Basic Side Navigation">
    <SideNavigationItem
      id="item-1"
      label={
        <span>
          This is a fancy label with a <Badge id="badge-1">Badge</Badge>
        </span>
      }
    />
  </SideNavigation>
);

const withCompletedInViewActive = (
  <SideNavigation id="basic-side-nav" title="Basic Side Navigation">
    <SideNavigationItem id="item-1" label="Item 1" completed inView active />
    <SideNavigationItem id="item-1" label="Item 1" href="#" completed inView active />
  </SideNavigation>
);

const withDraggedOn = (
  <SideNavigation id="basic-side-nav" title="Basic Side Navigation">
    <SideNavigationItem id="item-1" label="Item 1" draggedOn />
    <SideNavigationItem id="item-1" label="Item 1" href="#" draggedOn />
  </SideNavigation>
);

const basicSideNavWithOnToggleCollapse = (OnToggleCollapse: () => void) => (
  <SideNavigation id="basic-side-nav">
    <SideNavigationItem id="item-1" label="Item 1" onToggleCollapse={OnToggleCollapse}>
      <SideNavigation id="child-level">
        <SideNavigationItem id="child-1" label="Child Level Item 1" />
        <SideNavigationItem id="child-2" label="Child Level Item 2" />
      </SideNavigation>
    </SideNavigationItem>
  </SideNavigation>
);

const basicSideNavWithOnClick = (onClick: () => void) => (
  <SideNavigation id="basic-side-nav">
    <SideNavigationItem id="item-1" onClick={onClick} label="Item 1" href="#" />
    <SideNavigationItem id="item-2" label="Item 2" onClick={onClick} />
  </SideNavigation>
);

const basicSideNavWithOnDragEnter = (onDragEnter: () => void) => (
  <SideNavigation id="basic-side-nav">
    <SideNavigationItem id="item-1" onDragEnter={onDragEnter} label="Item 1" href="#" />
    <SideNavigationItem id="item-2" label="Item 2" />
  </SideNavigation>
);
const basicSideNavWithOnDragLeave = (onDragLeave: () => void) => (
  <SideNavigation id="basic-side-nav">
    <SideNavigationItem id="item-1" onDragLeave={onDragLeave} label="Item 1" href="#" />
    <SideNavigationItem id="item-2" label="Item 2" />
  </SideNavigation>
);

const basicSideNavWithOnDragOver = (onDragOver: () => void) => (
  <SideNavigation id="basic-side-nav">
    <SideNavigationItem id="item-1" onDragOver={onDragOver} label="Item 1" href="#" />
    <SideNavigationItem id="item-2" label="Item 2" />
  </SideNavigation>
);

const basicSideNavWithOnDrag = (onDrop: () => void) => (
  <SideNavigation id="basic-side-nav">
    <SideNavigationItem id="item-1" onDrop={onDrop} label="Item 1" href="#" />
    <SideNavigationItem id="item-2" label="Item 2" />
  </SideNavigation>
);

const multiLevelSideNav = (
  <SideNavigation id="basic-side-nav">
    <SideNavigationItem id="item-1" label="Item 1" collapse={false}>
      <SideNavigation id="child-level">
        <SideNavigationItem id="child-level-item-1" label="Child Level Item 1" />
        <SideNavigationItem id="child-level-item-2" label="Child Level Item 2" />
      </SideNavigation>
    </SideNavigationItem>
    <SideNavigationItem id="item-2" label="Item 2" />
  </SideNavigation>
);

const singleLevelWithAnchorAndLink = (
  <SideNavigation id="basic-side-nav">
    <SideNavigation id="child-level" showAnchors>
      <SideNavigationItem id="child-level-item-1" label="Child Level Item 1" />
      <SideNavigationItem id="child-level-item-2" label="Child Level Item 2" />
    </SideNavigation>
    <SideNavigationItem id="item-2" label="Item 2" />
  </SideNavigation>
);

const defaultCollapsed = (
  <SideNavigation id="basic-side-nav">
    <SideNavigationItem id="item-1" label="Item 1">
      <SideNavigation id="child-level">
        <SideNavigationItem id="child-level-item-1" label="Child Level Item 1" />
        <SideNavigationItem id="child-level-item-2" label="Child Level Item 2" />
      </SideNavigation>
    </SideNavigationItem>
  </SideNavigation>
);

const basicWithHref = (
  <SideNavigation id="basic-side-nav">
    <SideNavigationItem id="item-1" label="Item 1" href="#" />
    <SideNavigationItem id="item-2" label="Item 2" href="#" />
  </SideNavigation>
);

const basicWithSkipToEnd = (
  <SideNavigation id="basic-side-nav" skipToEnd>
    <SideNavigationItem id="item-1" label="Item 1" href="#" />
    <SideNavigationItem id="item-2" label="Item 2" href="#" />
  </SideNavigation>
);

const withBadTemplating = (
  <SideNavigation id="basic-side-nav" skipToEnd>
    <span>Foo</span>
    <SideNavigationItem id="item-1" label="Item 1" href="#" />
    <SideNavigationItem id="item-2" label="Item 2" href="#" />
  </SideNavigation>
);

const basicWithElementTitle = (
  <SideNavigation id="basic-side-nav" title={<span>This is an element title</span>}>
    <SideNavigationItem id="item-1" label="Item 1" href="#" />
    <SideNavigationItem id="item-2" label="Item 2" href="#" />
  </SideNavigation>
);
