import React, { useState } from 'react';
import { Meta, Story } from '@storybook/react';
import { Documentation, dropdownFromHeadingTypes, StoryBadge } from '../../stories';
import { a11yConfig } from '../../stories/story.config';
import { ISideNavigationProps, SideNavigation } from './side-navigation';
import { SideNavigationItem } from './side-navigation-item';
import { Icon, IconType } from '../../icon/icon';

export default {
  component: SideNavigation,
  subcomponents: { SideNavigationItem },
  title: 'Core Components/Navigation/Side Navigation',
  parameters: {
    badges: [StoryBadge.READY],
    a11y: a11yConfig,
    docs: {
      source: { type: 'code' },
    },
  },
} as Meta;

const whenToUse = (
  <>
    <p>
      Use side navigation to organize content in a user interface and enable a user to navigate to different sections.
    </p>
    <p>
      Side navigation can be used as a "checklist" in a task, allowing users to move through each step and mark them as
      complete without necessarily encouraging linear progression (as a Wizard does).
    </p>
    <p>
      When the side navigation describes a section with <b>child pages (sub-pages)</b>, link from the navigation to
      those child pages to enable users to navigate to them.
    </p>
    <p>
      On long pages with many sub-sections, link from the navigation to <b>anchor links </b>within the page so users can
      jump directly to the section they want to see. These links are visually distinguished from links to child pages to
      avoid confusing the user.
    </p>
    <p>
      Side navigation can also include checkmarks to the right of each item that indicate whether users have completed
      the task in that page.
    </p>{' '}
  </>
);

const accessibilityConsiderations = (
  <ul>
    <li>
      Developer's Checklist
      <ul>
        <li>Enable "skip links" option to allow user to jump to main page content if using this component as a menu</li>
        <li>Users should be able to tab to navigate among links</li>
        <li>Users should be able to activate a link when pressing "Enter" on their keyboard</li>
        <li>Users should be able to activate hover and focus states with both a mouse and a keyboard</li>
      </ul>
    </li>
  </ul>
);

const argTypes = {
  headingType: {
    control: dropdownFromHeadingTypes(),
    defaultValue: 'h2',
  },
};

export const SingleLevelSideNavigation: Story<ISideNavigationProps> = ({ headingType }: ISideNavigationProps) => {
  const [completed, setCompleted] = useState(false);

  const toggleCompleted = () => {
    setCompleted((prev) => !prev);
  };

  return (
    <div className="w-50">
      <SideNavigation id="side-nav-component" title="Single-level Side Navigation" headingType={headingType}>
        <SideNavigationItem id="completed-item" completed label="A completed step" />
        <SideNavigationItem
          id="long-title-item"
          label="A much, much longer title that will wrap on to multiple lines"
          active
        />
        <SideNavigationItem
          id="inactive-item"
          onClick={toggleCompleted}
          label="A navigation element. Click to toggle completed."
          completed={completed}
        />
        <SideNavigationItem id="tooltip-item" label="An element with a tooltip" tooltipContent="This is a tooltip" />
      </SideNavigation>
    </div>
  );
};
SingleLevelSideNavigation.storyName = 'Side Navigation';

SingleLevelSideNavigation.decorators = [
  (Story: Story) => (
    <Documentation
      name="Basic Side Navigation"
      whenToUse={whenToUse}
      description="Hierarchical, vertical navigation at the side of a page."
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <Story />
    </Documentation>
  ),
];
SingleLevelSideNavigation.argTypes = argTypes;

export const MultiLevelSideNavigation: Story<ISideNavigationProps> = ({ headingType }: ISideNavigationProps) => {
  return (
    <div className="w-50">
      <SideNavigation id="side-nav-component" title="Multi-level Side Navigation" headingType={headingType}>
        <SideNavigationItem
          id="parent-page"
          collapse={false}
          label={
            <span>
              Fancy Label with an <Icon type={IconType.star} description="Finished Step"></Icon>
            </span>
          }
          title="This is a tooltip description of the 'Fancy Label' item. Normally, this would provide additional information about the corresponding item in side navigation."
        >
          <SideNavigation id="child-pages">
            <SideNavigationItem id="child-page-1" active label="A child page" collapse={false} collapsible={false}>
              <SideNavigation id="grandchild-pages" showAnchors>
                <SideNavigationItem id="grandchild-page-1" inView label="An anchor link" />
                <SideNavigationItem id="grandchild-page-2" label="Another anchor link" />
                <SideNavigationItem id="grandchild-page-3" label="Scroll to a section" />
              </SideNavigation>
            </SideNavigationItem>

            <SideNavigationItem id="another-child-step" label="Another child step" />
            <SideNavigationItem id="a-child-step" label="A child step" />
          </SideNavigation>
        </SideNavigationItem>
        <SideNavigationItem id="completed-item" completed label="A completed step" />
        <SideNavigationItem
          id="long-title-item"
          label="A much, much longer title that will wrap on to multiple lines"
        />
        <SideNavigationItem id="inactive-item" label="An inactive navigation element" />
      </SideNavigation>
    </div>
  );
};

MultiLevelSideNavigation.storyName = 'Multiple-level Side Navigation';

MultiLevelSideNavigation.decorators = [
  (Story: Story) => (
    <Documentation
      name="Multi-Leveled Side Navigation"
      whenToUse={whenToUse}
      description="SideNavigation and SideNavigationItem can be inserted inside of each other to create multiple levels of items."
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <Story />
    </Documentation>
  ),
];
MultiLevelSideNavigation.argTypes = argTypes;

export const SideNavWithAnchors: Story<ISideNavigationProps> = ({ headingType }: ISideNavigationProps) => {
  const [inView, setInView] = useState('');
  return (
    <div className="w-50">
      <SideNavigation id="side-nav-component" title="Mixed Links" headingType={headingType}>
        <SideNavigationItem
          id="parent-page"
          collapse={false}
          active
          label="Navigation item with anchors links and non-anchor links. Click anchor to set inview."
        >
          <SideNavigation id="child-pages">
            <SideNavigation id="grandchild-pages" showAnchors>
              <SideNavigationItem
                onClick={(e) => setInView('grandchild-page-1')}
                id="grandchild-page-1"
                label="An anchor link"
                inView={inView === 'grandchild-page-1'}
              />
              <SideNavigationItem
                onClick={(e) => setInView('grandchild-page-2')}
                id="grandchild-page-2"
                label="Another anchor link"
                inView={inView === 'grandchild-page-2'}
              />
              <SideNavigationItem
                onClick={(e) => setInView('grandchild-page-3')}
                id="grandchild-page-3"
                label="Scroll to a section"
                inView={inView === 'grandchild-page-3'}
              />
            </SideNavigation>
            <SideNavigationItem id="a-child-step" label="A child step" />
            <SideNavigationItem id="another-child-step" label="Another child step" />
          </SideNavigation>
        </SideNavigationItem>
        <SideNavigationItem id="completed-item" completed label="A completed step" />
      </SideNavigation>
    </div>
  );
};

SideNavWithAnchors.storyName = 'Mixed-link Side Navigation';

SideNavWithAnchors.decorators = [
  (Story: Story) => (
    <Documentation
      name="Mixing Link Types"
      whenToUse={whenToUse}
      description="Left-bordered anchor link list can be on the same level as other non-anchor links"
      accessibilityConsiderations={accessibilityConsiderations}
    >
      <Story />
    </Documentation>
  ),
];
SideNavWithAnchors.argTypes = argTypes;
