describe('beacon: Data View component', () => {
  describe('Basic Data View', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-data-view--basic-example');

      cy.injectAxe();
    });

    it('should render a data view with data', () => {
      cy.get('.dataview').should('exist').checkAccessibility();
      cy.get('.dataview-row').should('have.length', 6).checkAccessibility();
    });
  });
});
