describe('beacon: Button component', () => {
  describe('Primary Button', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-buttons--primary');
      cy.injectAxe();
    });

    it('should render the component', () => {
      cy.findByText('Primary button').should('be.visible').checkAccessibility();
    });

    it('should render the disabled component', () => {
      cy.findByText('Primary button (Disabled)').should('be.visible').checkAccessibility();
    });
  });

  describe('Secondary Button', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-buttons--secondary');
      cy.injectAxe();
    });

    it('should render the component', () => {
      cy.findByText('Secondary button').should('be.visible').checkAccessibility();
    });

    it('should render the disabled component', () => {
      cy.findByText('Secondary button (Disabled)').should('be.visible').checkAccessibility();
    });
  });

  describe('Tertiary Button', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-buttons--tertiary');
      cy.injectAxe();
    });

    it('should render the component', () => {
      cy.findByText('Tertiary button').should('be.visible').checkAccessibility();
    });

    it('should render the disabled component', () => {
      cy.findByText('Tertiary button (Disabled)').should('be.visible').checkAccessibility();
    });
  });

  describe('Button Groups', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-buttons--button-groups');
      cy.injectAxe();
    });
  });
});
