describe('beacon: Text Input component', () => {
  describe('Basic Text Input', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-form-controls-text-input--basic-text-input');
      cy.injectAxe();
    });

    it('should render a basic text input', () => {
      cy.get('.form-control').should('exist').checkAccessibility();
    });
  });
});
