describe('beacon: Switch component', () => {
  describe('Basic Switch', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-form-controls-switch--basic-example');
      cy.injectAxe();
    });

    it('should render a basic switch', () => {
      cy.get('.switch').should('exist').checkAccessibility();
    });
  });
});
