describe('beacon: Side Navigation component', () => {
  describe('Single Level Side Navigation', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-navigation-side-navigation--single-level-side-navigation');
      cy.injectAxe();
    });

    it('should render single level side navigation', () => {
      cy.get('.nav').should('exist').checkAccessibility();
      cy.get('.nav-item').should('have.length', 4).checkAccessibility();
    });
  });
});
