describe('beacon: Datatable component', () => {
  describe('Example Datatable', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-tables-datatable--example');

      cy.injectAxe();
    });

    it('should render a datatable with data', () => {
      cy.get('[role="table"]').should('exist').checkAccessibility();
      cy.get('[role="row"]').should('have.length', 11).checkAccessibility();
    });
  });
});
