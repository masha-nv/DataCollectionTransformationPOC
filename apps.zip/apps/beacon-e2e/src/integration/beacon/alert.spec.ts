describe('beacon: Alert component', () => {
  describe('Basic Alert', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-notifications-alerts--error-alert');
      cy.injectAxe();
    });

    it('should render an error alert', () => {
      cy.get('.alert-label').should('exist').checkAccessibility();
    });
  });
});
