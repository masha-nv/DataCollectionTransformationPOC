describe('beacon: Accordion Group component', () => {
  describe('Group of Accordions', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-accordions-accordion--group-of-accordions');
      cy.injectAxe();
    });

    it('should render a group of accordions', () => {
      cy.get('.accordion-container').should('have.length', 3).checkAccessibility();
    });

    it('should render the body when header is clicked', () => {
      cy.get('#first-accordion-button').click();
      cy.findByText('Simple text-only header').should('be.visible').checkAccessibility();
    });
  });
});
