describe('beacon: Icon component', () => {
  describe('Icon Collection', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=styling-icons--icon-collection');
      cy.injectAxe();
    });

    it('should render a default icon', () => {
      cy.get('.beacon-icon-large').should('exist').checkAccessibility();
    });
  });

  describe('Icon Sizes', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=styling-icons--icon-sizes');
      cy.injectAxe();
    });

    it('should render a small icon', () => {
      cy.get('.beacon-icon-small').should('exist').checkAccessibility();
    });

    it('should render a regular icon', () => {
      cy.get('.beacon-icon-regular').should('exist').checkAccessibility();
    });

    it('should render a large icon', () => {
      cy.get('.beacon-icon-large').should('exist').checkAccessibility();
    });

    it('should render a default icon', () => {
      cy.get('.beacon-icon-default').should('exist').checkAccessibility();
    });
  });

  describe('Icon Variants', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=styling-icons--icon-variants');
      cy.injectAxe();
    });

    it('should render an info icon', () => {
      cy.get('.beacon-icon-info').should('exist').checkAccessibility();
    });
  });
});
