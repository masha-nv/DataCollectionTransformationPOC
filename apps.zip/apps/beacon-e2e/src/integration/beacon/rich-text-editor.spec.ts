describe('beacon: Rich Text Editor component', () => {
  describe('Basic Rich Text Editor', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-form-controls-rich-text-editor--basic-rich-text-editor');
      cy.injectAxe();
    });

    it('should render a basic rich text editor', () => {
      cy.get('.rich-text-editor').should('exist').checkAccessibility();
    });
  });
});
