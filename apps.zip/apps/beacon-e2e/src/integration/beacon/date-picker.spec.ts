describe('beacon: Date Picker component', () => {
  describe('Basic Date Picker', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-form-controls-date-picker--basic-date-picker');

      cy.injectAxe();
    });

    it('should render a basic date picker', () => {
      cy.get('.beacon-datepicker').should('exist').checkAccessibility();
    });
  });
});
