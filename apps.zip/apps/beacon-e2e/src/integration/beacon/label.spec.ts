describe('beacon: Label component', () => {
  describe('Basic Label', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-form-controls-label--basic-label');
      cy.injectAxe();
    });

    it('should render a basic label', () => {
      cy.findByText('First Name').should('exist').checkAccessibility();
    });
  });
});
