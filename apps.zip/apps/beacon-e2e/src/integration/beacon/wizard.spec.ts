describe('beacon: Wizard component', () => {
  describe('Basic Wizard', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-navigation-wizard-stepper--basic-example');
      cy.injectAxe();
    });

    it('should render wizard steps', () => {
      cy.get('.steps').should('exist').checkAccessibility();
      cy.get('.step').should('have.length', 4).checkAccessibility();
    });

    it('should click the next button and display step 2', () => {
      cy.get('#wizard-default-next-button').click();
      cy.findByText('The current step says to Run npm install').should('be.visible').checkAccessibility();
    });
  });
});
