describe('beacon: Accordion component', () => {
  describe('Primary Accordion', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-accordions-accordion--accordion-primary');
      cy.injectAxe();
    });

    it('should render simple text-only', () => {
      cy.findByText('Simple text-only header').should('be.visible').checkAccessibility();
    });

    it('should render the body when simple text-only is clicked', () => {
      cy.get('#first-accordion-button').click();
      cy.findByText('Simple text-only header').should('be.visible').checkAccessibility();
    });

    it('should render tsx header', () => {
      cy.findByText('Header with TSX code including a').should('be.visible').checkAccessibility();
    });

    it('should render the body when tsx header is clicked', () => {
      cy.get('#second-accordion-button').click();
      cy.findByText('Header with TSX code including a').should('be.visible').checkAccessibility();
    });

    it('should render header with action', () => {
      cy.findByText('Header on the left and action on the right').should('be.visible').checkAccessibility();
    });

    it('should render the body when header with action is clicked', () => {
      cy.get('#third-accordion-button').click();
      cy.findByText('Header on the left and action on the right').should('be.visible').checkAccessibility();
    });
  });
});
