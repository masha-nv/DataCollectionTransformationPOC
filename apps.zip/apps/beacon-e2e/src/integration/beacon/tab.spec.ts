describe('beacon: Tab component', () => {
  describe('Standard Tab', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-navigation-tab--standard-tab');
      cy.injectAxe();
    });

    //Cypress check accessibility is giving no errors when it's a 508 error for
    //ANDI / screen readers. Fixing it for ANDI / screen readers give cypress
    //accessibility errors. Primary focus is working for ANDI / screen readers
    //so removing the checkAccessibility() from here
    //NOTE: From best I can tell Cypress is erroring because it's not rendering
    //nor detecting the full page properly. It errors saying <li> exists outside
    //a <ul> but you can see in the snapshot & by manually looking at the html of
    //iframe.html?id=core-components-navigation-tab--standard-tab that this isn't the case

    it('should render standard tabs', () => {
      cy.get('.nav').should('exist');
      cy.get('.nav-item').should('have.length', 5);
    });

    it('should click the second tab and display the panel', () => {
      cy.get('#second-title').click();
      cy.findByText('First Name').should('be.visible');
    });
  });
});
