describe('beacon: Badge component', () => {
  describe('Badge Types', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-notifications-badges--error-badge');
      cy.injectAxe();
    });

    it('should render badge types', () => {
      cy.get('.react-beacon-label').should('exist').checkAccessibility();
    });
  });
});
