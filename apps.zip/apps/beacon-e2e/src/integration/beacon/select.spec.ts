describe('beacon: Select component', () => {
  describe('Basic Select', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-form-controls-dropdowns-single-select--select-basic');
      cy.injectAxe();
    });

    it('should render a basic select', () => {
      cy.get('.dropdown').should('exist').checkAccessibility();
    });
  });
});
