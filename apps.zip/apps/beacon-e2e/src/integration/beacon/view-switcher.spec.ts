describe('beacon: View Switcher component', () => {
  describe('Primary View Switcher', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-navigation-view-switcher--primary-view-switcher-navigation');
      cy.injectAxe();
    });

    it('should render view switcher options', () => {
      cy.get('.toggle').should('exist').checkAccessibility();
      cy.get('.toggle-option').should('have.length', 3).checkAccessibility();
    });
  });
});
