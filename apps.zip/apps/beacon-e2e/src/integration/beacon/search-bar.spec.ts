describe('beacon: Search Bar component', () => {
  describe('Basic Search Bar', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-form-controls-search-bar--example');
      cy.injectAxe();
    });

    it('should render a basic search bar', () => {
      cy.get('.beacon-search-bar').should('exist').checkAccessibility();
    });
  });
});
