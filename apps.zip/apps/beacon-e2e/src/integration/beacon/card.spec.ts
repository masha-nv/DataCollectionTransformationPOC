describe('beacon: Card component', () => {
  describe('Basic Card', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-cards--basic-example');
      cy.injectAxe();
    });
    it('should render a basic card', () => {
      cy.get('.card-body').should('exist').checkAccessibility();
    });
  });

  describe('Card with Title', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-cards--white-card-with-title');
      cy.injectAxe();
    });
    it('should render a card with title', () => {
      cy.get('.card-body > h2').should('exist').checkAccessibility();
      cy.get('.card-body').should('exist').checkAccessibility();
    });
  });

  describe('Card with Footer', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-cards--footer-example');
      cy.injectAxe();
    });
    it('should render a card with footer', () => {
      cy.get('.card-body').should('exist').checkAccessibility();
      cy.get('.card-footer').should('exist').checkAccessibility();
    });
  });

  describe('Card with Variant', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-cards--variant-example');
      cy.injectAxe();
    });
    it('should render a card with variant', () => {
      cy.get('.card-body').should('exist').checkAccessibility();
      cy.get('.card-gray').should('exist').checkAccessibility();
    });
  });
});
