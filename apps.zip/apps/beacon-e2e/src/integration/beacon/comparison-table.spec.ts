describe('beacon: Comparison Table component', () => {
  describe('Default Table', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-tables-comparison-table--default');
      cy.injectAxe();
    });

    it('should render a comparison table with data', () => {
      cy.get('.comparison-table').should('exist').checkAccessibility();
      cy.get('.comparison-table > tbody > tr').should('have.length', 5).checkAccessibility();
    });
  });
});
