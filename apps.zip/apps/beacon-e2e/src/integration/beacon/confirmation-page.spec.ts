describe('beacon: Confirmation Page component', () => {
  describe('Basic Confirmation Page', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-notifications-confirmation-pages--error-confirmation-page');
      cy.injectAxe();
    });

    it('should render a basic confirmation page', () => {
      cy.get('.page-level-alert').should('exist').checkAccessibility();
    });
  });
});
