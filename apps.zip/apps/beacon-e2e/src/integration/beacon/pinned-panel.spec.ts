describe('beacon: Pinned Panel component', () => {
  describe('Primary Pinned Panel', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-accordions-pinned-panel--primary-pinned-panel');
      cy.injectAxe();
    });

    it('should render pinned panel tabs', () => {
      cy.get('.accordion-tab').should('have.length', 3).checkAccessibility();
    });

    it('should render the body when header is clicked', () => {
      cy.get('#panel-medical-records-panel-title').click();
      cy.findByText("But don't get carried away!").should('be.visible').checkAccessibility();
    });
  });
  describe('Button Pinned Panel', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-accordions-pinned-panel--button-pinned-panel');
      cy.injectAxe();
    });

    it('should render pinned panel tabs', () => {
      cy.findByText('Open Comments and Testimony').should('be.visible').checkAccessibility();
    });

    it('should render the body when header is clicked', () => {
      cy.findByText('Open Comments (Disabled)').should('be.visible').checkAccessibility();
    });
  });
});
