describe('beacon: Spinner component', () => {
  describe('Spinner', () => {
    beforeEach(() => {
      cy.visit(
        '/iframe.html?id=core-components-notifications-progress-indicator--indeterminate-progress-indicator-example'
      );
      cy.injectAxe();
    });

    it('should render indeterminate progress indicator', () => {
      cy.get('.indeterminate-progress-indicator-sprite').should('exist').checkAccessibility();
    });
  });
});
