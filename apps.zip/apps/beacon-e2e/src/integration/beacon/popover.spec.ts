describe('beacon: Popover component', () => {
  describe('Basic Popover', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-modal-popover-and-tooltip-popover--basic-example');
      cy.injectAxe();
    });

    it('should render a basic popover when button clicked', () => {
      cy.get('#basic-beacon-button').click();
      cy.get('.beacon-popover').should('exist').checkAccessibility();
    });
  });
});
