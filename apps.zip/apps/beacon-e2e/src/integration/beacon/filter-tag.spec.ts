describe('beacon: Filter Tag component', () => {
  describe('Primary Filter Tag', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-filter-tag--primary');
      cy.injectAxe();
    });

    it('should render the component', () => {
      cy.findByText('Filter 1').should('be.visible').checkAccessibility();
    });
  });
});
