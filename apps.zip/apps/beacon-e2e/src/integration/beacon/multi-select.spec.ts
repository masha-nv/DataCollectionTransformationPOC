describe('beacon: Multi-Select component', () => {
  describe('Basic Multi-Select', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-form-controls-dropdowns-multi-select--multi-select-basic');
      cy.injectAxe();
    });

    it('should render a basic multi-select', () => {
      cy.get('.beacon-multi-select').should('exist').checkAccessibility();
    });
  });
});
