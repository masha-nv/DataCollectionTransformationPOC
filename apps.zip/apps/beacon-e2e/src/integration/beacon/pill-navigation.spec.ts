describe('beacon: Pill Navigation component', () => {
  describe('Basic Pill Navigation', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-navigation-pill-navigation--basic-pill-navigation');
      cy.injectAxe();
    });

    it('should render basic pill navigation', () => {
      cy.get('.nav').should('exist').checkAccessibility();
      cy.get('.nav-item').should('have.length', 2).checkAccessibility();
    });
  });
});
