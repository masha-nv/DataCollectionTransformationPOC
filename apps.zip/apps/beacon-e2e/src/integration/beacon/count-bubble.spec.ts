describe('beacon: Count Bubble component', () => {
  describe('Basic Count Bubble', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-notifications-count-bubble--basic-example');
      cy.injectAxe();
    });

    it('should render a basic count bubble', () => {
      cy.get('.label-count-bubble').should('exist').checkAccessibility();
    });
  });
});
