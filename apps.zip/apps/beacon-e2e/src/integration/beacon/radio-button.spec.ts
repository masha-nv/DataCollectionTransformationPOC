describe('beacon: Radio Button component', () => {
  describe('Basic Radio Button List', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-form-controls-radio-buttons--example');
      cy.injectAxe();
    });

    it('should render a basic radio button list', () => {
      cy.get('.custom-radio').should('have.length', 2).checkAccessibility();
    });
  });
});
