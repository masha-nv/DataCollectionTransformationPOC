describe('beacon: Modal component', () => {
  describe('Modal Sizes', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-modal-popover-and-tooltip-modal--modal-sizes');

      cy.injectAxe();
    });

    it('should render a small modal when button clicked', () => {
      cy.get('#btn-sm').click();
      cy.get('.modal-root-sm').should('exist').checkAccessibility();
    });

    it('should render a medium modal when button clicked', () => {
      cy.get('#btn-md').click();
      cy.get('.modal-root-md').should('exist').checkAccessibility();
    });

    it('should render a large modal when button clicked', () => {
      cy.get('#btn-lg').click();
      cy.get('.modal-root-lg').should('exist').checkAccessibility();
    });

    it('should render an XL modal when button clicked', () => {
      cy.get('#btn-xl').click();
      cy.get('.modal-root-xl').should('exist').checkAccessibility();
    });
  });
});
