describe('beacon: Checkbox component', () => {
  describe('Basic Checkbox', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-form-controls-checkboxes--basic-example');
      cy.injectAxe();
    });

    it('should render a basic checkbox', () => {
      cy.get('.beacon-checkbox').should('exist').checkAccessibility();
    });
  });

  describe('Basic Checkbox List', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-form-controls-checkboxes--basic-checkbox-list');
      cy.injectAxe();
    });

    it('should render a basic checkbox list', () => {
      cy.get('.beacon-checkbox').should('have.length', 2).checkAccessibility();
    });
  });
});
