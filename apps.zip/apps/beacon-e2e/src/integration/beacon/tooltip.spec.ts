describe('beacon: Tooltip component', () => {
  describe('Basic Tooltip', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-modal-popover-and-tooltip-tooltip--basic-example');
      cy.injectAxe();
    });

    it('should render a basic tooltip on button focus', () => {
      cy.get('#basic-beacon-button').focus();
      cy.get('.beacon-tooltip').should('exist').checkAccessibility();
    });
  });
});
