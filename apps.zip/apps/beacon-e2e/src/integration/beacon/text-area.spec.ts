describe('beacon: Text Area component', () => {
  describe('Basic Text Area', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-form-controls-text-area--example');
      cy.injectAxe();
    });

    it('should render a basic text area', () => {
      cy.get('.form-control').should('exist').checkAccessibility();
    });
  });
});
