describe('beacon: ActionMenu component', () => {
  describe('Basic Action Menu', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-action-menus--basic-example');
      cy.injectAxe();
    });

    it('should render the component', () => {
      cy.findByText('Actions').should('be.visible').checkAccessibility();
    });

    it('should render the menu when clicked', () => {
      cy.findByText('Actions').click();
      cy.findByText('Open').should('be.visible').closest('div').checkAccessibility();
    });
  });

  describe('Action Menu Type', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-action-menus--type-example');
      cy.injectAxe();
    });

    it('should render the primary type component', () => {
      cy.findByText('Primary Type').should('be.visible').checkAccessibility();
    });

    it('should render the menu when primary type clicked', () => {
      cy.findByText('Primary Type').click();
      cy.findByText('Open').should('be.visible').closest('div').checkAccessibility();
    });

    it('should render the secondary type component', () => {
      cy.findByText('Secondary Type').should('be.visible').checkAccessibility();
    });

    it('should render the menu when secondary type clicked', () => {
      cy.findByText('Secondary Type').click();
      cy.findByText('One').should('be.visible').closest('div').checkAccessibility();
    });
  });

  describe('Action Menu Separator', () => {
    beforeEach(() => {
      cy.visit('iframe.html?id=core-components-action-menus--separator-example');
      cy.injectAxe();
    });

    it('should render the component', () => {
      cy.findByText('Actions').should('be.visible').checkAccessibility();
    });

    it('should render the menu when clicked', () => {
      cy.findByText('Actions').click();
      cy.findByText('Open').should('be.visible').closest('div').checkAccessibility();
    });
  });

  describe('Disable Action Menu', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-action-menus--disabled-example');
      cy.injectAxe();
    });

    it('should render the component', () => {
      cy.findByText('Actions').should('be.visible').checkAccessibility();
    });

    it('should render the menu when clicked', () => {
      cy.findByText('Actions').click();
      cy.findByText('Open').should('be.visible').closest('div').checkAccessibility();
    });
  });

  describe('Basic Action Sub Menu', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-action-menus--sub-menu-example');
      cy.injectAxe();
    });

    it('should render the component', () => {
      cy.findByText('Actions').click();
      cy.findAllByText('Sub Menu').eq(1).should('be.visible').checkAccessibility();
    });

    it('should render the menu when clicked', () => {
      cy.findByText('Actions').click();
      cy.findAllByText('Sub Menu').eq(1).click();
      cy.findByText('Sub Menu Quit').should('be.visible').closest('div').checkAccessibility();
    });

    it('should render the disabled component', () => {
      cy.findByText('Disabled Actions').click();
      cy.findByText('Sub Menu disabled').should('be.visible').checkAccessibility();
    });
  });
});
