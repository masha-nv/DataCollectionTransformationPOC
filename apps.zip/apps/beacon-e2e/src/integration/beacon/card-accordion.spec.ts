describe('beacon: Card Accordion component', () => {
  describe('Primary Left Right', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-accordions-card-accordion--card-accordion-primary');

      cy.injectAxe();
    });

    it('should render card accordion tabs', () => {
      cy.get('.accordion-tab').should('have.length', 3).checkAccessibility();
    });

    it('should render the body when header is clicked', () => {
      cy.get('#accordion-0-button').click();
      cy.findByText('This query resulted in 5 TECS/NCIC matches.').should('be.visible').checkAccessibility();
    });
  });
});
