describe('beacon: Required Field Legend component', () => {
  describe('Basic Required Field Legend', () => {
    beforeEach(() => {
      cy.visit('/iframe.html?id=core-components-form-controls-required-field-legend--example');
      cy.injectAxe();
    });

    it('should render a basic required field legend', () => {
      cy.get('.form-required-instructions').should('exist').checkAccessibility();
    });
  });
});
