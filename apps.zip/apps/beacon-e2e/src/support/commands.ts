// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
import { Result } from 'axe-core';
import '@testing-library/cypress/add-commands';
import { Options } from 'cypress-axe';

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Cypress {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    interface Chainable<Subject> {
      checkAccessibility(skipFailures?: boolean): void;
      checkRteAccessibility(skipFailures?: boolean): void;
      checkStorybookStory(): void;
    }
  }
}

// Print cypress-axe violations to the terminal
const printAccessibilityViolations = (violations: Result[]) => {
  const violationData = violations.map(({ id, impact, description, help, helpUrl, nodes }) => ({
    id,
    impact,
    description,
    help,
    helpUrl,
    html: nodes.map((node: { html: string }) => node.html),
    failureSummary: nodes.map((node: { failureSummary?: string }) => node.failureSummary),
  }));
  cy.task('log', `Accessibility validations: ${violations.length}`);
  cy.task('log', violationData);
};

// Checks standard A11y accessibility and prints violations to the console
Cypress.Commands.add(
  'checkAccessibility',
  {
    prevSubject: 'optional',
  },
  (subject, { skipFailures = false } = {}) => {
    cy.checkA11y(
      subject,
      {
        rules: {
          'nested-interactive': {
            enabled: false,
          },
        },
      } as Options,
      printAccessibilityViolations,
      skipFailures
    );
  }
);

Cypress.Commands.add('checkStorybookStory', () => {
  cy.findAllByText('When to use').click();
  cy.findAllByText('508 considerations').click();
  cy.findAllByText('Language Guidelines').click();
  cy.get('div#root').checkAccessibility();
});
