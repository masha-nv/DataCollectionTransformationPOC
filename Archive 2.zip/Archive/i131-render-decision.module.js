var app = angular.module('i131RenderDecision', []);
var pathRoot = 'internal/I131/render-decision/';

app.constant('I131_RD_PATHS', {
	'ROOT': pathRoot,
	'RENDER_DECISION_PATH': pathRoot + 'i131-render-decision.view.html',
	'I131F_RENDER_DECISION_PATH': pathRoot + 'i131F-render-decision.view.html',
	'I131F_RENDER_DECISION_APPROVAL_INFO_PATH': pathRoot + 'i131F-render-decision-approval-info.view.html',
	'I131F_PROVISIONAL_RENDER_DECISION_PATH': pathRoot + 'i131F-render-decision-provisional.view.html',
	'DECISION_NOTES': pathRoot + 'i131-render-decision-notes.view.html'
});

app.constant('VACCINATION_STATUS_CODES', {
	'MMR_VACCINE': 494,
	'POLIO_VACCINE': 495,
	'COVID19_VACCINE_1D': 496,
	'COVID19_VACCINE_S': 497,
	'OTHER_VACCINE': 498,
	'TUBERCULOSIS_SCREENING': 499
});